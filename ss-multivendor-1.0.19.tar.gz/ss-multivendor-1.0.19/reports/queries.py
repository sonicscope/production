"""
SonicScope Report Queries
=========================
All SQL used by the report engine lives here.

Design rules:
  - Summary sections always query the daily_* aggregates (fast, tiny)
  - Detail/drill-down sections query fw_events with mandatory tenant_id +
    time range filters (index-backed, fast even on large tables)
  - Every query is a plain function returning a list of dicts via psycopg2
  - No query does a full table scan
"""

from __future__ import annotations
from datetime import datetime
from typing import Any


# Maps app_category values to a productivity tier.
# Used when web_category is NULL (IPFIX-only deployments).
# Once syslog flows, web_category will provide finer-grained classification.
PRODUCTIVITY_MAP: dict[str, str] = {
    'Business': 'productive',
    'Email': 'productive',
    'Remote Access': 'productive',
    'Streaming': 'unproductive',
    'General Internet': 'unproductive',
    'Social Media': 'unproductive',
    'Gaming': 'unacceptable',
    'Proxy': 'unacceptable',
    'Peer to Peer': 'unacceptable',
}
# app_category values not in PRODUCTIVITY_MAP are treated as 'neutral'

# web_category values that indicate unacceptable content (used for clean-mode redaction)
SENSITIVE_WEB_CATEGORIES: frozenset[str] = frozenset({
    'Adult/Mature Content', 'Pornography', 'Nudity', 'Sexual Expression',
    'Explicit Sexual Content', 'Dating/Personals', 'Gambling', 'Weapons',
    'Violence/Hate/Racism', 'Illegal Downloads', 'Illegal Drugs', 'Hacking',
    'Adult', 'Sex Education', 'Nudism',
})


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _rows(cursor) -> list[dict]:
    """Return all rows as a list of dicts."""
    cols = [d[0] for d in cursor.description]
    return [dict(zip(cols, row)) for row in cursor.fetchall()]


# ── Identity resolution ───────────────────────────────────────────────────────
# Report-time fallback: when user_name is NULL (IPFIX-only flows, or flows
# collected before the mapping was added), look up src_ip in identity_devices.
# Returns the user's full_name, then device label, then hostname — whichever is
# set first.  Falls back to host(src_ip) if nothing matches.
#
# Two variants:
#   'agg'    — for daily_user_traffic aggregate rows (no per-event timestamp,
#              so we only match currently-active devices: valid_to IS NULL)
#   'events' — for fw_events rows (uses the event's own timestamp to match
#              historical DHCP leases correctly)
#
# When identity_enabled=False the expression is just host(src_ip) — no JOIN,
# no names, raw IPs only (privacy / compliance mode).

_IDENTITY_SUBQ_AGG = """(
        SELECT COALESCE(iu.full_name, id.label, id.hostname)
        FROM   identity_devices id
        LEFT JOIN identity_users iu
               ON iu.id = id.user_id AND iu.active = true
        WHERE  id.tenant_id = %(tenant_id)s
          AND  id.ip_address >>= src_ip
          AND  id.valid_to IS NULL
        ORDER BY masklen(id.ip_address) DESC
        LIMIT  1
    )"""

_IDENTITY_SUBQ_EVENTS = """(
        SELECT COALESCE(iu.full_name, id.label, id.hostname)
        FROM   identity_devices id
        LEFT JOIN identity_users iu
               ON iu.id = id.user_id AND iu.active = true
        WHERE  id.tenant_id = %(tenant_id)s
          AND  id.ip_address >>= src_ip
          AND  (id.valid_to IS NULL OR id.valid_to > time)
        ORDER BY masklen(id.ip_address) DESC
        LIMIT  1
    )"""


def _user_label_expr(source: str, identity_enabled: bool) -> str:
    """Return a SQL expression for the user_label SELECT column.

    source: 'agg' for daily_user_traffic, 'events' for fw_events.
    """
    if not identity_enabled:
        return "host(src_ip)"
    subq = _IDENTITY_SUBQ_EVENTS if source == 'events' else _IDENTITY_SUBQ_AGG
    return f"COALESCE(user_name, {subq}, host(src_ip))"


# ─────────────────────────────────────────────────────────────────────────────
# Executive Summary
# ─────────────────────────────────────────────────────────────────────────────

EXEC_SUMMARY_SQL = """
SELECT
    SUM(bytes_total)        AS total_bytes,
    SUM(connection_count)   AS total_connections,
    SUM(allowed_count)      AS total_allowed,
    SUM(denied_count)       AS total_denied,
    COUNT(DISTINCT src_ip)  AS unique_ips
FROM daily_user_traffic
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
"""

THREAT_SUMMARY_SQL = """
SELECT
    SUM(event_count)        AS total_threats,
    COUNT(DISTINCT threat_category) AS unique_threat_types
FROM daily_threat_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
"""

def get_executive_summary(cur, tenant_id: int,
                          start: datetime, end: datetime) -> dict:
    cur.execute(EXEC_SUMMARY_SQL, {'tenant_id': tenant_id, 'start': start, 'end': end})
    row = cur.fetchone()
    traffic = dict(zip([d[0] for d in cur.description], row)) if row else {}

    cur.execute(THREAT_SUMMARY_SQL, {'tenant_id': tenant_id, 'start': start, 'end': end})
    row = cur.fetchone()
    threats = dict(zip([d[0] for d in cur.description], row)) if row else {}

    return {**traffic, **threats}


# ─────────────────────────────────────────────────────────────────────────────
# Bandwidth Timeline  (hourly for short periods, daily for monthly reports)
# ─────────────────────────────────────────────────────────────────────────────

BANDWIDTH_HOURLY_SQL = """
SELECT
    bucket,
    SUM(bytes_sent)      AS bytes_sent,
    SUM(bytes_received)  AS bytes_received,
    SUM(bytes_total)     AS bytes_total
FROM hourly_bandwidth_timeline
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY bucket
ORDER BY bucket
"""

BANDWIDTH_DAILY_SQL = """
SELECT
    time_bucket('1 day', bucket) AS bucket,
    SUM(bytes_sent)      AS bytes_sent,
    SUM(bytes_received)  AS bytes_received,
    SUM(bytes_total)     AS bytes_total
FROM hourly_bandwidth_timeline
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY 1
ORDER BY 1
"""

def get_bandwidth_timeline(cur, tenant_id: int,
                           start: datetime, end: datetime,
                           resolution: str = 'daily') -> list[dict]:
    sql = BANDWIDTH_HOURLY_SQL if resolution == 'hourly' else BANDWIDTH_DAILY_SQL
    cur.execute(sql, {'tenant_id': tenant_id, 'start': start, 'end': end})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Top Users by Bandwidth
# ─────────────────────────────────────────────────────────────────────────────

def get_top_users(cur, tenant_id: int,
                  start: datetime, end: datetime,
                  limit: int = 10,
                  identity_enabled: bool = True) -> list[dict]:
    sql = f"""
SELECT
    {_user_label_expr('agg', identity_enabled)}  AS user_label,
    device_name,
    department,
    src_ip,
    SUM(bytes_total)                    AS bytes_total,
    SUM(bytes_sent)                     AS bytes_sent,
    SUM(bytes_received)                 AS bytes_received,
    SUM(connection_count)               AS connections,
    SUM(allowed_count)                  AS allowed,
    SUM(denied_count)                   AS denied
FROM daily_user_traffic
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY user_label, device_name, department, src_ip
ORDER BY bytes_total DESC
LIMIT %(limit)s
"""
    cur.execute(sql, {'tenant_id': tenant_id, 'start': start,
                      'end': end, 'limit': limit})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Top Applications
# ─────────────────────────────────────────────────────────────────────────────

TOP_APPS_SQL = """
SELECT
    app_name,
    app_category,
    app_risk,
    SUM(bytes_total)    AS bytes_total,
    SUM(session_count)  AS sessions
FROM daily_app_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY app_name, app_category, app_risk
ORDER BY bytes_total DESC
LIMIT %(limit)s
"""

def get_top_apps(cur, tenant_id: int,
                 start: datetime, end: datetime,
                 limit: int = 20) -> list[dict]:
    cur.execute(TOP_APPS_SQL, {'tenant_id': tenant_id, 'start': start,
                               'end': end, 'limit': limit})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Web Category Breakdown
# ─────────────────────────────────────────────────────────────────────────────

WEB_CATEGORIES_SQL = """
SELECT
    web_category,
    action,
    SUM(request_count)  AS requests,
    SUM(bytes_total)    AS bytes_total
FROM daily_web_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY web_category, action
ORDER BY bytes_total DESC
"""

def get_web_categories(cur, tenant_id: int,
                       start: datetime, end: datetime) -> list[dict]:
    cur.execute(WEB_CATEGORIES_SQL, {'tenant_id': tenant_id,
                                     'start': start, 'end': end})
    return _rows(cur)


PRODUCTIVITY_SQL = """
SELECT
    app_category,
    SUM(bytes_total)    AS bytes_total,
    SUM(session_count)  AS sessions
FROM daily_app_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY app_category
ORDER BY bytes_total DESC
"""

def get_productivity_breakdown(cur, tenant_id: int,
                               start: datetime, end: datetime) -> list[dict]:
    cur.execute(PRODUCTIVITY_SQL, {'tenant_id': tenant_id, 'start': start, 'end': end})
    rows = _rows(cur)
    for row in rows:
        row['tier'] = PRODUCTIVITY_MAP.get(row['app_category'] or '', 'neutral')
    return rows


# ─────────────────────────────────────────────────────────────────────────────
# Department Bandwidth Breakdown  (queries daily_user_traffic aggregate)
# ─────────────────────────────────────────────────────────────────────────────

DEPARTMENT_BREAKDOWN_SQL = """
SELECT
    COALESCE(department, 'Unassigned')  AS department,
    COUNT(DISTINCT src_ip)              AS users,
    SUM(bytes_total)                    AS bytes_total,
    SUM(bytes_sent)                     AS bytes_sent,
    SUM(bytes_received)                 AS bytes_received,
    SUM(connection_count)               AS connections
FROM daily_user_traffic
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY department
ORDER BY bytes_total DESC
"""

def get_department_breakdown(cur, tenant_id: int,
                             start: datetime, end: datetime) -> list[dict]:
    cur.execute(DEPARTMENT_BREAKDOWN_SQL,
                {'tenant_id': tenant_id, 'start': start, 'end': end})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Group Bandwidth Breakdown  (queries fw_events directly — group_name not yet
# in continuous aggregates)
# ─────────────────────────────────────────────────────────────────────────────

GROUP_BREAKDOWN_SQL = """
SELECT
    COALESCE(group_name, 'Unassigned')  AS group_name,
    COALESCE(department, 'Unassigned')  AS department,
    COUNT(DISTINCT src_ip)              AS users,
    SUM(bytes_sent)                     AS bytes_sent,
    SUM(bytes_received)                 AS bytes_received,
    SUM(bytes_sent + bytes_received)    AS bytes_total,
    COUNT(*)                            AS connections
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
GROUP BY group_name, department
ORDER BY bytes_total DESC
"""

def get_group_breakdown(cur, tenant_id: int,
                        start: datetime, end: datetime) -> list[dict]:
    cur.execute(GROUP_BREAKDOWN_SQL,
                {'tenant_id': tenant_id, 'start': start, 'end': end})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Top Sites / Domains
# ─────────────────────────────────────────────────────────────────────────────

TOP_DOMAINS_SQL = """
SELECT
    domain,
    web_category,
    action,
    SUM(request_count)  AS requests,
    SUM(bytes_total)    AS bytes_total
FROM daily_domain_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY domain, web_category, action
ORDER BY bytes_total DESC
LIMIT %(limit)s
"""

def get_top_domains(cur, tenant_id: int,
                    start: datetime, end: datetime,
                    limit: int = 20) -> list[dict]:
    cur.execute(TOP_DOMAINS_SQL, {'tenant_id': tenant_id, 'start': start,
                                  'end': end, 'limit': limit})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Threats
# ─────────────────────────────────────────────────────────────────────────────

THREAT_BREAKDOWN_SQL = """
SELECT
    threat_category,
    threat_severity,
    SUM(event_count)    AS events
FROM daily_threat_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY threat_category, threat_severity
ORDER BY events DESC
"""

def get_threat_breakdown(cur, tenant_id: int,
                         start: datetime, end: datetime) -> list[dict]:
    cur.execute(THREAT_BREAKDOWN_SQL, {'tenant_id': tenant_id,
                                       'start': start, 'end': end})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Firewall Rule Activity
# ─────────────────────────────────────────────────────────────────────────────

RULE_ACTIVITY_SQL = """
SELECT
    rule_name,
    action,
    SUM(hit_count)      AS hits,
    SUM(bytes_total)    AS bytes_total
FROM daily_rule_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY rule_name, action
ORDER BY hits DESC
LIMIT %(limit)s
"""

def get_rule_activity(cur, tenant_id: int,
                      start: datetime, end: datetime,
                      limit: int = 20) -> list[dict]:
    cur.execute(RULE_ACTIVITY_SQL, {'tenant_id': tenant_id, 'start': start,
                                    'end': end, 'limit': limit})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# Geographic Traffic
# ─────────────────────────────────────────────────────────────────────────────

GEO_STATS_SQL = """
SELECT
    geo_dst_country,
    geo_dst_country_code,
    action,
    SUM(connection_count)   AS connections,
    SUM(bytes_total)        AS bytes_total
FROM daily_geo_stats
WHERE tenant_id  = %(tenant_id)s
  AND bucket    >= %(start)s
  AND bucket     < %(end)s
GROUP BY geo_dst_country, geo_dst_country_code, action
ORDER BY bytes_total DESC
"""

def get_geo_stats(cur, tenant_id: int,
                  start: datetime, end: datetime) -> list[dict]:
    cur.execute(GEO_STATS_SQL, {'tenant_id': tenant_id,
                                'start': start, 'end': end})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# VPN Activity
# ─────────────────────────────────────────────────────────────────────────────

def get_vpn_activity(cur, tenant_id: int,
                     start: datetime, end: datetime,
                     identity_enabled: bool = True) -> list[dict]:
    sql = f"""
SELECT
    {_user_label_expr('events', identity_enabled)} AS user_label,
    vpn_policy_name,
    COUNT(*)                    AS sessions,
    SUM(bytes_sent)             AS bytes_sent,
    SUM(bytes_received)         AS bytes_received,
    MIN(time)                   AS first_seen,
    MAX(time)                   AS last_seen
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND event_type = 'vpn'
GROUP BY user_label, vpn_policy_name
ORDER BY sessions DESC
"""
    cur.execute(sql, {'tenant_id': tenant_id, 'start': start, 'end': end})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# HR Investigation — User Summary
# ─────────────────────────────────────────────────────────────────────────────

def get_hr_user_summary(cur, tenant_id: int,
                        start: datetime, end: datetime,
                        user_name: str,
                        identity_enabled: bool = True) -> dict | None:
    sql = f"""
SELECT
    {_user_label_expr('events', identity_enabled)}  AS user_label,
    device_name,
    department,
    src_ip,
    SUM(bytes_sent)                     AS bytes_sent,
    SUM(bytes_received)                 AS bytes_received,
    SUM(bytes_sent + bytes_received)    AS bytes_total,
    COUNT(*)                            AS total_events,
    SUM(CASE WHEN action = 'allow'                 THEN 1 ELSE 0 END) AS allowed_events,
    SUM(CASE WHEN action IN ('deny','drop','reset') THEN 1 ELSE 0 END) AS blocked_events,
    MIN(time)                           AS first_activity,
    MAX(time)                           AS last_activity,
    COUNT(DISTINCT domain)              AS unique_domains
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND (user_name = %(user_name)s OR host(src_ip) = %(user_name)s)
GROUP BY user_label, device_name, department, src_ip
"""
    cur.execute(sql, {'tenant_id': tenant_id, 'start': start,
                      'end': end, 'user_name': user_name})
    row = cur.fetchone()
    if not row:
        return None
    return dict(zip([d[0] for d in cur.description], row))


# ─────────────────────────────────────────────────────────────────────────────
# HR Investigation — Full Activity Timeline
# Queries fw_events directly (raw data), but is index-backed via
# the (tenant_id, user_name, time DESC) index.
# ─────────────────────────────────────────────────────────────────────────────

HR_TIMELINE_SQL = """
SELECT
    time,
    action,
    dst_ip,
    dst_port,
    protocol,
    domain,
    url,
    web_category,
    app_name,
    bytes_sent,
    bytes_received,
    bytes_sent + bytes_received     AS bytes_total,
    duration_ms,
    rule_name,
    threat_name,
    message
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND (user_name = %(user_name)s OR host(src_ip) = %(user_name)s)
ORDER BY time ASC
LIMIT %(limit)s
"""

# Cap timeline rows to prevent OOM on high-volume hosts.
# WeasyPrint loads all rows as DOM before layout; 5,000 rows ≈ 150-300 KB HTML,
# manageable in ~500 MB. For a typical office user (200-500 events/day) this
# covers 10-25 days. Narrow the date range to get more detail.
HR_TIMELINE_LIMIT = 5_000

def get_hr_timeline(cur, tenant_id: int,
                    start: datetime, end: datetime,
                    user_name: str,
                    limit: int = HR_TIMELINE_LIMIT) -> list[dict]:
    cur.execute(HR_TIMELINE_SQL, {'tenant_id': tenant_id, 'start': start,
                                  'end': end, 'user_name': user_name,
                                  'limit': limit})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# HR Investigation — Top Sites for User
# ─────────────────────────────────────────────────────────────────────────────

HR_TOP_SITES_SQL = """
SELECT
    domain,
    web_category,
    app_category,
    action,
    COUNT(*)                            AS visits,
    SUM(bytes_sent)                     AS bytes_sent,
    SUM(bytes_received)                 AS bytes_received,
    SUM(bytes_sent + bytes_received)    AS bytes_total,
    SUM(duration_ms)                    AS total_duration_ms,
    MIN(time)                           AS first_visit,
    MAX(time)                           AS last_visit
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND (user_name = %(user_name)s OR host(src_ip) = %(user_name)s)
  AND domain IS NOT NULL
GROUP BY domain, web_category, app_category, action
ORDER BY visits DESC
LIMIT %(limit)s
"""

def get_hr_top_sites(cur, tenant_id: int,
                     start: datetime, end: datetime,
                     user_name: str, limit: int = 50) -> list[dict]:
    cur.execute(HR_TOP_SITES_SQL, {'tenant_id': tenant_id, 'start': start,
                                   'end': end, 'user_name': user_name,
                                   'limit': limit})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# HR Investigation — Blocked Attempts for User
# ─────────────────────────────────────────────────────────────────────────────

HR_BLOCKED_SQL = """
SELECT
    time,
    dst_ip,
    domain,
    url,
    web_category,
    app_name,
    dst_port,
    protocol,
    rule_name,
    message
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND (user_name = %(user_name)s OR host(src_ip) = %(user_name)s)
  AND action IN ('deny', 'drop', 'reset')
ORDER BY time ASC
"""

def get_hr_blocked(cur, tenant_id: int,
                   start: datetime, end: datetime,
                   user_name: str) -> list[dict]:
    cur.execute(HR_BLOCKED_SQL, {'tenant_id': tenant_id, 'start': start,
                                 'end': end, 'user_name': user_name})
    return _rows(cur)


# ─────────────────────────────────────────────────────────────────────────────
# HR Investigation — Web Category Breakdown for User
# ─────────────────────────────────────────────────────────────────────────────

HR_CATEGORIES_SQL = """
SELECT
    web_category,
    action,
    COUNT(*)                            AS requests,
    SUM(bytes_sent + bytes_received)    AS bytes_total,
    SUM(duration_ms)                    AS total_duration_ms
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND (user_name = %(user_name)s OR host(src_ip) = %(user_name)s)
  AND web_category IS NOT NULL
GROUP BY web_category, action
ORDER BY requests DESC
"""

def get_hr_categories(cur, tenant_id: int,
                      start: datetime, end: datetime,
                      user_name: str) -> list[dict]:
    cur.execute(HR_CATEGORIES_SQL, {'tenant_id': tenant_id, 'start': start,
                                    'end': end, 'user_name': user_name})
    return _rows(cur)


HR_APP_BREAKDOWN_SQL = """
SELECT
    app_category,
    action,
    COUNT(*)                            AS events,
    SUM(bytes_sent)                     AS bytes_sent,
    SUM(bytes_received)                 AS bytes_received,
    SUM(bytes_sent + bytes_received)    AS bytes_total
FROM fw_events
WHERE tenant_id  = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND (user_name = %(user_name)s OR host(src_ip) = %(user_name)s)
GROUP BY app_category, action
ORDER BY bytes_total DESC
"""

def get_hr_app_breakdown(cur, tenant_id: int,
                         start: datetime, end: datetime,
                         user_name: str) -> list[dict]:
    cur.execute(HR_APP_BREAKDOWN_SQL, {'tenant_id': tenant_id, 'start': start,
                                       'end': end, 'user_name': user_name})
    rows = _rows(cur)
    for row in rows:
        row['tier'] = PRODUCTIVITY_MAP.get(row['app_category'] or '', 'neutral')
    return rows


# ─────────────────────────────────────────────────────────────────────────────
# Security Report — Blocked Traffic
# ─────────────────────────────────────────────────────────────────────────────

BLOCKED_SITES_SQL = """
SELECT
    COALESCE(domain, host(dst_ip))              AS site,
    COUNT(*)                                    AS block_count,
    COUNT(DISTINCT src_ip)                      AS affected_users,
    SUM(bytes_sent + bytes_received)            AS bytes_total
FROM fw_events
WHERE tenant_id = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND action IN ('deny', 'drop', 'block', 'reset')
  AND (domain IS NOT NULL OR dst_ip IS NOT NULL)
GROUP BY site
ORDER BY block_count DESC
LIMIT %(limit)s
"""

def get_blocked_sites(cur, tenant_id: int,
                      start: datetime, end: datetime,
                      limit: int = 20) -> list[dict]:
    cur.execute(BLOCKED_SITES_SQL, {'tenant_id': tenant_id, 'start': start,
                                    'end': end, 'limit': limit})
    return _rows(cur)


def get_blocked_users(cur, tenant_id: int,
                      start: datetime, end: datetime,
                      limit: int = 20,
                      identity_enabled: bool = True) -> list[dict]:
    sql = f"""
SELECT
    {_user_label_expr('events', identity_enabled)}  AS user_label,
    host(src_ip)                                    AS src_ip,
    COUNT(*)                                        AS block_count,
    COUNT(DISTINCT COALESCE(domain, host(dst_ip)))  AS distinct_sites,
    SUM(bytes_sent + bytes_received)                AS bytes_total
FROM fw_events
WHERE tenant_id = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND action IN ('deny', 'drop', 'block', 'reset')
GROUP BY user_label, src_ip
ORDER BY block_count DESC
LIMIT %(limit)s
"""
    cur.execute(sql, {'tenant_id': tenant_id, 'start': start,
                      'end': end, 'limit': limit})
    return _rows(cur)


TOP_PORTS_SQL = """
SELECT
    dst_port,
    protocol,
    COUNT(*)                                                                   AS connection_count,
    SUM(bytes_sent + bytes_received)                                           AS bytes_total,
    SUM(CASE WHEN action IN ('deny','drop','block','reset') THEN 1 ELSE 0 END) AS blocked_count
FROM fw_events
WHERE tenant_id = %(tenant_id)s
  AND time      >= %(start)s
  AND time       < %(end)s
  AND dst_port IS NOT NULL
  AND dst_port > 0
GROUP BY dst_port, protocol
ORDER BY connection_count DESC
LIMIT %(limit)s
"""

def get_top_ports(cur, tenant_id: int,
                  start: datetime, end: datetime,
                  limit: int = 20) -> list[dict]:
    cur.execute(TOP_PORTS_SQL, {'tenant_id': tenant_id, 'start': start,
                                'end': end, 'limit': limit})
    return _rows(cur)
