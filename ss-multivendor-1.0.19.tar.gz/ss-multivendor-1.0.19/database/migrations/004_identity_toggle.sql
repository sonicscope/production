-- 004_identity_toggle.sql
-- Per-tenant switch: identity_enabled = false → all users shown as raw IPs in reports.
-- Useful for privacy/compliance deployments that must not map IPs to names.
-- Default true preserves existing behaviour for all existing tenants.

ALTER TABLE tenants
    ADD COLUMN IF NOT EXISTS identity_enabled BOOLEAN NOT NULL DEFAULT true;
