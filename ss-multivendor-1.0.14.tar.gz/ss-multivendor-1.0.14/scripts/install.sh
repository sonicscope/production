#!/bin/bash
# SonicScope Multi-Vendor Collector — Installer
# Tested on Ubuntu 22.04 / 24.04 / 26.04 LTS
# Run as root: sudo bash install.sh

set -e

INSTALL_DIR="/opt/ss-multivendor"
CONFIG_DIR="/etc/ss-multivendor"
LOG_DIR="/var/log/ss-multivendor"
GEOIP_DIR="/opt/ss-multivendor/geoip"
SERVICE_USER="ss-collector"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

[ "$(id -u)" -ne 0 ] && error "Must be run as root"

# ── Detect existing SonicScope installs ──────────────────────────────────────
section "Checking existing SonicScope installations"

HAS_FLOW=false; HAS_SYSLOG=false
systemctl is-active --quiet swfr-collector 2>/dev/null   && HAS_FLOW=true
systemctl is-active --quiet syslog-receiver 2>/dev/null  && HAS_SYSLOG=true

if $HAS_FLOW;   then info "SS-FLOW collector detected — will share TimescaleDB"; fi
if $HAS_SYSLOG; then info "SS-SYSLOG receiver detected — will coexist on different ports"; fi

# ── System packages ──────────────────────────────────────────────────────────
section "Installing system packages"
apt-get update -qq
apt-get install -y -qq \
    python3 python3-pip python3-venv \
    postgresql-client \
    openssl curl wget gnupg lsb-release

# ── Install TimescaleDB (if not already installed) ───────────────────────────
section "Checking PostgreSQL + TimescaleDB"

# Detect installed PostgreSQL major version, or install PG16 from PGDG.
# PGDG supports all Ubuntu versions so we can always get PG16 even on 26.04+.
if ! command -v psql &>/dev/null; then
    info "Installing PostgreSQL 16 from PGDG..."
    curl -fsSL https://www.postgresql.org/media/keys/ACCC4CF8.asc \
        | gpg --dearmor -o /usr/share/keyrings/postgresql.gpg
    echo "deb [signed-by=/usr/share/keyrings/postgresql.gpg] \
https://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" \
        > /etc/apt/sources.list.d/pgdg.list
    apt-get update -qq
    apt-get install -y -qq postgresql-16
fi

# Resolve the installed PG major version for package name matching
PG_VER=$(psql --version 2>/dev/null | grep -oP '(?<=PostgreSQL )\d+' | head -1)
PG_VER=${PG_VER:-16}
info "PostgreSQL version: ${PG_VER}"

if ! psql -U postgres -c "SELECT default_version FROM pg_available_extensions WHERE name='timescaledb'" 2>/dev/null | grep -q "[0-9]"; then
    info "Installing TimescaleDB for PostgreSQL ${PG_VER}..."
    curl -fsSL https://packagecloud.io/timescale/timescaledb/gpgkey \
        | gpg --dearmor -o /usr/share/keyrings/timescaledb.gpg

    # packagecloud.io/timescale may not carry packages for Ubuntu releases newer
    # than 24.04 (noble). Binary-compatible noble packages work on later LTS too.
    UBUNTU_MAJOR=$(lsb_release -rs | cut -d. -f1)
    if [[ "$UBUNTU_MAJOR" -ge 26 ]]; then
        TSB_CODENAME="noble"
        info "Using noble (24.04) TimescaleDB packages for Ubuntu ${UBUNTU_MAJOR}.x"
    else
        TSB_CODENAME=$(lsb_release -cs)
    fi

    echo "deb [signed-by=/usr/share/keyrings/timescaledb.gpg] \
https://packagecloud.io/timescale/timescaledb/ubuntu/ ${TSB_CODENAME} main" \
        > /etc/apt/sources.list.d/timescaledb.list
    apt-get update -qq
    apt-get install -y -qq "timescaledb-2-postgresql-${PG_VER}"
    timescaledb-tune --quiet --yes
    systemctl restart postgresql
    info "TimescaleDB installed"
fi

# ── Create DB user and database ──────────────────────────────────────────────
section "Setting up PostgreSQL database"
DB_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=')

if sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='sonicscope'" | grep -q 1; then
    sudo -u postgres psql -c "ALTER USER sonicscope WITH PASSWORD '$DB_PASSWORD';" >/dev/null
    info "DB user 'sonicscope' exists — password synced to collector.env"
else
    sudo -u postgres psql -c "CREATE USER sonicscope WITH PASSWORD '$DB_PASSWORD';" >/dev/null
    info "DB user 'sonicscope' created"
fi

sudo -u postgres psql -tc \
    "SELECT 1 FROM pg_database WHERE datname='sonicscope'" | grep -q 1 || \
    sudo -u postgres psql -c \
    "CREATE DATABASE sonicscope OWNER sonicscope;"

# Copy SQL files to /tmp so the postgres user can read them
# (postgres cannot access files inside /home/netadmin due to directory permissions)
TMP_SCHEMA=$(mktemp /tmp/ss_schema_XXXXXX.sql)
TMP_AGG=$(mktemp /tmp/ss_aggregates_XXXXXX.sql)
TMP_IDENTITY=$(mktemp /tmp/ss_identity_XXXXXX.sql)
TMP_AUTH=$(mktemp /tmp/ss_auth_XXXXXX.sql)
TMP_PASSWORDS=$(mktemp /tmp/ss_passwords_XXXXXX.sql)
TMP_IDENTITY_TOGGLE=$(mktemp /tmp/ss_identity_toggle_XXXXXX.sql)
cp "$REPO_DIR/database/schema.sql"                                  "$TMP_SCHEMA"
cp "$REPO_DIR/database/aggregates.sql"                              "$TMP_AGG"
cp "$REPO_DIR/database/identity_schema.sql"                         "$TMP_IDENTITY"
cp "$REPO_DIR/database/migrations/002_auth.sql"                     "$TMP_AUTH"
cp "$REPO_DIR/database/migrations/003_passwords.sql"                "$TMP_PASSWORDS"
cp "$REPO_DIR/database/migrations/004_identity_toggle.sql"          "$TMP_IDENTITY_TOGGLE"
chmod 644 "$TMP_SCHEMA" "$TMP_AGG" "$TMP_IDENTITY" "$TMP_AUTH" "$TMP_PASSWORDS" "$TMP_IDENTITY_TOGGLE"

info "Creating schema..."
sudo -u postgres psql -d sonicscope -f "$TMP_SCHEMA"
info "Creating aggregates..."
sudo -u postgres psql -d sonicscope -f "$TMP_AGG"
info "Creating identity schema..."
sudo -u postgres psql -d sonicscope -f "$TMP_IDENTITY"
info "Creating auth schema..."
sudo -u postgres psql -d sonicscope -f "$TMP_AUTH"
info "Creating password auth migration..."
sudo -u postgres psql -d sonicscope -f "$TMP_PASSWORDS"
info "Creating identity toggle migration..."
sudo -u postgres psql -d sonicscope -f "$TMP_IDENTITY_TOGGLE"
rm -f "$TMP_SCHEMA" "$TMP_AGG" "$TMP_IDENTITY" "$TMP_AUTH" "$TMP_PASSWORDS" "$TMP_IDENTITY_TOGGLE"
info "Schema created"

# Grant the sonicscope app user access to all tables and sequences
sudo -u postgres psql -d sonicscope -c "
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO sonicscope;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO sonicscope;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO sonicscope;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO sonicscope;
" >/dev/null
info "Database permissions granted"

# ── Service user ─────────────────────────────────────────────────────────────
section "Creating service user"
id -u $SERVICE_USER &>/dev/null || \
    useradd -r -s /usr/sbin/nologin -d $INSTALL_DIR -m $SERVICE_USER
info "Service user: $SERVICE_USER"

# ── Install application ───────────────────────────────────────────────────────
section "Installing collector"
mkdir -p $INSTALL_DIR $CONFIG_DIR/certs $LOG_DIR $GEOIP_DIR

# Python virtual environment
python3 -m venv $INSTALL_DIR/venv
$INSTALL_DIR/venv/bin/pip install -q --upgrade pip
$INSTALL_DIR/venv/bin/pip install -q -r "$REPO_DIR/collector/requirements.txt"

# Copy collector code
cp -r "$REPO_DIR/collector/"* $INSTALL_DIR/

chown -R $SERVICE_USER:$SERVICE_USER $INSTALL_DIR $LOG_DIR $GEOIP_DIR

# ── TLS certificate for syslog ────────────────────────────────────────────────
section "Generating TLS certificate for syslog"
HOSTNAME=$(hostname -f)
openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
    -keyout $CONFIG_DIR/certs/server.key \
    -out    $CONFIG_DIR/certs/server.crt \
    -subj   "/CN=$HOSTNAME" \
    -addext "subjectAltName=IP:$(hostname -I | awk '{print $1}'),DNS:$HOSTNAME" \
    2>/dev/null
cp $CONFIG_DIR/certs/server.crt $CONFIG_DIR/certs/ca.crt
chmod 640 $CONFIG_DIR/certs/server.key
chown -R $SERVICE_USER:$SERVICE_USER $CONFIG_DIR/certs
info "TLS certificate generated: $CONFIG_DIR/certs/server.crt"

# ── Write configuration file ──────────────────────────────────────────────────
section "Writing configuration"

# Helper: run a single psql query and return trimmed output
pg() { sudo -u postgres psql -d sonicscope -tAc "$1" | tr -d ' \n'; }

# MSP profile — insert if not exists, then fetch id
sudo -u postgres psql -d sonicscope -c \
    "INSERT INTO msp_profiles (name) VALUES ('Default MSP') ON CONFLICT DO NOTHING;" >/dev/null
MSP_ID=$(pg "SELECT id FROM msp_profiles ORDER BY id LIMIT 1;")
[ -z "$MSP_ID" ] && error "Could not create msp_profiles row"

# Tenant
sudo -u postgres psql -d sonicscope -c \
    "INSERT INTO tenants (msp_profile_id, name, slug)
     VALUES ($MSP_ID, 'Site 1', 'site-1') ON CONFLICT DO NOTHING;" >/dev/null
TENANT_DB_ID=$(pg "SELECT id FROM tenants WHERE slug='site-1';")
[ -z "$TENANT_DB_ID" ] && error "Could not create tenants row"

# Sensor
sudo -u postgres psql -d sonicscope -c \
    "INSERT INTO sensors (tenant_id, name, vendor, data_sources)
     VALUES ($TENANT_DB_ID, 'SonicWall Firewall', 'sonicwall', '{ipfix,syslog}')
     ON CONFLICT DO NOTHING;" >/dev/null
SENSOR_DB_ID=$(pg "SELECT id FROM sensors WHERE tenant_id=$TENANT_DB_ID ORDER BY id LIMIT 1;")
[ -z "$SENSOR_DB_ID" ] && error "Could not create sensors row"

cat > $CONFIG_DIR/collector.env <<EOF
# SonicScope Multi-Vendor Collector — $(date +%Y-%m-%d)
SS_TENANT_ID=${TENANT_DB_ID:-1}
SS_SENSOR_ID=${SENSOR_DB_ID:-1}

DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=sonicscope
DB_USER=sonicscope
DB_PASSWORD=$DB_PASSWORD

ENABLE_IPFIX=true
IPFIX_LISTEN_IP=0.0.0.0
IPFIX_LISTEN_PORT=2055
IPFIX_ALLOWED_SOURCES=

ENABLE_SYSLOG=true
SYSLOG_LISTEN_IP=0.0.0.0
SYSLOG_UDP_PORT=514
SYSLOG_TCP_PORT=514
SYSLOG_TLS_PORT=6514
SYSLOG_ALLOWED_SOURCES=
SYSLOG_TLS_CERT=/etc/ss-multivendor/certs/server.crt
SYSLOG_TLS_KEY=/etc/ss-multivendor/certs/server.key
SYSLOG_TLS_CA=/etc/ss-multivendor/certs/ca.crt

ENABLE_GEOIP=true
GEOIP_DB_DIR=/opt/ss-multivendor/geoip

ENABLE_DNS=true
DNS_TIMEOUT=1.0

ENABLE_APP_CLASSIFIER=true
ENABLE_THREAT_INTEL=true
THREAT_INTEL_BLOCKLIST=

LOG_DIR=/var/log/ss-multivendor

# SonicScope Licence — paste the block from your licence email here
SONICSCOPE_LICENSE=
SONICSCOPE_PRODUCT=SS-MULTIVENDOR
SONICSCOPE_CUSTOMER_ID=
SONICSCOPE_EXPIRY=
SONICSCOPE_MAX_SENSORS=
EOF

chmod 660 $CONFIG_DIR/collector.env
chown root:$SERVICE_USER $CONFIG_DIR/collector.env

# Allow the ss-reports Flask app (runs as ss-collector) to restart the collector
# when firewall allowlists change — no password required for this one command only
SUDOERS_FILE="/etc/sudoers.d/ss-collector"
echo "ss-collector ALL=(root) NOPASSWD: /usr/bin/systemctl restart ss-collector" \
    > "$SUDOERS_FILE"
chmod 440 "$SUDOERS_FILE"
info "Sudoers rule added: ss-collector can restart ss-collector"
info "Config written to $CONFIG_DIR/collector.env"

# ── systemd service ───────────────────────────────────────────────────────────
section "Installing systemd service"
cat > /etc/systemd/system/ss-collector.service <<EOF
[Unit]
Description=SonicScope Multi-Vendor Collector
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
Environment="SS_ENV=$CONFIG_DIR/collector.env"
ExecStart=$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/main.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-collector

# Allow binding to ports < 1024
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ss-collector
info "Service installed: ss-collector"

# ── UFW rules ─────────────────────────────────────────────────────────────────
if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
    section "Configuring firewall (UFW)"
    ufw allow 2055/udp  comment "SonicScope IPFIX"  >/dev/null
    ufw allow 514/udp   comment "SonicScope Syslog UDP" >/dev/null
    ufw allow 514/tcp   comment "SonicScope Syslog TCP" >/dev/null
    ufw allow 6514/tcp  comment "SonicScope Syslog TLS" >/dev/null
    info "UFW rules added"
fi

# ── Final instructions ────────────────────────────────────────────────────────
echo
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  SonicScope Multi-Vendor Collector installed${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo
echo "  Config:   $CONFIG_DIR/collector.env"
echo "  Logs:     $LOG_DIR/"
echo "  TLS cert: $CONFIG_DIR/certs/ca.crt  (upload to SonicWall for TLS syslog)"
echo
echo "  Before starting:"
echo "  1. Edit $CONFIG_DIR/collector.env"
echo "     — Add SONICSCOPE_LICENSE, SONICSCOPE_CUSTOMER_ID, SONICSCOPE_EXPIRY"
echo "     — Set IPFIX_ALLOWED_SOURCES to your firewall's IP"
echo
echo "  2. Download GeoIP databases (free MaxMind account required):"
echo "     sudo bash $REPO_DIR/scripts/download-geoip.sh <MaxMind_Key>"
echo
echo "  3. Start the collector:"
echo "     sudo systemctl start ss-collector"
echo "     sudo journalctl -u ss-collector -f"
echo
echo "  4. Install Grafana dashboards (requires Grafana to be running):"
echo "     sudo bash $REPO_DIR/scripts/install-grafana-dashboards.sh"
echo
echo "  5. Install report engine and web UI:"
echo "     sudo bash $REPO_DIR/scripts/install-reports.sh"
echo "     Then configure SMTP in $CONFIG_DIR/collector.env"
echo
