#!/bin/bash
# SonicScope Multi-Vendor — In-Place Updater
# Updates application code without touching the database or collector.env.
# Safe to run on a live system — data is preserved.
#
# Run as root: sudo bash scripts/update.sh
#
# What this does:
#   1. Stops ss-collector and ss-reports
#   2. Rsyncs collector/ and reports/ code to /opt/ss-multivendor/
#   3. Applies any new DB migrations (all are idempotent — safe to re-run)
#   4. Reinstalls Python packages if requirements.txt changed
#   5. Restarts both services
#
# What this does NOT touch:
#   - /etc/ss-multivendor/collector.env  (config, licence, SMTP)
#   - PostgreSQL data
#   - GeoIP databases
#   - Generated PDF reports
#   - TLS certificates
#   - Grafana dashboards (run install-grafana-dashboards.sh separately if needed)

set -euo pipefail

INSTALL_DIR="/opt/ss-multivendor"
SERVICE_USER="ss-collector"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

[ "$(id -u)" -ne 0 ] && error "Must be run as root"
[ -d "$INSTALL_DIR" ] || error "$INSTALL_DIR not found — run install.sh first"

# ── Detect versions ───────────────────────────────────────────────────────────
NEW_VER=$(grep '__version__' "$REPO_DIR/collector/main.py" 2>/dev/null \
    | head -1 | grep -oP '[\d.]+') || NEW_VER="unknown"
CUR_VER=$(grep '__version__' "$INSTALL_DIR/main.py" 2>/dev/null \
    | head -1 | grep -oP '[\d.]+') || CUR_VER="unknown"

echo
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  SonicScope ss-multivendor — Update${NC}"
echo -e "${GREEN}  Installed: ${CUR_VER}  →  New: ${NEW_VER}${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo
echo "  Database and collector.env will NOT be changed."
echo
read -r -p "Proceed with update? [y/N] " CONFIRM
[[ "${CONFIRM,,}" == "y" ]] || { echo "Aborted."; exit 0; }

# ── Ensure services are restarted even if something fails mid-update ──────────
_SERVICES_STOPPED=false
cleanup() {
    if $_SERVICES_STOPPED; then
        warn "Restarting services after early exit..."
        systemctl start ss-collector 2>/dev/null || true
        systemctl start ss-reports  2>/dev/null || true
    fi
}
trap cleanup EXIT

# ── Stop services ─────────────────────────────────────────────────────────────
section "Stopping services"
systemctl stop ss-reports  2>/dev/null && info "ss-reports stopped"  || info "ss-reports was not running"
systemctl stop ss-collector 2>/dev/null && info "ss-collector stopped" || info "ss-collector was not running"
_SERVICES_STOPPED=true

# ── Sync application code ─────────────────────────────────────────────────────
section "Updating application code"
rsync -a --delete \
    --exclude '__pycache__' \
    --exclude '*.pyc' \
    --exclude '*.pyo' \
    --exclude '.env' \
    --exclude 'venv/' \
    --exclude 'geoip/' \
    "$REPO_DIR/collector/" \
    "$INSTALL_DIR/"
info "Collector code updated"

rsync -a --delete \
    --exclude '__pycache__' \
    --exclude '*.pyc' \
    "$REPO_DIR/reports/" \
    "$INSTALL_DIR/reports/"
info "Reports code updated"

chown -R $SERVICE_USER:$SERVICE_USER "$INSTALL_DIR"

# Ensure collector.env is writable by the service group (ss-reports needs to update allowlist)
chown root:$SERVICE_USER /etc/ss-multivendor/collector.env
chmod 660 /etc/ss-multivendor/collector.env

# ── Update Python packages if requirements changed ────────────────────────────
section "Checking Python packages"
$INSTALL_DIR/venv/bin/pip install -q --upgrade -r "$REPO_DIR/collector/requirements.txt"
$INSTALL_DIR/venv/bin/pip install -q --upgrade -r "$REPO_DIR/reports/requirements.txt"
info "Python packages up to date"

# ── Apply DB migrations (all idempotent — safe to re-run) ────────────────────
section "Applying DB migrations"

apply_sql() {
    local label="$1" src="$2"
    local tmp
    tmp=$(mktemp /tmp/ss_mig_XXXXXX.sql)
    cp "$src" "$tmp"
    chmod 644 "$tmp"
    # No ON_ERROR_STOP: IF NOT EXISTS clauses mean "already exists" is not an error
    if sudo -u postgres psql -d sonicscope -f "$tmp" -q 2>/tmp/ss_mig_err.txt; then
        info "$label applied"
    else
        warn "$label — psql reported warnings (may be harmless IF NOT EXISTS notices):"
        cat /tmp/ss_mig_err.txt | head -5
    fi
    rm -f "$tmp" /tmp/ss_mig_err.txt
}

apply_sql "schema"          "$REPO_DIR/database/schema.sql"
apply_sql "aggregates"      "$REPO_DIR/database/aggregates.sql"
apply_sql "identity schema" "$REPO_DIR/database/identity_schema.sql"
apply_sql "002_auth"        "$REPO_DIR/database/migrations/002_auth.sql"
apply_sql "003_passwords"   "$REPO_DIR/database/migrations/003_passwords.sql"

# Apply any additional numbered migrations in order
for f in $(ls "$REPO_DIR/database/migrations/"*.sql 2>/dev/null | sort); do
    base=$(basename "$f")
    [[ "$base" == "002_auth.sql" || "$base" == "003_passwords.sql" ]] && continue
    apply_sql "$base" "$f"
done

# Ensure sonicscope user has permissions on any new tables
sudo -u postgres psql -d sonicscope -q -c "
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO sonicscope;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO sonicscope;
" >/dev/null
info "DB permissions refreshed"

# ── Restart services ──────────────────────────────────────────────────────────
section "Restarting services"
_SERVICES_STOPPED=false   # disarm the trap — we're handling restart ourselves

systemctl start ss-collector
sleep 2
if systemctl is-active --quiet ss-collector; then
    info "ss-collector is running"
else
    error "ss-collector failed to start — check: sudo journalctl -u ss-collector -n 30"
fi

systemctl start ss-reports
sleep 3
if systemctl is-active --quiet ss-reports; then
    info "ss-reports is running"
else
    warn "ss-reports failed to start — check: sudo journalctl -u ss-reports -n 30"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Update complete — now running v${NEW_VER}${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo
echo "  Verify collector is receiving data:"
echo "  sudo -u postgres psql -d sonicscope -c \\"
echo "    \"SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';\""
echo
echo "  If Grafana dashboards need refreshing:"
echo "  sudo bash scripts/install-grafana-dashboards.sh"
echo
