#!/bin/bash
# SonicScope Reports Engine — Installer
# Installs the report engine, Flask UI, and configures the ss-reports systemd service.
# Run as root: sudo bash scripts/install-reports.sh
# Tested on Ubuntu 22.04 / 24.04 / 26.04+ LTS

set -euo pipefail

INSTALL_DIR="/opt/ss-multivendor"
VENV_PIP="${INSTALL_DIR}/venv/bin/pip"
VENV_PYTHON="${INSTALL_DIR}/venv/bin/python3"
CONFIG_FILE="/etc/ss-multivendor/collector.env"
DATA_DIR="/var/lib/ss-multivendor"
LOG_DIR="/var/log/ss-multivendor"
SERVICE_USER="ss-collector"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

[ "$(id -u)" -ne 0 ] && error "Must be run as root"

# ── System dependencies for WeasyPrint ───────────────────────────────────────
# WeasyPrint >= 61 uses Pango + Cairo for rendering; GDK-PixBuf is no longer
# required. Package names are consistent across Ubuntu 22.04 / 24.04 / 26.04+.
section "Installing system packages for WeasyPrint"
apt-get update -qq
apt-get install -y -qq \
    python3 python3-pip python3-venv \
    libpango-1.0-0 libpangocairo-1.0-0 \
    libcairo2 libharfbuzz0b \
    libffi-dev shared-mime-info \
    fonts-liberation fonts-dejavu-core

# ── Python packages ───────────────────────────────────────────────────────────
section "Installing Python packages"
[ -x "${VENV_PIP}" ] || error "Venv not found at ${INSTALL_DIR}/venv — run install.sh first"
"${VENV_PIP}" install --quiet \
    "weasyprint>=61.0" \
    "jinja2>=3.1" \
    "apscheduler>=3.10" \
    "psycopg2-binary>=2.9" \
    "flask>=3.0" \
    "werkzeug>=3.0"

info "Python packages installed"

# ── Directories ───────────────────────────────────────────────────────────────
section "Creating data directories"
mkdir -p "${DATA_DIR}/reports"
mkdir -p "${DATA_DIR}/logos"
mkdir -p "${LOG_DIR}"

if id "${SERVICE_USER}" &>/dev/null; then
    chown -R "${SERVICE_USER}:${SERVICE_USER}" "${DATA_DIR}" "${LOG_DIR}"
    info "Ownership set to ${SERVICE_USER}"
else
    warn "Service user '${SERVICE_USER}' not found — directories created but ownership not set"
fi

# ── Install source files ──────────────────────────────────────────────────────
section "Installing report engine to ${INSTALL_DIR}"
mkdir -p "${INSTALL_DIR}"
rsync -av --delete \
    "${REPO_DIR}/reports/" \
    "${INSTALL_DIR}/reports/"
info "Report engine installed to ${INSTALL_DIR}/reports/"

# ── Add env vars to collector.env if not already set ─────────────────────────
section "Updating ${CONFIG_FILE}"

if [ -f "${CONFIG_FILE}" ]; then
    if ! grep -q "^REPORT_OUTPUT_DIR=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << EOF

# ── Report Engine ──────────────────────────────────────────────────────────
REPORT_OUTPUT_DIR=${DATA_DIR}/reports
REPORT_LOGO_DIR=${DATA_DIR}/logos
EOF
        info "Added REPORT_OUTPUT_DIR and REPORT_LOGO_DIR to ${CONFIG_FILE}"
    else
        info "REPORT_OUTPUT_DIR already set in ${CONFIG_FILE}"
    fi

    if ! grep -q "^SMTP_HOST=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << 'EOF'

# ── SMTP (for scheduled report delivery and login codes) ──────────────────────
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=
SMTP_USE_TLS=true
EOF
        info "Added SMTP settings placeholder to ${CONFIG_FILE}"
    fi

    # Generate a stable Flask secret key (persisted so sessions survive restarts)
    if ! grep -q "^FLASK_SECRET=" "${CONFIG_FILE}"; then
        FLASK_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
        echo "FLASK_SECRET=${FLASK_SECRET}" >> "${CONFIG_FILE}"
        info "Generated and saved FLASK_SECRET"
    fi
else
    warn "${CONFIG_FILE} not found — SMTP and report settings not added"
fi

# ── Systemd service ───────────────────────────────────────────────────────────
section "Installing ss-reports.service"

cat > /etc/systemd/system/ss-reports.service << EOF
[Unit]
Description=SonicScope Reports Web UI and Scheduler
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_FILE}
ExecStart=${VENV_PYTHON} ${INSTALL_DIR}/reports/web/app.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-reports

NoNewPrivileges=yes
ProtectSystem=full
ReadWritePaths=/etc/ss-multivendor /var/lib/ss-multivendor /var/log/ss-multivendor /var/lib/grafana/dashboards
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ss-reports
systemctl restart ss-reports

sleep 3
if systemctl is-active --quiet ss-reports; then
    info "ss-reports is running"
    info "Web UI: http://$(hostname -I | awk '{print $1}'):8080"
else
    warn "ss-reports did not start — check: sudo journalctl -u ss-reports -n 50"
fi

# ── Create default admin user ─────────────────────────────────────────────────
section "Creating default admin user"

GF_PASS_FILE="/etc/ss-multivendor/grafana-admin-password"
if [[ -f "$GF_PASS_FILE" ]]; then
    ADMIN_PASS=$(cat "$GF_PASS_FILE")
    info "Using Grafana admin password for Reports UI admin"
else
    ADMIN_PASS=$(openssl rand -base64 12 | tr -d '/+=')
    info "Grafana not yet installed — generated new admin password"
fi

# Write password to temp file to avoid shell injection when passing to Python
PASS_TMP=$(mktemp /tmp/ss_adminpw_XXXXXX)
chmod 600 "$PASS_TMP"
echo "$ADMIN_PASS" > "$PASS_TMP"

ADMIN_RESULT=$(${VENV_PYTHON} - "$PASS_TMP" "${CONFIG_FILE}" << 'PYEOF'
import sys, os
from werkzeug.security import generate_password_hash
import psycopg2

pass_file, env_file = sys.argv[1], sys.argv[2]

with open(pass_file) as f:
    admin_pass = f.read().strip()

env = {}
with open(env_file) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            env[k.strip()] = v.strip().strip('"').strip("'")

ph = generate_password_hash(admin_pass)
try:
    conn = psycopg2.connect(
        host=env.get('DB_HOST', '127.0.0.1'),
        port=int(env.get('DB_PORT', '5432')),
        dbname=env.get('DB_NAME', 'sonicscope'),
        user=env.get('DB_USER', 'sonicscope'),
        password=env.get('DB_PASSWORD', ''),
    )
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM ui_users WHERE role='admin' LIMIT 1")
        if not cur.fetchone():
            cur.execute(
                "INSERT INTO ui_users (email, full_name, role, password_hash) "
                "VALUES (%s, %s, %s, %s)",
                ('admin@sonicscope.local', 'Administrator', 'admin', ph),
            )
            print('CREATED')
        else:
            print('EXISTS')
    conn.close()
except Exception as e:
    print(f'ERROR: {e}', file=sys.stderr)
    sys.exit(1)
PYEOF
)

rm -f "$PASS_TMP"

if [[ "$ADMIN_RESULT" == "CREATED" ]]; then
    info "Default admin created"
    echo
    echo -e "${YELLOW}  ╔══════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}  ║  DEFAULT ADMIN — change password after first login   ║${NC}"
    echo -e "${YELLOW}  ║  Email:    admin@sonicscope.local                    ║${NC}"
    echo -e "${YELLOW}  ║  Password: ${ADMIN_PASS}$(printf '%*s' $((22 - ${#ADMIN_PASS})) '')║${NC}"
    echo -e "${YELLOW}  ╚══════════════════════════════════════════════════════╝${NC}"
    echo
elif [[ "$ADMIN_RESULT" == "EXISTS" ]]; then
    info "Admin user already exists — skipping default admin creation"
else
    warn "Could not create default admin — check DB connection and try again"
fi

section "Installation complete"
echo
echo "Next steps:"
echo "  1. Configure SMTP in ${CONFIG_FILE}"
echo "  2. Open the web UI at http://$(hostname -I | awk '{print $1}'):8080"
echo "  3. Log in as admin@sonicscope.local with the password shown above"
echo "  4. Create your MSP profile, add tenants, and configure report schedules"
echo
