"""
SonicScope Reports — Web Management UI
=======================================
Flask management console for MSP profiles, tenants, report schedules,
and on-demand PDF report generation.

Port:  8080
Start: python3 /opt/ss-multivendor/reports/web/app.py
"""
from __future__ import annotations

import csv
import io
import logging
import os
import re
import secrets
import sys
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import psycopg2
import psycopg2.extras
from flask import (Flask, abort, flash, g, get_flashed_messages, redirect,
                   render_template_string, request, send_file, session, url_for)
from markupsafe import escape as esc
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

import functools
import hashlib
import random
import smtplib
import string
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# ── Resolve imports relative to the ss-multivendor project root ───────────────
_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from reports.generator import generate_hr_report, generate_periodic_report, generate_security_report  # noqa: E402
from reports.scheduler import reload_schedules, start_scheduler, stop_scheduler  # noqa: E402

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
)
log = logging.getLogger('ss.reports.web')

# ── Config from env ───────────────────────────────────────────────────────────

def _load_env(path: str) -> None:
    """Load key=value pairs from a .env file into os.environ (no overwrite)."""
    try:
        for line in Path(path).read_text().splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, _, v = line.partition('=')
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except FileNotFoundError:
        pass


_load_env('/etc/ss-multivendor/collector.env')


def _e(key: str, default: str = '') -> str:
    return os.environ.get(key, default).strip()


DB_CONFIG = {
    'host': _e('DB_HOST', '127.0.0.1'),
    'port': int(_e('DB_PORT', '5432')),
    'dbname': _e('DB_NAME', 'sonicscope'),
    'user': _e('DB_USER', 'sonicscope'),
    'password': _e('DB_PASSWORD', ''),
}

SMTP_CONFIG = {
    'host': _e('SMTP_HOST'),
    'port': int(_e('SMTP_PORT', '587')),
    'user': _e('SMTP_USER'),
    'password': _e('SMTP_PASSWORD'),
    'from_addr': _e('SMTP_FROM'),
    'use_tls': _e('SMTP_USE_TLS', 'true').lower() in ('1', 'true', 'yes'),
}

OUTPUT_DIR = _e('REPORT_OUTPUT_DIR', '/var/lib/ss-multivendor/reports')
LOGO_DIR = _e('REPORT_LOGO_DIR', '/var/lib/ss-multivendor/logos')

ALLOWED_LOGO_EXTS = {'png', 'jpg', 'jpeg', 'svg'}
ALLOWED_LOGO_MIMETYPES = {'image/png', 'image/jpeg', 'image/svg+xml'}
VALID_REPORT_TYPES = frozenset({'daily', 'weekly', 'monthly', 'custom'})
VALID_DEVICE_SOURCES = frozenset({'manual', 'dhcp', 'sso', 'ldap'})

_CODE_EXPIRY_MINUTES = 15
_CODE_MAX_ATTEMPTS = 3

# ── Security helpers ──────────────────────────────────────────────────────────

def _csrf_token() -> str:
    """Return (creating if needed) a per-session CSRF token."""
    if 'csrf' not in session:
        session['csrf'] = secrets.token_hex(32)
    return session['csrf']


def _check_csrf() -> None:
    """Abort 400 if the submitted CSRF token does not match the session token."""
    token = request.form.get('_csrf', '')
    if not token or not secrets.compare_digest(token, session.get('csrf', '')):
        abort(400)


def _sanitise_svg(data: bytes) -> bytes:
    """Strip <script> elements and on* event attributes from SVG XML."""
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise ValueError(f"Invalid SVG XML: {exc}") from exc
    for elem in root.iter():
        # Remove <script> tags
        if elem.tag.lower().endswith('}script') or elem.tag.lower() == 'script':
            elem.clear()
        # Remove event-handler attributes
        bad_attrs = [a for a in list(elem.attrib) if a.lower().startswith('on')]
        for a in bad_attrs:
            del elem.attrib[a]
    return ET.tostring(root, encoding='unicode').encode('utf-8')


def _validated_logo_path(logo_path: str | None, logo_dir: str) -> str | None:
    """Return logo_path only if it resolves safely inside logo_dir; else None."""
    if not logo_path:
        return None
    try:
        real = os.path.realpath(logo_path)
        real_dir = os.path.realpath(logo_dir)
        if real.startswith(real_dir + os.sep) and os.path.isfile(real):
            return logo_path
    except (OSError, ValueError):
        pass
    return None

# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = _e('FLASK_SECRET') or secrets.token_hex(32)
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24 hours

_scheduler = None  # Initialised by _init_scheduler()

app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = _e('COOKIE_SECURE', 'false').lower() in ('1', 'true', 'yes')
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5 MB — prevents DoS on CSV upload


@app.errorhandler(413)
def file_too_large(_e):
    flash('Upload too large — maximum 5 MB.', 'error')
    return redirect(request.referrer or url_for('identity_dhcp_import')), 413


@app.after_request
def set_security_headers(response):
    """Apply security headers to every response."""
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; "
        "style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; "
        "font-src 'self' https://fonts.gstatic.com data:; "
        "img-src 'self' data: blob:; "
        "object-src 'none';"
    )
    return response


# ── Login enforcement ─────────────────────────────────────────────────────────

_PUBLIC_ENDPOINTS = frozenset({'login', 'forgot_password', 'reset_password', 'logout', 'static'})

@app.before_request
def _enforce_login():
    if request.endpoint in _PUBLIC_ENDPOINTS:
        return
    if not session.get('user_id'):
        return redirect(url_for('login', next=request.path))


def _init_scheduler() -> None:
    """Start the report scheduler if not already running. Safe to call from WSGI."""
    global _scheduler
    if _scheduler is None:
        _scheduler = start_scheduler(DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)


# Start scheduler for WSGI deployments (gunicorn, uwsgi).
# Under __main__ this runs twice harmlessly; _init_scheduler guards against that.
with app.app_context():
    try:
        _init_scheduler()
    except Exception:
        log.exception('Could not connect to DB at startup — scheduler not started')

# ── DB helpers ────────────────────────────────────────────────────────────────

def get_db():
    """Return the per-request psycopg2 connection, opening it if needed."""
    if 'db' not in g:
        g.db = psycopg2.connect(**DB_CONFIG)
    return g.db


@app.teardown_appcontext
def close_db(_error):
    """Close the DB connection at the end of each request."""
    db = g.pop('db', None)
    if db is not None:
        try:
            db.close()
        except Exception:
            pass


def qall(sql: str, params=()) -> list[dict]:
    """Execute SQL and return all rows as dicts."""
    with get_db().cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]


def qone(sql: str, params=()) -> dict | None:
    """Execute SQL and return the first row as a dict, or None."""
    with get_db().cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(sql, params)
        row = cur.fetchone()
        return dict(row) if row else None


def qexec(sql: str, params=()) -> None:
    """Execute a DML statement and commit."""
    with get_db().cursor() as cur:
        cur.execute(sql, params)
    get_db().commit()


def qinsert(sql: str, params=()) -> int:
    """Execute an INSERT RETURNING id statement and return the new id."""
    with get_db().cursor() as cur:
        cur.execute(sql, params)
        row_id = cur.fetchone()[0]
    get_db().commit()
    return row_id


# ── HTML base layout ──────────────────────────────────────────────────────────

_BASE = '''<!DOCTYPE html>
<html lang="en" data-bs-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{{TITLE}} — SonicScope Reports</title>
  <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
  <style>
    body{background:#070D1A;}
    .ss-brand{color:#00C9A7!important;font-weight:700;letter-spacing:1px;}
    .sidebar{background:#0D1629;border-right:1px solid #1A2A4A;min-height:calc(100vh - 56px);padding-top:1rem;}
    .sidebar .nav-link{color:#8BA3C0;padding:.45rem .75rem;border-radius:5px;}
    .sidebar .nav-link:hover,.sidebar .nav-link.active{color:#00C9A7;background:#131F38;}
    .card{background:#0D1629;border:1px solid #1A2A4A;}
    .card-header{background:#131F38;border-bottom:1px solid #1A2A4A;}
    .table{color:#E8EFF8;}
    .table th{color:#8BA3C0;font-size:.75rem;text-transform:uppercase;letter-spacing:.5px;border-color:#1A2A4A;}
    .table td{border-color:#1A2A4A;}
    .badge-teal{background:#00C9A7;color:#070D1A;}
    .stat-val{font-size:1.8rem;font-weight:700;color:#00C9A7;}
    .form-control,.form-select{background:#131F38;border-color:#1A2A4A;color:#E8EFF8;}
    .form-control:focus,.form-select:focus{background:#131F38;border-color:#378ADD;color:#E8EFF8;box-shadow:0 0 0 .2rem rgba(55,138,221,.25);}
    .btn-ss{background:#00C9A7;color:#070D1A;border:none;font-weight:600;}
    .btn-ss:hover{background:#00b394;color:#070D1A;}
  </style>
</head>
<body>
<nav class="navbar" style="background:#0D1629;border-bottom:1px solid #1A2A4A;">
  <div class="container-fluid">
    <a class="navbar-brand ss-brand" href="/">⬡ SonicScope Reports</a>
    <div class="d-flex align-items-center gap-3">
      <span class="text-muted small">{{USER_INFO}}</span>
      <a href="/change-password" class="text-muted small text-decoration-none" title="Change password">🔑</a>
      <form method="post" action="/logout" style="margin:0">
        <button class="btn btn-sm btn-outline-secondary py-0 px-2" style="font-size:12px;">Sign out</button>
      </form>
    </div>
  </div>
</nav>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-2 sidebar p-3">
      <ul class="nav flex-column gap-1">
        <li><a class="nav-link {{A_dash}}"      href="/">📊 Report Dashboard</a></li>
        <li><a class="nav-link {{A_tenants}}"   href="/tenants">🏢 Tenants</a></li>
        <li><a class="nav-link {{A_identity}}"  href="/identity">👤 User Identity</a></li>
        <li><a class="nav-link {{A_devices}}"   href="/identity/devices">💻 Devices</a></li>
        {{ADMIN_NAV}}
        <li><a class="nav-link {{A_msp}}"       href="/msp-profiles">🎨 MSP Profiles</a></li>
        <li><a class="nav-link {{A_schedules}}" href="/schedules">🗓 Schedules</a></li>
        <li><a class="nav-link {{A_generate}}"  href="/generate">⚡ Generate Now</a></li>
      </ul>
    </div>
    <div class="col-md-10 p-4">
      {{FLASHES}}
      {{CONTENT}}
    </div>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>'''


def _flashes() -> str:
    """Render flashed messages as Bootstrap alerts."""
    msgs = []
    for cat, text in get_flashed_messages(with_categories=True):
        cls = 'danger' if cat == 'error' else 'success'
        msgs.append(
            f'<div class="alert alert-{cls} alert-dismissible fade show">'
            f'{esc(text)}'
            f'<button type="button" class="btn-close" data-bs-dismiss="alert"></button>'
            f'</div>'
        )
    return ''.join(msgs)


def page(title: str, content: str, active: str = '') -> str:
    """Wrap content in the base layout and return the complete HTML response."""
    nav = {k: '' for k in ('dash', 'tenants', 'identity', 'devices', 'msp', 'schedules', 'generate', 'admin_users')}
    if active in nav:
        nav[active] = 'active'
    u = current_user()
    user_info = f'{esc(u["full_name"])} ({u["role"]})' if u else ''
    admin_nav = (
        '<li><a class="nav-link {{A_admin_users}}" href="/admin/users">👥 Users</a></li>'
        if u and u['role'] == 'admin' else ''
    )
    html = (
        _BASE
        .replace('{{TITLE}}', str(esc(title)))
        .replace('{{CONTENT}}', content)
        .replace('{{FLASHES}}', _flashes())
        .replace('{{A_dash}}', nav['dash'])
        .replace('{{A_tenants}}', nav['tenants'])
        .replace('{{A_identity}}', nav['identity'])
        .replace('{{A_devices}}', nav['devices'])
        .replace('{{A_msp}}', nav['msp'])
        .replace('{{A_schedules}}', nav['schedules'])
        .replace('{{A_generate}}', nav['generate'])
        .replace('{{USER_INFO}}', user_info)
        .replace('{{ADMIN_NAV}}', admin_nav)
        .replace('{{A_admin_users}}', nav['admin_users'])
    )
    # Inject CSRF into ALL post forms in the assembled page — including the
    # logout button in the navbar which lives in _BASE, not in content.
    csrf_field = f'<input type="hidden" name="_csrf" value="{_csrf_token()}">'
    html = re.sub(
        r'(<form\b[^>]*\bmethod=["\']post["\'][^>]*>)',
        lambda m: m.group(0) + csrf_field,
        html,
        flags=re.IGNORECASE,
    )
    return html


_GRAFANA_DASHBOARD_DIR = Path('/var/lib/grafana/dashboards/sonicscope')
_COLLECTOR_ENV = Path('/etc/ss-multivendor/collector.env')


def _update_collector_allowlist() -> bool:
    """Sync IPFIX_ALLOWED_SOURCES and SYSLOG_ALLOWED_SOURCES in collector.env
    with all registered sensor IPs, then restart ss-collector.
    Returns True on success, False if the env file could not be written."""
    import subprocess
    if not _COLLECTOR_ENV.exists():
        log.warning("collector.env not found — cannot update allowlist")
        return False
    try:
        rows = qall(
            "SELECT host(ip_address) AS ip FROM sensors "
            "WHERE ip_address IS NOT NULL ORDER BY ip_address"
        )
        ips = ','.join(r['ip'] for r in rows)
        content = _COLLECTOR_ENV.read_text()
        for key in ('IPFIX_ALLOWED_SOURCES', 'SYSLOG_ALLOWED_SOURCES'):
            if re.search(rf'^{key}=', content, re.MULTILINE):
                content = re.sub(rf'^{key}=.*$', f'{key}={ips}', content, flags=re.MULTILINE)
            else:
                content += f'\n{key}={ips}\n'
        _COLLECTOR_ENV.write_text(content)
        log.info("Collector allowlist updated: %s", ips or "(all sources allowed)")
    except Exception as exc:
        log.error("Failed to write collector.env allowlist: %s", exc)
        return False
    try:
        subprocess.run(
            ['sudo', '/usr/bin/systemctl', 'restart', 'ss-collector'],
            check=True, timeout=15, capture_output=True,
        )
        log.info("ss-collector restarted — new allowlist active")
    except Exception as exc:
        log.warning("Could not restart ss-collector: %s — allowlist written but restart needed", exc)
    return True


def _update_grafana_tenants() -> bool:
    """Patch the tenant_id dropdown in all Grafana dashboard JSONs from the DB.
    Runs in-process — no shell script or sudo required. No-op if Grafana dir
    is absent (e.g. Grafana not installed).
    Returns True if at least one dashboard was updated, False otherwise."""
    import json as _json
    if not _GRAFANA_DASHBOARD_DIR.exists():
        return True  # Grafana not installed — not an error
    tenants = qall("SELECT id, name FROM tenants ORDER BY id")
    if not tenants:
        return True
    options = [
        {'selected': i == 0, 'text': t['name'], 'value': str(t['id'])}
        for i, t in enumerate(tenants)
    ]
    first = tenants[0]
    updated = 0
    failed = 0
    for jf in _GRAFANA_DASHBOARD_DIR.glob('*.json'):
        try:
            d = _json.loads(jf.read_text())
            changed = False
            for v in d.get('templating', {}).get('list', []):
                if v.get('name') == 'tenant_id':
                    v['options'] = options
                    v['current'] = {'selected': True, 'text': first['name'], 'value': str(first['id'])}
                    v['query'] = ', '.join(f"{t['name']} : {t['id']}" for t in tenants)
                    changed = True
            if changed:
                jf.write_text(_json.dumps(d, indent=2))
                updated += 1
        except Exception as exc:
            log.error("Could not patch Grafana dashboard %s: %s — run: sudo bash scripts/install-grafana-dashboards.sh", jf.name, exc)
            failed += 1
    if updated:
        log.info("Grafana tenant dropdown updated in %d dashboard(s)", updated)
    return failed == 0


def _fmt_bytes(n: int | None) -> str:
    """Format bytes to human-readable string."""
    if not n:
        return '0 B'
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if abs(n) < 1024.0:
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.2f} PB"


# ── Auth helpers ──────────────────────────────────────────────────────────────

def _hash_code(code: str) -> str:
    return hashlib.sha256(code.encode()).hexdigest()


def current_user() -> dict | None:
    uid = session.get('user_id')
    if not uid:
        return None
    return qone("SELECT * FROM ui_users WHERE id = %s AND is_active = true", (uid,))


def is_admin() -> bool:
    u = current_user()
    return bool(u and u['role'] == 'admin')


def user_tenant_ids() -> list[int]:
    """Tenant IDs the current user may access. Admins get all."""
    u = current_user()
    if not u:
        return []
    if u['role'] == 'admin':
        return [r['id'] for r in qall("SELECT id FROM tenants ORDER BY id")]
    return [r['tenant_id'] for r in qall(
        "SELECT tenant_id FROM ui_user_tenants WHERE user_id = %s", (u['id'],)
    )]


def can_access_tenant(tenant_id: int) -> bool:
    if is_admin():
        return True
    uid = session.get('user_id')
    if not uid:
        return False
    return bool(qone(
        "SELECT 1 FROM ui_user_tenants WHERE user_id = %s AND tenant_id = %s",
        (uid, tenant_id),
    ))


def require_auth(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login', next=request.path))
        return f(*args, **kwargs)
    return decorated


def require_admin(f):
    @functools.wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('user_id'):
            return redirect(url_for('login', next=request.path))
        if not is_admin():
            abort(403)
        return f(*args, **kwargs)
    return decorated


def _send_reset_code(to_email: str, code: str, full_name: str) -> None:
    """Send a 6-digit password reset code by email using the configured SMTP settings."""
    host = SMTP_CONFIG['host']
    port = SMTP_CONFIG['port']
    user = SMTP_CONFIG['user']
    password = SMTP_CONFIG['password']
    from_addr = SMTP_CONFIG['from_addr'] or user

    if not host:
        raise ValueError("SMTP not configured — set SMTP_HOST in collector.env")

    subject = "SonicScope — Password Reset Code"
    name_line = f"Hi {esc(full_name)}," if full_name else "Hi,"

    html_body = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;background:#f4f7fb;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f7fb;padding:32px 0;">
    <tr><td align="center">
      <table width="520" cellpadding="0" cellspacing="0"
             style="max-width:520px;width:100%;border-radius:8px;overflow:hidden;">
        <tr>
          <td style="background:#070D1A;padding:20px 32px;">
            <span style="font-size:20px;font-weight:700;color:#00C9A7;">SonicScope</span>
            <span style="display:block;font-size:11px;color:#8BA3C0;margin-top:2px;">Network Visibility Platform</span>
          </td>
        </tr>
        <tr>
          <td style="background:#ffffff;padding:32px;border:1px solid #e4e9f0;border-top:none;">
            <p style="margin:0 0 16px;font-size:15px;color:#1C2B3A;">{name_line}</p>
            <p style="margin:0 0 20px;font-size:14px;color:#4a5568;">
              Your SonicScope login code is:
            </p>
            <div style="text-align:center;margin:24px 0;">
              <span style="font-size:36px;font-weight:700;letter-spacing:10px;
                           color:#070D1A;background:#f0f7ff;border:2px solid #378ADD;
                           border-radius:8px;padding:12px 24px;display:inline-block;">
                {code}
              </span>
            </div>
            <p style="margin:20px 0 0;font-size:13px;color:#8BA3C0;">
              This code expires in <strong>{_CODE_EXPIRY_MINUTES} minutes</strong>.
              If you did not request this, ignore this email.
            </p>
          </td>
        </tr>
        <tr>
          <td style="background:#f0f3f8;padding:12px 32px;border:1px solid #e4e9f0;
                     border-top:none;border-radius:0 0 8px 8px;">
            <span style="font-size:11px;color:#8BA3C0;">
              SonicScope &bull; sonicscope.co.za
            </span>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""

    text_body = (
        f"Your SonicScope login code is: {code}\n\n"
        f"Expires in {_CODE_EXPIRY_MINUTES} minutes.\n"
        "If you did not request this, ignore this email."
    )

    msg = MIMEMultipart('alternative')
    msg['From'] = from_addr
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(text_body, 'plain', 'utf-8'))
    msg.attach(MIMEText(html_body, 'html', 'utf-8'))
    raw = msg.as_bytes()

    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=30) as smtp:
            if user and password:
                smtp.login(user, password)
            smtp.sendmail(from_addr, [to_email], raw)
    else:
        with smtplib.SMTP(host, port, timeout=30) as smtp:
            smtp.ehlo()
            if port != 25:
                smtp.starttls()
                smtp.ehlo()
            if user and password:
                smtp.login(user, password)
            smtp.sendmail(from_addr, [to_email], raw)

    log.info("Password reset code sent to %s", to_email)


# ── Routes ────────────────────────────────────────────────────────────────────

# ── Login / logout ────────────────────────────────────────────────────────────

def _render_auth_page(title: str, content: str) -> str:
    """Render a page in the unauthenticated layout (no sidebar, no user info)."""
    csrf_field = f'<input type="hidden" name="_csrf" value="{_csrf_token()}">'
    import re as _re
    patched = _re.sub(
        r'(<form\b[^>]*\bmethod=["\']post["\'][^>]*>)',
        lambda m: m.group(0) + csrf_field,
        content, flags=_re.IGNORECASE,
    )
    return (
        _BASE
        .replace('{{TITLE}}', f'{title} — SonicScope Reports')
        .replace('{{CONTENT}}', patched)
        .replace('{{FLASHES}}', _flashes())
        .replace('{{A_dash}}', '').replace('{{A_tenants}}', '')
        .replace('{{A_identity}}', '').replace('{{A_devices}}', '')
        .replace('{{A_msp}}', '').replace('{{A_schedules}}', '')
        .replace('{{A_generate}}', '').replace('{{A_admin_users}}', '')
        .replace('{{USER_INFO}}', '').replace('{{ADMIN_NAV}}', '')
    )


@app.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('user_id'):
        return redirect(url_for('dashboard'))

    error = None
    if request.method == 'POST':
        _check_csrf()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        u = qone("SELECT * FROM ui_users WHERE email = %s AND is_active = true", (email,))
        if not u or not u.get('password_hash') or not check_password_hash(u['password_hash'], password):
            error = 'Invalid email or password.'
            log.warning("Failed login attempt for: %s", email)
        else:
            qexec("UPDATE ui_users SET last_login = NOW() WHERE id = %s", (u['id'],))
            session.clear()
            session.permanent = True
            session['user_id'] = u['id']
            session['user_role'] = u['role']
            log.info("User %s (%s) logged in", u['email'], u['role'])
            return redirect(request.args.get('next') or url_for('dashboard'))

    csrf = _csrf_token()
    content = f'''
    <div style="min-height:80vh;display:flex;align-items:center;justify-content:center;">
      <div style="width:100%;max-width:400px;">
        <div class="text-center mb-4">
          <div style="font-size:2rem;font-weight:700;color:#00C9A7;letter-spacing:1px;">⬡ SonicScope</div>
          <div class="text-muted small mt-1">Management Console</div>
        </div>
        <div class="card p-4">
          <h5 class="mb-1">Sign In</h5>
          <p class="text-muted small mb-4">Enter your credentials to continue.</p>
          {"<div class='alert alert-danger py-2'>"+str(esc(error))+"</div>" if error else ""}
          <form method="post">
            <input type="hidden" name="_csrf" value="{csrf}">
            <div class="mb-3">
              <label class="form-label">Email address</label>
              <input name="email" type="email" class="form-control" required autofocus
                     placeholder="you@example.com">
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input name="password" type="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-ss w-100">Sign In</button>
          </form>
          <div class="mt-3 text-center">
            <a href="/forgot-password" class="text-muted small">Forgot password?</a>
          </div>
        </div>
      </div>
    </div>'''
    return _render_auth_page('Sign In', content)


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if session.get('user_id'):
        return redirect(url_for('dashboard'))

    sent = False
    error = None
    if request.method == 'POST':
        _check_csrf()
        email = request.form.get('email', '').strip().lower()
        u = qone("SELECT * FROM ui_users WHERE email = %s AND is_active = true", (email,))
        if u:
            import datetime as _dt
            code = ''.join(random.choices(string.digits, k=6))
            expires = datetime.now() + _dt.timedelta(minutes=_CODE_EXPIRY_MINUTES)
            qexec("UPDATE ui_login_codes SET used = true WHERE email = %s AND NOT used", (email,))
            qinsert(
                "INSERT INTO ui_login_codes (email, code_hash, expires_at) VALUES (%s, %s, %s) RETURNING id",
                (email, _hash_code(code), expires),
            )
            try:
                _send_reset_code(email, code, u['full_name'])
                session['reset_email'] = email
            except Exception as exc:
                log.error("Failed to send reset code to %s: %s", email, exc)
                error = 'Could not send email — check SMTP settings. Contact your administrator.'
        if not error:
            sent = True

    csrf = _csrf_token()
    if sent:
        body = '''
          <h5 class="mb-2">Check Your Email</h5>
          <p class="text-muted small mb-3">
            If that address is registered you will receive a reset code shortly.
          </p>
          <a href="/reset-password" class="btn btn-ss w-100">Enter Reset Code</a>
          <div class="mt-3 text-center">
            <a href="/login" class="text-muted small">← Back to sign in</a>
          </div>'''
    else:
        body = f'''
          <h5 class="mb-1">Reset Password</h5>
          <p class="text-muted small mb-4">Enter your email to receive a reset code.</p>
          {"<div class='alert alert-danger py-2'>"+str(esc(error))+"</div>" if error else ""}
          <form method="post">
            <input type="hidden" name="_csrf" value="{csrf}">
            <div class="mb-3">
              <label class="form-label">Email address</label>
              <input name="email" type="email" class="form-control" required autofocus
                     placeholder="you@example.com">
            </div>
            <button type="submit" class="btn btn-ss w-100">Send Reset Code</button>
          </form>
          <div class="mt-3 text-center">
            <a href="/login" class="text-muted small">← Back to sign in</a>
          </div>'''

    content = f'''
    <div style="min-height:80vh;display:flex;align-items:center;justify-content:center;">
      <div style="width:100%;max-width:400px;">
        <div class="text-center mb-4">
          <div style="font-size:2rem;font-weight:700;color:#00C9A7;letter-spacing:1px;">⬡ SonicScope</div>
          <div class="text-muted small mt-1">Management Console</div>
        </div>
        <div class="card p-4">{body}</div>
      </div>
    </div>'''
    return _render_auth_page('Reset Password', content)


@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if session.get('user_id'):
        return redirect(url_for('dashboard'))

    email = session.get('reset_email', '')
    error = None
    if request.method == 'POST':
        _check_csrf()
        if not email:
            return redirect(url_for('forgot_password'))
        submitted = request.form.get('code', '').strip()
        new_pw = request.form.get('password', '')
        confirm = request.form.get('confirm', '')

        row = qone(
            """SELECT * FROM ui_login_codes
               WHERE email = %s AND NOT used AND expires_at > NOW()
               ORDER BY created_at DESC LIMIT 1""",
            (email,),
        )
        if not row:
            error = 'Code has expired — request a new one.'
        elif row['attempts'] >= _CODE_MAX_ATTEMPTS:
            error = 'Too many attempts — request a new code.'
        elif not secrets.compare_digest(row['code_hash'], _hash_code(submitted)):
            qexec("UPDATE ui_login_codes SET attempts = attempts + 1 WHERE id = %s", (row['id'],))
            remaining = _CODE_MAX_ATTEMPTS - row['attempts'] - 1
            error = f'Incorrect code. {remaining} attempt(s) remaining.'
        elif len(new_pw) < 8:
            error = 'Password must be at least 8 characters.'
        elif new_pw != confirm:
            error = 'Passwords do not match.'
        else:
            qexec("UPDATE ui_login_codes SET used = true WHERE id = %s", (row['id'],))
            qexec("UPDATE ui_users SET password_hash = %s WHERE email = %s",
                  (generate_password_hash(new_pw), email))
            session.pop('reset_email', None)
            flash('Password updated. Please sign in.', 'success')
            log.info("Password reset for %s", email)
            return redirect(url_for('login'))

    csrf = _csrf_token()
    content = f'''
    <div style="min-height:80vh;display:flex;align-items:center;justify-content:center;">
      <div style="width:100%;max-width:400px;">
        <div class="text-center mb-4">
          <div style="font-size:2rem;font-weight:700;color:#00C9A7;letter-spacing:1px;">⬡ SonicScope</div>
          <div class="text-muted small mt-1">Management Console</div>
        </div>
        <div class="card p-4">
          <h5 class="mb-1">Set New Password</h5>
          <p class="text-muted small mb-4">
            Enter the 6-digit code sent to
            <strong>{esc(email) if email else "your email"}</strong>
            and choose a new password.
          </p>
          {"<div class='alert alert-danger py-2'>"+str(esc(error))+"</div>" if error else ""}
          <form method="post">
            <input type="hidden" name="_csrf" value="{csrf}">
            <div class="mb-3">
              <label class="form-label">Reset code</label>
              <input name="code" class="form-control text-center font-monospace"
                     style="font-size:1.4rem;letter-spacing:8px;"
                     maxlength="6" pattern="[0-9]{{6}}" inputmode="numeric"
                     required autofocus autocomplete="one-time-code" placeholder="000000">
            </div>
            <div class="mb-3">
              <label class="form-label">New password <span class="text-muted small">(min 8 chars)</span></label>
              <input name="password" type="password" class="form-control" required minlength="8">
            </div>
            <div class="mb-3">
              <label class="form-label">Confirm password</label>
              <input name="confirm" type="password" class="form-control" required minlength="8">
            </div>
            <button type="submit" class="btn btn-ss w-100">Set New Password</button>
          </form>
          <div class="mt-3 text-center">
            <a href="/forgot-password" class="text-muted small">← Request a new code</a>
          </div>
        </div>
      </div>
    </div>'''
    return _render_auth_page('Set New Password', content)


@app.route('/logout', methods=['POST'])
def logout():
    _check_csrf()
    session.clear()
    return redirect(url_for('login'))


@app.route('/change-password', methods=['GET', 'POST'])
@require_auth
def change_password():
    u = current_user()
    error = None
    if request.method == 'POST':
        _check_csrf()
        current_pw = request.form.get('current', '')
        new_pw = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        if not u.get('password_hash') or not check_password_hash(u['password_hash'], current_pw):
            error = 'Current password is incorrect.'
        elif len(new_pw) < 8:
            error = 'New password must be at least 8 characters.'
        elif new_pw != confirm:
            error = 'Passwords do not match.'
        else:
            qexec("UPDATE ui_users SET password_hash = %s WHERE id = %s",
                  (generate_password_hash(new_pw), u['id']))
            flash('Password updated successfully.', 'success')
            log.info("Password changed for %s", u['email'])
            return redirect(url_for('dashboard'))

    content = f'''
    <h3 class="mb-3">🔑 Change Password</h3>
    <div class="card p-4" style="max-width:480px;">
      {"<div class='alert alert-danger py-2'>"+str(esc(error))+"</div>" if error else ""}
      <form method="post">
        <div class="mb-3">
          <label class="form-label">Current password</label>
          <input name="current" type="password" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label">New password <span class="text-muted small">(min 8 characters)</span></label>
          <input name="password" type="password" class="form-control" required minlength="8">
        </div>
        <div class="mb-3">
          <label class="form-label">Confirm new password</label>
          <input name="confirm" type="password" class="form-control" required minlength="8">
        </div>
        <button type="submit" class="btn btn-ss">Update Password</button>
        <a href="/" class="btn btn-outline-secondary ms-2">Cancel</a>
      </form>
    </div>'''
    return page('Change Password', content)


@app.route('/')
def dashboard():
    """List the 50 most recent generated reports with download links."""
    tenant_filter = request.args.get('tenant_id', type=int)
    params: tuple = ()
    where = ''
    if tenant_filter:
        where = 'WHERE gr.tenant_id = %s'
        params = (tenant_filter,)

    reports = qall(
        f"""
        SELECT gr.id, gr.report_type, gr.period_start, gr.period_end,
               gr.generated_at, gr.delivery_status, gr.file_size_bytes,
               gr.subject_user, t.name AS tenant_name
        FROM generated_reports gr
        JOIN tenants t ON t.id = gr.tenant_id
        {where}
        ORDER BY gr.generated_at DESC
        LIMIT 50
        """,
        params,
    )
    tenants = qall("SELECT id, name FROM tenants ORDER BY name")

    rows_html = ''
    for r in reports:
        status_cls = {'sent': 'success', 'ready': 'success', 'failed': 'danger', 'pending': 'secondary'}.get(
            r['delivery_status'], 'secondary'
        )
        subject_badge = (
            f' <span class="badge bg-warning text-dark">{esc(r["subject_user"])}</span>'
            if r.get('subject_user') else ''
        )
        rows_html += (
            f'<tr>'
            f'<td>{esc(r["tenant_name"])}</td>'
            f'<td><span class="badge badge-teal">{esc(r["report_type"])}</span>{subject_badge}</td>'
            f'<td>{r["period_start"].strftime("%d %b %Y")} – {r["period_end"].strftime("%d %b %Y")}</td>'
            f'<td class="text-muted small">{r["generated_at"].strftime("%d %b %Y %H:%M")}</td>'
            f'<td><span class="badge bg-{status_cls}">{esc(r["delivery_status"])}</span></td>'
            f'<td class="text-muted small">{_fmt_bytes(r["file_size_bytes"])}</td>'
            f'<td><a href="/reports/{r["id"]}/download" class="btn btn-sm btn-outline-success">⬇ PDF</a></td>'
            f'</tr>'
        )
    if not rows_html:
        rows_html = '<tr><td colspan="7" class="text-center text-muted py-4">No reports yet</td></tr>'

    tenant_options = ''.join(
        f'<option value="{t["id"]}" {"selected" if tenant_filter == t["id"] else ""}>{t["name"]}</option>'
        for t in tenants
    )

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">📊 Report Dashboard</h3>
      <div class="d-flex gap-2">
        <form class="d-flex gap-2" method="get">
          <select name="tenant_id" class="form-select form-select-sm" style="width:200px;">
            <option value="">All tenants</option>{tenant_options}
          </select>
          <button class="btn btn-sm btn-outline-secondary">Filter</button>
        </form>
        <button class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#purgeModal">
          🗑 Purge Old Reports
        </button>
      </div>
    </div>
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr>
            <th>Tenant</th><th>Type</th><th>Period</th>
            <th>Generated</th><th>Status</th><th>Size</th><th></th>
          </tr></thead>
          <tbody>{rows_html}</tbody>
        </table>
      </div>
    </div>

    <div class="modal fade" id="purgeModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">🗑 Purge Old Reports</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <form method="post" action="/reports/purge">
            <div class="modal-body">
              <p class="text-muted">Permanently deletes PDF files and database records for reports older than the specified number of days. This cannot be undone.</p>
              <div class="mb-3">
                <label class="form-label fw-semibold">Delete reports older than</label>
                <div class="input-group" style="max-width:200px;">
                  <input type="number" name="days" class="form-control" value="90" min="1" max="3650" required>
                  <span class="input-group-text">days</span>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-danger">Delete Reports</button>
            </div>
          </form>
        </div>
      </div>
    </div>'''
    return page('Report Dashboard', content, 'dash')


@app.route('/reports/purge', methods=['POST'])
def purge_reports():
    """Delete PDF files and DB records for reports older than N days."""
    if not is_admin():
        abort(403)
    _check_csrf()
    days = request.form.get('days', type=int)
    if not days or days < 1:
        flash('Please enter a valid number of days.', 'error')
        return redirect(url_for('dashboard'))

    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    old = qall(
        "SELECT id, file_path FROM generated_reports WHERE generated_at < %s",
        (cutoff,),
    )
    if not old:
        flash(f'No reports older than {days} day(s) found.', 'success')
        return redirect(url_for('dashboard'))

    deleted_files = 0
    file_errors = []
    for row in old:
        fp = row.get('file_path')
        if fp:
            try:
                real = os.path.realpath(fp)
                if real.startswith(OUTPUT_DIR) and os.path.isfile(real):
                    os.remove(real)
                    deleted_files += 1
            except OSError as exc:
                file_errors.append(str(exc))

    ids = [row['id'] for row in old]
    qexec(
        f"DELETE FROM generated_reports WHERE id = ANY(%s)",
        (ids,),
    )

    msg = f'Purged {len(ids)} report(s) older than {days} day(s). {deleted_files} PDF file(s) removed.'
    if file_errors:
        msg += f' ({len(file_errors)} file deletion error(s) — DB records still removed.)'
        flash(msg, 'error')
    else:
        flash(msg, 'success')
    return redirect(url_for('dashboard'))


@app.route('/tenants', methods=['GET', 'POST'])
def tenants():
    """List all tenants and create new ones."""
    if request.method == 'POST':
        if not is_admin():
            abort(403)
        _check_csrf()
        name = request.form.get('name', '').strip()
        slug = re.sub(r'[^\w\-]', '-', request.form.get('slug', name).lower().strip())
        timezone = request.form.get('timezone', 'Africa/Johannesburg').strip()
        contact_name = request.form.get('contact_name', '').strip()
        contact_email = request.form.get('contact_email', '').strip()
        msp_id = request.form.get('msp_profile_id', type=int)

        if not name or not slug:
            flash('Name and slug are required.', 'error')
            return redirect(url_for('tenants'))

        try:
            qinsert(
                """
                INSERT INTO tenants (msp_profile_id, name, slug, contact_name, contact_email, timezone)
                VALUES (%s, %s, %s, %s, %s, %s) RETURNING id
                """,
                (msp_id, name, slug, contact_name or None, contact_email or None, timezone),
            )
            flash(f'Tenant "{name}" created.', 'success')
            if not _update_grafana_tenants():
                flash('Grafana tenant dropdown could not be updated — run: sudo bash scripts/install-grafana-dashboards.sh', 'warning')
        except psycopg2.IntegrityError:
            get_db().rollback()
            flash(f'Slug "{slug}" already exists. Choose a different one.', 'error')
        return redirect(url_for('tenants'))

    allowed = user_tenant_ids()
    if is_admin():
        rows = qall(
            """
            SELECT t.id, t.name, t.slug, t.timezone, t.contact_name, t.contact_email,
                   m.name AS msp_name
            FROM tenants t
            LEFT JOIN msp_profiles m ON m.id = t.msp_profile_id
            ORDER BY t.name
            """
        )
    else:
        rows = qall(
            """
            SELECT t.id, t.name, t.slug, t.timezone, t.contact_name, t.contact_email,
                   m.name AS msp_name
            FROM tenants t
            LEFT JOIN msp_profiles m ON m.id = t.msp_profile_id
            WHERE t.id = ANY(%s)
            ORDER BY t.name
            """,
            (allowed,),
        )
    msps = qall("SELECT id, name FROM msp_profiles ORDER BY name")

    rows_html = ''
    for r in rows:
        rows_html += (
            f'<tr>'
            f'<td><strong>{esc(r["name"])}</strong></td>'
            f'<td class="mono text-muted">{esc(r["slug"])}</td>'
            f'<td>{esc(r["msp_name"]) if r["msp_name"] else "—"}</td>'
            f'<td class="text-muted">{esc(r["timezone"])}</td>'
            f'<td>{esc(r["contact_email"]) if r["contact_email"] else "—"}</td>'
            f'<td><a href="/tenants/{r["id"]}/edit" class="btn btn-sm btn-outline-primary">Edit</a></td>'
            f'</tr>'
        )
    if not rows_html:
        rows_html = '<tr><td colspan="6" class="text-center text-muted py-3">No tenants yet</td></tr>'

    msp_options = ''.join(f'<option value="{m["id"]}">{m["name"]}</option>' for m in msps)

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">🏢 Tenants</h3>
      <button class="btn btn-ss" data-bs-toggle="modal" data-bs-target="#addModal">+ New Tenant</button>
    </div>
    <div class="card mb-4">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>Name</th><th>Slug</th><th>MSP Profile</th><th>Timezone</th><th>Contact</th><th></th></tr></thead>
          <tbody>{rows_html}</tbody>
        </table>
      </div>
    </div>

    <div class="modal fade" id="addModal" tabindex="-1">
      <div class="modal-dialog"><div class="modal-content" style="background:#0D1629;">
        <div class="modal-header" style="border-color:#1A2A4A;">
          <h5 class="modal-title">New Tenant</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form method="post">
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Company Name *</label>
              <input name="name" class="form-control" required></div>
            <div class="mb-3"><label class="form-label">Slug (URL-safe ID) *</label>
              <input name="slug" class="form-control" placeholder="acme-corp" required></div>
            <div class="mb-3"><label class="form-label">MSP Profile</label>
              <select name="msp_profile_id" class="form-select">
                <option value="">— None —</option>{msp_options}
              </select></div>
            <div class="mb-3"><label class="form-label">Timezone</label>
              <input name="timezone" class="form-control" value="Africa/Johannesburg"></div>
            <div class="row">
              <div class="col"><label class="form-label">Contact Name</label>
                <input name="contact_name" class="form-control"></div>
              <div class="col"><label class="form-label">Contact Email</label>
                <input name="contact_email" type="email" class="form-control"></div>
            </div>
          </div>
          <div class="modal-footer" style="border-color:#1A2A4A;">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-ss">Create</button>
          </div>
        </form>
      </div></div>
    </div>'''
    return page('Tenants', content, 'tenants')


@app.route('/tenants/<int:tenant_id>/edit', methods=['GET', 'POST'])
def tenant_edit(tenant_id: int):
    """Edit a tenant record."""
    t = qone("SELECT * FROM tenants WHERE id = %s", (tenant_id,))
    if not t:
        abort(404)
    if not can_access_tenant(tenant_id):
        abort(403)

    if request.method == 'POST':
        _check_csrf()
        qexec(
            """
            UPDATE tenants
            SET name=%s, slug=%s, msp_profile_id=%s, timezone=%s,
                contact_name=%s, contact_email=%s, identity_enabled=%s
            WHERE id=%s
            """,
            (
                request.form.get('name', '').strip(),
                re.sub(r'[^\w\-]', '-', request.form.get('slug', '').lower().strip()),
                request.form.get('msp_profile_id', type=int),
                request.form.get('timezone', 'Africa/Johannesburg').strip(),
                request.form.get('contact_name', '').strip() or None,
                request.form.get('contact_email', '').strip() or None,
                'identity_enabled' in request.form,
                tenant_id,
            ),
        )
        flash('Tenant updated.', 'success')
        if not _update_grafana_tenants():
            flash('Grafana tenant dropdown could not be updated — run: sudo bash scripts/install-grafana-dashboards.sh', 'warning')
        return redirect(url_for('tenants'))

    msps = qall("SELECT id, name FROM msp_profiles ORDER BY name")
    msp_options = ''.join(
        f'<option value="{m["id"]}" {"selected" if t["msp_profile_id"]==m["id"] else ""}>{m["name"]}</option>'
        for m in msps
    )
    csrf = _csrf_token()

    subnets = qall(
        "SELECT id, subnet::text AS subnet, description FROM tenant_subnets "
        "WHERE tenant_id = %s ORDER BY subnet",
        (tenant_id,),
    )
    subnet_rows = ''
    for s in subnets:
        subnet_rows += (
            f'<tr>'
            f'<td class="font-monospace small">{esc(s["subnet"])}</td>'
            f'<td class="text-muted small">{esc(s["description"] or "")}</td>'
            f'<td>'
            f'<form method="post" action="/tenants/{tenant_id}/subnets/{s["id"]}/delete" style="display:inline">'
            f'<input type="hidden" name="_csrf" value="{csrf}">'
            f'<button class="btn btn-sm btn-outline-danger" '
            f'onclick="return confirm(\'Remove {esc(s["subnet"])}?\')">Remove</button>'
            f'</form>'
            f'</td>'
            f'</tr>'
        )
    if not subnet_rows:
        subnet_rows = '<tr><td colspan="3" class="text-muted text-center py-2">No subnets — used as fallback when firewall IP is not registered</td></tr>'

    sensors = qall(
        "SELECT id, name, vendor, host(ip_address) AS ip_address, model "
        "FROM sensors WHERE tenant_id = %s ORDER BY name",
        (tenant_id,),
    )
    sensor_rows = ''
    for s in sensors:
        ip_badge = (
            f'<span class="badge badge-teal font-monospace">{esc(s["ip_address"])}</span>'
            if s["ip_address"] else
            '<span class="text-muted small">not set</span>'
        )
        sensor_rows += (
            f'<tr>'
            f'<td>{esc(s["name"])}</td>'
            f'<td><span class="badge bg-secondary">{esc(s["vendor"])}</span></td>'
            f'<td>{ip_badge}</td>'
            f'<td class="text-muted small">{esc(s["model"] or "")}</td>'
            f'<td>'
            f'<form method="post" action="/tenants/{tenant_id}/sensors/{s["id"]}/delete" style="display:inline">'
            f'<input type="hidden" name="_csrf" value="{csrf}">'
            f'<button class="btn btn-sm btn-outline-danger" '
            f'onclick="return confirm(\'Remove firewall {esc(s["name"])}?\')">Remove</button>'
            f'</form>'
            f'</td>'
            f'</tr>'
        )
    if not sensor_rows:
        sensor_rows = '<tr><td colspan="5" class="text-muted text-center py-2">No firewalls registered — add one below</td></tr>'

    vendor_options = ''.join(
        f'<option value="{v}">{v.title()}</option>'
        for v in ('sonicwall', 'fortinet', 'sophos', 'checkpoint', 'paloalto', 'other')
    )

    content = f'''
    <h3 class="mb-3">Edit Tenant: {esc(t["name"])}</h3>
    <div class="row g-4">

      <div class="col-md-4">
        <div class="card p-4">
          <h6 class="text-muted mb-3">TENANT DETAILS</h6>
          <form method="post">
            <input type="hidden" name="_csrf" value="{csrf}">
            <div class="mb-3"><label class="form-label">Company Name</label>
              <input name="name" class="form-control" value="{esc(t["name"])}" required></div>
            <div class="mb-3"><label class="form-label">Slug</label>
              <input name="slug" class="form-control" value="{esc(t["slug"])}" required></div>
            <div class="mb-3"><label class="form-label">MSP Profile</label>
              <select name="msp_profile_id" class="form-select">
                <option value="">— None —</option>{msp_options}
              </select></div>
            <div class="mb-3"><label class="form-label">Timezone</label>
              <input name="timezone" class="form-control" value="{esc(t["timezone"])}"></div>
            <div class="row mb-3">
              <div class="col"><label class="form-label">Contact Name</label>
                <input name="contact_name" class="form-control" value="{esc(t["contact_name"] or "")}"></div>
              <div class="col"><label class="form-label">Contact Email</label>
                <input name="contact_email" type="email" class="form-control" value="{esc(t["contact_email"] or "")}"></div>
            </div>
            <div class="mb-3">
              <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" name="identity_enabled"
                       id="identity_enabled" {"checked" if t.get("identity_enabled", True) else ""}>
                <label class="form-check-label" for="identity_enabled">
                  <strong>Identity mapping enabled</strong>
                  <span class="text-muted small d-block">
                    When on, reports resolve IPs to user names using the identity database.
                    Turn off for privacy/compliance deployments that must show raw IPs only.
                  </span>
                </label>
              </div>
            </div>
            <button type="submit" class="btn btn-ss">Save Changes</button>
            <a href="/tenants" class="btn btn-outline-secondary ms-2">Cancel</a>
          </form>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card p-4">
          <h6 class="text-muted mb-3">🔥 REGISTERED FIREWALLS</h6>
          <p class="small text-muted mb-3">
            Register each firewall that sends IPFIX or syslog for this tenant.
            The collector uses the source IP to route flows to the correct tenant —
            this works even when multiple tenants share the same internal subnets.
          </p>
          <div class="table-responsive mb-3">
            <table class="table table-sm mb-0">
              <thead><tr><th>Name</th><th>Vendor</th><th>Source IP</th><th>Model</th><th></th></tr></thead>
              <tbody>{sensor_rows}</tbody>
            </table>
          </div>
          <form method="post" action="/tenants/{tenant_id}/sensors/add">
            <input type="hidden" name="_csrf" value="{csrf}">
            <div class="row g-2">
              <div class="col-12">
                <input name="name" class="form-control form-control-sm"
                       placeholder="Firewall name (e.g. HQ Firewall)" required>
              </div>
              <div class="col-6">
                <select name="vendor" class="form-select form-select-sm">{vendor_options}</select>
              </div>
              <div class="col-6">
                <input name="ip_address" class="form-control form-control-sm font-monospace"
                       placeholder="Source IP (e.g. 10.0.0.1)" required>
              </div>
              <div class="col-12">
                <input name="model" class="form-control form-control-sm"
                       placeholder="Model (optional, e.g. NSa 2700)">
              </div>
              <div class="col-12">
                <button type="submit" class="btn btn-ss btn-sm w-100">Register Firewall</button>
              </div>
            </div>
          </form>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card p-4">
          <h6 class="text-muted mb-3">🌐 IP SUBNETS (FALLBACK)</h6>
          <p class="small text-muted mb-3">
            Optional fallback for flows from unregistered firewalls.
            If a flow arrives from an unknown source IP, the internal
            src IP is checked against these subnets. Most-specific match wins.
          </p>
          <div class="table-responsive mb-3">
            <table class="table table-sm mb-0">
              <thead><tr><th>Subnet</th><th>Description</th><th></th></tr></thead>
              <tbody>{subnet_rows}</tbody>
            </table>
          </div>
          <form method="post" action="/tenants/{tenant_id}/subnets/add">
            <input type="hidden" name="_csrf" value="{csrf}">
            <div class="input-group input-group-sm">
              <input name="subnet" class="form-control font-monospace"
                     placeholder="192.168.10.0/24" required
                     pattern="^[\\d.:a-fA-F]+/\\d+$">
              <input name="description" class="form-control" placeholder="Description">
              <button type="submit" class="btn btn-ss">Add</button>
            </div>
          </form>
        </div>
      </div>

    </div>'''
    return page(f'Edit Tenant — {esc(t["name"])}', content, 'tenants')


@app.route('/tenants/<int:tenant_id>/sensors/add', methods=['POST'])
def tenant_sensor_add(tenant_id: int):
    """Register a firewall as a flow source for a tenant."""
    _check_csrf()
    if not qone("SELECT id FROM tenants WHERE id = %s", (tenant_id,)):
        abort(404)
    if not can_access_tenant(tenant_id):
        abort(403)
    name = request.form.get('name', '').strip()
    vendor = request.form.get('vendor', 'sonicwall').strip()
    ip_raw = request.form.get('ip_address', '').strip()
    model = request.form.get('model', '').strip() or None

    if not name:
        flash('Firewall name is required.', 'error')
        return redirect(url_for('tenant_edit', tenant_id=tenant_id))

    import ipaddress as _ia
    try:
        ip_address = str(_ia.ip_address(ip_raw))
    except ValueError:
        flash(f'"{ip_raw}" is not a valid IP address.', 'error')
        return redirect(url_for('tenant_edit', tenant_id=tenant_id))

    existing = qone("SELECT id FROM sensors WHERE ip_address = %s::inet", (ip_address,))
    if existing:
        flash(f'{ip_address} is already registered as a flow source.', 'error')
        return redirect(url_for('tenant_edit', tenant_id=tenant_id))

    qinsert(
        """
        INSERT INTO sensors (tenant_id, name, vendor, ip_address, model, data_sources)
        VALUES (%s, %s, %s, %s::inet, %s, %s) RETURNING id
        """,
        (tenant_id, name, vendor, ip_address, model, ['ipfix', 'syslog']),
    )
    flash(f'Firewall "{name}" ({ip_address}) registered.', 'success')
    if not _update_collector_allowlist():
        flash('collector.env allowlist could not be updated — add the IP manually and restart ss-collector.', 'warning')
    return redirect(url_for('tenant_edit', tenant_id=tenant_id))


@app.route('/tenants/<int:tenant_id>/sensors/<int:sensor_id>/delete', methods=['POST'])
def tenant_sensor_delete(tenant_id: int, sensor_id: int):
    """Remove a registered firewall from a tenant."""
    _check_csrf()
    if not can_access_tenant(tenant_id):
        abort(403)
    qexec(
        "DELETE FROM sensors WHERE id = %s AND tenant_id = %s",
        (sensor_id, tenant_id),
    )
    flash('Firewall removed.', 'success')
    _update_collector_allowlist()
    return redirect(url_for('tenant_edit', tenant_id=tenant_id))


@app.route('/tenants/<int:tenant_id>/subnets/add', methods=['POST'])
def tenant_subnet_add(tenant_id: int):
    """Add a subnet to a tenant."""
    _check_csrf()
    if not qone("SELECT id FROM tenants WHERE id = %s", (tenant_id,)):
        abort(404)
    if not can_access_tenant(tenant_id):
        abort(403)
    raw = request.form.get('subnet', '').strip()
    description = request.form.get('description', '').strip() or None
    import ipaddress
    try:
        net = ipaddress.ip_network(raw, strict=False)
        subnet_cidr = str(net)
    except ValueError:
        flash(f'"{raw}" is not a valid CIDR subnet.', 'error')
        return redirect(url_for('tenant_edit', tenant_id=tenant_id))
    try:
        qinsert(
            "INSERT INTO tenant_subnets (tenant_id, subnet, description) "
            "VALUES (%s, %s::cidr, %s) RETURNING id",
            (tenant_id, subnet_cidr, description),
        )
        flash(f'Subnet {subnet_cidr} added.', 'success')
    except psycopg2.IntegrityError:
        get_db().rollback()
        flash(f'Subnet {subnet_cidr} is already assigned to this tenant.', 'error')
    return redirect(url_for('tenant_edit', tenant_id=tenant_id))


@app.route('/tenants/<int:tenant_id>/subnets/<int:subnet_id>/delete', methods=['POST'])
def tenant_subnet_delete(tenant_id: int, subnet_id: int):
    """Remove a subnet from a tenant."""
    _check_csrf()
    if not can_access_tenant(tenant_id):
        abort(403)
    qexec(
        "DELETE FROM tenant_subnets WHERE id = %s AND tenant_id = %s",
        (subnet_id, tenant_id),
    )
    flash('Subnet removed.', 'success')
    return redirect(url_for('tenant_edit', tenant_id=tenant_id))


# ── Admin — user management ───────────────────────────────────────────────────

@app.route('/admin/users')
@require_admin
def admin_users():
    users = qall("""
        SELECT u.id, u.email, u.full_name, u.role, u.is_active, u.last_login,
               COUNT(ut.tenant_id) AS tenant_count
        FROM ui_users u
        LEFT JOIN ui_user_tenants ut ON ut.user_id = u.id
        GROUP BY u.id ORDER BY u.role, u.full_name
    """)
    rows = ''
    for u in users:
        role_badge = (
            '<span class="badge badge-teal">admin</span>'
            if u['role'] == 'admin' else
            '<span class="badge bg-secondary">user</span>'
        )
        active_badge = (
            '<span class="badge bg-success">Active</span>'
            if u['is_active'] else
            '<span class="badge bg-danger">Inactive</span>'
        )
        last = u['last_login'].strftime('%d %b %Y %H:%M') if u['last_login'] else 'Never'
        rows += (
            f'<tr>'
            f'<td>{esc(u["full_name"])}</td>'
            f'<td class="text-muted">{esc(u["email"])}</td>'
            f'<td>{role_badge}</td>'
            f'<td class="text-muted">{u["tenant_count"] if u["role"] != "admin" else "All"}</td>'
            f'<td>{active_badge}</td>'
            f'<td class="text-muted small">{last}</td>'
            f'<td>'
            f'<a href="/admin/users/{u["id"]}/edit" class="btn btn-sm btn-outline-primary me-1">Edit</a>'
            f'</td>'
            f'</tr>'
        )
    if not rows:
        rows = '<tr><td colspan="7" class="text-center text-muted py-3">No users</td></tr>'

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">👥 Users</h3>
      <a href="/admin/users/new" class="btn btn-ss">+ New User</a>
    </div>
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr>
            <th>Name</th><th>Email</th><th>Role</th>
            <th>Tenants</th><th>Status</th><th>Last Login</th><th></th>
          </tr></thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
    </div>'''
    return page('Users', content, 'admin_users')


@app.route('/admin/users/new', methods=['GET', 'POST'])
@require_admin
def admin_user_new():
    tenants = qall("SELECT id, name FROM tenants ORDER BY name")
    if request.method == 'POST':
        _check_csrf()
        email = request.form.get('email', '').strip().lower()
        full_name = request.form.get('full_name', '').strip()
        role = request.form.get('role', 'user').strip()
        if role not in ('admin', 'user'):
            role = 'user'
        tenant_ids = request.form.getlist('tenant_ids', type=int)

        password = request.form.get('password', '').strip()
        if not email or not full_name:
            flash('Email and name are required.', 'error')
            return redirect(url_for('admin_user_new'))
        if len(password) < 8:
            flash('Password must be at least 8 characters.', 'error')
            return redirect(url_for('admin_user_new'))

        try:
            uid = qinsert(
                "INSERT INTO ui_users (email, full_name, role, password_hash) "
                "VALUES (%s, %s, %s, %s) RETURNING id",
                (email, full_name, role, generate_password_hash(password)),
            )
        except psycopg2.IntegrityError:
            get_db().rollback()
            flash(f'Email {email} is already registered.', 'error')
            return redirect(url_for('admin_user_new'))

        if role == 'user':
            for tid in tenant_ids:
                try:
                    qexec("INSERT INTO ui_user_tenants (user_id, tenant_id) VALUES (%s, %s)",
                          (uid, tid))
                except psycopg2.IntegrityError:
                    get_db().rollback()

        flash(f'User {full_name} created. They can sign in at /login with their email and the password you set.', 'success')
        return redirect(url_for('admin_users'))

    tenant_checkboxes = ''.join(
        f'<div class="form-check">'
        f'<input class="form-check-input" type="checkbox" name="tenant_ids" value="{t["id"]}" id="t{t["id"]}">'
        f'<label class="form-check-label" for="t{t["id"]}">{esc(t["name"])}</label>'
        f'</div>'
        for t in tenants
    )
    content = f'''
    <h3 class="mb-3">👥 New User</h3>
    <div class="card p-4" style="max-width:560px;">
      <form method="post">
        <div class="mb-3"><label class="form-label">Full Name *</label>
          <input name="full_name" class="form-control" required autofocus></div>
        <div class="mb-3"><label class="form-label">Email *</label>
          <input name="email" type="email" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Password * <span class="text-muted small">(min 8 chars)</span></label>
          <input name="password" type="password" class="form-control" required minlength="8"></div>
        <div class="mb-3"><label class="form-label">Role</label>
          <select name="role" class="form-select" id="role_select"
                  onchange="document.getElementById('tenant_section').style.display=this.value==='user'?'':'none'">
            <option value="user">User — restricted to assigned tenants</option>
            <option value="admin">Admin — full access to everything</option>
          </select>
        </div>
        <div id="tenant_section" class="mb-3">
          <label class="form-label">Tenant Access</label>
          <div class="card p-3" style="background:#131F38;">
            {tenant_checkboxes if tenant_checkboxes else '<span class="text-muted small">No tenants yet</span>'}
          </div>
          <div class="form-text text-muted">Select which tenants this user can access.</div>
        </div>
        <button type="submit" class="btn btn-ss">Create User</button>
        <a href="/admin/users" class="btn btn-outline-secondary ms-2">Cancel</a>
      </form>
    </div>'''
    return page('New User', content, 'admin_users')


@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@require_admin
def admin_user_edit(user_id: int):
    u = qone("SELECT * FROM ui_users WHERE id = %s", (user_id,))
    if not u:
        abort(404)
    tenants = qall("SELECT id, name FROM tenants ORDER BY name")
    assigned = {r['tenant_id'] for r in qall(
        "SELECT tenant_id FROM ui_user_tenants WHERE user_id = %s", (user_id,)
    )}

    if request.method == 'POST':
        _check_csrf()
        action = request.form.get('action', 'save')

        if action == 'delete':
            if u['id'] == session.get('user_id'):
                flash('You cannot delete your own account.', 'error')
                return redirect(url_for('admin_user_edit', user_id=user_id))
            qexec("DELETE FROM ui_users WHERE id = %s", (user_id,))
            flash(f'User {u["full_name"]} deleted.', 'success')
            return redirect(url_for('admin_users'))

        if action == 'toggle_active':
            qexec("UPDATE ui_users SET is_active = NOT is_active WHERE id = %s", (user_id,))
            flash('Account status updated.', 'success')
            return redirect(url_for('admin_user_edit', user_id=user_id))

        if action == 'reset_password':
            new_pw = request.form.get('new_password', '').strip()
            if len(new_pw) < 8:
                flash('Password must be at least 8 characters.', 'error')
            else:
                qexec("UPDATE ui_users SET password_hash = %s WHERE id = %s",
                      (generate_password_hash(new_pw), user_id))
                flash(f"Password updated for {u['full_name']}.", 'success')
            return redirect(url_for('admin_user_edit', user_id=user_id))

        # save
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip().lower()
        role = request.form.get('role', 'user').strip()
        if role not in ('admin', 'user'):
            role = 'user'
        new_tenant_ids = set(request.form.getlist('tenant_ids', type=int))

        try:
            qexec(
                "UPDATE ui_users SET full_name=%s, email=%s, role=%s WHERE id=%s",
                (full_name, email, role, user_id),
            )
        except psycopg2.IntegrityError:
            get_db().rollback()
            flash('Email already in use by another account.', 'error')
            return redirect(url_for('admin_user_edit', user_id=user_id))

        # Sync tenant assignments
        qexec("DELETE FROM ui_user_tenants WHERE user_id = %s", (user_id,))
        if role == 'user':
            for tid in new_tenant_ids:
                try:
                    qexec("INSERT INTO ui_user_tenants (user_id, tenant_id) VALUES (%s, %s)",
                          (user_id, tid))
                except psycopg2.IntegrityError:
                    get_db().rollback()

        flash('User updated.', 'success')
        return redirect(url_for('admin_user_edit', user_id=user_id))

    role_options = ''.join(
        f'<option value="{r}" {"selected" if u["role"]==r else ""}>{r.title()}</option>'
        for r in ('user', 'admin')
    )
    tenant_checkboxes = ''.join(
        f'<div class="form-check">'
        f'<input class="form-check-input" type="checkbox" name="tenant_ids" value="{t["id"]}" '
        f'id="t{t["id"]}" {"checked" if t["id"] in assigned else ""}>'
        f'<label class="form-check-label" for="t{t["id"]}">{esc(t["name"])}</label>'
        f'</div>'
        for t in tenants
    )
    active_badge = 'Active' if u['is_active'] else 'Inactive'
    active_btn_cls = 'btn-outline-warning' if u['is_active'] else 'btn-outline-success'
    active_btn_txt = 'Deactivate' if u['is_active'] else 'Activate'
    self_edit = u['id'] == session.get('user_id')

    content = f'''
    <h3 class="mb-3">Edit User: {esc(u["full_name"])}</h3>
    <div class="row g-4">
      <div class="col-md-6">
        <div class="card p-4">
          <h6 class="text-muted mb-3">USER DETAILS</h6>
          <form method="post">
            <input type="hidden" name="action" value="save">
            <div class="mb-3"><label class="form-label">Full Name</label>
              <input name="full_name" class="form-control" value="{esc(u["full_name"])}" required></div>
            <div class="mb-3"><label class="form-label">Email</label>
              <input name="email" type="email" class="form-control" value="{esc(u["email"])}" required></div>
            <div class="mb-3"><label class="form-label">Role</label>
              <select name="role" class="form-select" id="role_select"
                      onchange="document.getElementById('tenant_section').style.display=this.value==='user'?'':'none'">
                {role_options}
              </select>
            </div>
            <div id="tenant_section" class="mb-3" {"style='display:none'" if u["role"]=="admin" else ""}>
              <label class="form-label">Tenant Access</label>
              <div class="card p-3" style="background:#131F38;">
                {tenant_checkboxes if tenant_checkboxes else '<span class="text-muted small">No tenants yet</span>'}
              </div>
            </div>
            <button type="submit" class="btn btn-ss">Save Changes</button>
            <a href="/admin/users" class="btn btn-outline-secondary ms-2">Cancel</a>
          </form>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card p-4">
          <h6 class="text-muted mb-3">ACCOUNT ACTIONS</h6>
          <p class="text-muted small mb-3">Status: <strong>{active_badge}</strong></p>
          <form method="post" class="d-inline">
            <input type="hidden" name="action" value="toggle_active">
            <button class="btn {active_btn_cls} me-2">{active_btn_txt}</button>
          </form>
          {"" if self_edit else f'''
          <form method="post" class="d-inline"
                onsubmit="return confirm('Delete {esc(u["full_name"])}? This cannot be undone.')">
            <input type="hidden" name="action" value="delete">
            <button class="btn btn-outline-danger">Delete User</button>
          </form>'''}
          {('<p class="text-muted small mt-3">You cannot delete or deactivate your own account.</p>' if self_edit else '')}
          <hr style="border-color:#1A2A4A;">
          <h6 class="text-muted mb-2">RESET PASSWORD</h6>
          <form method="post">
            <input type="hidden" name="action" value="reset_password">
            <input name="new_password" type="password" class="form-control mb-2"
                   placeholder="New password (min 8 chars)" required minlength="8">
            <button class="btn btn-outline-warning btn-sm">Set New Password</button>
          </form>
        </div>
      </div>
    </div>'''
    return page(f'Edit User — {esc(u["full_name"])}', content, 'admin_users')


@app.route('/msp-profiles', methods=['GET', 'POST'])
@require_admin
def msp_profiles():
    """List MSP profiles and create new ones."""
    if request.method == 'POST':
        _check_csrf()
        name = request.form.get('name', '').strip()
        if not name:
            flash('Profile name is required.', 'error')
            return redirect(url_for('msp_profiles'))

        qinsert(
            """
            INSERT INTO msp_profiles
                (name, primary_color, secondary_color, contact_name, contact_email,
                 contact_phone, website, footer_text)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id
            """,
            (
                name,
                request.form.get('primary_color', '#378ADD').strip(),
                request.form.get('secondary_color', '#00C9A7').strip(),
                request.form.get('contact_name', '').strip() or None,
                request.form.get('contact_email', '').strip() or None,
                request.form.get('contact_phone', '').strip() or None,
                request.form.get('website', '').strip() or None,
                request.form.get('footer_text', '').strip() or None,
            ),
        )
        flash(f'MSP profile "{name}" created.', 'success')
        return redirect(url_for('msp_profiles'))

    rows = qall("SELECT * FROM msp_profiles ORDER BY name")

    rows_html = ''
    for r in rows:
        safe_color = esc(r["primary_color"] or '#378ADD')
        color_dot = (
            f'<span style="display:inline-block;width:14px;height:14px;'
            f'background:{safe_color};border-radius:3px;vertical-align:middle;margin-right:5px;"></span>'
        )
        rows_html += (
            f'<tr>'
            f'<td><strong>{esc(r["name"])}</strong></td>'
            f'<td>{color_dot}{safe_color}</td>'
            f'<td>{esc(r["contact_email"]) if r["contact_email"] else "—"}</td>'
            f'<td>{esc(r["website"]) if r["website"] else "—"}</td>'
            f'<td>'
            f'<a href="/msp-profiles/{r["id"]}/edit" class="btn btn-sm btn-outline-primary me-1">Edit</a>'
            f'</td>'
            f'</tr>'
        )
    if not rows_html:
        rows_html = '<tr><td colspan="5" class="text-center text-muted py-3">No MSP profiles yet</td></tr>'

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">🎨 MSP Profiles</h3>
      <button class="btn btn-ss" data-bs-toggle="modal" data-bs-target="#addModal">+ New Profile</button>
    </div>
    <div class="card mb-4">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr><th>Name</th><th>Accent Colour</th><th>Email</th><th>Website</th><th></th></tr></thead>
          <tbody>{rows_html}</tbody>
        </table>
      </div>
    </div>

    <div class="modal fade" id="addModal" tabindex="-1">
      <div class="modal-dialog"><div class="modal-content" style="background:#0D1629;">
        <div class="modal-header" style="border-color:#1A2A4A;">
          <h5 class="modal-title">New MSP Profile</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form method="post">
          <div class="modal-body">
            <div class="mb-3"><label class="form-label">Profile Name *</label>
              <input name="name" class="form-control" required placeholder="Acme IT Solutions"></div>
            <div class="row mb-3">
              <div class="col"><label class="form-label">Primary Colour</label>
                <input name="primary_color" type="color" class="form-control form-control-color" value="#378ADD"></div>
              <div class="col"><label class="form-label">Secondary Colour</label>
                <input name="secondary_color" type="color" class="form-control form-control-color" value="#00C9A7"></div>
            </div>
            <div class="mb-3"><label class="form-label">Contact Name</label>
              <input name="contact_name" class="form-control"></div>
            <div class="mb-3"><label class="form-label">Contact Email</label>
              <input name="contact_email" type="email" class="form-control"></div>
            <div class="mb-3"><label class="form-label">Phone</label>
              <input name="contact_phone" class="form-control"></div>
            <div class="mb-3"><label class="form-label">Website</label>
              <input name="website" class="form-control" placeholder="https://"></div>
            <div class="mb-3"><label class="form-label">Report Footer Text</label>
              <input name="footer_text" class="form-control" placeholder="Optional custom footer line"></div>
          </div>
          <div class="modal-footer" style="border-color:#1A2A4A;">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-ss">Create</button>
          </div>
        </form>
      </div></div>
    </div>'''
    return page('MSP Profiles', content, 'msp')


@app.route('/msp-profiles/<int:profile_id>/edit', methods=['GET', 'POST'])
@require_admin
def msp_profile_edit(profile_id: int):
    """Edit an MSP profile, including logo upload."""
    m = qone("SELECT * FROM msp_profiles WHERE id = %s", (profile_id,))
    if not m:
        abort(404)

    if request.method == 'POST':
        _check_csrf()
        logo_path = m['logo_path']

        # Handle logo upload
        logo_file = request.files.get('logo')
        if logo_file and logo_file.filename:
            ext = logo_file.filename.rsplit('.', 1)[-1].lower() if '.' in logo_file.filename else ''
            if ext not in ALLOWED_LOGO_EXTS or logo_file.mimetype not in ALLOWED_LOGO_MIMETYPES:
                flash('Logo must be PNG, JPG, or SVG.', 'error')
                return redirect(url_for('msp_profile_edit', profile_id=profile_id))
            os.makedirs(LOGO_DIR, exist_ok=True)
            safe_name = secure_filename(f"msp_{profile_id}.{ext}")
            logo_path = os.path.join(LOGO_DIR, safe_name)
            if ext == 'svg':
                raw = logo_file.read()
                try:
                    cleaned = _sanitise_svg(raw)
                except ValueError:
                    flash('SVG file is not valid XML and could not be sanitised.', 'error')
                    return redirect(url_for('msp_profile_edit', profile_id=profile_id))
                with open(logo_path, 'wb') as fh:
                    fh.write(cleaned)
            else:
                logo_file.save(logo_path)

        qexec(
            """
            UPDATE msp_profiles
            SET name=%s, logo_path=%s, primary_color=%s, secondary_color=%s,
                contact_name=%s, contact_email=%s, contact_phone=%s,
                website=%s, footer_text=%s, updated_at=NOW()
            WHERE id=%s
            """,
            (
                request.form.get('name', '').strip(),
                logo_path,
                request.form.get('primary_color', '#378ADD').strip(),
                request.form.get('secondary_color', '#00C9A7').strip(),
                request.form.get('contact_name', '').strip() or None,
                request.form.get('contact_email', '').strip() or None,
                request.form.get('contact_phone', '').strip() or None,
                request.form.get('website', '').strip() or None,
                request.form.get('footer_text', '').strip() or None,
                profile_id,
            ),
        )
        flash('MSP profile updated.', 'success')
        return redirect(url_for('msp_profiles'))

    logo_preview = (
        f'<img src="/logos/{os.path.basename(m["logo_path"])}" style="max-height:60px;border-radius:4px;" class="mb-2"><br>'
        if m.get('logo_path') and os.path.isfile(m['logo_path']) else ''
    )
    content = f'''
    <h3 class="mb-3">Edit MSP Profile: {esc(m["name"])}</h3>
    <div class="card p-4" style="max-width:640px;">
      <form method="post" enctype="multipart/form-data">
        <div class="mb-3"><label class="form-label">Profile Name *</label>
          <input name="name" class="form-control" value="{esc(m["name"])}" required></div>
        <div class="mb-3"><label class="form-label">Logo (PNG / JPG / SVG)</label>
          {logo_preview}
          <input name="logo" type="file" class="form-control" accept=".png,.jpg,.jpeg,.svg">
          <small class="text-muted">Leave blank to keep existing logo</small>
        </div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Primary Colour</label>
            <input name="primary_color" type="color" class="form-control form-control-color"
                   value="{m["primary_color"] or "#378ADD"}"></div>
          <div class="col"><label class="form-label">Secondary Colour</label>
            <input name="secondary_color" type="color" class="form-control form-control-color"
                   value="{m["secondary_color"] or "#00C9A7"}"></div>
        </div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Contact Name</label>
            <input name="contact_name" class="form-control" value="{m["contact_name"] or ""}"></div>
          <div class="col"><label class="form-label">Contact Email</label>
            <input name="contact_email" type="email" class="form-control" value="{m["contact_email"] or ""}"></div>
        </div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Phone</label>
            <input name="contact_phone" class="form-control" value="{m["contact_phone"] or ""}"></div>
          <div class="col"><label class="form-label">Website</label>
            <input name="website" class="form-control" value="{m["website"] or ""}"></div>
        </div>
        <div class="mb-3"><label class="form-label">Footer Text</label>
          <input name="footer_text" class="form-control" value="{m["footer_text"] or ""}"></div>
        <button type="submit" class="btn btn-ss">Save Changes</button>
        <a href="/msp-profiles" class="btn btn-outline-secondary ms-2">Cancel</a>
      </form>
    </div>'''
    return page(f'Edit MSP Profile — {esc(m["name"])}', content, 'msp')


@app.route('/logos/<filename>')
def serve_logo(filename: str):
    """Serve uploaded MSP logo files."""
    safe = secure_filename(filename)
    full_path = os.path.join(LOGO_DIR, safe)
    real_path = os.path.realpath(full_path)
    real_logo_dir = os.path.realpath(LOGO_DIR)
    if not real_path.startswith(real_logo_dir + os.sep):
        abort(403)
    if not os.path.isfile(real_path):
        abort(404)
    # SVG served as attachment so browsers do not execute inline scripts when
    # the URL is navigated to directly. <img src> tags still render it correctly.
    is_svg = safe.lower().endswith('.svg')
    return send_file(
        real_path,
        as_attachment=is_svg,
        download_name=safe if is_svg else None,
    )


_DOW_OPTIONS = [
    ('mon', 'Monday'), ('tue', 'Tuesday'), ('wed', 'Wednesday'),
    ('thu', 'Thursday'), ('fri', 'Friday'), ('sat', 'Saturday'), ('sun', 'Sunday'),
]
_DOM_OPTIONS = [
    (str(i), f'{i}{"st" if i == 1 else "nd" if i == 2 else "rd" if i == 3 else "th"}')
    for i in range(1, 29)
]


def _cron_to_friendly(cron_expr: str) -> dict:
    """Parse a stored 5-field cron into friendly display values."""
    parts = cron_expr.strip().split()
    if len(parts) != 5:
        return {'label': cron_expr, 'freq': 'daily', 'hour': 6, 'dow': 'mon', 'dom': '1'}
    _minute, hour, day, month, dow = parts
    try:
        h = int(hour)
    except ValueError:
        h = 6
    if day == '*' and month == '*' and dow == '*':
        return {'label': f'Daily at {h:02d}:00', 'freq': 'daily', 'hour': h, 'dow': 'mon', 'dom': '1'}
    if day == '*' and month == '*' and dow != '*':
        day_name = dict(_DOW_OPTIONS).get(dow.lower(), dow.capitalize())
        return {'label': f'Every {day_name} at {h:02d}:00', 'freq': 'weekly',
                'hour': h, 'dow': dow.lower(), 'dom': '1'}
    if day != '*' and month == '*' and dow == '*':
        sfx = 'st' if day == '1' else 'nd' if day == '2' else 'rd' if day == '3' else 'th'
        return {'label': f'Monthly on the {day}{sfx} at {h:02d}:00', 'freq': 'monthly',
                'hour': h, 'dow': 'mon', 'dom': day}
    return {'label': cron_expr, 'freq': 'daily', 'hour': h, 'dow': 'mon', 'dom': '1'}


def _friendly_to_cron(freq: str, hour: int, dow: str = 'mon', dom: str = '1') -> str:
    """Build a 5-field cron string from friendly inputs."""
    if freq == 'daily':
        return f'0 {hour} * * *'
    if freq == 'weekly':
        return f'0 {hour} * * {dow}'
    if freq == 'monthly':
        return f'0 {hour} {dom} * *'
    raise ValueError(f'Unknown frequency: {freq!r}')


def _schedule_form_fields(vals: dict | None = None) -> str:
    """Return inner HTML (no <form> tag) for schedule create/edit form."""
    v = {'freq': 'monthly', 'hour': 7, 'dow': 'mon', 'dom': '1'}
    if vals:
        v.update(vals)
    freq = v.get('freq', 'monthly')
    hour = int(v.get('hour', 7))
    dow = str(v.get('dow', 'mon'))
    dom = str(v.get('dom', '1'))

    hour_opts = ''.join(
        f'<option value="{h}"{" selected" if h == hour else ""}>{h:02d}:00</option>'
        for h in range(24)
    )
    dow_opts = ''.join(
        f'<option value="{dv}"{" selected" if dv == dow else ""}>{dl}</option>'
        for dv, dl in _DOW_OPTIONS
    )
    dom_opts = ''.join(
        f'<option value="{dv}"{" selected" if dv == dom else ""}>{dl}</option>'
        for dv, dl in _DOM_OPTIONS
    )
    dow_style = '' if freq == 'weekly' else ' style="display:none"'
    dom_style = '' if freq == 'monthly' else ' style="display:none"'
    daily_sel = ' selected' if freq == 'daily' else ''
    weekly_sel = ' selected' if freq == 'weekly' else ''
    monthly_sel = ' selected' if freq == 'monthly' else ''

    return (
        '<div class="row mb-3">'
        '<div class="col"><label class="form-label">Frequency *</label>'
        '<select name="freq" class="form-select" required'
        ' onchange="ssOnFreqChange(this.value)">'
        f'<option value="daily"{daily_sel}>Daily</option>'
        f'<option value="weekly"{weekly_sel}>Weekly</option>'
        f'<option value="monthly"{monthly_sel}>Monthly</option>'
        '</select></div>'
        '<div class="col"><label class="form-label">Delivery Time *</label>'
        f'<select name="hour" class="form-select" required>{hour_opts}</select>'
        '</div></div>'
        f'<div class="row mb-3" id="ssRowDow"{dow_style}>'
        '<div class="col-6"><label class="form-label">Day of Week</label>'
        f'<select name="dow" class="form-select">{dow_opts}</select>'
        '</div></div>'
        f'<div class="row mb-3" id="ssRowDom"{dom_style}>'
        '<div class="col-6"><label class="form-label">Day of Month</label>'
        f'<select name="dom" class="form-select">{dom_opts}</select>'
        '</div></div>'
        '<script>function ssOnFreqChange(v){'
        'document.getElementById("ssRowDow").style.display=(v==="weekly")?"":"none";'
        'document.getElementById("ssRowDom").style.display=(v==="monthly")?"":"none";'
        '}</script>'
    )


def _parse_schedule_post() -> tuple[int | None, int | None, str, str, str, str, str, str]:
    """Extract and validate schedule form fields. Returns (tenant_id, msp_id, report_type,
    cron_expr, recipient_name, emails_raw, error_msg, redirect_target)."""
    tenant_id = request.form.get('tenant_id', type=int)
    msp_id = request.form.get('msp_profile_id', type=int)
    report_type = request.form.get('report_type', '').strip()
    freq = request.form.get('freq', '').strip()
    hour_str = request.form.get('hour', '').strip()
    dow = request.form.get('dow', 'mon').strip()
    dom = request.form.get('dom', '1').strip()
    recipient_name = request.form.get('recipient_name', '').strip()
    emails_raw = request.form.get('recipient_emails', '').strip()

    if not all([tenant_id, report_type, freq, hour_str, emails_raw]):
        return None, None, '', '', '', emails_raw, \
            'Tenant, report type, frequency, time, and recipients are required.', ''
    try:
        hour = int(hour_str)
        if not 0 <= hour <= 23:
            raise ValueError
    except ValueError:
        return None, None, '', '', '', emails_raw, 'Invalid delivery time.', ''
    if freq == 'weekly' and not dow:
        return None, None, '', '', '', emails_raw, 'Day of week is required for weekly schedules.', ''
    try:
        cron_expr = _friendly_to_cron(freq, hour, dow, dom or '1')
    except ValueError as exc:
        return None, None, '', '', '', emails_raw, str(exc), ''
    return tenant_id, msp_id, report_type, cron_expr, recipient_name, emails_raw, '', ''


@app.route('/schedules', methods=['GET', 'POST'])
def schedules():
    """List report schedules and create new ones."""
    if request.method == 'POST':
        _check_csrf()
        tenant_id, msp_id, report_type, cron_expr, recipient_name, emails_raw, err, _ = \
            _parse_schedule_post()
        if err:
            flash(err, 'error')
            return redirect(url_for('schedules'))

        emails = [e.strip() for e in re.split(r'[,\s]+', emails_raw) if e.strip()]
        schedule_id = qinsert(
            """
            INSERT INTO report_schedules
                (tenant_id, msp_profile_id, report_type, schedule_cron,
                 recipient_name, recipient_emails, is_active)
            VALUES (%s, %s, %s, %s, %s, %s, TRUE) RETURNING id
            """,
            (tenant_id, msp_id, report_type, cron_expr, recipient_name or None, emails),
        )
        if _scheduler:
            reload_schedules(_scheduler, DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)
        flash(f'Schedule #{schedule_id} created and activated.', 'success')
        return redirect(url_for('schedules'))

    allowed = user_tenant_ids()
    if is_admin():
        rows = qall(
            """
            SELECT rs.id, rs.report_type, rs.schedule_cron, rs.recipient_name,
                   rs.recipient_emails, rs.is_active, rs.last_run_at,
                   t.name AS tenant_name, m.name AS msp_name
            FROM report_schedules rs
            JOIN tenants t ON t.id = rs.tenant_id
            LEFT JOIN msp_profiles m ON m.id = rs.msp_profile_id
            ORDER BY rs.id DESC
            """
        )
    else:
        rows = qall(
            """
            SELECT rs.id, rs.report_type, rs.schedule_cron, rs.recipient_name,
                   rs.recipient_emails, rs.is_active, rs.last_run_at,
                   t.name AS tenant_name, m.name AS msp_name
            FROM report_schedules rs
            JOIN tenants t ON t.id = rs.tenant_id
            LEFT JOIN msp_profiles m ON m.id = rs.msp_profile_id
            WHERE rs.tenant_id = ANY(%s)
            ORDER BY rs.id DESC
            """,
            (allowed,),
        )
    tenants = qall("SELECT id, name, msp_profile_id FROM tenants ORDER BY name")
    msps = qall("SELECT id, name FROM msp_profiles ORDER BY name")

    rows_html = ''
    for r in rows:
        friendly = _cron_to_friendly(r['schedule_cron'])
        active_badge = (
            '<span class="badge bg-success">Active</span>'
            if r['is_active'] else '<span class="badge bg-secondary">Paused</span>'
        )
        toggle_label = 'Pause' if r['is_active'] else 'Activate'
        last_run = r['last_run_at'].strftime('%d %b %Y %H:%M') if r.get('last_run_at') else 'Never'
        rows_html += (
            f'<tr>'
            f'<td>{r["tenant_name"]}</td>'
            f'<td><span class="badge badge-teal">{r["report_type"].capitalize()}</span></td>'
            f'<td class="text-muted small">{friendly["label"]}</td>'
            f'<td class="text-muted small">{", ".join(r["recipient_emails"] or [])}</td>'
            f'<td>{active_badge}</td>'
            f'<td class="text-muted small">{last_run}</td>'
            f'<td>'
            f'<a href="/schedules/{r["id"]}/edit" class="btn btn-sm btn-outline-secondary me-1">Edit</a>'
            f'<form method="post" action="/schedules/{r["id"]}/toggle" style="display:inline;">'
            f'<button class="btn btn-sm btn-outline-warning me-1">{toggle_label}</button></form>'
            f'<form method="post" action="/schedules/{r["id"]}/delete" style="display:inline;"'
            f' onsubmit="return confirm(\'Delete this schedule?\');">'
            f'<button class="btn btn-sm btn-outline-danger">Delete</button></form>'
            f'</td>'
            f'</tr>'
        )
    if not rows_html:
        rows_html = '<tr><td colspan="7" class="text-center text-muted py-3">No schedules configured</td></tr>'

    tenant_options = ''.join(f'<option value="{t["id"]}">{t["name"]}</option>' for t in tenants)
    msp_options = ''.join(f'<option value="{m["id"]}">{m["name"]}</option>' for m in msps)

    form_fields = _schedule_form_fields()

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">🗓 Report Schedules</h3>
      <button class="btn btn-ss" data-bs-toggle="modal" data-bs-target="#addModal">+ New Schedule</button>
    </div>
    <div class="card mb-4">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr>
            <th>Tenant</th><th>Type</th><th>Schedule</th><th>Recipients</th>
            <th>Status</th><th>Last Run</th><th></th>
          </tr></thead>
          <tbody>{rows_html}</tbody>
        </table>
      </div>
    </div>

    <div class="modal fade" id="addModal" tabindex="-1">
      <div class="modal-dialog modal-lg"><div class="modal-content" style="background:#0D1629;">
        <div class="modal-header" style="border-color:#1A2A4A;">
          <h5 class="modal-title">New Report Schedule</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <form method="post">
          <div class="modal-body">
            <div class="row mb-3">
              <div class="col"><label class="form-label">Tenant *</label>
                <select name="tenant_id" class="form-select" required>
                  <option value="">Select tenant…</option>{tenant_options}
                </select></div>
              <div class="col"><label class="form-label">MSP Profile</label>
                <select name="msp_profile_id" class="form-select">
                  <option value="">— Auto from tenant —</option>{msp_options}
                </select></div>
            </div>
            <div class="row mb-3">
              <div class="col-6"><label class="form-label">Report Type *</label>
                <select name="report_type" class="form-select" required>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly" selected>Monthly</option>
                </select></div>
            </div>
            {form_fields}
            <div class="mb-3"><label class="form-label">Recipient Name (for cover page)</label>
              <input name="recipient_name" class="form-control" placeholder="IT Manager"></div>
            <div class="mb-3"><label class="form-label">Recipient Email(s) *</label>
              <input name="recipient_emails" class="form-control" required
                     placeholder="manager@company.co.za, cto@company.co.za">
              <small class="text-muted">Comma or space separated</small></div>
          </div>
          <div class="modal-footer" style="border-color:#1A2A4A;">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-ss">Create Schedule</button>
          </div>
        </form>
      </div></div>
    </div>'''
    return page('Schedules', content, 'schedules')


@app.route('/schedules/<int:schedule_id>/toggle', methods=['POST'])
def schedule_toggle(schedule_id: int):
    """Toggle a schedule between active and inactive."""
    _check_csrf()
    qexec(
        "UPDATE report_schedules SET is_active = NOT is_active WHERE id = %s",
        (schedule_id,),
    )
    if _scheduler:
        reload_schedules(_scheduler, DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)
    flash('Schedule updated.', 'success')
    return redirect(url_for('schedules'))


@app.route('/schedules/<int:schedule_id>/delete', methods=['POST'])
def schedule_delete(schedule_id: int):
    """Delete a report schedule."""
    _check_csrf()
    qexec("DELETE FROM report_schedules WHERE id = %s", (schedule_id,))
    if _scheduler:
        reload_schedules(_scheduler, DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)
    flash('Schedule deleted.', 'success')
    return redirect(url_for('schedules'))


@app.route('/schedules/<int:schedule_id>/edit', methods=['GET', 'POST'])
def schedule_edit(schedule_id: int):
    """Edit an existing report schedule."""
    row = qone(
        """
        SELECT rs.id, rs.tenant_id, rs.msp_profile_id, rs.report_type,
               rs.schedule_cron, rs.recipient_name, rs.recipient_emails,
               t.name AS tenant_name
        FROM report_schedules rs
        JOIN tenants t ON t.id = rs.tenant_id
        WHERE rs.id = %s
        """,
        (schedule_id,),
    )
    if row is None:
        flash('Schedule not found.', 'error')
        return redirect(url_for('schedules'))

    if request.method == 'POST':
        _check_csrf()
        tenant_id, msp_id, report_type, cron_expr, recipient_name, emails_raw, err, _ = \
            _parse_schedule_post()
        if err:
            flash(err, 'error')
            return redirect(url_for('schedule_edit', schedule_id=schedule_id))

        emails = [e.strip() for e in re.split(r'[,\s]+', emails_raw) if e.strip()]
        qexec(
            """
            UPDATE report_schedules
            SET tenant_id=%s, msp_profile_id=%s, report_type=%s, schedule_cron=%s,
                recipient_name=%s, recipient_emails=%s
            WHERE id=%s
            """,
            (tenant_id, msp_id, report_type, cron_expr, recipient_name or None, emails, schedule_id),
        )
        if _scheduler:
            reload_schedules(_scheduler, DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)
        flash('Schedule updated.', 'success')
        return redirect(url_for('schedules'))

    tenants = qall("SELECT id, name, msp_profile_id FROM tenants ORDER BY name")
    msps = qall("SELECT id, name FROM msp_profiles ORDER BY name")

    friendly = _cron_to_friendly(row['schedule_cron'])
    form_fields = _schedule_form_fields(friendly)

    tenant_options = ''.join(
        f'<option value="{t["id"]}"{" selected" if t["id"] == row["tenant_id"] else ""}>'
        f'{t["name"]}</option>'
        for t in tenants
    )
    msp_options = (
        f'<option value="">— Auto from tenant —</option>'
        + ''.join(
            f'<option value="{m["id"]}"{" selected" if m["id"] == row["msp_profile_id"] else ""}>'
            f'{m["name"]}</option>'
            for m in msps
        )
    )
    rt = row['report_type']
    type_options = ''.join(
        f'<option value="{v}"{" selected" if v == rt else ""}>{lbl}</option>'
        for v, lbl in [('daily', 'Daily'), ('weekly', 'Weekly'), ('monthly', 'Monthly')]
    )
    emails_str = ', '.join(row['recipient_emails'] or [])

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">Edit Schedule #{schedule_id}</h3>
      <a href="/schedules" class="btn btn-outline-secondary">← Back</a>
    </div>
    <div class="card">
      <div class="card-body">
        <form method="post">
          <div class="row mb-3">
            <div class="col"><label class="form-label">Tenant *</label>
              <select name="tenant_id" class="form-select" required>
                {tenant_options}
              </select></div>
            <div class="col"><label class="form-label">MSP Profile</label>
              <select name="msp_profile_id" class="form-select">
                {msp_options}
              </select></div>
          </div>
          <div class="row mb-3">
            <div class="col-6"><label class="form-label">Report Type *</label>
              <select name="report_type" class="form-select" required>
                {type_options}
              </select></div>
          </div>
          {form_fields}
          <div class="mb-3"><label class="form-label">Recipient Name (for cover page)</label>
            <input name="recipient_name" class="form-control"
                   value="{row['recipient_name'] or ''}" placeholder="IT Manager"></div>
          <div class="mb-3"><label class="form-label">Recipient Email(s) *</label>
            <input name="recipient_emails" class="form-control" required
                   value="{emails_str}"
                   placeholder="manager@company.co.za, cto@company.co.za">
            <small class="text-muted">Comma or space separated</small></div>
          <div class="d-flex gap-2">
            <button type="submit" class="btn btn-ss">Save Changes</button>
            <a href="/schedules" class="btn btn-outline-secondary">Cancel</a>
          </div>
        </form>
      </div>
    </div>'''
    return page(f'Edit Schedule #{schedule_id}', content, 'schedules')


_GENERATE_COOLDOWN = 30  # seconds between PDF generation requests per session

@app.route('/generate', methods=['GET', 'POST'])
def generate():
    """On-demand report generation form."""
    allowed = user_tenant_ids()
    if is_admin():
        tenants_for_select = qall(
            "SELECT id, name, msp_profile_id FROM tenants ORDER BY name"
        )
    else:
        tenants_for_select = qall(
            "SELECT id, name, msp_profile_id FROM tenants WHERE id = ANY(%s) ORDER BY name",
            (allowed,),
        )
    tenants = tenants_for_select
    msps = qall("SELECT id, name FROM msp_profiles ORDER BY name")
    if request.method == 'POST':
        _check_csrf()
        import time as _time
        last_gen = session.get('last_generate', 0)
        if _time.time() - last_gen < _GENERATE_COOLDOWN:
            remaining = int(_GENERATE_COOLDOWN - (_time.time() - last_gen))
            flash(f'Please wait {remaining}s before generating another report.', 'error')
            return redirect(url_for('generate'))
        session['last_generate'] = _time.time()

        report_kind = request.form.get('report_kind', 'periodic')
        tenant_id = request.form.get('tenant_id', type=int)
        msp_id = request.form.get('msp_profile_id', type=int)
        start_str = request.form.get('period_start', '')
        end_str = request.form.get('period_end', '')

        if not tenant_id or not start_str or not end_str:
            flash('Tenant and period are required.', 'error')
        else:
            try:
                period_start = datetime.fromisoformat(start_str)
                period_end = datetime.fromisoformat(end_str).replace(
                    hour=23, minute=59, second=59
                )

                effective_msp = msp_id or _get_tenant_msp(tenant_id)
                if not effective_msp:
                    flash('No MSP profile assigned to this tenant. Create and assign one first.', 'error')
                    return redirect(url_for('generate'))

                conn = psycopg2.connect(**DB_CONFIG)
                try:
                    if report_kind == 'hr':
                        subject_user = request.form.get('subject_user', '').strip()
                        generated_by = request.form.get('generated_by', 'Web UI').strip()
                        if not subject_user:
                            flash('Subject user is required for HR reports.', 'error')
                            conn.close()
                            return redirect(url_for('generate'))
                        clean_mode = 'clean_mode' in request.form
                        file_path = generate_hr_report(
                            db_conn=conn,
                            tenant_id=tenant_id,
                            msp_profile_id=effective_msp,
                            subject_user=subject_user,
                            period_start=period_start,
                            period_end=period_end,
                            generated_by=generated_by,
                            output_dir=OUTPUT_DIR,
                            clean_mode=clean_mode,
                        )
                    elif report_kind == 'security':
                        file_path = generate_security_report(
                            db_conn=conn,
                            tenant_id=tenant_id,
                            msp_profile_id=effective_msp,
                            period_start=period_start,
                            period_end=period_end,
                            output_dir=OUTPUT_DIR,
                        )
                    else:
                        report_type = request.form.get('report_type', 'monthly')
                        if report_type not in VALID_REPORT_TYPES:
                            flash('Invalid report type.', 'error')
                            conn.close()
                            return redirect(url_for('generate'))
                        file_path = generate_periodic_report(
                            db_conn=conn,
                            tenant_id=tenant_id,
                            msp_profile_id=effective_msp,
                            report_type=report_type,
                            period_start=period_start,
                            period_end=period_end,
                            output_dir=OUTPUT_DIR,
                        )
                finally:
                    conn.close()

                size = _fmt_bytes(os.path.getsize(file_path))
                report_id = _latest_report_id()
                if report_id:
                    qexec(
                        "UPDATE generated_reports SET delivery_status = 'ready' WHERE id = %s",
                        (report_id,),
                    )
                flash(f'✅ Your report is ready ({size}). Download it below.', 'success')
                return redirect(url_for('dashboard'))
            except Exception as exc:
                log.exception('On-demand report generation failed')
                flash(f'Generation failed: {exc}', 'error')

    tenant_options = ''.join(f'<option value="{t["id"]}">{t["name"]}</option>' for t in tenants)
    msp_options = ''.join(f'<option value="{m["id"]}">{m["name"]}</option>' for m in msps)
    today = date.today().isoformat()
    first_of_month = date.today().replace(day=1).isoformat()

    content = f'''
    <h3 class="mb-3">⚡ Generate Report Now</h3>
    <div class="card p-4" style="max-width:700px;">
      <form method="post">
        <div class="mb-3">
          <label class="form-label">Report Kind</label>
          <div class="d-flex gap-3 flex-wrap">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="report_kind"
                     value="periodic" id="rk_periodic" checked>
              <label class="form-check-label" for="rk_periodic">Periodic (bandwidth / productivity / rules)</label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="report_kind"
                     value="security" id="rk_security">
              <label class="form-check-label" for="rk_security">IT &amp; Network Security (threats / blocked / firewall)</label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="report_kind"
                     value="hr" id="rk_hr">
              <label class="form-check-label" for="rk_hr">HR Investigation (per-user activity)</label>
            </div>
          </div>
        </div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Tenant *</label>
            <select name="tenant_id" class="form-select" required>
              <option value="">Select tenant…</option>{tenant_options}
            </select></div>
          <div class="col"><label class="form-label">MSP Profile (optional override)</label>
            <select name="msp_profile_id" class="form-select">
              <option value="">— Auto from tenant —</option>{msp_options}
            </select></div>
        </div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Period Start *</label>
            <input name="period_start" type="date" class="form-control" value="{first_of_month}" required></div>
          <div class="col"><label class="form-label">Period End *</label>
            <input name="period_end" type="date" class="form-control" value="{today}" required></div>
        </div>
        <div id="periodic_fields">
          <div class="mb-3"><label class="form-label">Report Type (for cover page)</label>
            <select name="report_type" class="form-select">
              <option value="monthly" selected>Monthly</option>
              <option value="weekly">Weekly</option>
              <option value="daily">Daily</option>
              <option value="custom">Custom Range</option>
            </select></div>
        </div>
        <div id="hr_fields" style="display:none;">
          <div class="mb-3"><label class="form-label">Subject User (name or IP) *</label>
            <input name="subject_user" class="form-control" placeholder="jsmith or 192.168.1.45"></div>
          <div class="mb-3"><label class="form-label">Generated By</label>
            <input name="generated_by" class="form-control" placeholder="HR Manager" value="Web UI"></div>
          <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="clean_mode" name="clean_mode" value="1">
            <label class="form-check-label" for="clean_mode">
              Clean mode <small class="text-muted">(redact sensitive domain names in printed report)</small>
            </label>
          </div>
        </div>
        <button type="submit" class="btn btn-ss" id="gen-btn">Generate PDF</button>
      </form>
    </div>

    <!-- Generating overlay -->
    <div id="gen-overlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:9999;align-items:center;justify-content:center;">
      <div style="background:#1e2a38;border:1px solid #2e4057;border-radius:8px;padding:2.5rem 3rem;text-align:center;max-width:420px;">
        <div style="font-size:2rem;margin-bottom:1rem;">📄</div>
        <h5 style="color:#e0e6ed;margin-bottom:0.5rem;">Your report is being generated</h5>
        <p style="color:#8a9bb0;font-size:0.9rem;margin-bottom:1.5rem;">
          This may take up to 30 seconds depending on the date range.<br>
          You will be taken to the Report Dashboard automatically when it is ready.
        </p>
        <div style="display:flex;align-items:center;justify-content:center;gap:0.6rem;color:#4a9eda;">
          <div style="width:18px;height:18px;border:3px solid #4a9eda;border-top-color:transparent;border-radius:50%;animation:spin 0.8s linear infinite;"></div>
          <span style="font-size:0.9rem;">Generating…</span>
        </div>
      </div>
    </div>
    <style>@keyframes spin{{from{{transform:rotate(0deg)}}to{{transform:rotate(360deg)}}}}</style>

    <script>
      document.querySelectorAll('[name=report_kind]').forEach(r => r.addEventListener('change', () => {{
        const isHR  = document.getElementById('rk_hr').checked;
        document.getElementById('hr_fields').style.display       = isHR ? '' : 'none';
        document.getElementById('periodic_fields').style.display = isHR ? 'none' : '';
      }}));

      document.getElementById('gen-btn').closest('form').addEventListener('submit', function() {{
        const overlay = document.getElementById('gen-overlay');
        overlay.style.display = 'flex';
        document.getElementById('gen-btn').disabled = true;
      }});
    </script>'''
    return page('Generate Report', content, 'generate')


def _get_tenant_msp(tenant_id: int) -> int | None:
    """Return the msp_profile_id for a tenant, or None."""
    row = qone("SELECT msp_profile_id FROM tenants WHERE id = %s", (tenant_id,))
    return row['msp_profile_id'] if row else None


def _latest_report_id() -> int | None:
    """Return the id of the most recently generated report."""
    row = qone("SELECT id FROM generated_reports ORDER BY generated_at DESC LIMIT 1")
    return row['id'] if row else None


@app.route('/reports/<int:report_id>/download')
def download_report(report_id: int):
    """Serve the PDF file for a generated report."""
    row = qone("SELECT file_path FROM generated_reports WHERE id = %s", (report_id,))
    if not row:
        abort(404)

    file_path = row['file_path']
    real_file = os.path.realpath(file_path)
    real_out = os.path.realpath(OUTPUT_DIR)

    # Prevent path traversal: file must be inside OUTPUT_DIR
    if not real_file.startswith(real_out + os.sep):
        abort(403)

    if not os.path.isfile(real_file):
        abort(404)

    return send_file(
        real_file,
        mimetype='application/pdf',
        as_attachment=True,
        download_name=os.path.basename(real_file),
    )


# ── Error pages ───────────────────────────────────────────────────────────────

@app.errorhandler(400)
def bad_request(_e):
    """Render a 400 error page."""
    return page('Bad Request', '<div class="alert alert-danger"><h4>400 — Bad Request</h4></div>'), 400


@app.errorhandler(403)
def forbidden(_e):
    """Render a 403 error page."""
    return page('Forbidden', '<div class="alert alert-danger"><h4>403 — Access Denied</h4></div>'), 403


@app.errorhandler(404)
def not_found(_e):
    """Render a 404 error page."""
    return page('Not Found', '<div class="alert alert-warning"><h4>404 — Page Not Found</h4></div>'), 404


@app.errorhandler(500)
def server_error(_e):
    """Render a 500 error page."""
    return page('Error', '<div class="alert alert-danger"><h4>500 — Internal Server Error</h4><p>Check the application log for details.</p></div>'), 500


# ── Identity Management ───────────────────────────────────────────────────────

import ipaddress as _ipaddress


def _normalise_mac(raw: str) -> str | None:
    """Normalise a MAC address to lowercase colon-separated aa:bb:cc:dd:ee:ff.

    Accepts: aa:bb:cc:dd:ee:ff, AA-BB-CC-DD-EE-FF, AABBCCDDEEFF.
    Returns None if the value cannot be parsed as exactly 12 hex digits.
    """
    stripped = re.sub(r'[:\-\.]', '', raw.strip()).lower()
    if not re.fullmatch(r'[0-9a-f]{12}', stripped):
        return None
    return ':'.join(stripped[i:i+2] for i in range(0, 12, 2))


def _validate_ip(raw: str) -> bool:
    """Return True if raw is a valid IPv4/IPv6 address or network."""
    try:
        _ipaddress.ip_network(raw.strip(), strict=False)
        return True
    except ValueError:
        return False


@app.route('/identity')
def identity_overview():
    """Identity management overview — users, devices, unassigned stats."""
    tenant_id = request.args.get('tenant_id', 1, type=int)
    tenants = qall("SELECT id, name FROM tenants ORDER BY name")
    stats = qone("""
        SELECT
            (SELECT COUNT(*) FROM identity_users WHERE tenant_id=%s AND active=true) AS users,
            (SELECT COUNT(*) FROM identity_devices WHERE tenant_id=%s) AS devices,
            (SELECT COUNT(*) FROM identity_devices WHERE tenant_id=%s AND user_id IS NULL) AS unassigned
    """, (tenant_id, tenant_id, tenant_id)) or {}
    users = qall("""
        SELECT u.id, u.full_name, u.username, u.department, u.group_name, u.active,
               COUNT(d.id) AS device_count
        FROM identity_users u
        LEFT JOIN identity_devices d ON d.user_id = u.id
        WHERE u.tenant_id = %s
        GROUP BY u.id ORDER BY u.full_name
    """, (tenant_id,))

    tenant_options = ''.join(
        f'<option value="{t["id"]}" {"selected" if tenant_id == t["id"] else ""}>{esc(t["name"])}</option>'
        for t in tenants
    )

    user_rows = ''
    for u in users:
        active_badge = (
            '<span class="badge badge-teal">Active</span>'
            if u['active'] else '<span class="badge bg-secondary">Inactive</span>'
        )
        user_rows += (
            f'<tr>'
            f'<td><a href="/identity/users/{u["id"]}" class="text-info">{esc(u["full_name"] or "—")}</a></td>'
            f'<td class="text-muted">{esc(u["username"] or "—")}</td>'
            f'<td class="text-muted">{esc(u["department"] or "—")}</td>'
            f'<td class="text-muted">{esc(u["group_name"] or "—")}</td>'
            f'<td><span class="badge bg-secondary">{u["device_count"]}</span></td>'
            f'<td>{active_badge}</td>'
            f'<td>'
            f'<a href="/identity/users/{u["id"]}" class="btn btn-sm btn-outline-primary me-1">Edit</a>'
            f'<form method="post" action="/identity/users/{u["id"]}/delete" style="display:inline;"'
            f' onsubmit="return confirm(\'Delete user and unlink their devices?\');">'
            f'<button class="btn btn-sm btn-outline-danger">Delete</button></form>'
            f'</td>'
            f'</tr>'
        )
    if not user_rows:
        user_rows = '<tr><td colspan="7" class="text-center text-muted py-4">No users yet</td></tr>'

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">👤 Identity Management</h3>
      <div class="d-flex gap-2">
        <form class="d-flex gap-2" method="get">
          <select name="tenant_id" class="form-select form-select-sm" style="width:200px;">
            {tenant_options}
          </select>
          <button class="btn btn-sm btn-outline-secondary">Filter</button>
        </form>
        <a href="/identity/users/new?tenant_id={tenant_id}" class="btn btn-ss">+ Add User</a>
        <a href="/identity/dhcp-import?tenant_id={tenant_id}" class="btn btn-outline-info">⬆ DHCP Import</a>
        <a href="/identity/unassigned?tenant_id={tenant_id}" class="btn btn-outline-warning">Unassigned Devices</a>
      </div>
    </div>
    <div class="row g-3 mb-4">
      <div class="col-md-4">
        <div class="card p-3 text-center">
          <div class="stat-val">{stats.get("users", 0)}</div>
          <div class="text-muted small">Active Users</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3 text-center">
          <div class="stat-val">{stats.get("devices", 0)}</div>
          <div class="text-muted small">Total Devices</div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3 text-center">
          <div class="stat-val">{stats.get("unassigned", 0)}</div>
          <div class="text-muted small">Unassigned Devices</div>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr>
            <th>Full Name</th><th>Username</th><th>Department</th>
            <th>Group</th><th>Devices</th><th>Status</th><th></th>
          </tr></thead>
          <tbody>{user_rows}</tbody>
        </table>
      </div>
    </div>'''
    return page('Identity', content, 'identity')


@app.route('/identity/users/new', methods=['GET', 'POST'])
def identity_user_new():
    """Create a new identity user."""
    tenant_id = request.args.get('tenant_id', 1, type=int)
    if request.method == 'POST':
        _check_csrf()
        tenant_id = request.form.get('tenant_id', 1, type=int)
        full_name = request.form.get('full_name', '').strip()
        if not full_name:
            flash('Full name is required.', 'error')
            return redirect(url_for('identity_user_new', tenant_id=tenant_id))
        username = request.form.get('username', '').strip() or None
        email = request.form.get('email', '').strip() or None
        department = request.form.get('department', '').strip() or None
        group_name = request.form.get('group_name', '').strip() or None
        notes = request.form.get('notes', '').strip() or None
        active = 'active' in request.form
        new_id = qinsert(
            """
            INSERT INTO identity_users
                (tenant_id, username, full_name, email, department, group_name, notes, active)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id
            """,
            (tenant_id, username, full_name, email, department, group_name, notes, active),
        )
        flash(f'User "{full_name}" created.', 'success')
        return redirect(url_for('identity_user_edit', user_id=new_id))

    departments = [r['department'] for r in qall(
        "SELECT DISTINCT department FROM identity_users WHERE tenant_id=%s AND department IS NOT NULL ORDER BY department",
        (tenant_id,)
    )]
    groups = [r['group_name'] for r in qall(
        "SELECT DISTINCT group_name FROM identity_users WHERE tenant_id=%s AND group_name IS NOT NULL ORDER BY group_name",
        (tenant_id,)
    )]
    dept_options = ''.join(f'<option value="{esc(d)}">' for d in departments)
    group_options = ''.join(f'<option value="{esc(g)}">' for g in groups)

    content = f'''
    <h3 class="mb-3">👤 New User</h3>
    <div class="card p-4" style="max-width:640px;">
      <form method="post">
        <input type="hidden" name="tenant_id" value="{tenant_id}">
        <div class="mb-3"><label class="form-label">Full Name *</label>
          <input name="full_name" class="form-control" required autofocus></div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Username</label>
            <input name="username" class="form-control" placeholder="jsmith"></div>
          <div class="col"><label class="form-label">Email</label>
            <input name="email" type="email" class="form-control"></div>
        </div>
        <div class="row mb-3">
          <div class="col"><label class="form-label">Department</label>
            <input name="department" class="form-control" list="dept_list" autocomplete="off">
            <datalist id="dept_list">{dept_options}</datalist></div>
          <div class="col"><label class="form-label">Group</label>
            <input name="group_name" class="form-control" list="group_list" autocomplete="off">
            <datalist id="group_list">{group_options}</datalist></div>
        </div>
        <div class="mb-3"><label class="form-label">Notes</label>
          <textarea name="notes" class="form-control" rows="2"></textarea></div>
        <div class="mb-3 form-check">
          <input type="checkbox" class="form-check-input" id="active" name="active" checked>
          <label class="form-check-label" for="active">Active</label>
        </div>
        <button type="submit" class="btn btn-ss">Create User</button>
        <a href="/identity?tenant_id={tenant_id}" class="btn btn-outline-secondary ms-2">Cancel</a>
      </form>
    </div>'''
    return page('New User', content, 'identity')


@app.route('/identity/users/<int:user_id>', methods=['GET', 'POST'])
def identity_user_edit(user_id: int):
    """Edit an identity user and manage their devices."""
    u = qone("SELECT * FROM identity_users WHERE id = %s", (user_id,))
    if not u:
        abort(404)
    tenant_id = u['tenant_id']

    if request.method == 'POST':
        _check_csrf()
        action = request.form.get('action', 'save_user')

        if action == 'save_user':
            full_name = request.form.get('full_name', '').strip()
            if not full_name:
                flash('Full name is required.', 'error')
                return redirect(url_for('identity_user_edit', user_id=user_id))
            qexec(
                """
                UPDATE identity_users
                SET full_name=%s, username=%s, email=%s, department=%s,
                    group_name=%s, notes=%s, active=%s, updated_at=NOW()
                WHERE id=%s AND tenant_id=%s
                """,
                (
                    full_name,
                    request.form.get('username', '').strip() or None,
                    request.form.get('email', '').strip() or None,
                    request.form.get('department', '').strip() or None,
                    request.form.get('group_name', '').strip() or None,
                    request.form.get('notes', '').strip() or None,
                    'active' in request.form,
                    user_id,
                    tenant_id,
                ),
            )
            flash('User updated.', 'success')
            return redirect(url_for('identity_user_edit', user_id=user_id))

        elif action == 'add_device':
            ip_raw = request.form.get('ip_address', '').strip()
            mac_raw = request.form.get('mac_address', '').strip()
            hostname = request.form.get('hostname', '').strip() or None
            label = request.form.get('label', '').strip() or None
            source = request.form.get('source', 'manual').strip()
            if source not in VALID_DEVICE_SOURCES:
                source = 'manual'
            valid_from_str = request.form.get('valid_from', '').strip()
            valid_to_str = request.form.get('valid_to', '').strip()

            if not ip_raw and not mac_raw and not hostname:
                flash('Provide at least one of IP address, MAC address, or hostname.', 'error')
                return redirect(url_for('identity_user_edit', user_id=user_id))

            ip_address = None
            if ip_raw:
                if not _validate_ip(ip_raw):
                    flash(f'Invalid IP address: {ip_raw}', 'error')
                    return redirect(url_for('identity_user_edit', user_id=user_id))
                ip_address = ip_raw

            mac_address = None
            if mac_raw:
                mac_address = _normalise_mac(mac_raw)
                if mac_address is None:
                    flash(f'Invalid MAC address: {mac_raw}', 'error')
                    return redirect(url_for('identity_user_edit', user_id=user_id))

            # Validate date strings before DB insert to give friendly errors
            for date_field, date_val in (('Valid From', valid_from_str), ('Valid To', valid_to_str)):
                if date_val:
                    try:
                        datetime.fromisoformat(date_val)
                    except ValueError:
                        flash(f'{date_field}: invalid date format — use YYYY-MM-DD.', 'error')
                        return redirect(url_for('identity_user_edit', user_id=user_id))

            valid_to = valid_to_str if valid_to_str else None

            if valid_from_str:
                qinsert(
                    """
                    INSERT INTO identity_devices
                        (tenant_id, user_id, ip_address, mac_address, hostname, label,
                         source, valid_from, valid_to)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING id
                    """,
                    (tenant_id, user_id, ip_address, mac_address, hostname, label,
                     source, valid_from_str, valid_to),
                )
            else:
                qinsert(
                    """
                    INSERT INTO identity_devices
                        (tenant_id, user_id, ip_address, mac_address, hostname, label,
                         source, valid_to)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id
                    """,
                    (tenant_id, user_id, ip_address, mac_address, hostname, label,
                     source, valid_to),
                )
            flash('Device added.', 'success')
            return redirect(url_for('identity_user_edit', user_id=user_id))

        return redirect(url_for('identity_user_edit', user_id=user_id))

    tenant = qone("SELECT name FROM tenants WHERE id = %s", (tenant_id,))
    tenant_name = tenant['name'] if tenant else f'Tenant {tenant_id}'

    devices = qall(
        """
        SELECT id, ip_address, mac_address, hostname, label, source, valid_from, valid_to
        FROM identity_devices WHERE user_id=%s AND tenant_id=%s ORDER BY created_at DESC
        """,
        (user_id, tenant_id),
    )

    departments = [r['department'] for r in qall(
        "SELECT DISTINCT department FROM identity_users WHERE tenant_id=%s AND department IS NOT NULL ORDER BY department",
        (tenant_id,)
    )]
    groups = [r['group_name'] for r in qall(
        "SELECT DISTINCT group_name FROM identity_users WHERE tenant_id=%s AND group_name IS NOT NULL ORDER BY group_name",
        (tenant_id,)
    )]
    dept_options = ''.join(f'<option value="{esc(d)}">' for d in departments)
    group_options = ''.join(f'<option value="{esc(g)}">' for g in groups)

    active_checked = 'checked' if u['active'] else ''

    device_rows = ''
    for d in devices:
        vf = d['valid_from'].strftime('%d %b %Y') if d.get('valid_from') else '—'
        vt = d['valid_to'].strftime('%d %b %Y') if d.get('valid_to') else '—'
        device_rows += (
            f'<tr>'
            f'<td>{esc(d["label"] or "—")}</td>'
            f'<td class="mono text-muted">{esc(d["ip_address"] or "—")}</td>'
            f'<td class="mono text-muted">{esc(d["mac_address"] or "—")}</td>'
            f'<td class="text-muted">{esc(d["hostname"] or "—")}</td>'
            f'<td><span class="badge bg-secondary">{esc(d["source"] or "manual")}</span></td>'
            f'<td class="text-muted small">{vf}</td>'
            f'<td class="text-muted small">{vt}</td>'
            f'<td>'
            f'<form method="post" action="/identity/devices/{d["id"]}/delete" style="display:inline;"'
            f' onsubmit="return confirm(\'Remove this device?\');">'
            f'<button class="btn btn-sm btn-outline-danger">Remove</button></form>'
            f'</td>'
            f'</tr>'
        )
    if not device_rows:
        device_rows = '<tr><td colspan="8" class="text-center text-muted py-3">No devices assigned</td></tr>'

    today = date.today().isoformat()

    content = f'''
    <h3 class="mb-3">👤 Edit User: {esc(u["full_name"] or "")}</h3>
    <div class="row g-4">
      <div class="col-md-5">
        <div class="card p-4">
          <h6 class="text-muted mb-3">User Details</h6>
          <form method="post">
            <input type="hidden" name="action" value="save_user">
            <div class="mb-3"><label class="form-label">Full Name *</label>
              <input name="full_name" class="form-control" value="{esc(u["full_name"] or "")}" required></div>
            <div class="row mb-3">
              <div class="col"><label class="form-label">Username</label>
                <input name="username" class="form-control" value="{esc(u["username"] or "")}"></div>
              <div class="col"><label class="form-label">Email</label>
                <input name="email" type="email" class="form-control" value="{esc(u["email"] or "")}"></div>
            </div>
            <div class="row mb-3">
              <div class="col"><label class="form-label">Department</label>
                <input name="department" class="form-control" list="dept_list"
                       value="{esc(u["department"] or "")}" autocomplete="off">
                <datalist id="dept_list">{dept_options}</datalist></div>
              <div class="col"><label class="form-label">Group</label>
                <input name="group_name" class="form-control" list="group_list"
                       value="{esc(u["group_name"] or "")}" autocomplete="off">
                <datalist id="group_list">{group_options}</datalist></div>
            </div>
            <div class="mb-3"><label class="form-label">Notes</label>
              <textarea name="notes" class="form-control" rows="2">{esc(u["notes"] or "")}</textarea></div>
            <div class="mb-3 form-check">
              <input type="checkbox" class="form-check-input" id="active" name="active" {active_checked}>
              <label class="form-check-label" for="active">Active</label>
            </div>
            <button type="submit" class="btn btn-ss">Save Changes</button>
            <a href="/identity?tenant_id={tenant_id}" class="btn btn-outline-secondary ms-2">Back</a>
          </form>
        </div>
      </div>
      <div class="col-md-7">
        <div class="card">
          <div class="card-header d-flex justify-content-between align-items-center">
            <span>Assigned Devices</span>
          </div>
          <div class="table-responsive">
            <table class="table table-hover mb-0">
              <thead><tr>
                <th>Label</th><th>IP Address</th><th>MAC Address</th>
                <th>Hostname</th><th>Source</th><th>Valid From</th><th>Valid To</th><th></th>
              </tr></thead>
              <tbody>{device_rows}</tbody>
            </table>
          </div>
          <div class="card-header mt-0" style="border-top:1px solid #1A2A4A;">
            <span class="text-muted small">Add Device</span>
            <span class="badge badge-teal ms-2">{esc(tenant_name)}</span>
          </div>
          <div class="p-3">
            <form method="post">
              <input type="hidden" name="action" value="add_device">
              <div class="row g-2 mb-2">
                <div class="col"><input name="ip_address" class="form-control form-control-sm"
                  placeholder="IP (e.g. 192.168.1.10)"></div>
                <div class="col"><input name="mac_address" class="form-control form-control-sm"
                  placeholder="MAC (e.g. aa:bb:cc:dd:ee:ff)"></div>
                <div class="col"><input name="hostname" class="form-control form-control-sm"
                  placeholder="Hostname"></div>
              </div>
              <div class="row g-2 mb-2">
                <div class="col"><input name="label" class="form-control form-control-sm"
                  placeholder="Label (friendly name)"></div>
                <div class="col">
                  <select name="source" class="form-select form-select-sm">
                    <option value="manual" selected>manual</option>
                    <option value="dhcp">dhcp</option>
                    <option value="sso">sso</option>
                    <option value="ldap">ldap</option>
                  </select>
                </div>
                <div class="col"><input name="valid_from" type="date" class="form-control form-control-sm"
                  value="{today}"></div>
                <div class="col"><input name="valid_to" type="date" class="form-control form-control-sm"
                  placeholder="Leave blank = active"></div>
              </div>
              <button type="submit" class="btn btn-sm btn-ss">Add Device</button>
            </form>
          </div>
        </div>
      </div>
    </div>'''
    return page(f'Edit User — {esc(u["full_name"] or "")}', content, 'identity')


@app.route('/identity/devices/<int:device_id>/delete', methods=['POST'])
def identity_device_delete(device_id: int):
    """Delete an identity device."""
    _check_csrf()
    row = qone("SELECT user_id, tenant_id FROM identity_devices WHERE id=%s", (device_id,))
    if not row:
        abort(404)
    tenant_id = row['tenant_id']
    user_id = row['user_id']
    qexec(
        "DELETE FROM identity_devices WHERE id=%s AND tenant_id=%s",
        (device_id, tenant_id),
    )
    flash('Device removed.', 'success')
    if user_id:
        return redirect(url_for('identity_user_edit', user_id=user_id))
    return redirect(url_for('identity_unassigned', tenant_id=tenant_id))


@app.route('/identity/users/<int:user_id>/delete', methods=['POST'])
def identity_user_delete(user_id: int):
    """Unlink all devices from a user and delete the user record."""
    _check_csrf()
    u = qone("SELECT tenant_id FROM identity_users WHERE id=%s", (user_id,))
    if not u:
        abort(404)
    tenant_id = u['tenant_id']
    qexec(
        "UPDATE identity_devices SET user_id=NULL WHERE user_id=%s AND tenant_id=%s",
        (user_id, tenant_id),
    )
    qexec(
        "DELETE FROM identity_users WHERE id=%s AND tenant_id=%s",
        (user_id, tenant_id),
    )
    flash('User deleted; devices unlinked.', 'success')
    return redirect(url_for('identity_overview', tenant_id=tenant_id))


@app.route('/identity/dhcp-import', methods=['GET', 'POST'])
def identity_dhcp_import():
    """Import DHCP leases from a CSV file to populate identity_devices."""
    tenants = qall("SELECT id, name FROM tenants ORDER BY name")
    tenant_id = request.args.get('tenant_id', 1, type=int)
    results_html = ''

    if request.method == 'POST':
        _check_csrf()
        tenant_id = request.form.get('tenant_id', 1, type=int)
        f = request.files.get('csv_file')
        if not f or not f.filename:
            flash('Please select a CSV file to upload.', 'error')
            return redirect(url_for('identity_dhcp_import', tenant_id=tenant_id))

        raw = f.stream.read().decode('utf-8', errors='replace')
        reader = csv.reader(io.StringIO(raw))

        matched = 0
        new_count = 0
        skipped = 0
        imported_rows = []

        for lineno, row in enumerate(reader, start=1):
            # Skip blank lines and comment lines
            if not row or not any(cell.strip() for cell in row):
                continue
            first = row[0].strip()
            if first.startswith('#'):
                continue
            # Skip header row if detected
            if lineno == 1 and first.lower() in ('ip_address', 'ip', 'address'):
                continue

            # Parse columns: ip_address, mac_address, hostname [, label [, valid_to]]
            ip_raw = row[0].strip() if len(row) > 0 else ''
            mac_raw = row[1].strip() if len(row) > 1 else ''
            hostname = row[2].strip() if len(row) > 2 else None
            label = row[3].strip() if len(row) > 3 else None
            valid_to = row[4].strip() if len(row) > 4 else None

            hostname = hostname or None
            label = label or None
            valid_to = valid_to or None

            # Validate IP
            if ip_raw and not _validate_ip(ip_raw):
                skipped += 1
                continue
            ip_address = ip_raw or None

            # Validate and normalise MAC
            if not mac_raw:
                skipped += 1
                continue
            mac_address = _normalise_mac(mac_raw)
            if mac_address is None:
                skipped += 1
                continue

            existing = qone(
                "SELECT id FROM identity_devices WHERE tenant_id=%s AND mac_address=%s",
                (tenant_id, mac_address),
            )
            if existing:
                qexec(
                    """
                    UPDATE identity_devices
                    SET ip_address=COALESCE(%s, ip_address),
                        hostname=COALESCE(%s, hostname),
                        valid_from=NOW()
                    WHERE id=%s AND tenant_id=%s
                    """,
                    (ip_address, hostname, existing['id'], tenant_id),
                )
                matched += 1
            else:
                qinsert(
                    """
                    INSERT INTO identity_devices
                        (tenant_id, user_id, ip_address, mac_address, hostname,
                         label, source, valid_from, valid_to)
                    VALUES (%s, NULL, %s, %s, %s, %s, 'dhcp', NOW(), %s) RETURNING id
                    """,
                    (tenant_id, ip_address, mac_address, hostname, label, valid_to),
                )
                new_count += 1

            imported_rows.append((ip_address or '', mac_address, hostname or '', label or ''))

        table_rows = ''.join(
            f'<tr><td class="mono">{esc(ip)}</td><td class="mono">{esc(mac)}</td>'
            f'<td>{esc(host)}</td><td>{esc(lbl)}</td></tr>'
            for ip, mac, host, lbl in imported_rows
        )
        results_html = f'''
        <div class="alert alert-success mt-3">
          Import complete: <strong>{matched}</strong> updated,
          <strong>{new_count}</strong> new (unassigned),
          <strong>{skipped}</strong> rows skipped.
        </div>
        <div class="card mt-3">
          <div class="card-header">Imported Rows</div>
          <div class="table-responsive">
            <table class="table table-hover mb-0">
              <thead><tr><th>IP Address</th><th>MAC Address</th><th>Hostname</th><th>Label</th></tr></thead>
              <tbody>{table_rows if table_rows else
                      "<tr><td colspan='4' class='text-center text-muted py-3'>No rows imported</td></tr>"
              }</tbody>
            </table>
          </div>
        </div>'''

    tenant_options = ''.join(
        f'<option value="{t["id"]}" {"selected" if tenant_id == t["id"] else ""}>{esc(t["name"])}</option>'
        for t in tenants
    )

    content = f'''
    <h3 class="mb-3">⬆ DHCP CSV Import</h3>
    <div class="card p-4" style="max-width:700px;">
      <form method="post" enctype="multipart/form-data">
        <div class="mb-3"><label class="form-label">Tenant *</label>
          <select name="tenant_id" class="form-select" required>
            {tenant_options}
          </select></div>
        <div class="mb-3"><label class="form-label">CSV File</label>
          <input name="csv_file" type="file" class="form-control" accept=".csv,.txt" required>
          <small class="text-muted">
            Columns: <code>ip_address, mac_address, hostname</code> (optional: <code>label, valid_to</code>)<br>
            Example: <code>192.168.1.10,aa:bb:cc:dd:ee:ff,DESKTOP-JOHN</code><br>
            Accepts MAC formats: <code>aa:bb:cc:dd:ee:ff</code>, <code>AA-BB-CC-DD-EE-FF</code>,
            <code>AABBCCDDEEFF</code>
          </small>
        </div>
        <button type="submit" class="btn btn-ss">Import</button>
        <a href="/identity?tenant_id={tenant_id}" class="btn btn-outline-secondary ms-2">Cancel</a>
      </form>
      {results_html}
    </div>'''
    return page('DHCP Import', content, 'identity')


@app.route('/identity/unassigned', methods=['GET', 'POST'])
def identity_unassigned():
    """List unassigned devices and allow assigning them to users."""
    tenant_id = request.args.get('tenant_id', 1, type=int)

    if request.method == 'POST':
        _check_csrf()
        tenant_id = request.form.get('tenant_id', 1, type=int)
        device_id = request.form.get('device_id', type=int)
        user_id = request.form.get('user_id', type=int)
        if device_id and user_id:
            qexec(
                "UPDATE identity_devices SET user_id=%s WHERE id=%s AND tenant_id=%s",
                (user_id, device_id, tenant_id),
            )
            flash('Device assigned.', 'success')
        return redirect(url_for('identity_unassigned', tenant_id=tenant_id))

    tenants = qall("SELECT id, name FROM tenants ORDER BY name")
    devices = qall(
        """
        SELECT id, ip_address, mac_address, hostname, label, source, created_at
        FROM identity_devices WHERE user_id IS NULL AND tenant_id=%s ORDER BY created_at DESC
        """,
        (tenant_id,),
    )
    users = qall(
        "SELECT id, full_name, username FROM identity_users WHERE tenant_id=%s AND active=true ORDER BY full_name",
        (tenant_id,),
    )

    tenant_options = ''.join(
        f'<option value="{t["id"]}" {"selected" if tenant_id == t["id"] else ""}>{esc(t["name"])}</option>'
        for t in tenants
    )

    user_select_options = ''.join(
        f'<option value="{u["id"]}">{esc(u["full_name"] or u["username"] or str(u["id"]))}</option>'
        for u in users
    )

    csrf_val = _csrf_token()
    device_rows = ''
    for d in devices:
        imported = d['created_at'].strftime('%d %b %Y %H:%M') if d.get('created_at') else '—'
        device_rows += (
            f'<tr>'
            f'<td class="mono text-muted">{esc(d["ip_address"] or "—")}</td>'
            f'<td class="mono text-muted">{esc(d["mac_address"] or "—")}</td>'
            f'<td class="text-muted">{esc(d["hostname"] or "—")}</td>'
            f'<td class="text-muted">{esc(d["label"] or "—")}</td>'
            f'<td><span class="badge bg-secondary">{esc(d["source"] or "—")}</span></td>'
            f'<td class="text-muted small">{imported}</td>'
            f'<td>'
            f'<form method="post" style="display:flex;gap:4px;">'
            f'<input type="hidden" name="tenant_id" value="{tenant_id}">'
            f'<input type="hidden" name="device_id" value="{d["id"]}">'
            f'<input type="hidden" name="_csrf" value="{csrf_val}">'
            f'<select name="user_id" class="form-select form-select-sm" style="min-width:160px;">'
            f'<option value="">— Select user —</option>{user_select_options}'
            f'</select>'
            f'<button class="btn btn-sm btn-ss">Assign</button>'
            f'</form>'
            f'</td>'
            f'</tr>'
        )
    if not device_rows:
        device_rows = '<tr><td colspan="7" class="text-center text-muted py-4">No unassigned devices</td></tr>'

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">Unassigned Devices</h3>
      <div class="d-flex gap-2">
        <form class="d-flex gap-2" method="get">
          <select name="tenant_id" class="form-select form-select-sm" style="width:200px;">
            {tenant_options}
          </select>
          <button class="btn btn-sm btn-outline-secondary">Filter</button>
        </form>
        <a href="/identity?tenant_id={tenant_id}" class="btn btn-outline-secondary">Back to Identity</a>
      </div>
    </div>
    <div class="card">
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr>
            <th>IP Address</th><th>MAC Address</th><th>Hostname</th>
            <th>Label</th><th>Source</th><th>Imported</th><th>Assign to User</th>
          </tr></thead>
          <tbody>{device_rows}</tbody>
        </table>
      </div>
    </div>'''
    return page('Unassigned Devices', content, 'identity')


# ── Devices overview ─────────────────────────────────────────────────────────

@app.route('/identity/devices', methods=['GET', 'POST'])
def identity_devices():
    """All devices for a tenant — add, view, and manage across all users."""
    tenants = qall("SELECT id, name FROM tenants ORDER BY name")
    tenant_id = request.args.get('tenant_id', tenants[0]['id'] if tenants else 1, type=int)

    if request.method == 'POST':
        _check_csrf()
        action = request.form.get('action', '')

        if action == 'add_device':
            tenant_id = request.form.get('tenant_id', type=int)
            if not tenant_id or not qone("SELECT id FROM tenants WHERE id = %s", (tenant_id,)):
                abort(400)
            if not can_access_tenant(tenant_id):
                abort(403)
            ip_raw = request.form.get('ip_address', '').strip()
            mac_raw = request.form.get('mac_address', '').strip()
            hostname = request.form.get('hostname', '').strip() or None
            label = request.form.get('label', '').strip() or None
            source = request.form.get('source', 'manual').strip()
            if source not in VALID_DEVICE_SOURCES:
                source = 'manual'
            user_id = request.form.get('user_id', type=int) or None

            if not ip_raw and not mac_raw and not hostname:
                flash('Provide at least one of IP, MAC, or hostname.', 'error')
                return redirect(url_for('identity_devices', tenant_id=tenant_id))

            ip_address = None
            if ip_raw:
                if not _validate_ip(ip_raw):
                    flash(f'Invalid IP address: {ip_raw}', 'error')
                    return redirect(url_for('identity_devices', tenant_id=tenant_id))
                ip_address = ip_raw

            mac_address = None
            if mac_raw:
                mac_address = _normalise_mac(mac_raw)
                if mac_address is None:
                    flash(f'Invalid MAC address: {mac_raw}', 'error')
                    return redirect(url_for('identity_devices', tenant_id=tenant_id))

            qinsert(
                """
                INSERT INTO identity_devices
                    (tenant_id, user_id, ip_address, mac_address, hostname, label, source)
                VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id
                """,
                (tenant_id, user_id, ip_address, mac_address, hostname, label, source),
            )
            flash('Device added.', 'success')
            return redirect(url_for('identity_devices', tenant_id=tenant_id))

        if action == 'reassign':
            device_id = request.form.get('device_id', type=int)
            new_user_id = request.form.get('user_id', type=int) or None
            if device_id:
                if new_user_id and not qone(
                    "SELECT id FROM identity_users WHERE id = %s AND tenant_id = %s",
                    (new_user_id, tenant_id),
                ):
                    flash('User does not belong to this tenant.', 'error')
                    return redirect(url_for('identity_devices', tenant_id=tenant_id))
                qexec(
                    "UPDATE identity_devices SET user_id=%s WHERE id=%s AND tenant_id=%s",
                    (new_user_id, device_id, tenant_id),
                )
                flash('Device reassigned.', 'success')
            return redirect(url_for('identity_devices', tenant_id=tenant_id))

    tenant_options = ''.join(
        f'<option value="{t["id"]}" {"selected" if tenant_id == t["id"] else ""}>{esc(t["name"])}</option>'
        for t in tenants
    )
    users = qall(
        "SELECT id, full_name, username FROM identity_users WHERE tenant_id=%s AND active=true ORDER BY full_name",
        (tenant_id,),
    )
    user_options = '<option value="">— Unassigned —</option>' + ''.join(
        f'<option value="{u["id"]}">{esc(u["full_name"] or u["username"] or str(u["id"]))}</option>'
        for u in users
    )
    devices = qall(
        """
        SELECT d.id, d.ip_address, d.mac_address, d.hostname, d.label, d.source,
               d.valid_from, d.valid_to, d.user_id,
               u.full_name AS user_name
        FROM identity_devices d
        LEFT JOIN identity_users u ON u.id = d.user_id
        WHERE d.tenant_id = %s
        ORDER BY d.created_at DESC
        """,
        (tenant_id,),
    )

    csrf_val = _csrf_token()
    device_rows = ''
    for d in devices:
        vf = d['valid_from'].strftime('%d %b %Y') if d.get('valid_from') else '—'
        vt = d['valid_to'].strftime('%d %b %Y') if d.get('valid_to') else '—'
        selected_opts = '<option value="">— Unassigned —</option>' + ''.join(
            f'<option value="{u["id"]}" {"selected" if d["user_id"] == u["id"] else ""}>'
            f'{esc(u["full_name"] or u["username"] or str(u["id"]))}</option>'
            for u in users
        )
        device_rows += (
            f'<tr>'
            f'<td class="font-monospace small">{esc(d["ip_address"] or "—")}</td>'
            f'<td class="font-monospace small text-muted">{esc(d["mac_address"] or "—")}</td>'
            f'<td class="text-muted small">{esc(d["hostname"] or "—")}</td>'
            f'<td class="text-muted small">{esc(d["label"] or "—")}</td>'
            f'<td><span class="badge bg-secondary">{esc(d["source"] or "manual")}</span></td>'
            f'<td class="text-muted small">{vf}</td>'
            f'<td class="text-muted small">{vt}</td>'
            f'<td>'
            f'<form method="post" style="display:flex;gap:4px;">'
            f'<input type="hidden" name="action" value="reassign">'
            f'<input type="hidden" name="tenant_id" value="{tenant_id}">'
            f'<input type="hidden" name="device_id" value="{d["id"]}">'
            f'<input type="hidden" name="_csrf" value="{csrf_val}">'
            f'<select name="user_id" class="form-select form-select-sm" style="min-width:140px;">'
            f'{selected_opts}</select>'
            f'<button class="btn btn-sm btn-outline-secondary">Save</button>'
            f'</form>'
            f'</td>'
            f'<td>'
            f'<form method="post" action="/identity/devices/{d["id"]}/delete" style="display:inline">'
            f'<input type="hidden" name="_csrf" value="{csrf_val}">'
            f'<button class="btn btn-sm btn-outline-danger"'
            f' onclick="return confirm(\'Delete this device?\')">Del</button>'
            f'</form>'
            f'</td>'
            f'</tr>'
        )
    if not device_rows:
        device_rows = '<tr><td colspan="9" class="text-center text-muted py-4">No devices for this tenant</td></tr>'

    content = f'''
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0">💻 Devices</h3>
      <div class="d-flex gap-2">
        <form class="d-flex gap-2" method="get">
          <select name="tenant_id" class="form-select form-select-sm" style="width:200px;">
            {tenant_options}
          </select>
          <button class="btn btn-sm btn-outline-secondary">Filter</button>
        </form>
        <a href="/identity/dhcp-import?tenant_id={tenant_id}" class="btn btn-outline-info btn-sm">⬆ DHCP Import</a>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <span>All Devices — {esc(next((t["name"] for t in tenants if t["id"] == tenant_id), ""))}</span>
        <span class="badge badge-teal">{len(devices)} device(s)</span>
      </div>
      <div class="table-responsive">
        <table class="table table-hover mb-0">
          <thead><tr>
            <th>IP Address</th><th>MAC Address</th><th>Hostname</th>
            <th>Label</th><th>Source</th><th>Valid From</th><th>Valid To</th>
            <th>Assigned User</th><th></th>
          </tr></thead>
          <tbody>{device_rows}</tbody>
        </table>
      </div>
    </div>

    <div class="card p-4">
      <h6 class="text-muted mb-3">ADD DEVICE</h6>
      <form method="post">
        <input type="hidden" name="action" value="add_device">
        <div class="row g-2 mb-2">
          <div class="col-md-2">
            <label class="form-label form-label-sm">Tenant *</label>
            <select name="tenant_id" class="form-select form-select-sm" required>
              {tenant_options}
            </select>
          </div>
          <div class="col-md-2">
            <label class="form-label form-label-sm">IP Address</label>
            <input name="ip_address" class="form-control form-control-sm" placeholder="192.168.1.10">
          </div>
          <div class="col-md-2">
            <label class="form-label form-label-sm">MAC Address</label>
            <input name="mac_address" class="form-control form-control-sm" placeholder="aa:bb:cc:dd:ee:ff">
          </div>
          <div class="col-md-2">
            <label class="form-label form-label-sm">Hostname</label>
            <input name="hostname" class="form-control form-control-sm" placeholder="DESKTOP-01">
          </div>
          <div class="col-md-2">
            <label class="form-label form-label-sm">Label</label>
            <input name="label" class="form-control form-control-sm" placeholder="John's PC">
          </div>
        </div>
        <div class="row g-2 mb-3">
          <div class="col-md-2">
            <label class="form-label form-label-sm">Source</label>
            <select name="source" class="form-select form-select-sm">
              <option value="manual" selected>manual</option>
              <option value="dhcp">dhcp</option>
              <option value="sso">sso</option>
              <option value="ldap">ldap</option>
            </select>
          </div>
          <div class="col-md-3">
            <label class="form-label form-label-sm">Assign to User (optional)</label>
            <select name="user_id" class="form-select form-select-sm">
              {user_options}
            </select>
          </div>
        </div>
        <button type="submit" class="btn btn-ss btn-sm">Add Device</button>
      </form>
    </div>'''
    return page('Devices', content, 'devices')


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(LOGO_DIR, exist_ok=True)
    _init_scheduler()
    try:
        app.run(host='0.0.0.0', port=8080, debug=False)
    finally:
        if _scheduler:
            stop_scheduler(_scheduler)
