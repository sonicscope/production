"""Spec §4.2 / §9: nothing the model can write may cross the tenant boundary."""
import psycopg2
import pytest

from reports.ai import credentials, executor
from reports.ai.sql_guard import GuardError, check_sql

ATTACKS = [
    "SELECT set_config('ss.tenant_id', '{b}', false)",
    "SELECT set_config('ss.tenant_id', '{b}', true), domain FROM ai.events",
    "WITH x AS (SELECT set_config('ss.tenant_id', '{b}', false)) SELECT * FROM ai.events",
    "SELECT current_setting('ss.tenant_id')",
    "SET ss.tenant_id = '{b}'",
    "RESET ALL",
    "SET search_path = public",
    "SELECT * FROM public.fw_events",
    "SELECT * FROM fw_events",
    "SELECT * FROM events",
    "SELECT * FROM pg_catalog.pg_roles",
    "SELECT * FROM pg_class",
    "SELECT * FROM information_schema.tables",
    "SELECT * FROM ai.events UNION SELECT * FROM public.fw_events",
    "SELECT * FROM public.lookup_identity({b}, '10.0.0.1')",
    "SELECT pg_read_file('/etc/passwd')",
    "SELECT pg_sleep(30)",
    "SELECT dblink('x', 'SELECT 1')",
    "SELECT lo_import('/etc/passwd')",
    "COPY (SELECT 1) TO PROGRAM 'id'",
    "SELECT 1; SELECT set_config('ss.tenant_id','{b}',false)",
    "EXPLAIN ANALYZE SELECT * FROM ai.events",
    "CREATE TEMP TABLE t AS SELECT 1",
    "SELECT * FROM ai.events FOR UPDATE",
    "SELECT * INTO TEMP t2 FROM ai.events",
    "SELECT * FROM ai . events /* c */ WHERE true",   # odd spacing must not bypass the rewrite
    "SELECT * FROM \"ai\".\"events\"",
]


@pytest.fixture
def two_tenants(seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example')
    seed_fw_event(b, domain='b.example')
    return a, b


@pytest.mark.parametrize('attack', ATTACKS)
def test_attack_is_rejected_or_stays_in_tenant(attack, ai_ro_config, two_tenants):
    a, b = two_tenants
    sql = attack.format(a=a, b=b)
    try:
        guarded = check_sql(sql, a)
        result = executor.run_query(ai_ro_config, a, guarded)
    except (GuardError, executor.ExecutorError):
        return                                              # rejected: fine
    leaked = [row for row in result.rows if any('b.example' in str(v) for v in row)]
    assert leaked == [], f'cross-tenant leak via: {sql}'


# Guard-PASSING queries that really execute: tenant A's row must come back
# (positive control) and tenant B's data must never appear.
PASSING = [
    "SELECT domain FROM ai.events WHERE true OR 1 = 1",
    "SELECT domain FROM ai.events WHERE domain = 'a.example' OR tenant_id = {b}",
    "SELECT e.domain FROM ai.events e WHERE e.domain IS NOT NULL",
    "WITH events AS (SELECT domain FROM ai.events) SELECT domain FROM events",
    "SELECT x.domain FROM ai.events x JOIN ai.events y ON x.domain = y.domain",
    "SELECT domain FROM ai.events UNION SELECT domain FROM ai.events",
    "SELECT domain FROM ai.events WHERE domain IN (SELECT domain FROM ai.events)",
    "SELECT domain, count(*) OVER (PARTITION BY domain) AS n FROM ai.events",
    "SELECT row_to_json(e)::text FROM ai.events e",
    "SELECT e.row_to_json FROM ai.events e",
]


@pytest.mark.parametrize('query', PASSING)
def test_guard_passing_query_returns_own_tenant_only(query, ai_ro_config, two_tenants):
    a, b = two_tenants
    sql = query.format(a=a, b=b)
    try:
        guarded = check_sql(sql, a)
    except GuardError:
        pytest.skip(f'guard rejects this form (acceptable): {sql}')
    result = executor.run_query(ai_ro_config, a, guarded)
    flat = [str(v) for row in result.rows for v in row]
    assert any('a.example' in v for v in flat), f'positive control failed: {sql}'
    assert not any('b.example' in v for v in flat), f'cross-tenant leak via: {sql}'


def test_at_least_six_passing_queries_actually_execute():
    accepted = 0
    for q in PASSING:
        try:
            check_sql(q.format(a=1, b=2), 1)
            accepted += 1
        except GuardError:
            pass
    assert accepted >= 6


def test_every_rewritten_relation_carries_the_literal_tenant(two_tenants):
    a, b = two_tenants
    for view in ('events', 'daily_app', 'daily_web', 'daily_geo', 'hourly_bandwidth'):
        q = check_sql(f'SELECT * FROM ai.{view}', a)
        assert f'tenant_id = {a}' in q.sql and f'tenant_id = {b}' not in q.sql


def test_role_has_no_path_to_sensitive_data(ai_ro_config):
    for sql in ("SELECT * FROM public.ai_settings", "SELECT * FROM public.ai_audit",
                "SELECT * FROM public.ui_users", "SELECT * FROM public.msp_profiles",
                "SELECT * FROM public.identity_mappings", "SELECT * FROM public.sensors",
                "SELECT * FROM public.hourly_user_traffic",
                "SELECT public.lookup_identity(1, '10.0.0.1')"):
        with psycopg2.connect(**ai_ro_config) as conn:
            with conn.cursor() as cur:
                with pytest.raises(psycopg2.errors.InsufficientPrivilege):
                    cur.execute(sql)


def test_ai_audit_cannot_be_edited_by_model_role(ai_ro_config):
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            with pytest.raises(psycopg2.Error):
                cur.execute("DELETE FROM public.ai_audit")


# ── authorisation matrix (beyond spec §4.2): every AI endpoint ──────────────
ENDPOINTS = [
    ('GET', '/investigate'),
    ('GET', '/settings/ai'),
    ('POST', '/settings/ai'),
    ('POST', '/settings/ai/test'),
    ('POST', '/investigate/chat'),
]


def _call(client, method, path, token, tenant):
    if path == '/investigate/chat':
        return client.open(path, method=method, json={'tenant_id': tenant, 'question': 'x'},
                           headers={'X-CSRF-Token': token})
    if method == 'POST':
        return client.open(path, method=method, data={'_csrf': token, 'provider': 'openai'},
                           headers={'X-CSRF-Token': token})
    return client.open(path, method=method)


@pytest.mark.parametrize('method,path', ENDPOINTS)
def test_customer_role_is_blocked(method, path, client, login_as, csrf_of, seed_tenants):
    t, = seed_tenants('Acme')
    login_as('customer', [t])
    resp = _call(client, method, path, csrf_of(client), t)
    assert resp.status_code in (302, 404), (method, path, resp.status_code)
    if resp.status_code == 302:
        assert '/portal' in resp.headers['Location']
        assert 'ai' not in resp.headers['Location'].replace('portal', '')


@pytest.mark.parametrize('method,path', ENDPOINTS)
def test_unauthenticated_is_redirected_to_login(method, path, client):
    resp = (client.post(path, json={}) if method == 'POST' else client.get(path))
    assert resp.status_code == 302
    assert 'login' in resp.headers['Location']


# ── secrets never leave the server via /settings/ai ─────────────────────────
def test_api_key_value_never_in_any_settings_response(client, app_module, login_as, csrf_of,
                                                      seed_tenants, tmp_path, monkeypatch):
    secret = 'sk-ZZTOPSECRET-0123456789abcdef'
    key_path = str(tmp_path / 'ai.key')
    credentials.generate_key_file(key_path)
    monkeypatch.setenv('AI_KEY_FILE', key_path)
    t, = seed_tenants('Acme')
    login_as('admin')
    token = csrf_of(client)
    seen = []
    resp = client.get('/settings/ai')
    seen.append(resp)
    resp = client.post('/settings/ai', data={
        '_csrf': token, 'provider': 'openai', 'model': 'gpt-x', 'api_key': secret,
        'consent': 'on', 'tenant_ids': [str(t)]}, follow_redirects=True)
    seen.append(resp)
    seen.append(client.get('/settings/ai'))
    seen.append(client.post('/settings/ai', data={'_csrf': token, 'provider': 'openai',
                                                  'model': 'gpt-x'}, follow_redirects=True))
    for r in seen:
        blob = r.get_data(as_text=True) + str(dict(r.headers))
        assert secret not in blob
        assert 'ZZTOPSECRET' not in blob
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute('SELECT row_to_json(s)::text FROM ai_settings s')
        assert secret not in cur.fetchone()[0]          # stored encrypted only


# ════════════════════════════════════════════════════════════════════════════
# Stage 2 (saved investigations) security regression block — spec §7 / §8
# ════════════════════════════════════════════════════════════════════════════
import csv  # noqa: E402
import json  # noqa: E402
import io  # noqa: E402
import re  # noqa: E402

from reports.ai import export, store  # noqa: E402
from reports.tests.test_ai_investigations_routes import (  # noqa: E402,F401
    detail as inv_detail, make, one_turn)
from reports.tests.test_ai_routes import ai_ready, audit_rows, chat  # noqa: E402,F401

HDR = 'X-CSRF-Token'


def _db(app_module):
    return psycopg2.connect(**app_module.DB_CONFIG)


def _sql(app_module, sql, params=()):
    with _db(app_module) as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall() if cur.description else None
        conn.commit()
    return rows


@pytest.fixture
def exec_spy(monkeypatch):
    """Records every executor.run_query call (tenant, guarded, kwargs) and still runs it."""
    calls = []
    real = executor.run_query

    def wrapper(config, tenant_id, guarded, **kw):
        calls.append((tenant_id, guarded, kw))
        return real(config, tenant_id, guarded, **kw)

    monkeypatch.setattr(executor, 'run_query', wrapper)
    return calls


@pytest.fixture
def seeded(client, app_module, login_as, csrf_of, ai_ready, monkeypatch, exec_spy):
    """Factory: a saved investigation (+ one pinned query finding) as a fresh owner."""
    def _seed(role='user', share=False):
        uid, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch, role=role,
                           share=share)
        d = inv_detail(app_module, inv_id)
        rid = d['results'][0]['id']
        resp = client.post(f'/investigate/{inv_id}/pin', headers={HDR: csrf_of(client)},
                           json={'kind': 'query', 'result_id': rid, 'title': 'First finding'})
        assert resp.status_code == 200, resp.get_data(as_text=True)
        exec_spy.clear()                       # the seeding chat ran SQL; assertions start clean
        return {'uid': uid, 'inv': inv_id, 'rid': rid, 'fid': resp.get_json()['id'],
                'tenant': ai_ready}
    return _seed


def _post(client, csrf_of, path, **body):
    return client.post(path, json=body, headers={HDR: csrf_of(client)})


# (a) stored SQL replaced after save: re-run and export must refuse, executor never called
STORED_ATTACKS = ['SELECT * FROM pg_user', "SELECT pg_read_file('/etc/passwd')",
                  'SELECT 1; SET ROLE postgres', 'SELECT * FROM public.ui_users']


@pytest.mark.parametrize('sql', STORED_ATTACKS)
@pytest.mark.parametrize('route', ['rerun', 'export'])
def test_tampered_stored_sql_is_refused_without_executor_call(
        sql, route, client, app_module, csrf_of, seeded, exec_spy):
    s = seeded()
    _sql(app_module, 'UPDATE ai_query_results SET sql_text = %s WHERE id = %s', (sql, s['rid']))
    resp = _post(client, csrf_of, f"/investigate/{s['inv']}/{route}", result_id=s['rid'])
    assert resp.status_code in (400, 422), resp.get_data(as_text=True)
    assert 'error' in resp.get_json()
    assert exec_spy == []
    rows = audit_rows(app_module, route)
    assert len(rows) == 1 and rows[0][5]                   # the refusal is audited with an error


# (b) the tenant lock follows the investigation ROW, never the SQL text
def test_tenant_lock_follows_the_investigation_row(client, app_module, login_as, csrf_of,
                                                   ai_ready, seed_tenants, seed_fw_event,
                                                   monkeypatch):
    b, = seed_tenants('Bravo')
    with _db(app_module) as conn, conn.cursor() as cur:
        store.set_enabled_tenants(cur, {ai_ready, b})
        conn.commit()
    for i in range(2):
        seed_fw_event(ai_ready, domain=f'a{i}.example')
    for i in range(5):
        seed_fw_event(b, domain=f'b{i}.example')
    uid = login_as('admin')
    one_turn(monkeypatch)
    from reports.tests.test_ai_investigations_routes import saved_id
    inv_id = saved_id(chat(client, csrf_of(client), ai_ready, question='count'))
    rid = inv_detail(app_module, inv_id)['results'][0]['id']
    assert 'tenant' not in inv_detail(app_module, inv_id)['results'][0]['sql'].lower()
    first = _post(client, csrf_of, f'/investigate/{inv_id}/rerun', result_id=rid).get_json()
    assert first['rows'] == [[2]]
    _sql(app_module, 'UPDATE ai_investigations SET tenant_id = %s WHERE id = %s', (b, inv_id))
    second = _post(client, csrf_of, f'/investigate/{inv_id}/rerun', result_id=rid).get_json()
    assert second['rows'] == [[5]]                          # B's rows only, never 7


# (c) the model's DB role cannot touch the Stage 2 tables
@pytest.mark.parametrize('table', ['ai_investigations', 'ai_messages', 'ai_query_results',
                                   'ai_findings'])
@pytest.mark.parametrize('stmt', ['SELECT * FROM public.{t}', 'INSERT INTO public.{t} DEFAULT VALUES',
                                  'DELETE FROM public.{t}'])
def test_ai_ro_role_has_no_access_to_stage2_tables(table, stmt, ai_ro_config, seeded):
    with psycopg2.connect(**ai_ro_config) as conn:
        conn.autocommit = True
        with conn.cursor() as cur:
            # The role is read-only by default; lift that so the GRANTs (not the
            # transaction mode) are what is under test for the writes.
            cur.execute('BEGIN READ WRITE')
            with pytest.raises(psycopg2.errors.InsufficientPrivilege):
                cur.execute(stmt.format(t=table))


# (d) stored XSS payloads come back as JSON strings, never HTML
XSS = ['<script>alert(1)</script>', '<img src=x onerror=alert(1)>']


@pytest.mark.parametrize('payload', XSS)
def test_stored_xss_is_returned_only_as_json(payload, client, app_module, csrf_of, seeded):
    s = seeded()
    inv = s['inv']
    _sql(app_module, 'UPDATE ai_investigations SET title = %s WHERE id = %s', (payload, inv))
    _sql(app_module, 'UPDATE ai_query_results SET columns = %s::jsonb, rows_snapshot = %s::jsonb '
         'WHERE id = %s', (json.dumps([payload]), json.dumps([[payload]]), s['rid']))
    assert client.patch(f"/investigate/{inv}/findings/{s['fid']}", headers={HDR: csrf_of(client)},
                        json={'title': payload, 'note': payload}).status_code == 200
    seen = [client.get(f'/investigate/{inv}'), client.get('/investigate/list?tab=mine'),
            client.patch(f"/investigate/{inv}/findings/{s['fid']}",
                         headers={HDR: csrf_of(client)}, json={'note': payload})]
    for resp in seen:
        assert resp.status_code == 200
        assert resp.mimetype == 'application/json'
        assert 'text/html' not in resp.headers['Content-Type']
        d = seen[0].get_json()
    assert d['investigation']['title'] == payload
    assert d['results'][0]['rows'] == [[payload]] and d['results'][0]['columns'] == [payload]
    assert d['findings'][0]['title'] == payload and d['findings'][0]['note'] == payload
    assert seen[1].get_json()['items'][0]['title'] == payload
    # the pinned evidence is a frozen copy: it carries the payload as a plain string too
    pinned = inv_detail(app_module, inv)['findings'][0]
    assert isinstance(pinned['title'], str)


# (e) route sweep with REAL ids: customers blocked, CSRF header/field required
def _sweep_paths(app_module, s):
    ids = {'inv_id': s['inv'], 'fid': s['fid']}
    out = []
    for rule in app_module.app.url_map.iter_rules():
        if not rule.endpoint.startswith('ai.'):
            continue
        path = re.sub(r'<(?:\w+:)?(\w+)>', lambda m: str(ids[m.group(1)]), rule.rule)
        for method in ('GET', 'POST', 'PATCH', 'DELETE'):
            if method in rule.methods:
                out.append((method, path))
    return out


def test_every_ai_route_blocks_customers_with_real_ids(client, app_module, login_as, csrf_of,
                                                       seeded, ai_ready):
    s = seeded()
    paths = _sweep_paths(app_module, s)
    assert len(paths) >= 17, paths          # 4 GET + 11 POST + PATCH + DELETE (Stage 1 + 2)
    assert any(str(s['inv']) in p for _, p in paths)       # parametrised rules were exercised
    login_as('customer', [ai_ready])
    token = csrf_of(client)
    for method, path in paths:
        resp = client.open(path, method=method, json={'tenant_id': ai_ready,
                                                      'result_id': s['rid'], 'title': 'x',
                                                      'kind': 'query', 'shared': True,
                                                      'message_seq': 1, 'ip': '10.0.0.1'},
                           headers={HDR: token})
        assert resp.status_code in (302, 404), (method, path, resp.status_code)
        if resp.status_code == 302:
            assert '/portal' in resp.headers['Location'], (method, path)
    assert _sql(app_module, 'SELECT count(*) FROM ai_investigations WHERE id = %s',
                (s['inv'],)) == [(1,)]                     # nothing deleted/changed


def test_every_mutating_ai_route_needs_csrf(client, app_module, login_as, csrf_of, seeded):
    s = seeded()
    paths = [(m, p) for m, p in _sweep_paths(app_module, s) if m != 'GET']
    assert len(paths) >= 13
    login_as('admin')                                       # staff, so only CSRF can refuse
    for method, path in paths:
        resp = client.open(path, method=method, json={'tenant_id': s['tenant'],
                                                      'result_id': s['rid'], 'title': 'x',
                                                      'kind': 'query', 'shared': True})
        assert resp.status_code == 400, (method, path, resp.status_code)
        bad = client.open(path, method=method, json={'tenant_id': s['tenant']},
                          headers={HDR: 'not-the-token'})
        assert bad.status_code == 400, (method, path, bad.status_code)
    assert _sql(app_module, 'SELECT count(*) FROM ai_investigations WHERE id = %s',
                (s['inv'],)) == [(1,)]


# (f) IDOR sweep: a same-tenant non-owner
def _calls(s):
    i, rid, fid = s['inv'], s['rid'], s['fid']
    return {
        'open': ('GET', f'/investigate/{i}', None),
        'rerun': ('POST', f'/investigate/{i}/rerun', {'result_id': rid}),
        'export': ('POST', f'/investigate/{i}/export', {'result_id': rid}),
        'rerun_update': ('POST', f'/investigate/{i}/rerun',
                         {'result_id': rid, 'update_snapshot': True}),
        'pin_query': ('POST', f'/investigate/{i}/pin',
                      {'kind': 'query', 'result_id': rid, 'title': 'idor'}),
        'pin_timeline': ('POST', f'/investigate/{i}/pin',
                         {'kind': 'timeline', 'ip': '10.0.0.1', 'title': 'idor'}),
        'rename': ('POST', f'/investigate/{i}/rename', {'title': 'hijacked'}),
        'share': ('POST', f'/investigate/{i}/share', {'shared': True}),
        'refresh': ('POST', f'/investigate/{i}/refresh', {'message_seq': 1}),
        'finding_edit': ('PATCH', f'/investigate/{i}/findings/{fid}', {'title': 'hijacked'}),
        'finding_delete': ('DELETE', f'/investigate/{i}/findings/{fid}', None),
        'delete': ('POST', f'/investigate/{i}/delete', {}),
    }


def _fire(client, csrf_of, call):
    method, path, body = call
    kw = {'headers': {HDR: csrf_of(client)}}
    if body is not None:
        kw['json'] = body
    return client.open(path, method=method, **kw)


def _state(app_module, s):
    return (_sql(app_module, 'SELECT title, shared FROM ai_investigations WHERE id = %s',
                 (s['inv'],)),
            _sql(app_module, 'SELECT id, title FROM ai_findings WHERE investigation_id = %s '
                 'ORDER BY id', (s['inv'],)),
            _sql(app_module, 'SELECT count(*) FROM ai_messages WHERE investigation_id = %s',
                 (s['inv'],)))


def test_private_investigation_is_404_on_every_route_for_a_peer(
        client, app_module, login_as, csrf_of, seeded, ai_ready, exec_spy):
    s = seeded()
    before = _state(app_module, s)
    login_as('user', [ai_ready])                            # same tenant, not the owner
    for name, call in _calls(s).items():
        resp = _fire(client, csrf_of, call)
        assert resp.status_code == 404, (name, resp.status_code)
    for tab in ('mine', 'shared', 'all'):
        items = client.get(f'/investigate/list?tab={tab}').get_json()['items']
        assert s['inv'] not in [i['id'] for i in items], tab
    assert chat(client, csrf_of(client), ai_ready, question='q',
                investigation_id=s['inv']).status_code == 404
    assert exec_spy == []                                   # nothing executed on the peer's behalf
    assert _state(app_module, s) == before


def test_shared_investigation_peer_can_read_and_rerun_but_not_mutate(
        client, app_module, login_as, csrf_of, seeded, ai_ready, exec_spy):
    s = seeded(share=True)
    before = _state(app_module, s)
    login_as('user', [ai_ready])
    calls = _calls(s)
    for name in ('open', 'rerun', 'export'):
        resp = _fire(client, csrf_of, calls[name])
        assert resp.status_code == 200, (name, resp.status_code)
    assert resp.mimetype == 'text/csv'
    assert [c[0] for c in exec_spy] == [ai_ready, ai_ready]
    for name in ('rerun_update', 'pin_query', 'pin_timeline', 'rename', 'share', 'refresh',
                 'finding_edit', 'finding_delete', 'delete'):
        assert _fire(client, csrf_of, calls[name]).status_code == 404, name
    assert chat(client, csrf_of(client), ai_ready, question='q',
                investigation_id=s['inv']).status_code == 404
    assert len(exec_spy) == 2                               # mutations ran nothing
    assert _state(app_module, s) == before
    shared = client.get('/investigate/list?tab=shared').get_json()['items']
    assert [i['id'] for i in shared] == [s['inv']]


def test_owner_control_for_the_idor_sweep_is_not_vacuous(client, app_module, csrf_of, seeded,
                                                         monkeypatch):
    s = seeded()
    calls = _calls(s)
    one_turn(monkeypatch)
    for name in ('open', 'rerun', 'export', 'rerun_update', 'pin_query', 'rename', 'share',
                 'finding_edit', 'finding_delete', 'delete'):
        resp = _fire(client, csrf_of, calls[name])
        assert resp.status_code == 200, (name, resp.status_code, resp.get_data(as_text=True))


# (g) a revoked tenant grant blocks every route immediately
@pytest.mark.parametrize('shared', [False, True])
def test_revoked_tenant_grant_blocks_every_route(shared, client, app_module, login_as, csrf_of,
                                                 seeded, ai_ready, exec_spy):
    s = seeded(share=shared)
    _fire(client, csrf_of, _calls(s)['open'])               # owner reaches it first
    for who in ('owner', 'peer'):
        if who == 'owner':
            uid = s['uid']
            with client.session_transaction() as sess:
                sess['user_id'], sess['user_role'] = uid, 'user'
        else:
            uid = login_as('user', [ai_ready])
        assert _fire(client, csrf_of, _calls(s)['open']).status_code in (
            (200,) if who == 'owner' or shared else (404,))
        _sql(app_module, 'DELETE FROM ui_user_tenants WHERE user_id = %s', (uid,))
        for name, call in _calls(s).items():
            assert _fire(client, csrf_of, call).status_code == 404, (who, name)
        assert _post(client, csrf_of, '/investigate/timeline', tenant_id=ai_ready,
                     ip='10.0.0.1').status_code == 404
        assert chat(client, csrf_of(client), ai_ready, question='q').status_code == 404
        assert client.get('/investigate/list?tab=mine').get_json()['items'] == []
    assert _sql(app_module, 'SELECT count(*) FROM ai_investigations WHERE id = %s',
                (s['inv'],)) == [(1,)]
    assert len(exec_spy) <= 2 if shared else exec_spy == []   # only the pre-revoke peer reads


# (h) export honours min(setting, hard cap); the cap cannot be raised by the setting
def _csv_rows(resp):
    return list(csv.reader(io.StringIO(resp.get_data(as_text=True).lstrip('﻿'))))


def test_export_cap_is_min_of_setting_and_hard_cap(client, app_module, csrf_of, seeded, ai_ready,
                                                   seed_fw_event, exec_spy, monkeypatch):
    for i in range(6):
        seed_fw_event(ai_ready, domain=f'cap{i}.example')
    s = seeded()
    _sql(app_module, 'UPDATE ai_query_results SET sql_text = %s WHERE id = %s',
         ('SELECT domain FROM ai.events ORDER BY domain', s['rid']))
    _sql(app_module, 'UPDATE ai_settings SET export_max_rows = 50000')
    monkeypatch.setattr(export, 'EXPORT_HARD_CAP', 3)
    resp = _post(client, csrf_of, f"/investigate/{s['inv']}/export", result_id=s['rid'])
    assert resp.status_code == 200
    assert exec_spy[-1][2]['max_rows'] == 3                 # hard cap wins over 50000
    rows = _csv_rows(resp)
    assert rows[0] == ['domain'] and len(rows) == 1 + 3 + 1
    assert rows[-1] == ['Showing the first 3 rows only']
    # a smaller stored setting is honoured when below the cap
    monkeypatch.setattr(export, 'EXPORT_HARD_CAP', 1000)
    _sql(app_module, 'UPDATE ai_settings SET export_max_rows = 100')
    resp = _post(client, csrf_of, f"/investigate/{s['inv']}/export", result_id=s['rid'])
    assert resp.status_code == 200 and exec_spy[-1][2]['max_rows'] == 100
    assert len(_csv_rows(resp)) == 1 + 6                    # 6 rows < 100: complete, no note


def test_hard_cap_constant_and_setting_range_cannot_exceed_it():
    assert export.effective_cap(10**9) == export.EXPORT_HARD_CAP == 50_000
    assert store.EXPORT_ROWS_RANGE[1] <= export.EXPORT_HARD_CAP


# (i) the Stage 1 batteries are intact (not edited down)
def test_stage1_battery_sizes_unchanged():
    assert len(ATTACKS) == 27 and len(PASSING) == 10


# (j) timeline IP injection via the HTTP route and the timeline pin
INJECT = ["fe80::1%x' OR '1'='1", "10.0.0.1'; DROP TABLE ai_findings;--", 'fe80::1%eth0']


@pytest.mark.parametrize('bad', INJECT)
def test_timeline_ip_injection_is_400_via_route_and_pin(bad, client, app_module, csrf_of, seeded,
                                                        exec_spy):
    s = seeded()
    resp = _post(client, csrf_of, '/investigate/timeline', tenant_id=s['tenant'], ip=bad)
    assert resp.status_code == 400 and resp.get_json()['error'] == 'Enter a valid IP address.'
    resp = _post(client, csrf_of, f"/investigate/{s['inv']}/pin", kind='timeline', ip=bad,
                 title='inject')
    assert resp.status_code == 400
    assert exec_spy == []
    assert audit_rows(app_module, 'timeline') == []
    assert len(inv_detail(app_module, s['inv'])['findings']) == 1     # only the seeded finding
