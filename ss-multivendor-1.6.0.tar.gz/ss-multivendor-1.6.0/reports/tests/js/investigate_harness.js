// Runs the Investigate page script in jsdom against stubbed fetch/clipboard and
// prints one JSON object {scenario: observations}. Page HTML arrives on stdin.
// jsdom is resolved from JSDOM_NODE_MODULES (a node_modules dir) or ./node_modules.
'use strict';
const path = require('path');
const fs = require('fs');
const base = process.env.JSDOM_NODE_MODULES || path.join(process.cwd(), 'node_modules');
const { JSDOM } = require(require.resolve('jsdom', { paths: [base, process.cwd()] }));

const html = fs.readFileSync(0, 'utf8');
const enc = new TextEncoder();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fr = (o) => 'data: ' + JSON.stringify(o) + '\n\n';

function stream(chunks, fail) {
  let i = 0;
  return new ReadableStream({
    pull(c) {
      if (i < chunks.length) { c.enqueue(chunks[i++]); }
      else if (fail) { c.error(new Error('boom')); }
      else { c.close(); }
    },
  });
}
const okStream = (frames, fail) => ({ ok: true, status: 200, body: stream([enc.encode(frames.join(''))], fail) });

async function run(fetchImpl, act, opts = {}) {
  const errs = [];
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/investigate',
    beforeParse(w) {
      w.TextDecoder = TextDecoder;
      w.__calls = []; w.__reqs = []; w.__apiBodies = [];
      w.fetch = async (u, o) => {
        w.__reqs.push(o.method + ' ' + u);
        if (u !== '/investigate/chat' && !/\/refresh$/.test(u)) {   // rail/API calls: served by opts.api
          const pb = o.body ? JSON.parse(o.body) : null;
          if (pb) { w.__apiBodies.push(u + ' ' + JSON.stringify(pb)); }
          const j = opts.api ? await opts.api(u, o.method, pb) : { items: [] };
          if (j && j.__status) { return { ok: false, status: j.__status, json: async () => ({ error: j.error }) }; }
          if (j && j.__csv !== undefined) {
            return { ok: true, status: 200, headers: { get: () => j.__cd || '' }, blob: async () => new w.Blob([j.__csv]) };
          }
          return { ok: true, status: 200, json: async () => j };
        }
        const body = JSON.parse(o.body);
        w.__calls.push(body);
        if (o.signal) {
          const aborted = new Promise((_, rej) => o.signal.addEventListener('abort', () => {
            const e = new Error('aborted'); e.name = 'AbortError'; rej(e);
          }));
          return Promise.race([Promise.resolve(fetchImpl(w.__calls.length, body, w)), aborted]);
        }
        return fetchImpl(w.__calls.length, body, w);
      };
      if (opts.chart) { w.Chart = function (c, cfg) { if (opts.chart === 'throw') { throw new Error('x'); } w.__chart = cfg; }; }
      if (opts.clipboard === 'reject') { w.navigator.clipboard = { writeText: () => Promise.reject(new Error('no')) }; }
      else if (opts.clipboard !== 'none') { w.navigator.clipboard = { writeText: (t) => { w.__clip = t; return Promise.resolve(); } }; }
      w.__dl = []; w.__revoked = [];
      w.URL.createObjectURL = (b) => { w.__blobSize = b.size; return 'blob:x/1'; };
      w.URL.revokeObjectURL = (u) => w.__revoked.push(u);
      w.HTMLAnchorElement.prototype.click = function () { w.__dl.push(this.download + '|' + this.getAttribute('href')); };
      w.addEventListener('error', (e) => errs.push(e.message));
    },
  });
  const w = dom.window; const d = w.document;
  const ask = (q) => {
    d.getElementById('inv-input').value = q;
    d.getElementById('inv-form').dispatchEvent(new w.Event('submit', { cancelable: true }));
  };
  await act({ w, d, ask });
  const send = d.getElementById('inv-send');
  const out = {
    dl: w.__dl, revoked: w.__revoked, errs, calls: w.__calls, reqs: w.__reqs, apiBodies: w.__apiBodies,
    rail: [...d.querySelectorAll('#rail-list li')].map((l) => l.textContent),
    railImgs: d.querySelectorAll('#rail-list img,#rail-list script').length,
    railCurrent: [...d.querySelectorAll('#rail-list [aria-current="true"]')].length,
    allTabHidden: d.getElementById('rail-all').classList.contains('d-none'),
    tenantValue: d.getElementById('inv-tenant').value, sendDisabled: send.disabled, label: send.textContent,
    tenantDisabled: d.getElementById('inv-tenant').disabled,
    bubbles: [...d.querySelectorAll('.bubble')].map((b) => (b.classList.contains('err') ? 'ERR:' : b.classList.contains('me') ? 'ME:' : 'A:') + b.textContent),
    msgsText: d.getElementById('inv-msgs').textContent,
    scripts: d.querySelectorAll('#inv-msgs script,#inv-msgs img').length,
    details: d.querySelectorAll('details.evidence').length,
    summary: (d.querySelector('summary') || {}).textContent,
    tds: [...d.querySelectorAll('tbody td')].map((t) => t.textContent),
    chips: [...d.querySelectorAll('.chips button')].map((b) => b.textContent),
    toolbarBtns: [...d.querySelectorAll('.ev-toolbar button')].map((b) => b.textContent),
    badge: [...d.querySelectorAll('.diff-badge')].map((b) => b.textContent + '|' + b.className),
    toolbarMeta: [...d.querySelectorAll('.ev-toolbar .meta')].map((b) => b.textContent),
    order: [...d.getElementById('inv-msgs').children].map((c) => c.className || c.tagName),
    chartNote: [...d.querySelectorAll('.chartbox .status')].map((n) => n.textContent),
    copyLabel: (d.querySelector('.evidence .btn') || {}).textContent,
    clip: w.__clip, chartCfg: w.__chart ? w.__chart.type : null,
    canvasLabel: d.querySelector('canvas') ? d.querySelector('canvas').getAttribute('aria-label') : null,
  };
  w.close();
  return out;
}

(async () => {
  const R = {};
  const evil = '<script>alert(1)</script>"\'><img src=x onerror=1>';
  const frames = [
    fr({ type: 'status', message: 'Running query…' }),
    fr({ type: 'sql', sql: 'SELECT ' + evil, columns: ['host', 'threat_name', 'n'],
         rows: [[evil, 'Evil.Threat', 1], [null, null, null]], truncated: false, row_count: 1234, duration_ms: 1234 }),
    fr({ type: 'chart', kind: 'bar', title: 'T"<b>', x: 'host', y: 'n', labels: ['a'], values: [1] }),
    fr({ type: 'text', text: 'Answer ✓ ünï 日本語 <b>x</b>' }),
    fr({ type: 'followups', items: ['Next 1?', 'Next <i>2</i>?'] }),
    fr({ type: 'done' }),
  ];
  const bytes = enc.encode(frames.join(''));
  const mb = [...bytes].findIndex((b) => b === 0xE2);
  const cuts = [7, 40, mb + 1, mb + 2, Math.floor(bytes.length / 2), bytes.length - 3].sort((a, b) => a - b);
  const chunks = []; let p = 0;
  for (const c of cuts) { chunks.push(bytes.slice(p, c)); p = c; }
  chunks.push(bytes.slice(p));
  const split = () => ({ ok: true, status: 200, body: stream(chunks) });

  R.success = await run(split, async ({ w, d, ask }) => { ask('  hello  '); await sleep(300); }, { chart: true });
  R.success_nochart = await run(split, async ({ ask }) => { ask('q'); await sleep(300); });
  R.chart_throws = await run(split, async ({ ask }) => { ask('q'); await sleep(300); }, { chart: 'throw' });
  R.copy = await run(split, async ({ w, d, ask }) => {
    ask('q'); await sleep(300); d.querySelector('.evidence .btn').click(); await sleep(30);
  });
  R.copy_fail = await run(split, async ({ d, ask }) => {
    ask('q'); await sleep(300); d.querySelector('.evidence .btn').click(); await sleep(30);
  }, { clipboard: 'reject' });
  R.copy_none = await run(split, async ({ d, ask }) => {
    ask('q'); await sleep(300); d.querySelector('.evidence .btn').click(); await sleep(30);
  }, { clipboard: 'none' });
  R.followup_explain = await run(split, async ({ d, ask }) => {
    ask('q'); await sleep(300);
    d.querySelector('.chips button').click(); await sleep(300);
    d.querySelector('td button').click(); await sleep(300);
  });
  R.error_event = await run(() => okStream([fr({ type: 'status', message: 's' }),
    fr({ type: 'error', message: 'Model failed <b>', tokens_in: 1, tokens_out: 2 }), fr({ type: 'done' })]),
    async ({ ask }) => { ask('q'); await sleep(200); });
  for (const [st, body] of [[429, '{"error":"Rate limited"}'], [409, '{"error":"Busy"}'], [502, '<html>bad gateway</html>']]) {
    R['http_' + st] = await run(() => ({ ok: false, status: st, json: async () => JSON.parse(body), body: null }),
      async ({ ask }) => { ask('q'); await sleep(100); });
  }
  R.fetch_reject = await run(() => { throw new Error('net'); }, async ({ ask }) => { ask('q'); await sleep(100); });
  R.no_done = await run(() => okStream([fr({ type: 'text', text: 'hi' })]),
    async ({ ask }) => { ask('q'); await sleep(150); ask('q2'); await sleep(150); });
  R.empty_stream = await run(() => okStream([]),
    async ({ ask }) => { ask('q'); await sleep(100); ask('q2'); await sleep(100); });
  R.stream_error_no_answer = await run(() => okStream([fr({ type: 'status', message: 's' })], true),
    async ({ ask }) => { ask('q'); await sleep(150); ask('q2'); await sleep(150); });
  R.double_submit = await run(() => new Promise((res) => setTimeout(() => res(okStream([fr({ type: 'done' })])), 150)),
    async ({ d, ask }) => { ask('a'); ask('b'); await sleep(50); R._dbl_disabled = d.getElementById('inv-tenant').disabled; await sleep(300); });
  R.history_bound = await run(() => okStream([fr({ type: 'text', text: 'A'.repeat(6000) }), fr({ type: 'done' })]),
    async ({ ask }) => { for (let i = 0; i < 8; i++) { ask('q' + i); await sleep(80); } });
  // Tenant switch while a request is in flight (regression: old answer leaked).
  R.tenant_race = await run(async (n) => {
    if (n === 1) { await sleep(100); return okStream([fr({ type: 'text', text: 'OLDTENANT answer' }), fr({ type: 'done' })]); }
    return okStream([fr({ type: 'done' })]);
  }, async ({ w, d, ask }) => {
    ask('q'); await sleep(30);
    const s = d.getElementById('inv-tenant'); s.disabled = false; s.value = '2';
    s.dispatchEvent(new w.Event('change'));
    await sleep(250); ask('q2'); await sleep(100);
  });
  R.tenant_select_disabled_in_flight = await run(() => new Promise((res) => setTimeout(() => res(okStream([fr({ type: 'done' })])), 100)),
    async ({ d, ask }) => { ask('q'); await sleep(20); R._sel_disabled_mid = d.getElementById('inv-tenant').disabled; await sleep(250); });
  // ---- Stage 2 rail ----
  const evilTitle = '<img src=x onerror=1> Q';
  const listItems = [
    { id: 7, title: evilTitle, tenant_id: 2, tenant_name: 'Beta', shared: true, owner_is_me: true,
      updated_at: '2026-11-18T10:00:00+00:00', finding_count: 2 },
    { id: 8, title: 'Second', tenant_id: 1, tenant_name: 'Acme', shared: false, owner_is_me: true,
      updated_at: '2026-11-18T09:00:00+00:00', finding_count: 0 },
  ];
  const detail = {
    investigation: { id: 7, tenant_id: 2, title: evilTitle, shared: true },
    messages: [{ seq: 1, role: 'user', content: 'old q <b>' }, { seq: 2, role: 'assistant', content: 'old a' }],
    results: [{ id: 1, message_seq: 2, ordinal: 0, sql: 'SELECT 1', columns: ['n'], rows: [[1]],
                row_count: 1, truncated: false, duration_ms: 5, snapshot_at: '2026-11-18T10:00:00+00:00' }],
    findings: [], can_edit: true,
  };
  const api = (u, m) => (u.indexOf('/investigate/list') === 0 ? { items: listItems }
    : u === '/investigate/7' ? detail : {});
  R.rail_list = await run(() => okStream([fr({ type: 'done' })]), async () => { await sleep(100); }, { api });
  R.rail_open = await run(() => okStream([fr({ type: 'text', text: 'next' }), fr({ type: 'done' })]),
    async ({ d, ask }) => {
      await sleep(80); d.querySelector('#rail-list button').click(); await sleep(100);
      ask('follow'); await sleep(200);
    }, { api });
  R.rail_saved = await run(() => okStream([
    fr({ type: 'saved', investigation_id: 8, title: 'Second' }),
    fr({ type: 'text', text: 'a' }), fr({ type: 'done' })]),
    async ({ ask }) => { await sleep(50); ask('q1'); await sleep(200); ask('q2'); await sleep(200); }, { api });
  R.rail_new = await run(() => okStream([fr({ type: 'text', text: 'next' }), fr({ type: 'done' })]),
    async ({ d, ask }) => {
      await sleep(80); d.querySelector('#rail-list button').click(); await sleep(100);
      d.getElementById('rail-new').click(); await sleep(30);
      R._new_bubbles = d.querySelectorAll('.bubble').length;
      ask('fresh'); await sleep(200);
    }, { api });
  R.rail_tab = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); d.querySelector('[data-tab="shared"]').click(); await sleep(50);
  }, { api });
  R.rail_search = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); const i = d.getElementById('rail-search'); i.value = 'second';
    i.dispatchEvent(new w.Event('input')); await sleep(20);
  }, { api });
  R.rail_api_fail = await run(() => okStream([]), async () => { await sleep(80); },
    { api: () => { throw new Error('down'); } });
  // ---- Stage 2 follow-ups: read-only composer, stale opens, drawer + tab a11y ----
  const roDetail = { investigation: { id: 9, tenant_id: 1, title: 'Peer', shared: true },
    messages: [{ seq: 1, role: 'user', content: 'pq' }, { seq: 2, role: 'assistant', content: 'pa' }],
    results: [{ id: 5, message_seq: 2, ordinal: 0, sql: 'SELECT 2', columns: ['n'], rows: [[2]],
                row_count: 1, truncated: false, duration_ms: 5, snapshot_at: '2026-11-18T10:00:00+00:00' }],
    findings: [], can_edit: false };
  const listItems2 = [listItems[0], Object.assign({}, listItems[1], { id: 9, title: 'Peer', tenant_name: 'Acme' })];
  const roApi = (u) => (u.indexOf('/investigate/list') === 0 ? { items: listItems2 }
    : u === '/investigate/9' ? roDetail : u === '/investigate/7' ? detail : {});
  R.readonly = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); const snap = () => ({ inp: d.getElementById('inv-input').disabled,
      btn: d.getElementById('inv-send').disabled, note: (d.getElementById('inv-ro') || {}).textContent });
    R._ro_before = snap();
    d.getElementById('inv-send').disabled = false;
    await roOpen(w, d, 9); R._ro_open = snap();
    d.getElementById('rail-new').click(); await sleep(30); R._ro_new = snap();
    await roOpen(w, d, 9); R._ro_open2 = snap();
    const s = d.getElementById('inv-tenant'); s.value = '2'; s.dispatchEvent(new w.Event('change')); await sleep(30);
    R._ro_tenant = snap();
  }, { api: roApi });
  function openBtn(d, id) { return () => d.querySelectorAll('#rail-list button')[id === 7 ? 0 : 1].click(); }
  async function roOpen(w, d, id) {
    openBtn(d, id)(); await sleep(60);
  }
  R.stale_open = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); openBtn(d, 7)(); openBtn(d, 9)(); await sleep(250);
  }, { api: async (u) => {
    if (u === '/investigate/7') { await sleep(120); return detail; }
    return roApi(u); } });
  R.stale_open_then_new = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); openBtn(d, 7)(); d.getElementById('rail-new').click(); await sleep(250);
  }, { api: async (u) => { if (u === '/investigate/7') { await sleep(100); return detail; } return roApi(u); } });
  R.drawer = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50);
    const rail = d.getElementById('inv-rail'), tog = d.getElementById('rail-toggle'), bd = d.getElementById('rail-backdrop') || d.createElement('div');
    const st = () => ({ open: rail.classList.contains('open'), exp: tog.getAttribute('aria-expanded'), bd: bd.classList.contains('show') });
    tog.click(); R._dr_open = st();
    d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); R._dr_esc = st();
    R._dr_focus = d.activeElement === tog;
    tog.click(); bd.click(); R._dr_bd = st();
    d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); R._dr_noop = st();
  }, { api });
  R.tabs_keys = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50);
    const tabs = [...d.querySelectorAll('[data-tab]')];
    const key = (el, k) => el.dispatchEvent(new w.KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true }));
    const st = () => ({ sel: tabs.map((t) => t.getAttribute('aria-selected')), ti: tabs.map((t) => t.tabIndex),
      focus: tabs.indexOf(d.activeElement) });
    R._tab_init = st();
    tabs[0].focus(); key(tabs[0], 'ArrowRight'); await sleep(30); R._tab_right = st();
    key(tabs[1], 'ArrowLeft'); await sleep(30); R._tab_left = st();
    key(tabs[0], 'ArrowLeft'); await sleep(30); R._tab_wrap = st();   // wraps to last
  }, { api });
  // ---- Task 3 toolbar: Re-run, diff badge, Ask AI to refresh ----
  const evilCell = '<img src=x onerror=1>';
  const rerunApi = (payload) => async (u) => {
    if (u === '/investigate/7/rerun' || u === '/investigate/9/rerun') { return payload; }
    return roApi(u);
  };
  const changed = { columns: ['n'], rows: [[evilCell], [3]], row_count: 134, truncated: false, duration_ms: 7,
    diff: { identical: false, columns_changed: false, row_count_old: 120, row_count_new: 134, delta: 14,
            added: 15, removed: 1, changed: 3, mode: 'keyed', added_rows: [], removed_rows: [] },
    snapshot_updated: false, snapshot_at: '2026-11-18T10:00:00+00:00' };
  const same = Object.assign({}, changed, { rows: [[1]], row_count: 1,
    diff: Object.assign({}, changed.diff, { identical: true, added: 0, removed: 0, changed: 0 }) });
  R.tb_owner = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    R._tb_before = [...d.querySelectorAll('.ev-toolbar button')].map((b) => b.textContent);
    [...d.querySelectorAll('.ev-toolbar button')].find((b) => b.textContent === 'Re-run').click(); await sleep(60);
  }, { api: rerunApi(changed) });
  R.tb_same = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    [...d.querySelectorAll('.ev-toolbar button')].find((b) => b.textContent === 'Re-run').click(); await sleep(60);
  }, { api: rerunApi(same) });
  R.tb_err = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    const b = [...d.querySelectorAll('.ev-toolbar button')].find((x) => x.textContent === 'Re-run'); b.click(); await sleep(60);
    R._tb_err_enabled = !b.disabled;
  }, { api: rerunApi({ __status: 422, error: 'Query rejected <b>' }) });
  R.tb_shared = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 9)(); await sleep(60);
    [...d.querySelectorAll('.ev-toolbar button')].find((b) => b.textContent === 'Re-run').click(); await sleep(60);
  }, { api: rerunApi(changed) });
  R.tb_refresh = await run(() => okStream([fr({ type: 'saved', investigation_id: 7, title: 'T' }),
    fr({ type: 'text', text: 'fresh answer' }), fr({ type: 'done' })]),
    async ({ d, ask }) => {
      await sleep(50); openBtn(d, 7)(); await sleep(60);
      [...d.querySelectorAll('.ev-toolbar button')].find((b) => b.textContent === 'Ask AI to refresh').click(); await sleep(150);
      ask('next'); await sleep(150);
    }, { api: rerunApi(changed) });
  // ---- Task 4: CSV button + sampled badge ----
  const csvApi = (payload) => async (u) => (u === '/investigate/7/export' ? payload : rerunApi(changed)(u));
  const csvClick = async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    R._csv_before = [...d.querySelectorAll('.ev-toolbar button')].map((b) => b.textContent);
    const b = [...d.querySelectorAll('.ev-toolbar button')].find((x) => x.textContent === 'CSV'); b.click(); await sleep(80);
    R._csv_enabled = !b.disabled; R._csv_aria = b.getAttribute('aria-label');
  };
  R.csv_ok = await run(() => okStream([]), csvClick, { api: csvApi({ __csv: 'a\r\n1', __cd: 'attachment; filename="T-1.csv"' }) });
  R.csv_err = await run(() => okStream([]), csvClick, { api: csvApi({ __status: 422, error: 'Query rejected <b>' }) });
  R.sampled = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    [...d.querySelectorAll('.ev-toolbar button')].find((b) => b.textContent === 'Re-run').click(); await sleep(60);
  }, { api: rerunApi(Object.assign({}, changed, { truncated: true })) });
  R.sampled_big = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    [...d.querySelectorAll('.ev-toolbar button')].find((b) => b.textContent === 'Re-run').click(); await sleep(60);
  }, { api: rerunApi(Object.assign({}, changed, { row_count: 501 })) });
  // ---- Task 5: header controls, Pin, findings tray ----
  const evEv = (n) => ({ sql: 'SELECT n', columns: ['n', 'threat_name'], rows: Array.from({ length: n }, (_, i) => [i === 0 ? evilCell : i, 'T' + i]),
    row_count: n, truncated: false, snapshot_at: '2026-11-18T10:00:00+00:00', duration_ms: 5 });
  const mkFinding = (id, title, n) => ({ id, title, note: evilCell, evidence_kind: 'query', evidence: evEv(n),
    pinned_at: '2026-11-18T10:05:00+00:00', updated_at: '2026-11-18T10:05:00+00:00', created_by: 1, report_id: null });
  const t5api = (state, ro) => async (u, m, pb) => {
    if (u.indexOf('/investigate/list') === 0) { return { items: listItems2 }; }
    if (u === '/investigate/7' && m === 'GET') {
      return Object.assign({}, detail, { investigation: Object.assign({}, detail.investigation, { title: state.title, shared: state.shared }), findings: state.findings });
    }
    if (u === '/investigate/9') { return Object.assign({}, roDetail, { findings: [mkFinding(4, 'Peer finding', 2)] }); }
    if (u === '/investigate/7/pin') { state.findings.push(mkFinding(state.findings.length + 10, pb.title, 2)); return { ok: true, id: 10 }; }
    if (/\/findings\/\d+$/.test(u) && m === 'PATCH') { const f = state.findings.find((x) => u.endsWith('/' + x.id)); Object.assign(f, pb); return { ok: true }; }
    if (/\/findings\/\d+$/.test(u) && m === 'DELETE') { state.findings = state.findings.filter((x) => !u.endsWith('/' + x.id)); return { ok: true }; }
    if (u === '/investigate/7/rename') { state.title = pb.title; return { ok: true }; }
    if (u === '/investigate/7/share') { state.shared = pb.shared; return { ok: true }; }
    if (u === '/investigate/7/delete') { return { ok: true }; }
    return {};
  };
  const t5fail = { on: false };
  const t5two2 = (() => { const st = { title: evilTitle, shared: true, findings: [mkFinding(3, evil, 7), mkFinding(5, 'Second', 3)] }; return st; })();
  const t5state = () => ({ title: evilTitle, shared: true, findings: [mkFinding(3, evil, 7)] });
  const btnsOf = (d, sel) => [...d.querySelectorAll(sel + ' button')].map((b) => b.textContent);
  const byText = (d, sel, t) => [...d.querySelectorAll(sel)].find((b) => b.textContent === t);
  const tray = (d) => ({
    cards: d.querySelectorAll('#tray-list .finding').length,
    titles: [...d.querySelectorAll('#tray-list .finding input')].map((i) => i.value),
    notes: [...d.querySelectorAll('#tray-list .finding textarea')].map((i) => i.value),
    text: d.getElementById('tray-list').textContent,
    inject: d.querySelectorAll('#tray-list img,#tray-list script,#inv-header img,#inv-header script').length,
    tds: d.querySelectorAll('#tray-list tbody td').length,
    explain: [...d.querySelectorAll('#tray-list button')].filter((b) => b.textContent === 'Explain').length,
    btns: btnsOf(d, '#tray-list'), toggle: d.getElementById('tray-toggle').textContent,
  });
  R.t5_owner = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    R._t5_tray = tray(d);
    R._t5_header = { text: d.getElementById('inv-header').textContent, btns: btnsOf(d, '#inv-header'),
      title: (d.querySelector('#inv-header .inv-title') || {}).textContent };
    R._t5_toolbar = btnsOf(d, '.ev-toolbar'); R._t5_title = evilTitle;
  }, { api: t5api(t5state()) });
  R.t5_pin = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '.ev-toolbar button', 'Pin').click();
    const f = d.querySelector('.pin-form');
    R._t5_pinform = { title: f.querySelector('input').value, hasNote: !!f.querySelector('textarea') };
    f.querySelector('textarea').value = 'why <b>';
    f.querySelector('input').value = 'My <i>pin</i>';
    byText(d, '.pin-form button', 'Save pin').click(); await sleep(100);
    R._t5_after = tray(d); R._t5_formGone = !d.querySelector('.pin-form');
    R._t5_status = [...d.querySelectorAll('.ev-toolbar .diff-badge')].map((b) => b.textContent);
  }, { api: t5api(t5state()) });
  R.t5_pin_err = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '.ev-toolbar button', 'Pin').click();
    byText(d, '.pin-form button', 'Save pin').click(); await sleep(80);
    R._t5_pinerr = [...d.querySelectorAll('.ev-toolbar .diff-badge')].map((b) => b.textContent);
    R._t5_pinform_kept = !!d.querySelector('.pin-form');
  }, { api: async (u, m, pb) => (u === '/investigate/7/pin' ? { __status: 400, error: 'Enter a title <b>' } : t5api(t5state())(u, m, pb)) });
  R.t5_edit = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    d.querySelector('#tray-list .finding input').value = 'Edited';
    d.querySelector('#tray-list .finding textarea').value = 'new note';
    byText(d, '#tray-list button', 'Save').click(); await sleep(100);
    R._t5_edited = tray(d);
  }, { api: t5api(t5state()) });
  R.t5_remove = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '#tray-list button', 'Remove').click();
    R._t5_rm_first = { btns: btnsOf(d, '#tray-list') };
    byText(d, '#tray-list button', 'Yes').click(); await sleep(100);
    R._t5_removed = tray(d);
  }, { api: t5api(t5state()) });
  R.t5_readonly = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 9)(); await sleep(80);
    R._t5_ro = { tray: tray(d), header: { text: d.getElementById('inv-header').textContent, btns: btnsOf(d, '#inv-header') },
      toolbar: btnsOf(d, '.ev-toolbar') };
  }, { api: t5api(t5state()) });
  R.t5_rename = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '#inv-header button', 'Rename').click();
    const i = d.querySelector('#inv-header input'); R._t5_renameVal = i.value;
    i.value = 'Renamed <b>'; byText(d, '#inv-header button', 'Save').click(); await sleep(100);
    R._t5_renamed = { title: d.querySelector('#inv-header .inv-title').textContent, inject: d.querySelectorAll('#inv-header b').length };
  }, { api: t5api(t5state()) });
  R.t5_share = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '#inv-header button', 'Unshare').click(); await sleep(100);
    R._t5_shared_after = btnsOf(d, '#inv-header');
  }, { api: t5api(t5state()) });
  R.t5_delete = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '#inv-header button', 'Delete').click();
    R._t5_confirm = btnsOf(d, '#inv-header');
    byText(d, '#inv-header button', 'No').click();
    R._t5_cancel = btnsOf(d, '#inv-header');
    byText(d, '#inv-header button', 'Delete').click();
    byText(d, '#inv-header button', 'Yes').click(); await sleep(100);
    R._t5_deleted = { header: d.getElementById('inv-header').textContent, bubbles: d.querySelectorAll('.bubble').length, tray: tray(d) };
  }, { api: t5api(t5state()) });
  R.t5_fresh = await run(() => okStream([]), async ({ d }) => {
    await sleep(60);
    R._t5_fresh = { header: d.getElementById('inv-header').textContent, btns: btnsOf(d, '#inv-header'), tray: tray(d) };
  }, { api: t5api(t5state()) });
  // ---- Task 5 review fixes: focus, live regions, reload failures, finding confirm, live pin ----
  const t5two = () => { const st = t5state(); st.findings.push(mkFinding(5, 'Second', 3)); return st; };
  const act = (d) => { const a = d.activeElement; return a === d.body ? 'BODY' : (a.id || a.getAttribute('aria-label') || a.textContent || a.tagName); };
  const actIn = (d, sel) => { const a = d.activeElement; return !!a && !!a.closest && !!a.closest(sel) ? (a.textContent || a.tagName) : 'NOT-IN:' + act(d); };
  const cardOf = (d, i) => d.querySelectorAll('#tray-list .finding')[i];
  R.t5_focus_header = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '#inv-header button', 'Rename').click();
    byText(d, '#inv-header button', 'Cancel').click(); R._f_cancel = act(d);
    byText(d, '#inv-header button', 'Rename').click();
    d.querySelector('#inv-header input').value = 'New name';
    byText(d, '#inv-header button', 'Save').click(); await sleep(100); R._f_rensave = act(d);
    byText(d, '#inv-header button', 'Delete').click();
    byText(d, '#inv-header button', 'No').click(); R._f_delno = act(d);
    byText(d, '#inv-header button', 'Unshare').click(); await sleep(100); R._f_share = act(d);
    byText(d, '#inv-header button', 'Delete').click();
    byText(d, '#inv-header button', 'Yes').click(); await sleep(100); R._f_delyes = act(d);
  }, { api: t5api(t5state()) });
  R.t5_status_nodes = await run(() => okStream([]), async ({ d }) => {
    await sleep(50);
    const h0 = d.getElementById('hdr-status'), t0 = d.getElementById('tray-status');
    R._s_attrs = { h: [h0.getAttribute('role'), h0.getAttribute('aria-live')], t: [t0.getAttribute('role'), t0.getAttribute('aria-live')],
      hEmpty: h0.textContent === '', tEmpty: t0.textContent === '' };
    openBtn(d, 7)(); await sleep(80);
    byText(d, '#inv-header button', 'Rename').click();
    d.querySelector('#inv-header input').value = 'x';
    byText(d, '#inv-header button', 'Save').click(); await sleep(100);   // server rejects
    R._s_hdr = { same: d.getElementById('hdr-status') === h0, text: h0.textContent, count: d.querySelectorAll('.hdr-status,#hdr-status').length };
    byText(d, '#inv-header button', 'Cancel').click();
    R._s_hdr_after_render = d.getElementById('hdr-status') === h0 && h0.isConnected;
  }, { api: async (u, m, pb) => (u === '/investigate/7/rename' ? { __status: 400, error: 'Title rejected <b>' } : t5api(t5two())(u, m, pb)) });
  R.t5_finding_save = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    const b = cardOf(d, 1); b.__mark = 'B';
    b.querySelector('input').value = 'B draft title'; b.querySelector('textarea').value = 'B draft note';
    const a = cardOf(d, 0);
    a.querySelector('input').value = 'A saved';
    byText(d, '#tray-list .finding:first-child button', 'Save').click(); await sleep(120);
    const b2 = cardOf(d, 1);
    R._fs = { active: actIn(d, '#tray-list .finding:first-child'), aTitle: cardOf(d, 0).querySelector('input').value,
      bSame: b2.__mark === 'B', bTitle: b2.querySelector('input').value, bNote: b2.querySelector('textarea').value,
      cards: d.querySelectorAll('#tray-list .finding').length };
  }, { api: t5api(t5two()) });
  R.t5_reload_fail = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    t5fail.on = true;
    cardOf(d, 1).querySelector('textarea').value = 'B draft';
    byText(d, '#tray-list .finding:first-child button', 'Save').click(); await sleep(120);
    t5fail.on = false;
    R._rf = { status: d.getElementById('tray-status').textContent, cards: d.querySelectorAll('#tray-list .finding').length,
      bNote: cardOf(d, 1).querySelector('textarea').value, active: act(d) };
  }, { api: async (u, m, pb) => ((t5fail.on && u === '/investigate/7' && m === 'GET') ? { __status: 500, error: 'down' } : t5api(t5two2)(u, m, pb)) });
  R.t5_finding_remove = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    const first = '#tray-list .finding:first-child button';
    byText(d, first, 'Remove').click();
    R._fr = { confirm: btnsOf(d, '#tray-list .finding:first-child'), noDelete: !w.__reqs.some((r) => r.indexOf('DELETE') === 0), activeNo: act(d) };
    byText(d, first, 'No').click();
    R._fr.restored = btnsOf(d, '#tray-list .finding:first-child'); R._fr.activeRm = act(d);
    byText(d, first, 'Remove').click(); byText(d, first, 'Yes').click(); await sleep(120);
    R._fr.deleted = w.__reqs.filter((r) => r.indexOf('DELETE') === 0);
    R._fr.afterFirst = { cards: d.querySelectorAll('#tray-list .finding').length, active: actIn(d, '#tray-list .finding'), val: d.activeElement.value };
    byText(d, first, 'Remove').click(); byText(d, first, 'Yes').click(); await sleep(120);
    R._fr.afterLast = { cards: d.querySelectorAll('#tray-list .finding').length, active: act(d) };
  }, { api: t5api(t5two()) });
  R.t5_pin_focus = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    byText(d, '.ev-toolbar button', 'Pin').click();
    R._pf_open = d.activeElement.tagName;
    byText(d, '.pin-form button', 'Save pin').click(); await sleep(120);
    R._pf = { active: act(d), formGone: !d.querySelector('.pin-form') };
  }, { api: t5api(t5state()) });
  const liveFrames = (ids) => [fr({ type: 'status', message: 's' }),
    fr({ type: 'sql', sql: 'SELECT live', columns: ['n'], rows: [[1]], truncated: false, row_count: 1, duration_ms: 5 }),
    fr({ type: 'saved', investigation_id: 7, title: 'Live <b>', result_ids: ids, assistant_seq: 2 }),
    fr({ type: 'text', text: 'Done' }), fr({ type: 'done' })];
  R.t5_live_pin = await run(() => okStream(liveFrames([55])), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(250);
    R._lp_bar = btnsOf(d, '.ev-toolbar');
    byText(d, '.ev-toolbar button', 'Pin').click();
    d.querySelector('.pin-form textarea').value = 'n';
    byText(d, '.pin-form button', 'Save pin').click(); await sleep(120);
    R._lp_active = act(d);
  }, { api: t5api(t5state()) });
  R.t5_live_mismatch = await run(() => okStream(liveFrames([])), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(250);
    R._lm = { bar: btnsOf(d, '.ev-toolbar'), details: d.querySelectorAll('details.evidence').length };
  }, { api: t5api(t5state()) });
  R.t5_live_nosaved = await run(() => okStream(liveFrames([55]).filter((x) => x.indexOf('"saved"') < 0)), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(250);
    R._ln = { bar: btnsOf(d, '.ev-toolbar'), details: d.querySelectorAll('details.evidence').length };
  }, { api: t5api(t5state()) });
  // ---- Task 6: timeline ----
  const tlRows = Array.from({ length: 150 }, (_, i) => ['2026-11-18T10:00:00+00:00', ['denied', 'threat', 'vpn', 'allowed'][i % 4], 'deny', '10.9.9.9', '1.1.1.1', 443, 'tcp', i === 0 ? evilCell : 'r' + i, 'T' + i, 'ZA']);
  const tlCols = ['time', 'kind', 'action', 'src_ip', 'dst_ip', 'dst_port', 'protocol', 'rule_name', 'threat_or_app', 'country'];
  const tlApi = (rows, truncated) => async (u, m, pb) => (u === '/investigate/timeline'
    ? { columns: tlCols, rows, row_count: rows.length, truncated: !!truncated, window: pb.window, ip: pb.ip, duration_ms: 5 }
    : t5api(t5state())(u, m, pb));
  const tlFrames = (cols, row, saved) => [fr({ type: 'status', message: 's' }),
    fr({ type: 'sql', sql: 'SELECT x', columns: cols, rows: [row, row.map(() => null)], truncated: false, row_count: 2, duration_ms: 5 }),
    ...(saved ? [fr({ type: 'saved', investigation_id: 7, title: 'T', result_ids: [55], assistant_seq: 2 })] : []),
    fr({ type: 'text', text: 'Done' }), fr({ type: 'done' })];
  const tlBtns = (d) => [...d.querySelectorAll('#inv-msgs button')].filter((b) => /^Timeline/.test(b.textContent));
  const dlg = (d) => d.querySelector('[role="dialog"]');
  const tlReqs = (w) => w.__apiBodies.filter((x) => x.indexOf('/investigate/timeline') === 0);
  R.t6_buttons = await run(() => okStream(tlFrames(['src_ip', 'dst_ip', 'n'], ['10.9.9.9', '2001:db8::1', 1])), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(200);
    R._tb = tlBtns(d).map((b) => b.getAttribute('aria-label'));
  }, { api: tlApi([]) });
  R.t6_buttons_none = await run(() => okStream(tlFrames(['host', 'n'], ['10.9.9.9', 1])), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(200); R._tbn = tlBtns(d).length;
  }, { api: tlApi([]) });
  R.t6_buttons_bad = await run(() => okStream(tlFrames(['ip', 'n'], ['<img src=x onerror=1>', 1])), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(200); R._tbb = tlBtns(d).length;
  }, { api: tlApi([]) });
  R.t6_panel = await run(() => okStream(tlFrames(['src_ip', 'n'], ['10.9.9.9', 1])), async ({ w, d, ask }) => {
    await sleep(50); ask('q'); await sleep(200);
    const opener = tlBtns(d)[0]; opener.focus(); opener.click(); await sleep(100);
    const dg = dlg(d);
    R._tp = { label: dg.getAttribute('aria-label'), modal: dg.getAttribute('aria-modal'), focusIn: dg.contains(d.activeElement),
      first: tlReqs(w).pop(), rows: dg.querySelectorAll('tbody tr').length,
      chips: [...dg.querySelectorAll('.chip')].slice(0, 4).map((c) => c.textContent + '|' + c.className),
      xss: dg.querySelectorAll('img,script').length,
      note: dg.textContent.indexOf('Authentication events are not included in this version') >= 0,
      winOpts: [...dg.querySelectorAll('select option')].map((o) => o.value + ':' + o.textContent), winVal: dg.querySelector('select').value,
      live: dg.querySelector('[role="status"]').getAttribute('aria-live'),
      pinDisabled: byText(d, '[role="dialog"] button', 'Pin as finding').disabled };
    dg.querySelector('select').value = '7d'; dg.querySelector('select').dispatchEvent(new w.Event('change')); await sleep(80);
    R._tp.win = tlReqs(w).pop();
    const cb = dg.querySelector('input[type="checkbox"]'); cb.checked = true; cb.dispatchEvent(new w.Event('change')); await sleep(80);
    R._tp.inc = tlReqs(w).pop(); R._tp.n = tlReqs(w).length;
    dg.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    R._tp.closed = !dlg(d); R._tp.restored = d.activeElement === opener;
  }, { api: tlApi(tlRows) });
  R.t6_error = await run(() => okStream(tlFrames(['src_ip', 'n'], ['10.9.9.9', 1])), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(200);
    tlBtns(d)[0].click(); await sleep(100);
    R._te = { status: dlg(d).querySelector('[role="status"]').textContent, rows: dlg(d).querySelectorAll('tbody tr').length };
  }, { api: async (u, m, pb) => (u === '/investigate/timeline' ? { __status: 429, error: 'Too many <b>' } : {}) });
  R.t6_pin = await run(() => okStream(tlFrames(['src_ip', 'n'], ['10.9.9.9', 1], true)), async ({ w, d, ask }) => {
    await sleep(50); ask('q'); await sleep(250);
    const opener = tlBtns(d)[0]; opener.click(); await sleep(100);
    const pin = byText(d, '[role="dialog"] button', 'Pin as finding');
    R._tpin = { disabled: pin.disabled };
    pin.click();
    R._tpin.formFocus = d.activeElement.tagName;
    dlg(d).querySelector('.pin-form textarea').value = 'note x';
    byText(d, '.pin-form button', 'Save pin').click(); await sleep(120);
    R._tpin.body = w.__apiBodies.filter((x) => x.indexOf('/investigate/7/pin') === 0).pop();
    R._tpin.formGone = !dlg(d).querySelector('.pin-form'); R._tpin.active = d.activeElement.textContent;
    R._tpin.status = dlg(d).querySelector('[role="status"]').textContent;
  }, { api: tlApi(tlRows) });
  R.t6_summarise = await run((n) => okStream(n === 1 ? tlFrames(['src_ip', 'n'], ['10.9.9.9', 1], true)
    : [fr({ type: 'text', text: 'ok' }), fr({ type: 'done' })]), async ({ w, d, ask }) => {
    await sleep(50); ask('first'); await sleep(250);
    tlBtns(d)[0].click(); await sleep(100);
    byText(d, '[role="dialog"] button', 'Summarise').click(); await sleep(200);
    const c = w.__calls[1] || {};
    R._ts = { n: w.__calls.length, q: c.question, closed: !dlg(d),
      bubble: [...d.querySelectorAll('.bubble.me')].pop().textContent };
  }, { api: tlApi(tlRows) });
  const tlCols1 = ['src_ip', 'n'], tlRow1 = ['10.9.9.9', 1];
  const later = (frames, ms) => new Promise((res) => setTimeout(() => res(okStream(frames)), ms));
  R.t6_trunc = await run(() => okStream(tlFrames(tlCols1, tlRow1)), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(200);
    tlBtns(d)[0].click(); await sleep(100);
    R._tt = { banner: dlg(d).textContent.indexOf('Showing the first 500 events.') >= 0, rows: dlg(d).querySelectorAll('tbody tr').length };
  }, { api: tlApi(tlRows.slice(0, 3), true) });
  R.t6_not_trunc = await run(() => okStream(tlFrames(tlCols1, tlRow1)), async ({ d, ask }) => {
    await sleep(50); ask('q'); await sleep(200);
    tlBtns(d)[0].click(); await sleep(100);
    R._tnt = dlg(d).textContent.indexOf('Showing the first 500') >= 0;
  }, { api: tlApi(tlRows.slice(0, 3), false) });
  R.t6_busy = await run((n) => (n === 1 ? okStream(tlFrames(tlCols1, tlRow1, true))
    : later([fr({ type: 'text', text: 'ok' }), fr({ type: 'done' })], 500)), async ({ w, d, ask }) => {
    await sleep(50); ask('first'); await sleep(250);
    ask('second'); await sleep(100);
    tlBtns(d)[0].click(); await sleep(100);
    byText(d, '[role="dialog"] button', 'Summarise').click(); await sleep(50);
    R._tbusy = { open: !!dlg(d), calls: w.__calls.length,
      status: dlg(d) ? dlg(d).querySelector('[role="status"]').textContent : null };
    await sleep(600);
  }, { api: tlApi(tlRows) });
  R.t6_pin_late = await run((n) => (n === 1 ? okStream(tlFrames(tlCols1, tlRow1))
    : later(tlFrames(tlCols1, tlRow1, true), 150)), async ({ d, ask }) => {
    await sleep(50); ask('first'); await sleep(250);
    tlBtns(d)[0].click(); await sleep(100);
    const pin = () => byText(d, '[role="dialog"] button', 'Pin as finding');
    R._tpl = { before: pin().disabled };
    ask('second'); await sleep(500);
    R._tpl.after = dlg(d) ? pin().disabled : null;
  }, { api: tlApi(tlRows) });

  // ---- Final review fixes: Update snapshot, timeline preview, a11y ----
  const NEW_SNAP = '2026-11-19T08:00:00+00:00';
  const usApi = async (u, m, pb) => {
    if (u === '/investigate/7/rerun' || u === '/investigate/9/rerun') {
      return pb && pb.update_snapshot ? Object.assign({}, changed, { snapshot_updated: true, snapshot_at: NEW_SNAP }) : changed;
    }
    return roApi(u);
  };
  const toolbarState = (d) => ({
    btns: btnsOf(d, '.ev-toolbar'),
    stamp: (d.querySelector('.ev-toolbar .meta') || {}).textContent,
    badge: [...d.querySelectorAll('.ev-toolbar .diff-badge')].map((b) => b.textContent + '|' + b.className),
    focus: (d.activeElement || {}).textContent,
  });
  R.us_owner = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    byText(d, '.ev-toolbar button', 'Re-run').click(); await sleep(60);
    R._us_after_rerun = toolbarState(d);
    const upd = byText(d, '.ev-toolbar button', 'Update snapshot'); if (upd) { upd.click(); } await sleep(60);
    R._us_after_update = toolbarState(d);
    R._us_expected = new w.Date(NEW_SNAP).toLocaleString();
    byText(d, '.ev-toolbar button', 'Re-run').click(); await sleep(60);       // identical-less rerun again: still changed
    R._us_rerun_again = toolbarState(d);
  }, { api: usApi });
  R.us_same = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(60);
    byText(d, '.ev-toolbar button', 'Re-run').click(); await sleep(60);
    R._us_same = toolbarState(d);
  }, { api: rerunApi(same) });
  R.us_shared = await run(() => okStream([]), async ({ d }) => {
    await sleep(50); openBtn(d, 9)(); await sleep(60);
    byText(d, '.ev-toolbar button', 'Re-run').click(); await sleep(60);
    R._us_shared = toolbarState(d);
  }, { api: rerunApi(changed) });
  const tlFinding = (id) => ({ id, title: 'Host 10.9.9.9', note: '', evidence_kind: 'timeline',
    evidence: { subject: '10.9.9.9', window: '24h', columns: ['time', 'kind'],
      rows: Array.from({ length: 7 }, (_, i) => [i === 0 ? evilCell : '2026-11-18T10:0' + i, 'denied']),
      row_count: 7, truncated: false, generated_at: '2026-11-18T10:05:00+00:00' },
    pinned_at: '2026-11-18T10:05:00+00:00', updated_at: '2026-11-18T10:05:00+00:00', created_by: 1, report_id: null });
  R.tl_card = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50); openBtn(d, 7)(); await sleep(80);
    R._tl_card = Object.assign(tray(d), { expectedDate: new w.Date('2026-11-18T10:05:00+00:00').toLocaleString() });
  }, { api: t5api({ title: 'T', shared: true, findings: [tlFinding(21)] }) });
  R.a11y = await run(() => okStream([]), async ({ w, d }) => {
    await sleep(50);
    const rail = d.getElementById('inv-rail'), tog = d.getElementById('rail-toggle'), bd = d.getElementById('rail-backdrop');
    const list = d.getElementById('rail-list');
    const panel = list.closest('[role="tabpanel"]');
    const tabs = [...d.querySelectorAll('[data-tab]')];
    R._a11y_static = {
      liveOnList: !!list.closest('[aria-live]'), hasPanel: !!panel,
      controls: tabs.map((t) => t.getAttribute('aria-controls') === (panel || {}).id && !!(panel || {}).id),
      labelledby: panel ? panel.getAttribute('aria-labelledby') === tabs[0].id && !!tabs[0].id : false,
    };
    tabs[1].click(); await sleep(30);
    R._a11y_tabswitch = panel ? panel.getAttribute('aria-labelledby') === tabs[1].id : false;
    tabs[0].click(); await sleep(30);
    tog.click(); R._a11y_rail_open = rail.contains(d.activeElement);
    bd.click(); R._a11y_rail_bd = d.activeElement === tog;
    tog.click(); d.dispatchEvent(new w.KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    R._a11y_rail_esc = d.activeElement === tog;
    const tt = d.getElementById('tray-toggle'), tr = d.getElementById('inv-tray');
    tt.click(); R._a11y_tray_open = tr.contains(d.activeElement);
    d.getElementById('tray-close').click(); R._a11y_tray_close = d.activeElement === tt;
  }, { api });
  console.log(JSON.stringify(R));
})().catch((e) => { console.error('HARNESS FAIL', e); process.exit(1); });
