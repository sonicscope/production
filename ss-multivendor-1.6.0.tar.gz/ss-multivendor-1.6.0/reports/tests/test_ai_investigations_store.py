import psycopg2
import pytest

from reports.ai import investigations as inv
from reports.ai.investigations import Viewer


@pytest.fixture
def cur(app_module):
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    yield conn.cursor()
    conn.rollback()
    conn.close()


@pytest.fixture
def users(cur):
    ids = []
    for n in ('owner', 'peer', 'admin2'):
        cur.execute("INSERT INTO ui_users (email, full_name, role, is_active) "
                    "VALUES (%s, %s, 'user', true) RETURNING id", (f'{n}@t.test', n))
        ids.append(cur.fetchone()[0])
    return ids


RES = {'sql': 'SELECT 1 AS n', 'columns': ['n'], 'rows': [[1]], 'row_count': 1,
       'truncated': False, 'duration_ms': 3}


def mk(cur, tenant, owner, title='t'):
    return inv.create(cur, tenant_id=tenant, owner_user_id=owner, title=title)


def test_title_from_question():
    assert inv.title_from('  Top   talkers\nlast week?  ') == 'Top talkers last week?'
    assert len(inv.title_from('x' * 500)) == 200
    assert inv.title_from('   ') == 'Untitled investigation'


def test_visibility_matrix(cur, seed_tenants, users):
    t1, t2 = seed_tenants('A', 'B')
    owner, peer, _ = users
    i = inv.get(cur, mk(cur, t1, owner))
    ov = Viewer(owner, False, frozenset({t1}))
    pv = Viewer(peer, False, frozenset({t1}))
    other_tenant = Viewer(peer, False, frozenset({t2}))
    adm = Viewer(99, True, frozenset({t1, t2}))
    assert inv.can_view(ov, i) and inv.can_edit(ov, i)
    assert not inv.can_view(pv, i) and not inv.can_edit(pv, i)       # private
    assert inv.can_view(adm, i) and inv.can_edit(adm, i)
    inv.set_shared(cur, i['id'], True)
    i = inv.get(cur, i['id'])
    assert inv.can_view(pv, i) and not inv.can_edit(pv, i)           # shared = read only
    assert not inv.can_view(other_tenant, i)                         # no tenant access


def test_orphan_hand_over_to_admins(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    owner, peer, _ = users
    i_id = mk(cur, t1, owner)
    cur.execute('DELETE FROM ui_users WHERE id = %s', (owner,))      # FK ON DELETE SET NULL
    i = inv.get(cur, i_id)
    assert i['owner_user_id'] is None
    adm = Viewer(99, True, frozenset({t1}))
    pv = Viewer(peer, False, frozenset({t1}))
    assert inv.can_view(adm, i) and inv.can_edit(adm, i)
    assert not inv.can_view(pv, i) and not inv.can_edit(pv, i)       # private orphan hidden
    inv.set_shared(cur, i_id, True)
    assert inv.can_view(pv, inv.get(cur, i_id)) and not inv.can_edit(pv, inv.get(cur, i_id))
    assert [r['id'] for r in inv.list_for(cur, adm, 'all')] == [i_id]
    assert inv.list_for(cur, adm, 'mine') == []


def test_list_tabs(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    owner, peer, _ = users
    a = mk(cur, t1, owner, 'mine-private')
    b = mk(cur, t1, peer, 'peer-shared'); inv.set_shared(cur, b, True)
    c = mk(cur, t1, peer, 'peer-private')
    ov = Viewer(owner, False, frozenset({t1}))
    assert [r['id'] for r in inv.list_for(cur, ov, 'mine')] == [a]
    assert [r['id'] for r in inv.list_for(cur, ov, 'shared')] == [b]
    assert inv.list_for(cur, ov, 'all') == []                        # 'all' is admin-only
    adm = Viewer(99, True, frozenset({t1}))
    assert {r['id'] for r in inv.list_for(cur, adm, 'all')} == {a, b, c}


def test_append_turn_and_detail(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    inv.append_turn(cur, i, question='q1', answer='a1', results=[RES])
    inv.append_turn(cur, i, question='q2', answer='a2', results=[])
    d = inv.detail(cur, i)
    assert [(m['seq'], m['role']) for m in d['messages']] == [(1, 'user'), (2, 'assistant'),
                                                              (3, 'user'), (4, 'assistant')]
    assert len(d['results']) == 1 and d['results'][0]['message_seq'] == 2
    assert d['results'][0]['rows'] == [[1]] and d['results'][0]['sql'] == 'SELECT 1 AS n'
    assert inv.get_result(cur, i, d['results'][0]['id'])['sql'] == 'SELECT 1 AS n'
    assert inv.get_result(cur, i + 999, d['results'][0]['id']) is None


def test_snapshot_rows_capped_at_500(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    big = dict(RES, rows=[[n] for n in range(900)], row_count=900, truncated=True)
    inv.append_turn(cur, i, question='q', answer='a', results=[big])
    r = inv.detail(cur, i)['results'][0]
    assert len(r['rows']) == 500 and r['row_count'] == 900 and r['truncated'] is True


def test_tenant_delete_cascades(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    inv.append_turn(cur, i, question='q', answer='a', results=[RES])
    cur.execute('DELETE FROM tenants WHERE id = %s', (t1,))
    cur.execute('SELECT count(*) FROM ai_messages WHERE investigation_id = %s', (i,))
    assert cur.fetchone()[0] == 0


def test_purge_expired_spares_report_linked(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    old, linked, fresh = (mk(cur, t1, users[0], n) for n in ('old', 'linked', 'fresh'))
    cur.execute("UPDATE ai_investigations SET updated_at = now() - interval '100 days' "
                "WHERE id IN (%s, %s)", (old, linked))
    cur.execute("INSERT INTO ai_findings (investigation_id, tenant_id, title, evidence_kind, "
                "evidence, report_id) VALUES (%s, %s, 'f', 'query', '{}', 7)", (linked, t1))
    assert inv.purge_expired(cur, 90) == 1
    assert inv.get(cur, old) is None
    assert inv.get(cur, linked) is not None and inv.get(cur, fresh) is not None


def test_role_ss_ai_ro_has_no_access(cur):
    cur.execute("SELECT rolname FROM pg_roles WHERE rolname = 'ss_ai_ro'")
    if cur.fetchone() is None:
        pytest.skip('ss_ai_ro not present in this test database')
    for table in ('ai_investigations', 'ai_messages', 'ai_query_results', 'ai_findings'):
        cur.execute("SELECT has_table_privilege('ss_ai_ro', %s, 'SELECT')", (table,))
        assert cur.fetchone()[0] is False, table


def test_purge_job_uses_retention_setting(app_module, seed_tenants):
    from reports import scheduler_service as ss
    t1, = seed_tenants('A')
    connect = lambda: psycopg2.connect(**app_module.DB_CONFIG)  # noqa: E731
    with connect() as conn:
        c = conn.cursor()
        c.execute("INSERT INTO ui_users (email, full_name, role, is_active) "
                  "VALUES ('job@t.test', 'job', 'user', true) RETURNING id")
        uid = c.fetchone()[0]
        mid = inv.create(c, tenant_id=t1, owner_user_id=uid, title='40 days old')
        old = inv.create(c, tenant_id=t1, owner_user_id=uid, title='100 days old')
        c.execute("UPDATE ai_investigations SET updated_at = now() - interval '40 days' "
                  "WHERE id = %s", (mid,))
        c.execute("UPDATE ai_investigations SET updated_at = now() - interval '100 days' "
                  "WHERE id = %s", (old,))
    conn.close()
    ss._ai_purge_job(connect)                       # no ai_settings row => 90 days
    with connect() as conn:
        c = conn.cursor()
        assert inv.get(c, mid) is not None          # 40d < 90d: kept
        assert inv.get(c, old) is None              # 100d > 90d: purged
        c.execute("SELECT count(*) FROM ai_audit WHERE kind = 'purge' AND row_count = 1")
        assert c.fetchone()[0] == 1
    conn.close()


# ── findings (Task 5) ───────────────────────────────────────────────────────
EVID = {'sql': 'SELECT 1', 'columns': ['n'], 'rows': [[1]], 'row_count': 1, 'truncated': False,
        'snapshot_at': '2026-11-18T10:00:00+00:00', 'duration_ms': 3}


def pin(cur, i, uid, **kw):
    args = dict(tenant_id=kw.pop('tenant_id'), created_by=uid, title='Finding', note='',
                evidence_kind='query', evidence=EVID)
    args.update(kw)
    return inv.add_finding(cur, i, **args)


def test_add_finding_freezes_evidence_and_lists_in_order(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    f1 = pin(cur, i, users[0], tenant_id=t1, title='  First \n one ', note=' n ')
    f2 = pin(cur, i, users[0], tenant_id=t1, title='Second')
    got = inv.get_finding(cur, i, f1)
    assert got['title'] == 'First one' and got['note'] == 'n'
    assert got['evidence'] == EVID and got['evidence_kind'] == 'query'
    assert [f['id'] for f in inv.list_findings(cur, i)] == [f1, f2]


def test_finding_limits_enforced_in_python(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    for bad in ('', '   ', 'x' * 201):
        with pytest.raises(ValueError):
            pin(cur, i, users[0], tenant_id=t1, title=bad)
    with pytest.raises(ValueError):
        pin(cur, i, users[0], tenant_id=t1, note='n' * 4001)
    with pytest.raises(ValueError):
        pin(cur, i, users[0], tenant_id=t1, evidence_kind='other')
    pin(cur, i, users[0], tenant_id=t1, title='x' * 200, note='n' * 4000)
    assert len(inv.list_findings(cur, i)) == 1


def test_update_finding_edits_and_bumps_updated_at(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    f = pin(cur, i, users[0], tenant_id=t1, title='Old', note='keep')
    cur.execute("UPDATE ai_findings SET updated_at = now() - interval '1 hour' WHERE id = %s", (f,))
    before = inv.get_finding(cur, i, f)['updated_at']
    inv.update_finding(cur, i, f, title='New')
    got = inv.get_finding(cur, i, f)
    assert got['title'] == 'New' and got['note'] == 'keep' and got['updated_at'] > before
    inv.update_finding(cur, i, f, note='changed')
    assert inv.get_finding(cur, i, f)['title'] == 'New'
    with pytest.raises(ValueError):
        inv.update_finding(cur, i, f, title='')
    with pytest.raises(ValueError):
        inv.update_finding(cur, i, f, note='n' * 4001)
    with pytest.raises(LookupError):
        inv.update_finding(cur, i, 99999999, title='x')


def test_finding_ops_are_scoped_to_the_investigation(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    a, b = mk(cur, t1, users[0]), mk(cur, t1, users[0])
    f = pin(cur, a, users[0], tenant_id=t1)
    assert inv.get_finding(cur, b, f) is None
    assert inv.delete_finding(cur, b, f) is False
    with pytest.raises(LookupError):
        inv.update_finding(cur, b, f, title='hijack')
    assert inv.get_finding(cur, a, f)['title'] == 'Finding'
    assert inv.delete_finding(cur, a, f) is True
    assert inv.get_finding(cur, a, f) is None


def test_findings_cascade_on_investigation_delete(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    f = pin(cur, i, users[0], tenant_id=t1)
    inv.delete(cur, i)
    cur.execute('SELECT count(*) FROM ai_findings WHERE id = %s', (f,))
    assert cur.fetchone()[0] == 0


def test_append_turn_returns_result_ids_in_order(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    second = dict(RES, sql='SELECT 2 AS n', rows=[[2]])
    ids = inv.append_turn(cur, i, question='q', answer='a', results=[RES, second])
    assert len(ids) == 2 and ids[0] != ids[1]
    assert [inv.get_result(cur, i, x)['sql'] for x in ids] == ['SELECT 1 AS n', 'SELECT 2 AS n']
    assert inv.append_turn(cur, i, question='q', answer='a', results=[]) == []


def test_add_finding_caps_at_max_findings(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    i = mk(cur, t1, users[0])
    kw = dict(tenant_id=t1, created_by=users[0], note='', evidence_kind='query', evidence={})
    for n in range(inv.MAX_FINDINGS):
        inv.add_finding(cur, i, title=f'f{n}', **kw)
    with pytest.raises(ValueError, match='already has 100 pinned findings'):
        inv.add_finding(cur, i, title='one too many', **kw)
    assert len(inv.list_findings(cur, i)) == 100
    # other investigations are unaffected
    j = mk(cur, t1, users[0])
    inv.add_finding(cur, j, title='ok', **kw)


def test_purge_uses_latest_of_updated_and_last_rerun(cur, seed_tenants, users):
    t1, = seed_tenants('A')
    both_old, rerun_recent, linked = (mk(cur, t1, users[0], n) for n in ('o', 'r', 'l'))
    cur.execute("UPDATE ai_investigations SET updated_at = now() - interval '100 days', "
                "last_rerun_at = now() - interval '95 days' WHERE id = %s", (both_old,))
    cur.execute("UPDATE ai_investigations SET updated_at = now() - interval '100 days', "
                "last_rerun_at = now() - interval '1 day' WHERE id = %s", (rerun_recent,))
    cur.execute("UPDATE ai_investigations SET updated_at = now() - interval '100 days', "
                "last_rerun_at = now() - interval '99 days' WHERE id = %s", (linked,))
    cur.execute("INSERT INTO ai_findings (investigation_id, tenant_id, title, evidence_kind, "
                "evidence, report_id) VALUES (%s, %s, 'f', 'query', '{}', 7)", (linked, t1))
    assert inv.purge_expired(cur, 90) == 1
    assert inv.get(cur, both_old) is None
    assert inv.get(cur, rerun_recent) is not None and inv.get(cur, linked) is not None


def test_query_results_message_index_exists(cur):
    cur.execute("SELECT 1 FROM pg_indexes WHERE indexname = 'ai_qr_msg_idx' "
                "AND tablename = 'ai_query_results'")
    assert cur.fetchone() is not None
