"""Install-wide AI settings (single row) and per-tenant enablement."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime

import psycopg2

from reports.ai import credentials
from reports.ai.providers import PROVIDER_NAMES
from reports.ai.providers.base import validate_model


@dataclass(frozen=True)
class AISettings:
    provider: str
    model: str
    api_key_last4: str
    key_version: int
    consent_at: datetime | None
    consent_provider: str | None
    export_max_rows: int = 5000
    retention_days: int = 90


CURRENT_KEY_VERSION = 1
EXPORT_ROWS_RANGE = (100, 50_000)
RETENTION_DAYS_RANGE = (7, 365)
_KEY_RE = re.compile(r'[\x21-\x7e]{8,512}')


def _clean_key(api_key: str) -> str:
    """Strip whitespace and check the key shape; the message never contains the key."""
    key = api_key.strip() if isinstance(api_key, str) else ''
    if not _KEY_RE.fullmatch(key):
        raise ValueError('the API key does not look valid')
    return key


def _check_range(name: str, value: int | None, bounds: tuple[int, int]) -> None:
    if value is None:
        return
    if type(value) is not int or not bounds[0] <= value <= bounds[1]:
        raise ValueError(f'{name} must be a whole number from {bounds[0]:,} to {bounds[1]:,}')


def _aad(version: int) -> bytes:
    return f'ai_settings:1:v{version}'.encode()


def load_settings(cur) -> AISettings | None:
    cur.execute('SELECT provider, model, api_key_last4, key_version, consent_at, '
                'consent_provider, export_max_rows, retention_days FROM ai_settings WHERE id = 1')
    row = cur.fetchone()
    return AISettings(*row) if row else None


def save_settings(cur, *, provider: str, model: str, api_key: str | None,
                  consent_user_id: int | None, key_path: str,
                  export_max_rows: int | None = None, retention_days: int | None = None) -> None:
    """Save settings; ``None`` for the two numeric fields keeps the current value."""
    if provider not in PROVIDER_NAMES:
        raise ValueError('choose a supported provider')
    _check_range('Max CSV export rows', export_max_rows, EXPORT_ROWS_RANGE)
    _check_range('Retention days', retention_days, RETENTION_DAYS_RANGE)
    validate_model(model)
    existing = load_settings(cur)
    if api_key:
        if consent_user_id is None:
            raise ValueError('consent to sending data to the provider is required')
        api_key = _clean_key(api_key)
        key = credentials.load_key(key_path, CURRENT_KEY_VERSION)
        blob = credentials.encrypt_secret(api_key, key, _aad(CURRENT_KEY_VERSION))
        cur.execute(
            """INSERT INTO ai_settings (id, provider, model, api_key_enc, api_key_last4,
                   key_version, consent_user_id, consent_at, consent_provider, updated_at,
                   export_max_rows, retention_days)
               VALUES (1, %s, %s, %s, %s, %s, %s, now(), %s, now(),
                   COALESCE(%s, 5000), COALESCE(%s, 90))
               ON CONFLICT (id) DO UPDATE SET provider = EXCLUDED.provider,
                   model = EXCLUDED.model, api_key_enc = EXCLUDED.api_key_enc,
                   api_key_last4 = EXCLUDED.api_key_last4, key_version = EXCLUDED.key_version,
                   consent_user_id = EXCLUDED.consent_user_id, consent_at = now(),
                   consent_provider = EXCLUDED.consent_provider, updated_at = now(),
                   export_max_rows = COALESCE(%s, ai_settings.export_max_rows),
                   retention_days = COALESCE(%s, ai_settings.retention_days)""",
            (provider, model, psycopg2.Binary(blob), api_key[-4:],
             CURRENT_KEY_VERSION, consent_user_id, provider,
             export_max_rows, retention_days, export_max_rows, retention_days))
        return
    if existing is None:
        raise ValueError('an API key is required')
    if provider != existing.provider:
        raise ValueError('enter an API key when changing provider')
    cur.execute('UPDATE ai_settings SET model = %s, updated_at = now(), '
                'export_max_rows = COALESCE(%s, export_max_rows), '
                'retention_days = COALESCE(%s, retention_days) '
                'WHERE id = 1 AND provider = %s',
                (model, export_max_rows, retention_days, provider))
    if cur.rowcount != 1:
        raise ValueError('settings changed — reload and try again')


def load_api_key(cur, key_path: str) -> str:
    cur.execute('SELECT api_key_enc, key_version FROM ai_settings WHERE id = 1')
    row = cur.fetchone()
    if row is None:
        raise credentials.CredentialError('AI assistant is not configured')
    version = int(row[1])
    return credentials.decrypt_secret(bytes(row[0]), credentials.load_key(key_path, version),
                                      _aad(version))


def tenant_ai_flags(cur) -> list[tuple[int, str, bool]]:
    cur.execute('SELECT id, name, ai_enabled FROM tenants ORDER BY name')
    return [(r[0], r[1], r[2]) for r in cur.fetchall()]


def set_enabled_tenants(cur, enabled_ids: set[int]) -> None:
    if any(type(i) is not int for i in enabled_ids):
        raise ValueError('tenant ids must be integers')
    ids = sorted(enabled_ids)
    cur.execute('UPDATE tenants SET ai_enabled = (id = ANY(%s)) '
                'WHERE ai_enabled IS DISTINCT FROM (id = ANY(%s))', (ids, ids))
