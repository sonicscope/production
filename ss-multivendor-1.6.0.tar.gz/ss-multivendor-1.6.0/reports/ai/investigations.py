"""Saved investigations: persistence and visibility rules (Stage 2 spec §2-§3).

Pure DB layer over a psycopg2 cursor; no Flask. Every function takes the cursor and
never commits (callers own the transaction).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

TITLE_MAX = 200
NOTE_MAX = 4000
MAX_FINDINGS = 100
SNAPSHOT_ROWS = 500
_WS = re.compile(r'\s+')
_INV_COLS = ('id', 'tenant_id', 'owner_user_id', 'title', 'shared', 'created_at', 'updated_at',
             'last_rerun_at')


@dataclass(frozen=True)
class Viewer:
    user_id: int
    is_admin: bool
    tenant_ids: frozenset


def _dicts(cur) -> list[dict]:
    names = [d[0] for d in cur.description]
    return [dict(zip(names, row)) for row in cur.fetchall()]


def title_from(question: str) -> str:
    t = _WS.sub(' ', question or '').strip()[:TITLE_MAX].strip()
    return t or 'Untitled investigation'


def can_view(v: Viewer, inv: dict) -> bool:
    """Tenant access must ALSO be enforced by the caller (require_tenant_access)."""
    if v.is_admin:
        return True
    if inv['tenant_id'] not in v.tenant_ids:
        return False
    return inv['owner_user_id'] == v.user_id or bool(inv['shared'])


def can_edit(v: Viewer, inv: dict) -> bool:
    if v.is_admin:
        return True
    return inv['owner_user_id'] is not None and inv['owner_user_id'] == v.user_id


def create(cur, *, tenant_id: int, owner_user_id: int, title: str) -> int:
    cur.execute('INSERT INTO ai_investigations (tenant_id, owner_user_id, title) '
                'VALUES (%s, %s, %s) RETURNING id',
                (tenant_id, owner_user_id, title_from(title)))
    return cur.fetchone()[0]


def get(cur, inv_id: int) -> dict | None:
    cur.execute(f"SELECT {', '.join(_INV_COLS)} FROM ai_investigations WHERE id = %s", (inv_id,))
    rows = _dicts(cur)
    return rows[0] if rows else None


def list_for(cur, v: Viewer, tab: str) -> list[dict]:
    base = ("SELECT i.id, i.tenant_id, t.name AS tenant_name, i.owner_user_id, i.title, "
            "i.shared, i.created_at, i.updated_at, "
            "(SELECT count(*) FROM ai_findings f WHERE f.investigation_id = i.id) AS finding_count "
            "FROM ai_investigations i JOIN tenants t ON t.id = i.tenant_id WHERE ")
    tenants = sorted(v.tenant_ids)
    if tab == 'mine':
        cur.execute(base + 'i.owner_user_id = %s AND i.tenant_id = ANY(%s) '
                    'ORDER BY i.updated_at DESC LIMIT 200', (v.user_id, tenants))
    elif tab == 'shared':
        cur.execute(base + 'i.shared AND i.tenant_id = ANY(%s) AND '
                    '(i.owner_user_id IS DISTINCT FROM %s) ORDER BY i.updated_at DESC LIMIT 200',
                    (tenants, v.user_id))
    elif tab == 'all' and v.is_admin:
        cur.execute(base + 'i.tenant_id = ANY(%s) ORDER BY i.updated_at DESC LIMIT 500',
                    (tenants,))
    else:
        return []
    return _dicts(cur)


def rename(cur, inv_id: int, title: str) -> None:
    cur.execute('UPDATE ai_investigations SET title = %s, updated_at = now() WHERE id = %s',
                (title_from(title), inv_id))


def set_shared(cur, inv_id: int, shared: bool) -> None:
    cur.execute('UPDATE ai_investigations SET shared = %s, updated_at = now() WHERE id = %s',
                (bool(shared), inv_id))


def delete(cur, inv_id: int) -> None:
    cur.execute('DELETE FROM ai_investigations WHERE id = %s', (inv_id,))


def append_turn(cur, inv_id: int, *, question: str, answer: str, results: list[dict]) -> list[int]:
    """Store one turn; returns the inserted result ids in result order."""
    cur.execute('SELECT COALESCE(max(seq), 0) FROM ai_messages WHERE investigation_id = %s',
                (inv_id,))
    seq = cur.fetchone()[0]
    cur.execute("INSERT INTO ai_messages (investigation_id, seq, role, content) "
                "VALUES (%s, %s, 'user', %s)", (inv_id, seq + 1, question))
    cur.execute("INSERT INTO ai_messages (investigation_id, seq, role, content) "
                "VALUES (%s, %s, 'assistant', %s) RETURNING id", (inv_id, seq + 2, answer))
    assistant_id = cur.fetchone()[0]
    result_ids: list[int] = []
    for n, r in enumerate(results):
        rows = r['rows'][:SNAPSHOT_ROWS]
        cur.execute(
            'INSERT INTO ai_query_results (investigation_id, message_id, ordinal, sql_text, '
            'columns, rows_snapshot, row_count, truncated, duration_ms) '
            'VALUES (%s, %s, %s, %s, %s::jsonb, %s::jsonb, %s, %s, %s) RETURNING id',
            (inv_id, assistant_id, n, r['sql'], json.dumps(list(r['columns'])),
             json.dumps(rows), int(r['row_count']),
             bool(r.get('truncated')) or len(r['rows']) > SNAPSHOT_ROWS, r.get('duration_ms')))
        result_ids.append(cur.fetchone()[0])
    cur.execute('UPDATE ai_investigations SET updated_at = now() WHERE id = %s', (inv_id,))
    return result_ids


def get_result(cur, inv_id: int, result_id: int) -> dict | None:
    cur.execute('SELECT id, ordinal, sql_text AS sql, columns, rows_snapshot AS rows, row_count, '
                'truncated, snapshot_at, duration_ms FROM ai_query_results '
                'WHERE id = %s AND investigation_id = %s', (result_id, inv_id))
    rows = _dicts(cur)
    return rows[0] if rows else None


def detail(cur, inv_id: int) -> dict:
    inv = get(cur, inv_id)
    cur.execute('SELECT seq, role, content FROM ai_messages WHERE investigation_id = %s '
                'ORDER BY seq', (inv_id,))
    messages = _dicts(cur)
    cur.execute('SELECT r.id, m.seq AS message_seq, r.ordinal, r.sql_text AS sql, r.columns, '
                'r.rows_snapshot AS rows, r.row_count, r.truncated, r.snapshot_at, r.duration_ms '
                'FROM ai_query_results r JOIN ai_messages m ON m.id = r.message_id '
                'WHERE r.investigation_id = %s ORDER BY m.seq, r.ordinal', (inv_id,))
    results = _dicts(cur)
    return {'investigation': inv, 'messages': messages, 'results': results,
            'findings': list_findings(cur, inv_id)}


def list_findings(cur, inv_id: int) -> list[dict]:
    """Pinned findings of an investigation, oldest first."""
    cur.execute('SELECT id, title, note, evidence_kind, evidence, pinned_at, updated_at, '
                'created_by, report_id FROM ai_findings WHERE investigation_id = %s '
                'ORDER BY pinned_at', (inv_id,))
    return _dicts(cur)


def validate_finding_text(title, note) -> tuple[str, str]:
    """Normalise and validate a finding title/note; ValueError carries the user message."""
    return _clip(title, note)


def _clip(title: str, note: str) -> tuple[str, str]:
    title = _WS.sub(' ', title or '').strip()
    if not 1 <= len(title) <= TITLE_MAX:
        raise ValueError('Enter a title (up to 200 characters).')
    note = (note or '').strip()
    if len(note) > NOTE_MAX:
        raise ValueError('The note is too long (up to 4000 characters).')
    return title, note


def add_finding(cur, inv_id, *, tenant_id, created_by, title, note, evidence_kind, evidence) -> int:
    """Pin evidence (frozen JSON, built server-side by the caller). Returns the finding id."""
    if evidence_kind not in ('query', 'timeline'):
        raise ValueError('bad evidence kind')
    title, note = validate_finding_text(title, note)
    # Lock the parent row so concurrent pins cannot both slip under the cap.
    cur.execute('SELECT id FROM ai_investigations WHERE id = %s FOR UPDATE', (inv_id,))
    if cur.fetchone() is None:
        raise LookupError('investigation')
    cur.execute('SELECT count(*) FROM ai_findings WHERE investigation_id = %s', (inv_id,))
    if cur.fetchone()[0] >= MAX_FINDINGS:
        raise ValueError(f'This investigation already has {MAX_FINDINGS} pinned findings.')
    cur.execute('INSERT INTO ai_findings (investigation_id, tenant_id, created_by, title, note, '
                'evidence_kind, evidence) VALUES (%s,%s,%s,%s,%s,%s,%s::jsonb) RETURNING id',
                (inv_id, tenant_id, created_by, title, note, evidence_kind,
                 json.dumps(evidence, default=str)))
    fid = cur.fetchone()[0]
    cur.execute('UPDATE ai_investigations SET updated_at = now() WHERE id = %s', (inv_id,))
    return fid


def get_finding(cur, inv_id, fid):
    cur.execute('SELECT id, title, note, evidence_kind, evidence, pinned_at, updated_at, '
                'created_by, report_id FROM ai_findings WHERE id=%s AND investigation_id=%s',
                (fid, inv_id))
    rows = _dicts(cur)
    return rows[0] if rows else None


def update_finding(cur, inv_id, fid, *, title=None, note=None) -> None:
    found = get_finding(cur, inv_id, fid)
    if found is None:
        raise LookupError('finding')
    t, n = _clip(found['title'] if title is None else title,
                 found['note'] if note is None else note)
    cur.execute('UPDATE ai_findings SET title=%s, note=%s, updated_at=now() '
                'WHERE id=%s AND investigation_id=%s', (t, n, fid, inv_id))


def delete_finding(cur, inv_id, fid) -> bool:
    cur.execute('DELETE FROM ai_findings WHERE id=%s AND investigation_id=%s', (fid, inv_id))
    return cur.rowcount == 1


def purge_expired(cur, retention_days: int) -> int:
    cur.execute(
        'DELETE FROM ai_investigations i WHERE '
        'GREATEST(i.updated_at, COALESCE(i.last_rerun_at, i.updated_at)) '
        '< now() - make_interval(days => %s) '
        'AND NOT EXISTS (SELECT 1 FROM ai_findings f WHERE f.investigation_id = i.id '
        'AND f.report_id IS NOT NULL)', (int(retention_days),))
    return cur.rowcount
