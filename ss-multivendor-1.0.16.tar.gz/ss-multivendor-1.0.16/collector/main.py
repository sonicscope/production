#!/usr/bin/env python3
"""
SonicScope Multi-Vendor Collector — Main Entry Point
Wires together IPFIX input, syslog input, the SonicWall parser,
enrichment modules, and the TimescaleDB writer.

Environment configuration: /etc/ss-multivendor/collector.env
"""

import os
import sys
import logging
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path

__version__ = '1.0.16'

# ── Logging ───────────────────────────────────────────────────────────────────
LOG_DIR = os.environ.get('LOG_DIR', '/var/log/ss-multivendor')
Path(LOG_DIR).mkdir(parents=True, exist_ok=True)

_handlers = [logging.StreamHandler(sys.stdout)]
try:
    _handlers.append(logging.FileHandler(
        f"{LOG_DIR}/collector-{datetime.now().strftime('%Y%m%d')}.log"
    ))
except PermissionError:
    pass

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=_handlers,
)
logger = logging.getLogger('ss.main')


# ── .env loader ───────────────────────────────────────────────────────────────

def _load_env(path: str):
    """Load key=value pairs from a .env file into os.environ."""
    try:
        for line in Path(path).read_text().splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, _, v = line.partition('=')
            v = v.strip().strip('"').strip("'")
            os.environ.setdefault(k.strip(), v)
    except FileNotFoundError:
        pass


def _e(key: str, default: str = '') -> str:
    return os.environ.get(key, default).strip()


def _ei(key: str, default: int) -> int:
    try:
        return int(_e(key, str(default)))
    except ValueError:
        return default


def _eb(key: str, default: bool = True) -> bool:
    return _e(key, 'true' if default else 'false').lower() in ('1', 'true', 'yes')


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    # Load config from .env
    env_path = os.environ.get('SS_ENV', '/etc/ss-multivendor/collector.env')
    _load_env(env_path)
    # Also try local .env for development
    if not Path(env_path).exists():
        _load_env(os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env'))

    logger.info(f"SonicScope Multi-Vendor Collector v{__version__} starting")

    # ── Licence validation ────────────────────────────────────────────────
    licence_invalid_event = None
    licence_result = None
    try:
        from license_validator import check_licence_or_exit, create_periodic_checker
        result = check_licence_or_exit(env_path=env_path)
        licence_result = result
        logger.info(f"Licence valid [{result.product}] "
                    f"customer={result.customer_id} expires={result.expiry_date} "
                    f"({result.days_remaining}d remaining)")
        checker_thread, licence_invalid_event, _ = create_periodic_checker(
            env_path=env_path, interval_hours=6
        )
        checker_thread.start()

        # Sensor count enforcement for V2 licences
        if result.max_sensors > 0 and result.max_sensors != 999:
            logger.info(f"Licence allows {result.max_sensors} sensor(s)")
            # Actual sensor count check happens after DB connects (see below)
    except ImportError:
        logger.warning("License validator not found — running without licence check "
                       "(development only)")
        result = None

    # ── Tenant / sensor config ────────────────────────────────────────────
    tenant_id = _ei('SS_TENANT_ID', 1)
    sensor_id = _ei('SS_SENSOR_ID', 1)

    # ── Database writer ───────────────────────────────────────────────────
    dsn = (
        f"host={_e('DB_HOST','127.0.0.1')} "
        f"port={_e('DB_PORT','5432')} "
        f"dbname={_e('DB_NAME','sonicscope')} "
        f"user={_e('DB_USER','sonicscope')} "
        f"password={_e('DB_PASSWORD','')} "
        f"connect_timeout=10"
    )
    from db_writer import DBWriter
    writer = DBWriter(
        dsn          = dsn,
        batch_size   = _ei('DB_BATCH_SIZE', 500),
        batch_timeout= float(_e('DB_BATCH_TIMEOUT', '2.0')),
    )
    writer.licence_invalid_event = licence_invalid_event
    writer.start()

    # ── Sensor count enforcement ──────────────────────────────────────────────
    if licence_result and licence_result.max_sensors > 0 and licence_result.max_sensors != 999:
        try:
            conn = writer.get_pool().getconn()
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM sensors WHERE tenant_id = %s", (tenant_id,))
                sensor_count = cur.fetchone()[0]
            writer.get_pool().putconn(conn)
            if sensor_count > licence_result.max_sensors:
                logger.error(
                    f"LICENCE VIOLATION: {sensor_count} sensors configured but "
                    f"licence allows {licence_result.max_sensors}. "
                    f"Contact sales@sonicscope.co.za to upgrade."
                )
                sys.exit(78)
            logger.info(f"Sensor check: {sensor_count}/{licence_result.max_sensors} sensors in use")
        except Exception as e:
            logger.warning(f"Could not verify sensor count: {e}")

    # ── Tenant / sensor resolver ──────────────────────────────────────────
    # Priority: registered firewall source IP → subnet match → config default
    from enrichment.tenant_resolver import TenantResolver
    tenant_resolver = TenantResolver(
        pool=writer.get_pool(),
        default_tenant_id=tenant_id,
        default_sensor_id=sensor_id,
    )

    # ── Identity enricher ─────────────────────────────────────────────────
    from identity import IdentityEnricher
    identity = IdentityEnricher(writer.get_pool())

    # ── Optional enrichment modules ───────────────────────────────────────
    geoip = None
    if _eb('ENABLE_GEOIP'):
        try:
            from enrichment.geoip import GeoIPEnricher
            geoip = GeoIPEnricher(db_dir=_e('GEOIP_DB_DIR',
                                            '/opt/ss-multivendor/geoip'))
            if not geoip.enabled:
                geoip = None
                logger.info("GeoIP databases not found — enrichment disabled")
            else:
                logger.info("GeoIP enrichment enabled")
        except Exception as e:
            logger.warning(f"GeoIP init failed: {e}")

    dns = None
    if _eb('ENABLE_DNS'):
        try:
            from enrichment.dns_resolver import DNSResolver
            dns = DNSResolver(timeout=float(_e('DNS_TIMEOUT', '1.0')))
            logger.info("DNS resolver enabled")
        except Exception as e:
            logger.warning(f"DNS resolver init failed: {e}")

    app_classifier = None
    if _eb('ENABLE_APP_CLASSIFIER'):
        try:
            from enrichment.app_classifier import AppClassifier
            app_classifier = AppClassifier()
            logger.info("Application classifier enabled")
        except Exception as e:
            logger.warning(f"App classifier init failed: {e}")

    threat_intel = None
    if _eb('ENABLE_THREAT_INTEL'):
        try:
            from enrichment.threat_intel import ThreatIntelligence
            threat_intel = ThreatIntelligence(
                blocklist_path=_e('THREAT_INTEL_BLOCKLIST') or None
            )
            logger.info(f"Threat intelligence enabled")
        except Exception as e:
            logger.warning(f"Threat intel init failed: {e}")

    # ── Enrichment pipeline ───────────────────────────────────────────────

    def enrich_and_write(event, source_ip: str = None):
        """Run all enrichment modules then send to DB writer."""
        identity.enrich(event)
        if geoip:
            geoip.enrich(event)
        if dns:
            dns.enrich(event)
        if app_classifier:
            app_classifier.enrich(event)
        if threat_intel:
            threat_intel.enrich(event)
        # Route to tenant+sensor: registered firewall IP takes priority,
        # then internal subnet match, then SS_TENANT_ID/SS_SENSOR_ID defaults.
        event.tenant_id, event.sensor_id = tenant_resolver.resolve(
            ip_str=str(event.src_ip) if event.src_ip else None,
            source_ip=source_ip,
        )
        writer.enqueue(event)

    # ── IPFIX callback ────────────────────────────────────────────────────
    from parsers.sonicwall_parser import normalize_ipfix
    from flow_tracker import FlowDeltaTracker

    _flow_tracker = FlowDeltaTracker()

    # Some firewalls (e.g. SonicWall with local-time clock) send IPFIX timestamps
    # in local time rather than UTC. IPFIX_TIMESTAMP_OFFSET_HOURS corrects this.
    # Example: Africa/Johannesburg (SAST = UTC+2) → set to -2.
    _ts_offset = timedelta(hours=_ei('IPFIX_TIMESTAMP_OFFSET_HOURS', 0))
    if _ts_offset:
        logger.info(f"IPFIX timestamp offset: {int(_ts_offset.total_seconds() // 3600):+d}h")

    def on_ipfix_flow(flow: dict, export_time, source_ip: str):
        event = normalize_ipfix(flow, export_time, tenant_id, sensor_id)
        if event:
            if _ts_offset:
                event.time = event.time + _ts_offset
            # Convert cumulative SonicWall IPFIX byte counters to per-export deltas.
            # Active flows export every ~60 s with running totals; without this
            # correction a single long-lived session inflates totals dramatically.
            d_sent, d_recv = _flow_tracker.delta(
                firewall_ip=source_ip,
                src_ip=event.src_ip,
                dst_ip=event.dst_ip,
                src_port=event.src_port,
                dst_port=event.dst_port,
                bytes_sent=event.bytes_sent,
                bytes_recv=event.bytes_received,
            )
            event.bytes_sent = d_sent
            event.bytes_received = d_recv
            enrich_and_write(event, source_ip=source_ip)

    # ── Syslog callback ───────────────────────────────────────────────────
    from parsers.sonicwall_parser import normalize_syslog as _sw_normalize_syslog, is_sonicwall_syslog
    from parsers.fortinet_parser import normalize_syslog as _ft_normalize_syslog, is_fortinet_syslog

    def on_syslog_message(raw: str, source_ip: str):
        if is_sonicwall_syslog(raw):
            event = _sw_normalize_syslog(raw, source_ip, tenant_id, sensor_id)
        elif is_fortinet_syslog(raw):
            event = _ft_normalize_syslog(raw, source_ip, tenant_id, sensor_id)
        else:
            return
        if event:
            enrich_and_write(event, source_ip=source_ip)

    # ── Start inputs ──────────────────────────────────────────────────────
    threads = []

    if _eb('ENABLE_IPFIX'):
        allowed_src = set(
            s.strip() for s in _e('IPFIX_ALLOWED_SOURCES').split(',') if s.strip()
        ) or None

        from inputs.ipfix_input import IPFIXInput
        ipfix = IPFIXInput(
            on_flow        = on_ipfix_flow,
            listen_ip      = _e('IPFIX_LISTEN_IP', '0.0.0.0'),
            listen_port    = _ei('IPFIX_LISTEN_PORT', 2055),
            allowed_sources= allowed_src,
        )
        t = threading.Thread(target=ipfix.run, daemon=True, name='ipfix-input')
        t.start()
        threads.append(t)
        logger.info(f"IPFIX input started on port {_ei('IPFIX_LISTEN_PORT', 2055)}")

    if _eb('ENABLE_SYSLOG'):
        syslog_allowed = set(
            s.strip() for s in _e('SYSLOG_ALLOWED_SOURCES').split(',') if s.strip()
        ) or None

        from inputs.syslog_input import SyslogInput
        syslog = SyslogInput(
            on_message      = on_syslog_message,
            udp_port        = _ei('SYSLOG_UDP_PORT', 514),
            tcp_port        = _ei('SYSLOG_TCP_PORT', 514),
            tls_port        = _ei('SYSLOG_TLS_PORT', 6514),
            tls_cert        = _e('SYSLOG_TLS_CERT', '/etc/ss-multivendor/certs/server.crt'),
            tls_key         = _e('SYSLOG_TLS_KEY',  '/etc/ss-multivendor/certs/server.key'),
            tls_ca          = _e('SYSLOG_TLS_CA',   '/etc/ss-multivendor/certs/ca.crt'),
            listen_ip       = _e('SYSLOG_LISTEN_IP', '0.0.0.0'),
            allowed_sources = syslog_allowed,
        )
        t = threading.Thread(target=syslog.run, daemon=True, name='syslog-input')
        t.start()
        threads.append(t)
        logger.info("Syslog input started")

    if not threads:
        logger.error("No inputs enabled. Set ENABLE_IPFIX=true and/or ENABLE_SYSLOG=true")
        sys.exit(1)

    logger.info("Collector running — press Ctrl+C to stop")

    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        logger.info("Shutting down...")
    finally:
        writer.stop()


if __name__ == '__main__':
    main()
