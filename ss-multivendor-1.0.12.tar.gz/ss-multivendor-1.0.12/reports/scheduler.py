"""
SonicScope Report Scheduler
============================
Uses APScheduler BackgroundScheduler to run periodic reports on their
configured cron schedules. Each job runs in its own DB connection so no
connection is shared across threads.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import psycopg2
import psycopg2.extras
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from .generator import period_label, generate_periodic_report
from .email_sender import send_report_email

log = logging.getLogger('ss.reports.scheduler')

_DEFAULT_TZ = 'Africa/Johannesburg'


def _db_connect(db_config: dict):
    """Open and return a new psycopg2 connection using the provided config dict."""
    return psycopg2.connect(**db_config)


def _resolve_tz(tz_name: str | None) -> ZoneInfo:
    """Return a ZoneInfo for tz_name, falling back to Africa/Johannesburg."""
    try:
        return ZoneInfo(tz_name or _DEFAULT_TZ)
    except (ZoneInfoNotFoundError, KeyError):
        return ZoneInfo(_DEFAULT_TZ)


def _date_range(report_type: str, tz_name: str | None) -> tuple[datetime, datetime]:
    """Return (period_start, period_end) for the report type in the tenant timezone."""
    tz = _resolve_tz(tz_name)
    now = datetime.now(tz)
    today = now.date()

    if report_type == 'daily':
        d = today - timedelta(days=1)
        start = datetime(d.year, d.month, d.day, 0, 0, 0, tzinfo=tz)
        end = datetime(d.year, d.month, d.day, 23, 59, 59, tzinfo=tz)

    elif report_type == 'weekly':
        # Last full Mon–Sun week
        days_since_mon = today.weekday()  # Mon=0, Sun=6
        last_mon = today - timedelta(days=days_since_mon + 7)
        last_sun = last_mon + timedelta(days=6)
        start = datetime(last_mon.year, last_mon.month, last_mon.day, 0, 0, 0, tzinfo=tz)
        end = datetime(last_sun.year, last_sun.month, last_sun.day, 23, 59, 59, tzinfo=tz)

    elif report_type == 'monthly':
        # Last full calendar month
        first_this_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        last_of_prev = first_this_month - timedelta(days=1)
        start = last_of_prev.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = last_of_prev.replace(hour=23, minute=59, second=59, microsecond=0)

    else:
        raise ValueError(f"Unknown report_type: {report_type!r}")

    return start, end


def _cron_trigger(cron_expr: str, tz_name: str | None) -> CronTrigger:
    """Parse a 5-field cron expression into an APScheduler CronTrigger."""
    parts = cron_expr.strip().split()
    if len(parts) != 5:
        raise ValueError(f"Expected 5-field cron expression, got: {cron_expr!r}")
    minute, hour, day, month, dow = parts
    tz = _resolve_tz(tz_name)
    return CronTrigger(
        minute=minute, hour=hour, day=day, month=month,
        day_of_week=dow, timezone=tz,
    )


def _run_scheduled_report(
    schedule_id: int,
    db_config: dict,
    smtp_config: dict,
    output_dir: str,
) -> None:
    """Execute one scheduled report: generate → email → update DB. Never raises."""
    conn = None
    report_id: int | None = None

    try:
        conn = _db_connect(db_config)

        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(
                """
                SELECT rs.id, rs.tenant_id, rs.msp_profile_id, rs.report_type,
                       rs.recipient_emails, rs.recipient_name,
                       t.timezone, t.name AS tenant_name
                FROM report_schedules rs
                JOIN tenants t ON t.id = rs.tenant_id
                WHERE rs.id = %s AND rs.is_active = TRUE
                """,
                (schedule_id,),
            )
            row = cur.fetchone()

        if row is None:
            log.warning('Schedule %d not found or inactive — skipping', schedule_id)
            return

        period_start, period_end = _date_range(row['report_type'], row['timezone'])

        file_path = generate_periodic_report(
            db_conn=conn,
            tenant_id=row['tenant_id'],
            msp_profile_id=row['msp_profile_id'],
            report_type=row['report_type'],
            period_start=period_start,
            period_end=period_end,
            output_dir=output_dir,
            schedule_id=schedule_id,
        )

        # Retrieve the generated_reports id that generate_periodic_report just inserted
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT id FROM generated_reports
                WHERE schedule_id = %s
                ORDER BY generated_at DESC
                LIMIT 1
                """,
                (schedule_id,),
            )
            r = cur.fetchone()
            report_id = r[0] if r else None

        pl = period_label(row['report_type'], period_start, period_end)
        recipients: list[str] = list(row['recipient_emails'] or [])

        if recipients and smtp_config.get('host'):
            email_subject = (
                f"Network Activity Report — {row['tenant_name']} — {pl}"
            )
            send_report_email(
                smtp_config=smtp_config,
                recipients=recipients,
                subject=email_subject,
                pdf_path=file_path,
                tenant_name=row['tenant_name'],
                period_label=pl,
            )
            now_utc = datetime.now(timezone.utc)
            with conn.cursor() as cur:
                if report_id:
                    cur.execute(
                        """
                        UPDATE generated_reports
                        SET delivery_status = 'sent', delivered_at = %s
                        WHERE id = %s
                        """,
                        (now_utc, report_id),
                    )
                cur.execute(
                    "UPDATE report_schedules SET last_run_at = %s WHERE id = %s",
                    (now_utc, schedule_id),
                )
            conn.commit()
            log.info(
                'Schedule %d: report sent to %d recipient(s)', schedule_id, len(recipients)
            )
        else:
            log.info(
                'Schedule %d: report generated; no SMTP configured or no recipients',
                schedule_id,
            )

    except Exception:
        log.exception('Scheduled report %d failed', schedule_id)
        if conn and report_id:
            try:
                conn.rollback()  # clear any aborted transaction before the recovery UPDATE
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE generated_reports SET delivery_status='failed' WHERE id=%s",
                        (report_id,),
                    )
                conn.commit()
            except Exception:
                log.exception(
                    'Could not mark report %d as failed in DB', report_id
                )
    finally:
        if conn:
            conn.close()


def start_scheduler(
    db_config: dict,
    smtp_config: dict,
    output_dir: str,
) -> BackgroundScheduler:
    """Start the BackgroundScheduler and load all active schedules from the DB."""
    scheduler = BackgroundScheduler(daemon=True)
    scheduler.start()
    reload_schedules(scheduler, db_config, smtp_config, output_dir)
    log.info('Report scheduler started')
    return scheduler


def stop_scheduler(scheduler: BackgroundScheduler) -> None:
    """Shut down the scheduler gracefully without waiting for running jobs."""
    scheduler.shutdown(wait=False)
    log.info('Report scheduler stopped')


def reload_schedules(
    scheduler: BackgroundScheduler,
    db_config: dict,
    smtp_config: dict,
    output_dir: str,
) -> None:
    """Remove all schedule jobs and re-load active schedules from the DB."""
    for job in scheduler.get_jobs():
        if job.id.startswith('schedule_'):
            job.remove()

    conn = None
    rows: list = []
    try:
        conn = _db_connect(db_config)
        with conn.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute(
                """
                SELECT rs.id, rs.schedule_cron, rs.report_type, t.timezone
                FROM report_schedules rs
                JOIN tenants t ON t.id = rs.tenant_id
                WHERE rs.is_active = TRUE
                """,
            )
            rows = cur.fetchall()
    except Exception:
        log.exception('Failed to load schedules from DB')
    finally:
        if conn:
            conn.close()

    loaded = 0
    for row in rows:
        try:
            trigger = _cron_trigger(row['schedule_cron'], row['timezone'])
            scheduler.add_job(
                _run_scheduled_report,
                trigger=trigger,
                args=[row['id'], db_config, smtp_config, output_dir],
                id=f"schedule_{row['id']}",
                replace_existing=True,
                misfire_grace_time=3600,
            )
            loaded += 1
        except Exception:
            log.exception('Could not add cron job for schedule %d', row['id'])

    log.info('Loaded %d active report schedule(s)', loaded)
