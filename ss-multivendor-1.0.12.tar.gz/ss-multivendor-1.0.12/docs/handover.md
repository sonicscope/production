# SonicScope V2 — Operations Handover

**Version:** 1.9 | **Date:** May 2026  
**Platform:** ss-multivendor on Ubuntu 24.04 (sonicscopedev — 192.168.8.16)

This document covers day-to-day operations, adding customers, managing users, and handling common situations. For architecture detail see `DESIGN.md`. For deployment see `docs/install-guide.html`.

---

## Services Quick Reference

| Service | Purpose | Port |
|---|---|---|
| `ss-collector` | IPFIX + syslog receiver, enrichment, DB writer | UDP 2055, 514, TCP 514, 6514 |
| `ss-reports` | Flask management UI + PDF scheduler | 8080 |
| `grafana-server` | Live dashboards | 3000 |
| `postgresql` | TimescaleDB — all flow data | 5432 (local only) |

```bash
# Status of all services
sudo systemctl status ss-collector ss-reports grafana-server postgresql

# Live collector log (watch flows coming in)
sudo journalctl -u ss-collector -f

# Reports UI log
sudo journalctl -u ss-reports -f

# Restart all SonicScope services
sudo systemctl restart ss-collector ss-reports
```

---

## Daily Checks

```bash
# Confirm data is flowing
sudo -u postgres psql sonicscope \
  -c "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '1 hour';"

# Check licence expiry
sudo journalctl -u ss-collector --since today | grep -i "licence\|expired\|warning"

# Check for DB write errors
sudo journalctl -u ss-collector --since today | grep -i "error\|failed\|dropped"

# Disk usage (TimescaleDB compresses chunks > 7 days automatically)
df -h /
sudo -u postgres psql sonicscope -c "\l+"
```

---

## Adding a New Tenant (Customer Site)

**1. Create the tenant in the Reports UI**

Open `http://192.168.8.16:8080` → log in with email OTP → **Tenants** → **+ New Tenant**

Fill in:
- Company Name, Slug (URL-safe), MSP Profile, Timezone, Contact

**2. Register their firewall(s)**

On the tenant edit page → **Registered Firewalls** panel → **Register Firewall**

- Enter the firewall's name, vendor, and the **source IP** it sends IPFIX/syslog from
- This is the IP that appears as the source of UDP packets on port 2055
- Saving automatically updates `IPFIX_ALLOWED_SOURCES` and `SYSLOG_ALLOWED_SOURCES` in `collector.env` and restarts the collector — no manual steps needed
- The TenantResolver also refreshes within 5 minutes

**3. Grafana tenant dropdown**

The dropdown updates automatically when you save a tenant. No manual action needed. If the dropdown ever looks stale, you can force a refresh:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

**4. Configure the firewall**

Point the customer's firewall IPFIX to this server's IP on UDP 2055:
- SonicWall: `Log → NetFlow` → set collector IP
- Syslog (optional, for denied traffic + user identity): UDP/TCP 514 or TLS 6514

**5. Add optional fallback subnets**

If the firewall IP cannot be registered (e.g. shared NAT), go to the tenant edit page → **IP Subnets** → add the customer's internal IP range as `192.168.x.0/24`.

---

## First Login (Fresh Install)

After running `install-reports.sh`, the default admin credentials are printed to the console:

- **Email:** `admin@sonicscope.local`
- **Password:** same as the Grafana admin password (stored in `/etc/ss-multivendor/grafana-admin-password`)

Log in at `http://<server-ip>:8080`, then click the 🔑 icon in the top-right navbar to change the password immediately.

---

## Adding a New UI User

Open the Reports UI → **👥 Users** (admin only) → **+ New User**

- Enter full name, email, and an initial password (min 8 characters)
- Select role: **Admin** (full access) or **User** (restricted to assigned tenants)
- For **User** role: tick which tenants they can access
- Save — they can log in immediately at `/login` with their email and the password you set

**Users log in with email + password.** To reset a forgotten password, use the "Forgot password?" link on the login page — a 6-digit reset code is emailed. SMTP must be configured for this to work.

**Admin can reset any user's password:** Users → Edit → Reset Password panel.

**Deactivate a user:** Users → Edit → Deactivate (they can no longer log in)

---

## Generating a PDF Report On-Demand

`http://192.168.8.16:8080` → **⚡ Generate Now**

1. Select tenant
2. Select report kind:
   - **Periodic** — full network activity overview (bandwidth, top users, top sites, threats, rules, VPN, geo, productivity)
   - **IT & Network Security** — security-focused (threats, blocked traffic, firewall rules, top ports, geographic destinations)
   - **HR Investigation** — per-user activity deep-dive (confidential, with optional clean mode to redact sensitive domains)
3. Set date range
4. Click Generate — PDF appears in the dashboard marked **Ready** when complete
5. Download or email directly from the dashboard

**Note:** There is a 30-second cooldown between generations to protect server resources.

---

## Setting Up Automatic Report Delivery

`http://192.168.8.16:8080` → **🗓 Schedules** → **+ New Schedule**

The schedule form uses friendly dropdowns — no cron knowledge needed:

| Field | Options |
|---|---|
| Frequency | Daily / Weekly / Monthly |
| Delivery Time | 00:00 – 23:00 |
| Day of Week | Mon–Sun (shown for Weekly only) |
| Day of Month | 1st–28th (shown for Monthly only) |
| Report Type | Daily / Weekly / Monthly (for date range label in PDF) |
| Recipients | Customer contact email(s), comma separated |

**Editing a schedule:** click **Edit** on any row in the schedule list — same form, pre-populated.

**Pausing a schedule:** click **Pause** — it stays saved but won't fire until reactivated.

The scheduler runs as part of `ss-reports`. Reports are generated and emailed automatically. On-demand reports show **Ready** in the dashboard; scheduled reports show **Sent** on successful email delivery or **Failed** if SMTP errors.

---

## Issuing a New Licence (After Online Payment)

When a customer completes payment on sonicscope.co.za, an email arrives at `license@sonicscope.co.za` with all the details needed. The email includes:
- Customer name, email, company, phone, country
- Tier (Solo/Micro/Small/Professional/Business/Enterprise/Unlimited)
- Number of firewalls (max sensors)
- Term (years) and calculated expiry date
- **Server MAC address** (collected during checkout — the licence will be bound to this)
- Payment reference and amount

**To issue the licence:**

1. Open `http://192.168.8.16:8888` (Licence Manager) → log in
2. **Customers** → **+ New Customer** — enter name and email from the notification email
3. On the customer page → **+ New Licence**
4. Set expiry date (from email), sensor count (from email), confirm MAC address (from email)
5. Tick **Send licence email** → Save
6. The customer receives their `licence.env` block and can deploy immediately using `deploy.sh`

---

## Renewing a Customer Licence

Open `http://192.168.8.16:8888` (Licence Manager) → log in → **Customers** → select customer → **+ New Licence**

Enter the new expiry date, confirm MAC and sensor count, check **Send licence email**. The customer receives a new `.env` block by email. They update `collector.env` and restart:

```bash
sudo systemctl restart ss-collector
```

---

## Adding GeoIP Databases

Required for country/city enrichment in dashboards and reports. Without GeoIP the world map and country columns are blank.

```bash
sudo bash scripts/download-geoip.sh <MaxMind_Licence_Key>
sudo systemctl restart ss-collector
```

Get a free MaxMind key at maxmind.com → Account → Manage Licence Keys.

**snwlrep2 status:** GeoIP installed 2026-05-07 (GeoLite2-City 63 MB + GeoLite2-ASN 12 MB). Country enrichment confirmed working.

---

## Upgrading Grafana Dashboards

After any dashboard JSON changes in the repo:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

This is idempotent — safe to run at any time. Also run after adding/renaming tenants.

---

## FortiGate Syslog (Live — v1.0.11)

FortiGate 7.x syslog is fully supported as of v1.0.11. No additional steps required once a FortiGate is registered and sending syslog.

**FortiGate syslog configuration (FortiOS CLI):**
```
config log syslogd setting
    set status enable
    set server <snwlrep2-ip>
    set port 514
    set mode udp
    set facility local7
    set format default
end
config log syslogd filter
    set severity information
    set forward-traffic enable
    set local-traffic enable
    set anomaly enable
end
```

**Note:** FortiGate VM eval licences do not support NetFlow/IPFIX (error -61). Syslog is the correct data source for FortiGate — it provides richer data anyway (app names, user identity, web categories).

**To add a FortiGate to an existing installation:**
1. Reports UI → Tenants → Edit → Register Firewall — enter the FortiGate's source IP
2. This auto-updates `SYSLOG_ALLOWED_SOURCES` in `collector.env` and restarts the collector
3. Configure syslog on the FortiGate pointing to the server IP on UDP 514
4. Verify: `sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events WHERE vendor='fortinet' AND time > NOW() - INTERVAL '5 minutes';"`

**Fields populated from FortiGate syslog:** src/dst IP and port, protocol, action, event type, interface names, zone roles (lan/wan/dmz), rule ID, app name (FortiGuard), app category, web category, threat name/severity (IPS/AV), user identity, bytes sent/received, duration.

---

## Updating an Existing Installation (Preserves Data)

Use this for all routine version updates on live customer systems. The database, all collected flow data, `collector.env`, GeoIP databases, and generated PDF reports are untouched.

```bash
# On the customer server — copy the new tarball across first, then:
tar -xzf ss-multivendor-<version>.tar.gz
cd ss-multivendor-<version>
sudo bash scripts/update.sh
```

The script will:
1. Show the current → new version and ask for confirmation
2. Stop `ss-collector` and `ss-reports`
3. Rsync the new collector and reports code into `/opt/ss-multivendor/` (skipping `venv/` and `geoip/`)
4. Install any new Python packages from both `collector/requirements.txt` and `reports/requirements.txt`
5. Re-apply all DB migrations (all are idempotent — safe to run on an existing database)
6. Start both services and confirm they are running

If anything fails mid-update a `trap` ensures services are always restarted before the script exits.

**After the update:**
- Log in to the Reports UI and confirm the version in the footer
- Check `sudo journalctl -u ss-reports --since "2 minutes ago" | grep "Loaded"` to confirm schedules reloaded
- If Grafana dashboards need refreshing: `sudo bash scripts/install-grafana-dashboards.sh`

**When to use full reinstall instead:** Only if migrating to a new server, recovering from a corrupt install, or if the release notes explicitly say a clean install is required.

**Note:** `update.sh` is idempotent — safe to re-run the same version. All migrations are applied again (they are all idempotent) and services are restarted. If you check status mid-run the services will briefly be down; wait for the script to finish before concluding something went wrong.

---

## Fresh Install / Redeploy

```bash
# Wipe everything (interactive confirmation required)
sudo bash scripts/uninstall.sh

# Reinstall in order
sudo bash scripts/install.sh
sudo bash scripts/download-geoip.sh <MaxMind_key>

# Edit collector.env — paste the licence block from the customer's .env file
sudo nano /etc/ss-multivendor/collector.env

sudo systemctl start ss-collector
sudo journalctl -u ss-collector -f   # confirm: Licence valid, no warnings

sudo bash scripts/install-grafana-dashboards.sh
sudo bash scripts/install-reports.sh
# ↑ prints default admin credentials at the end — save them
```

After reinstall: log in to Reports UI at `:8080` as `admin@sonicscope.local`, change the password, add MSP profile, add tenants, register firewalls (allowlist updates automatically), configure SMTP in `/etc/ss-multivendor/collector.env`, set up report schedules.

**Confirm data is flowing (no INFO logs for individual inserts — check DB directly):**
```bash
sudo -u postgres psql -d sonicscope -c \
  "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';"
```
A non-zero count confirms the collector is writing. The journal will also show a heartbeat every 10,000 events: `DB writer: N events inserted total`.

---

## Key collector.env Settings

| Setting | Default | Notes |
|---|---|---|
| `IPFIX_TIMESTAMP_OFFSET_HOURS` | `0` | Set to `-2` for SonicWall firewalls in SAST (UTC+2). SonicWall sends IPFIX timestamps in local time despite the `universal` flag in SonicOS. Without this, all data appears 2 hours in the future. |
| `IPFIX_ALLOWED_SOURCES` | *(blank)* | Comma-separated firewall IPs. Updated automatically when firewalls registered via Reports UI. |
| `ENABLE_GEOIP` | `true` | Requires MaxMind .mmdb files — run `download-geoip.sh` first. |
| `SMTP_HOST` / `SMTP_PORT` | *(blank)* | Required for scheduled report delivery and forgot-password OTP. |

---

## Key File Locations

| Path | Contents |
|---|---|
| `/etc/ss-multivendor/collector.env` | All config — DB credentials, SMTP, licence, feature toggles. Mode 660 (root:ss-collector) — writable by the Flask app |
| `/opt/ss-multivendor/` | Installed application (collector + reports) |
| `/opt/ss-multivendor/geoip/` | MaxMind .mmdb files |
| `/var/lib/ss-multivendor/reports/` | Generated PDF archive |
| `/var/lib/ss-multivendor/logos/` | Uploaded MSP logos |
| `/var/log/ss-multivendor/` | Collector and report logs |
| `/var/log/sonicscope/licence.log` | Licence validation events |
| `/etc/grafana/provisioning/` | Grafana datasource + dashboard config |
| `/var/lib/grafana/dashboards/sonicscope/` | Deployed dashboard JSON files (mode 775, writable by ss-collector group) |
| `/etc/ss-multivendor/grafana-admin-password` | Grafana + Reports UI default admin password (generated at install) |
| `/etc/sudoers.d/ss-collector` | Allows ss-reports to restart ss-collector without password (allowlist updates) |

---

## Data Accuracy Notes

IPFIX data from SonicWall firewalls is accurate for most traffic but has a few inherent behaviours to be aware of:

- **Large single-connection downloads** (one long-lived TCP session) may be under-reported or appear with a timestamp at the flow *start*, not when the download completed. The IPFIX record is only exported when the connection closes, which can lag the actual transfer by up to 60 seconds.
- **Validated accuracy (2026-05-07):** A 396 MB file download was recorded as 412 MB (~96% accurate). The 4% overhead is TCP/TLS handshake bytes included in the flow record.
- **FlowDeltaTracker** (v1.0.8+): SonicWall exports cumulative byte totals for active flows every ~60 seconds. The collector converts these to per-export deltas before storing. Without this, a single long-lived VPN or streaming session inflates totals dramatically. On collector restart, the first export of each active flow uses its full cumulative bytes (unavoidable without persisted state) — this self-corrects after the first IPFIX cycle (~60 seconds).
- **Syslog data** does not have the cumulative bytes issue — syslog records one entry per flow termination.

---

## Troubleshooting

### Collector not receiving flows
```bash
# Check the service is running
sudo systemctl status ss-collector

# Check IPFIX port is listening
ss -ulnp | grep 2055

# Confirm firewall is sending to the right IP
sudo tcpdump -i any udp port 2055 -c 10
```

### "Licence invalid" on startup
```bash
# Check the licence log for the specific error
cat /var/log/sonicscope/licence.log | tail -20

# Common causes:
# - Missing SONICSCOPE_LICENSE/CUSTOMER_ID/EXPIRY in collector.env
# - Server MAC changed (VM migration) — requires new key from licence manager
# - Licence expired — renew via http://192.168.8.16:8888
```

### Reports UI showing no data
```bash
# Check ss-reports is running
sudo systemctl status ss-reports

# Check the DB connection
sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events;"

# Check the tenant_id is correct in the UI dropdown
```

### Grafana tenant dropdown empty / shows wrong names
```bash
# Re-run the dashboard installer — it reads tenants from the DB live
sudo bash scripts/install-grafana-dashboards.sh
```

### Email not sending
```bash
# Verify SMTP settings in collector.env
sudo grep "^SMTP_" /etc/ss-multivendor/collector.env | grep -v PASSWORD

# Test SMTP manually
python3 -c "
import smtplib, ssl
with smtplib.SMTP_SSL('smtp.sonicscope.co.za', 465) as s:
    s.login('mailer@sonicscope.co.za', 'PASSWORD')
    print('SMTP OK')
"
```

### TenantResolver showing 0 firewalls after registering one
The resolver refreshes every 5 minutes automatically. Check it loaded:
```bash
sudo journalctl -u ss-collector --since "10 minutes ago" | grep TenantResolver
```
If it hasn't refreshed, restart the collector.

### Collector appears running but no flows visible in journal
IPFIX inserts log at DEBUG level — they are invisible in `journalctl` at INFO. The collector IS working if the DB has rows:
```bash
sudo -u postgres psql -d sonicscope -c \
  "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';"
```
A non-zero count means data is flowing. The journal will also show `DB writer: N events inserted total` every 10,000 events.

### Flows arriving (tcpdump shows packets) but collector silently drops them
`IPFIX_ALLOWED_SOURCES` is filtering them. Verify the registered sensor IPs match what the firewall actually sends from:
```bash
sudo tcpdump -i any udp port 2055 -c 5   # check source IP in output
sudo grep IPFIX_ALLOWED_SOURCES /etc/ss-multivendor/collector.env
```
Registering a firewall via the Reports UI automatically updates the allowlist and restarts the collector. If you edited collector.env manually, restart the collector to apply.

### "password authentication failed for user sonicscope" on collector start
The password in `collector.env` doesn't match what PostgreSQL has — usually caused by saving an old collector.env over a fresh install. Fix:
```bash
DB_PASS=$(sudo grep '^DB_PASSWORD=' /etc/ss-multivendor/collector.env | cut -d'=' -f2-)
sudo -u postgres psql -c "ALTER USER sonicscope WITH PASSWORD '$DB_PASS';"
sudo systemctl restart ss-collector
```

### Grafana tenant dropdown shows wrong or missing tenants
The dropdown is updated automatically when tenants are saved in the Reports UI. If it's stale, force a refresh:
```bash
sudo bash scripts/install-grafana-dashboards.sh
```

### Grafana shows data that is consistently 2 hours behind real time
The SonicWall's IPFIX export timestamps are in local time (SAST, UTC+2) instead of UTC. All flow records arrive with timestamps 2 hours ahead of the collector server's clock, so `NOW()`-relative queries in Grafana appear to show data from 2 hours ago.

**Fix on the SonicWall:**
1. Go to **System → Time** on the SonicWall management interface
2. Confirm **Time Zone** is set to `(GMT+02:00) Africa/Johannesburg`
3. Confirm **NTP Server** is configured and synchronised
4. After correcting, restart the collector: `sudo systemctl restart ss-collector`

The collector's flow delta tracker resets on restart — the first ~60 seconds of data after restart will carry the full cumulative bytes for any active long-lived flows (unavoidable without persisted state). This self-corrects after the first IPFIX export cycle.

### Bandwidth figures look inflated (Grafana shows GB/min on a home network)
The SonicWall exports active flow records every ~60 seconds with **cumulative** total bytes since session start, not bytes since the last export. Without delta correction, a single long-lived connection (e.g. a VPN tunnel or a large download) adds its full cumulative byte count on every export interval.

The collector (v1.0.8+) includes a `FlowDeltaTracker` that corrects this automatically. If you see inflation on an older install, update to v1.0.8:
```bash
sudo bash scripts/update.sh
sudo systemctl restart ss-collector
```

---

## Customer Self-Service Deployment

Customers deploy SonicScope using a single script downloaded from GitHub. No manual server access or configuration files required from you — the `deploy.sh` script handles everything.

**What the customer needs:**
1. A Ubuntu 22.04 or 24.04 LTS server (VM or bare metal)
2. Their `licence.env` file (emailed automatically after licence issuance)
3. Internet access from the server

**Deployment command:**
```bash
# On the customer server — place licence.env in the same directory first
sudo bash deploy.sh
```

The script downloads `ss-multivendor-latest.tar.gz` from github.com/sonicscope/production, runs the full installer, applies the licence, optionally downloads GeoIP (if `MAXMIND_KEY` is in `licence.env`), installs Grafana dashboards and the Reports UI, and prints the default admin credentials on completion.

**Optional keys the customer can add to `licence.env`** before running deploy.sh:
```
MAXMIND_KEY=<free MaxMind key>     # enables GeoIP enrichment automatically
SMTP_HOST=smtp.their-domain.com    # pre-configures scheduled report email delivery
SMTP_PORT=465
SMTP_USER=reports@their-domain.com
SMTP_PASSWORD=<password>
SMTP_FROM=reports@their-domain.com
SMTP_USE_TLS=true
```

**To release a new version** (update github.com/sonicscope/production):
```bash
cd /home/devadmin/production
cp /home/devadmin/ss-multivendor/dist/ss-multivendor-X.X.X.tar.gz .
cp ss-multivendor-X.X.X.tar.gz ss-multivendor-latest.tar.gz
git add ss-multivendor-X.X.X.tar.gz ss-multivendor-latest.tar.gz
git commit -m "release: vX.X.X — <summary>"
git push
```
All existing customers using `deploy.sh` or `update.sh` will automatically receive the new version on their next deployment/update.

---

## Pricing (SS-MULTIVENDOR)

| Tier | Firewalls | ZAR / year | USD / year |
|---|---|---|---|
| Solo | 1 | R1,490 | $89 |
| Micro | 3 | R3,490 | $199 |
| Small | 5 | R4,990 | $279 |
| Professional | 10 | R8,490 | $469 |
| Business | 25 | R16,990 | $949 |
| Enterprise | 50 | R27,990 | $1,549 |
| Unlimited | ∞ | R39,990 | $2,199 |

Multi-year discounts: 2 years = 10% off (×1.80 total), 3 years = 15% off (×2.55 total).

Payments are processed at sonicscope.co.za via PayFast (ZAR, South African customers) and Paystack (USD, international). On payment, `license@sonicscope.co.za` receives a notification with all details to issue the licence manually via the Licence Manager.

---

## Development Workflow

Source code lives on the dev machine (sonicscopedev — 192.168.8.16).

| Location | Purpose |
|---|---|
| `/home/devadmin/ss-multivendor/` | Working source directory |
| `/home/devadmin/sonicscope-software/` | Full git clone of `github.com/sonicscope/software` |
| `/home/devadmin/production/` | Release tarballs + git clone of `github.com/sonicscope/production` |

**Committing source changes to GitHub:**
```bash
cd /home/devadmin/ss-multivendor
bash git_commit.sh "feat: description of change"
```
This rsyncs the working directory into the `ss-multivendor/` subdirectory of the software repo clone, commits, and pushes. Excludes `dist/`, build artefacts, and other product directories.

**Building and releasing a new version:**
```bash
# 1. Bump version in collector/main.py and DESIGN.md
# 2. Build (salt is read from ~/ss-license/operator.env)
cd /home/devadmin/ss-multivendor
bash scripts/build-release.sh --version X.X.X --salt '<salt>'

# 3. Publish to production repo
cp dist/ss-multivendor-X.X.X.tar.gz /home/devadmin/production/
cp /home/devadmin/production/ss-multivendor-X.X.X.tar.gz /home/devadmin/production/ss-multivendor-latest.tar.gz
cd /home/devadmin/production
git add ss-multivendor-X.X.X.tar.gz ss-multivendor-latest.tar.gz
git commit -m "release: vX.X.X — summary"
git push

# 4. Update snwlrep2
rsync -av production/ss-multivendor-X.X.X.tar.gz devadmin@192.168.8.17:/tmp/
ssh devadmin@192.168.8.17 "cd /tmp && tar -xzf ss-multivendor-X.X.X.tar.gz && cd ss-multivendor-X.X.X && echo y | sudo bash scripts/update.sh"

# 5. Commit source changes
bash git_commit.sh "release: vX.X.X — summary"
```

**SSH access:** `devadmin@192.168.8.17` is set up with key auth and NOPASSWD sudo from sonicscopedev.

**Quick collector deploy to snwlrep2 (without a full release build):**
```bash
cd /home/devadmin/ss-multivendor
bash deploy_dev.sh
```
This rsyncs collector source to `/opt/ss-multivendor/` on snwlrep2 and restarts the collector. It intentionally excludes `license_validator.py` — the production copy has the licence salt baked in and must never be overwritten by rsync.

---

## Contacts

| Role | Contact |
|---|---|
| Platform owner | wynand@vannispen.co.za |
| SonicScope sales | sales@sonicscope.co.za |
| Licence notifications | license@sonicscope.co.za |
| Website | sonicscope.co.za |
