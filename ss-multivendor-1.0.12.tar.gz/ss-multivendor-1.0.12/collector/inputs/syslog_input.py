"""
Syslog input — listens on UDP/514, TCP/514, TLS/6514.
Parses RFC 3164/5424, detects SonicWall Enhanced Syslog, and calls
on_event(raw_message, source_ip) for every message received.

Adapted from ss-syslog/collector/syslog_receiver.py.
"""

from __future__ import annotations
import os
import re
import ssl
import socket
import logging
import threading
from typing import Callable, Optional

logger = logging.getLogger('ss.syslog')

_LISTEN_BACKLOG  = 50
_MAX_MSG_SIZE    = 65535
_MAX_TCP_CLIENTS = 100   # cap concurrent TCP/TLS syslog connections
_RECV_BUF       = 8192


class SyslogInput:
    """
    Multi-protocol syslog listener.

    Every received message is passed to on_message(raw: str, src_ip: str).
    The caller wires this to the SonicWall parser + normalizer.
    """

    def __init__(self, on_message: Callable[[str, str], None],
                 udp_port:  int  = 514,
                 tcp_port:  int  = 514,
                 tls_port:  int  = 6514,
                 tls_cert:  Optional[str] = None,
                 tls_key:   Optional[str] = None,
                 tls_ca:    Optional[str] = None,
                 listen_ip: str  = '0.0.0.0',
                 allowed_sources: Optional[set] = None):
        self._on_message = on_message
        self._udp_port   = udp_port
        self._tcp_port   = tcp_port
        self._tls_port   = tls_port
        self._tls_cert   = tls_cert
        self._tls_key    = tls_key
        self._tls_ca     = tls_ca
        self._listen_ip  = listen_ip
        self._allowed    = allowed_sources
        self._threads: list[threading.Thread] = []
        self._running = False
        self._tcp_sem = threading.Semaphore(_MAX_TCP_CLIENTS)

    def run(self):
        self._running = True

        # UDP listener
        t = threading.Thread(target=self._udp_listener, daemon=True, name='syslog-udp')
        t.start()
        self._threads.append(t)

        # TCP listener
        t = threading.Thread(target=self._tcp_listener,
                             args=(self._tcp_port, None), daemon=True, name='syslog-tcp')
        t.start()
        self._threads.append(t)

        # TLS listener (only if cert/key are configured)
        if self._tls_cert and self._tls_key and os.path.exists(self._tls_cert):
            t = threading.Thread(target=self._tcp_listener,
                                 args=(self._tls_port, self._make_tls_context()),
                                 daemon=True, name='syslog-tls')
            t.start()
            self._threads.append(t)
        else:
            logger.info("TLS syslog not enabled (no cert/key configured)")

        logger.info(f"Syslog listeners started: UDP/{self._udp_port} "
                    f"TCP/{self._tcp_port} TLS/{self._tls_port}")

        # Block until stopped
        for t in self._threads:
            t.join()

    def stop(self):
        self._running = False

    # ── UDP ───────────────────────────────────────────────────────────────

    def _udp_listener(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
        sock.bind((self._listen_ip, self._udp_port))
        sock.settimeout(1.0)
        logger.info(f"UDP syslog on {self._listen_ip}:{self._udp_port}")

        while self._running:
            try:
                data, addr = sock.recvfrom(_MAX_MSG_SIZE)
                self._dispatch(data, addr[0])
            except socket.timeout:
                continue
            except Exception as e:
                logger.error(f"UDP recv error: {e}")

        sock.close()

    # ── TCP / TLS ─────────────────────────────────────────────────────────

    def _tcp_listener(self, port: int, ctx: Optional[ssl.SSLContext]):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind((self._listen_ip, port))
        srv.listen(_LISTEN_BACKLOG)
        srv.settimeout(1.0)
        proto = 'TLS' if ctx else 'TCP'
        logger.info(f"{proto} syslog on {self._listen_ip}:{port}")

        while self._running:
            try:
                conn, addr = srv.accept()
            except socket.timeout:
                continue
            except Exception as e:
                logger.error(f"{proto} accept error: {e}")
                continue

            if ctx:
                try:
                    conn = ctx.wrap_socket(conn, server_side=True)
                except ssl.SSLError as e:
                    logger.warning(f"TLS handshake failed from {addr[0]}: {e}")
                    conn.close()
                    continue

            if not self._tcp_sem.acquire(blocking=False):
                logger.warning("Max TCP syslog connections (%d) reached — dropping %s",
                               _MAX_TCP_CLIENTS, addr[0])
                conn.close()
                continue
            t = threading.Thread(target=self._tcp_client_guarded,
                                 args=(conn, addr[0], proto),
                                 daemon=True)
            t.start()

        srv.close()

    def _tcp_client_guarded(self, conn: socket.socket, src_ip: str, proto: str):
        try:
            self._tcp_client(conn, src_ip, proto)
        finally:
            self._tcp_sem.release()

    def _tcp_client(self, conn: socket.socket, src_ip: str, proto: str):
        buf = b''
        try:
            while self._running:
                chunk = conn.recv(_RECV_BUF)
                if not chunk:
                    break
                buf += chunk
                if len(buf) > _MAX_MSG_SIZE:
                    logger.warning("%s client %s exceeded buffer limit — dropping connection",
                                   proto, src_ip)
                    break
                # Syslog over TCP uses newline framing (RFC 6587 non-transparent)
                while b'\n' in buf:
                    line, buf = buf.split(b'\n', 1)
                    if line.strip():
                        self._dispatch(line, src_ip)
        except Exception as e:
            logger.debug("%s client %s error: %s", proto, src_ip, e)
        finally:
            conn.close()

    # ── TLS context ───────────────────────────────────────────────────────

    def _make_tls_context(self) -> ssl.SSLContext:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(certfile=self._tls_cert, keyfile=self._tls_key)
        if self._tls_ca and os.path.exists(self._tls_ca):
            ctx.load_verify_locations(self._tls_ca)
            ctx.verify_mode = ssl.CERT_OPTIONAL
        return ctx

    # ── Dispatch ──────────────────────────────────────────────────────────

    def _dispatch(self, data: bytes, src_ip: str):
        if self._allowed and src_ip not in self._allowed:
            return
        try:
            raw = data.decode('utf-8', errors='replace').strip()
        except Exception:
            return
        if raw:
            self._on_message(raw, src_ip)
