"""
IPFIX / NetFlow v9 input — listens on UDP, parses packets into flow dicts,
then hands them to the SonicWall normalizer and enrichment pipeline.

Ported and adapted from ss-flow/collector/ipfix_collector.py.
Template parsing and field decoding kept identical; output goes to the
unified NormalizedEvent pipeline instead of Elasticsearch.
"""

from __future__ import annotations
import os
import socket
import struct
import logging
import threading
from collections import defaultdict
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger('ss.ipfix')

# Packet sizes
_NFV9_HEADER  = 20   # version(2)+count(2)+uptime(4)+secs(4)+seq(4)+src_id(4)
_IPFIX_HEADER = 16   # version(2)+length(2)+export_time(4)+seq(4)+domain_id(4)
_SET_HEADER   =  4   # set_id(2)+length(2)


class _TemplateCache:
    def __init__(self):
        self._data: dict = {}
        self._lock = threading.Lock()

    def add(self, src_ip: str, domain_id: int, tpl_id: int, fields: list):
        with self._lock:
            self._data[(src_ip, domain_id, tpl_id)] = fields
        logger.debug(f"Cached template {tpl_id} from {src_ip} ({len(fields)} fields)")

    def get(self, src_ip: str, domain_id: int, tpl_id: int) -> Optional[list]:
        with self._lock:
            return self._data.get((src_ip, domain_id, tpl_id))


class IPFIXInput:
    """
    UDP listener for IPFIX and NetFlow v9.

    Parsed flow dicts are passed to on_flow(flow_dict, export_time, source_ip).
    The caller (main.py) supplies this callback and wires it to the normalizer.
    """

    def __init__(self, on_flow, listen_ip: str = '0.0.0.0',
                 listen_port: int = 2055,
                 allowed_sources: Optional[set] = None):
        self._on_flow        = on_flow
        self._listen_ip      = listen_ip
        self._listen_port    = listen_port
        self._allowed        = allowed_sources
        self._templates      = _TemplateCache()
        self._stats          = defaultdict(int)
        self._running        = False

    def run(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 * 1024 * 1024)
        sock.bind((self._listen_ip, self._listen_port))
        sock.settimeout(1.0)
        self._running = True
        logger.info(f"IPFIX listening on {self._listen_ip}:{self._listen_port}")

        while self._running:
            try:
                data, addr = sock.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                break

            src = addr[0]
            if self._allowed and src not in self._allowed:
                self._stats['rejected'] += 1
                continue

            self._stats['packets'] += 1
            try:
                self._process(data, src)
            except Exception as e:
                logger.error(f"IPFIX packet error from {src}: {e}", exc_info=True)
                self._stats['errors'] += 1

        sock.close()

    def stop(self):
        self._running = False

    # ── Packet dispatch ───────────────────────────────────────────────────

    def _process(self, data: bytes, src: str):
        if len(data) < 4:
            return
        version = struct.unpack('!H', data[:2])[0]
        if version == 9:
            self._nfv9(data, src)
        elif version == 10:
            self._ipfix(data, src)
        else:
            self._stats['unknown_version'] += 1

    def _nfv9(self, data: bytes, src: str):
        if len(data) < _NFV9_HEADER:
            return
        _, count, uptime, unix_secs, seq, src_id = struct.unpack('!HHIIII', data[:_NFV9_HEADER])
        export_time = datetime.fromtimestamp(unix_secs, tz=timezone.utc)
        self._sets(data, _NFV9_HEADER, src, src_id, export_time, is_ipfix=False)

    def _ipfix(self, data: bytes, src: str):
        if len(data) < _IPFIX_HEADER:
            return
        _, length, export_ts, seq, domain_id = struct.unpack('!HHIII', data[:_IPFIX_HEADER])
        export_time = datetime.fromtimestamp(export_ts, tz=timezone.utc)
        self._sets(data, _IPFIX_HEADER, src, domain_id, export_time, is_ipfix=True)

    def _sets(self, data: bytes, offset: int, src: str, domain_id: int,
              export_time: datetime, is_ipfix: bool):
        while offset < len(data) - _SET_HEADER:
            if offset + _SET_HEADER > len(data):
                break
            set_id, set_len = struct.unpack('!HH', data[offset:offset + _SET_HEADER])
            if set_len < _SET_HEADER:
                break

            payload = data[offset + _SET_HEADER: offset + set_len]

            if set_id in (0, 2):           # template set
                self._parse_templates(payload, src, domain_id)
            elif set_id in (1, 3):         # options template — skip
                pass
            elif set_id >= 256:            # data set
                self._parse_data(payload, src, domain_id, set_id, export_time)

            offset += set_len

    # ── Template parsing ──────────────────────────────────────────────────

    def _parse_templates(self, data: bytes, src: str, domain_id: int):
        offset = 0
        while offset < len(data) - 4:
            tpl_id, field_count = struct.unpack('!HH', data[offset:offset + 4])
            offset += 4
            if tpl_id < 256:
                break
            fields = []
            for _ in range(field_count):
                if offset + 4 > len(data):
                    break
                fid, flen = struct.unpack('!HH', data[offset:offset + 4])
                offset += 4
                eid = None
                if fid & 0x8000:
                    fid &= 0x7FFF
                    if offset + 4 <= len(data):
                        eid = struct.unpack('!I', data[offset:offset + 4])[0]
                        offset += 4
                fields.append((fid, flen, eid))
            self._templates.add(src, domain_id, tpl_id, fields)

    # ── Data record parsing ───────────────────────────────────────────────

    def _parse_data(self, data: bytes, src: str, domain_id: int,
                    tpl_id: int, export_time: datetime):
        template = self._templates.get(src, domain_id, tpl_id)
        if not template:
            self._stats['missing_template'] += 1
            return

        rec_len = sum(f[1] for f in template if f[1] > 0)
        if rec_len == 0:
            return

        offset = 0
        while offset + rec_len <= len(data):
            flow = self._decode_record(data[offset:offset + rec_len], template)
            if flow:
                self._on_flow(flow, export_time, src)
                self._stats['flows'] += 1
            offset += rec_len

    def _decode_record(self, data: bytes, template: list) -> Optional[dict]:
        from sonicwall_templates import get_field_definition, SONICWALL_ENTERPRISE_ID

        flow = {}
        offset = 0
        for fid, flen, eid in template:
            if offset + flen > len(data):
                break
            raw = data[offset:offset + flen]
            offset += flen
            fd = get_field_definition(fid, eid)
            if fd:
                try:
                    val = fd.decoder(raw)
                    if val is not None:
                        flow[fd.name] = val
                except Exception as exc:
                    logger.debug("Field decode error fid=%d len=%d: %s", fid, flen, exc)

        return flow if flow else None
