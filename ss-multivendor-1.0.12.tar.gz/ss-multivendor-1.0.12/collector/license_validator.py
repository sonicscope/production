#!/usr/bin/env python3
"""
SonicScope Licence Validator
=============================
Shared validation module imported by all SonicScope collectors.

This module:
  - Reads licence metadata from .env (or passed config dict)
  - Reconstructs the expected hash and compares to the stored key
  - Checks expiry status and warns if within 30 days
  - Provides a simple API for collectors to call on startup and periodically

Usage in a collector:
    from license_validator import LicenceValidator

    validator = LicenceValidator(env_path="/opt/sonicscope/flow/.env")
    result = validator.validate()

    if not result.valid:
        print(f"Licence invalid: {result.message}")
        sys.exit(1)

Copyright (c) 2026 SonicScope — sonicscope.co.za
This file is distributed with SonicScope products under licence terms.
"""

import hashlib
import logging
import os
import re
import uuid
import sys
from dataclasses import dataclass
from datetime import datetime, date
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
VALID_PRODUCTS = {"SS-FLOW", "SS-SYSLOG", "SS-CSE", "SS-SUITE", "SS-MULTIVENDOR"}
EXPIRY_WARNING_DAYS = 30
LICENCE_CHECK_INTERVAL_HOURS = 6

# Products that use the V2 formula (includes MAX_SENSORS in hash)
V2_PRODUCTS = {"SS-MULTIVENDOR", "SS-SUITE"}


SALT_OVERRIDE: str | None = "$oN!cSc0pe-8xKm2pQrVwHjZa5nEbTyFd3LuCg9Wsi6@"  # Production build

# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------
@dataclass
class LicenceResult:
    """Result of a licence validation check."""
    valid: bool
    message: str
    product: str = ""
    customer_id: str = ""
    expiry_date: str = ""
    days_remaining: int = -1
    max_sensors: int = 0        # 0 = not applicable; 999 = unlimited
    warning: bool = False
    warning_message: str = ""


@dataclass
class LicenceConfig:
    """Licence configuration extracted from .env or config dict."""
    licence_key: str
    product: str
    customer_id: str
    expiry: str
    max_sensors: int = 0   # 0 = not applicable; 999 = unlimited


# ---------------------------------------------------------------------------
# Logger setup
# ---------------------------------------------------------------------------
def setup_licence_logger(log_dir: str = "/var/log/sonicscope",
                         log_file: str = "licence.log") -> logging.Logger:
    """
    Set up a dedicated licence logger that writes to a separate file.
    This keeps licence events out of the main data pipeline logs.
    """
    logger = logging.getLogger("sonicscope.licence")
    logger.setLevel(logging.DEBUG)

    # Avoid duplicate handlers if called multiple times
    if logger.handlers:
        return logger

    # Ensure log directory exists
    log_path = Path(log_dir)
    try:
        log_path.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        # Fall back to current directory if /var/log isn't writable
        log_path = Path(".")
        log_file = "sonicscope-licence.log"

    fh = logging.FileHandler(log_path / log_file)
    fh.setLevel(logging.DEBUG)

    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(logging.WARNING)

    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )
    fh.setFormatter(fmt)
    ch.setFormatter(fmt)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


# ---------------------------------------------------------------------------
# Environment / config loading
# ---------------------------------------------------------------------------
def load_env_file(env_path: str) -> dict:
    """
    Parse a .env file into a dictionary.
    Handles comments, empty lines, and quoted values.
    """
    env_vars = {}
    path = Path(env_path)

    if not path.is_file():
        raise FileNotFoundError(f".env file not found: {env_path}")

    with open(path, "r") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue

            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip()

            # Remove surrounding quotes
            if (value.startswith('"') and value.endswith('"')) or \
               (value.startswith("'") and value.endswith("'")):
                value = value[1:-1]

            env_vars[key] = value

    return env_vars


def extract_licence_config(env_vars: dict) -> LicenceConfig:
    """Extract and validate licence fields from environment variables."""
    required = {
        "SONICSCOPE_LICENSE": "licence key",
        "SONICSCOPE_PRODUCT": "product code",
        "SONICSCOPE_CUSTOMER_ID": "customer ID",
        "SONICSCOPE_EXPIRY": "expiry date",
    }

    missing = [f"{v} ({k})" for k, v in required.items() if k not in env_vars]
    if missing:
        raise ValueError(f"Missing licence fields in .env: {', '.join(missing)}")

    max_sensors = 0
    if "SONICSCOPE_MAX_SENSORS" in env_vars:
        try:
            max_sensors = int(env_vars["SONICSCOPE_MAX_SENSORS"].strip())
        except ValueError:
            pass

    return LicenceConfig(
        licence_key=env_vars["SONICSCOPE_LICENSE"].strip(),
        product=env_vars["SONICSCOPE_PRODUCT"].strip().upper(),
        customer_id=env_vars["SONICSCOPE_CUSTOMER_ID"].strip().upper(),
        expiry=env_vars["SONICSCOPE_EXPIRY"].strip(),
        max_sensors=max_sensors,
    )


# ---------------------------------------------------------------------------
# MAC address detection
# ---------------------------------------------------------------------------
def get_mac_address() -> str:
    """
    Get the primary MAC address of this machine.
    Returns uppercase colon-separated format (AA:BB:CC:DD:EE:FF).
    """
    # Method 1: Try reading from /sys/class/net (Linux)
    try:
        net_path = Path("/sys/class/net")
        if net_path.exists():
            for iface in sorted(net_path.iterdir()):
                name = iface.name
                # Skip loopback and virtual interfaces
                if name == "lo" or name.startswith(("veth", "docker", "br-",
                                                      "virbr", "vnet", "tun",
                                                      "tap", "wg")):
                    continue
                addr_file = iface / "address"
                if addr_file.exists():
                    mac = addr_file.read_text().strip().upper()
                    if mac and mac != "00:00:00:00:00:00":
                        return mac
    except Exception:
        pass

    # Method 2: Fall back to uuid.getnode()
    mac_int = uuid.getnode()
    mac = ":".join(f"{(mac_int >> (8 * i)) & 0xFF:02X}" for i in range(5, -1, -1))
    return mac


# ---------------------------------------------------------------------------
# Core validation
# ---------------------------------------------------------------------------
class LicenceValidator:
    """
    SonicScope licence validator.

    Usage:
        validator = LicenceValidator(env_path="/path/to/.env")
        result = validator.validate()
        if not result.valid:
            handle_invalid_licence(result)
    """

    def __init__(self, env_path: str = ".env", salt: Optional[str] = None,
                 log_dir: str = "/var/log/sonicscope"):
        """
        Initialise the validator.

        Args:
            env_path: Path to the .env file containing licence data.
            salt:     The secret salt. If None, reads from SONICSCOPE_SALT
                      environment variable (for validation during development
                      only — in production, the salt is embedded in the
                      validator at deployment time; see SALT_OVERRIDE below).
            log_dir:  Directory for licence log files.
        """
        self.env_path = env_path
        self.logger = setup_licence_logger(log_dir)

        # Resolution order:
        #   1. Module-level SALT_OVERRIDE (baked in by build-release.sh for production)
        #   2. salt parameter (passed directly — tests only)
        #   3. SONICSCOPE_SALT env var (development only — never set on customer machines)
        self._salt = SALT_OVERRIDE or salt or ""

    def _compute_expected_key(self, mac: str, config: LicenceConfig) -> str:
        """
        Compute the expected licence key from components.

        V1 formula (SS-FLOW, SS-SYSLOG, SS-CSE):
            SHA256(MAC + PRODUCT + CUSTOMER_ID + EXPIRY + SALT)

        V2 formula (SS-MULTIVENDOR, SS-SUITE):
            SHA256(MAC + PRODUCT + CUSTOMER_ID + EXPIRY + MAX_SENSORS + SALT)
        """
        mac = mac.upper()
        if config.product in V2_PRODUCTS:
            payload = (
                f"{mac}"
                f"{config.product}"
                f"{config.customer_id}"
                f"{config.expiry}"
                f"{config.max_sensors}"
                f"{self._salt}"
            )
        else:
            payload = (
                f"{mac}"
                f"{config.product}"
                f"{config.customer_id}"
                f"{config.expiry}"
                f"{self._salt}"
            )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def validate(self, mac_override: Optional[str] = None) -> LicenceResult:
        """
        Perform full licence validation.

        Args:
            mac_override: If set, use this MAC instead of auto-detecting.
                          Useful for testing or containers with virtual MACs.

        Returns:
            LicenceResult with validation status and details.
        """
        # Step 1: Load .env
        try:
            env_vars = load_env_file(self.env_path)
        except FileNotFoundError as e:
            msg = f"Configuration file not found: {self.env_path}"
            self.logger.error(msg)
            return LicenceResult(valid=False, message=msg)
        except Exception as e:
            msg = f"Error reading configuration: {e}"
            self.logger.error(msg)
            return LicenceResult(valid=False, message=msg)

        # Step 2: Extract licence config
        try:
            config = extract_licence_config(env_vars)
        except ValueError as e:
            msg = str(e)
            self.logger.error(f"Licence config error: {msg}")
            return LicenceResult(valid=False, message=msg)

        # Step 3: Validate product code
        if config.product not in VALID_PRODUCTS:
            msg = f"Unknown product code: {config.product}"
            self.logger.error(msg)
            return LicenceResult(valid=False, message=msg,
                                product=config.product)

        # Step 4: Check expiry date format and status
        try:
            expiry_date = datetime.strptime(config.expiry, "%Y-%m-%d").date()
        except ValueError:
            msg = f"Invalid expiry date format: {config.expiry}"
            self.logger.error(msg)
            return LicenceResult(valid=False, message=msg,
                                product=config.product,
                                customer_id=config.customer_id)

        days_remaining = (expiry_date - date.today()).days

        if days_remaining < 0:
            msg = (f"Licence expired on {config.expiry} "
                   f"({abs(days_remaining)} days ago)")
            self.logger.error(f"LICENCE EXPIRED: {msg} "
                             f"[customer={config.customer_id}, "
                             f"product={config.product}]")
            return LicenceResult(
                valid=False, message=msg,
                product=config.product,
                customer_id=config.customer_id,
                expiry_date=config.expiry,
                days_remaining=days_remaining,
            )

        # Step 5: Get MAC address
        mac = mac_override or get_mac_address()
        if not mac or mac == "00:00:00:00:00:00":
            msg = "Could not determine server MAC address"
            self.logger.error(msg)
            return LicenceResult(valid=False, message=msg)

        # Step 6: Compute expected key and compare
        if not self._salt:
            msg = ("Licence validation salt not configured. "
                   "Set SONICSCOPE_SALT environment variable or "
                   "configure salt in validator.")
            self.logger.error(msg)
            return LicenceResult(valid=False, message=msg)

        expected_key = self._compute_expected_key(mac, config)

        if config.licence_key.lower() != expected_key.lower():
            # Also try SS-SUITE as a fallback (bundle licence covers all products).
            # SS-SUITE uses the V2 formula so pass max_sensors through.
            suite_config = LicenceConfig(
                licence_key=config.licence_key,
                product="SS-SUITE",
                customer_id=config.customer_id,
                expiry=config.expiry,
                max_sensors=config.max_sensors,
            )
            suite_key = self._compute_expected_key(mac, suite_config)

            if config.licence_key.lower() != suite_key.lower():
                msg = ("Licence key mismatch — key does not match this "
                       "machine/product/customer combination")
                self.logger.error(
                    f"LICENCE INVALID: key mismatch "
                    f"[customer={config.customer_id}, "
                    f"product={config.product}, mac={mac}]"
                )
                return LicenceResult(
                    valid=False, message=msg,
                    product=config.product,
                    customer_id=config.customer_id,
                    expiry_date=config.expiry,
                    days_remaining=days_remaining,
                )

        # Step 7: Check expiry warning threshold
        warning = False
        warning_msg = ""
        if 0 <= days_remaining <= EXPIRY_WARNING_DAYS:
            warning = True
            warning_msg = (f"Licence expires in {days_remaining} day(s) "
                          f"on {config.expiry}. Please contact "
                          f"sales@sonicscope.co.za to renew.")
            self.logger.warning(
                f"LICENCE EXPIRY WARNING: {days_remaining} days remaining "
                f"[customer={config.customer_id}, product={config.product}]"
            )

        # All checks passed
        sensor_info = ""
        if config.max_sensors > 0:
            sensor_info = (f", max_sensors="
                           f"{'unlimited' if config.max_sensors == 999 else config.max_sensors}")
        self.logger.info(
            f"Licence valid [customer={config.customer_id}, "
            f"product={config.product}, expires={config.expiry}, "
            f"days_remaining={days_remaining}{sensor_info}]"
        )
        return LicenceResult(
            valid=True,
            message="Licence valid",
            product=config.product,
            customer_id=config.customer_id,
            expiry_date=config.expiry,
            days_remaining=days_remaining,
            max_sensors=config.max_sensors,
            warning=warning,
            warning_message=warning_msg,
        )


# ---------------------------------------------------------------------------
# Convenience functions for collector integration
# ---------------------------------------------------------------------------
def check_licence_or_exit(env_path: str = ".env",
                          salt: Optional[str] = None,
                          exit_code: int = 78) -> LicenceResult:
    """
    Validate the licence and exit the process if invalid.

    This is the recommended function to call at collector startup.
    Exit code 78 = EX_CONFIG (configuration error) per sysexits.h.

    Returns the LicenceResult if valid (for logging/display).
    """
    validator = LicenceValidator(env_path=env_path, salt=salt)
    result = validator.validate()

    if not result.valid:
        print(f"\n{'='*66}", file=sys.stderr)
        print(f"  SONICSCOPE LICENCE ERROR", file=sys.stderr)
        print(f"  {result.message}", file=sys.stderr)
        print(f"", file=sys.stderr)
        print(f"  Contact sales@sonicscope.co.za for licence assistance.", file=sys.stderr)
        print(f"{'='*66}\n", file=sys.stderr)
        sys.exit(exit_code)

    if result.warning:
        print(f"\n  ⚠ {result.warning_message}\n", file=sys.stderr)

    return result


def create_periodic_checker(env_path: str = ".env",
                            salt: Optional[str] = None,
                            interval_hours: float = LICENCE_CHECK_INTERVAL_HOURS):
    """
    Create a background thread that periodically validates the licence.

    Returns a (thread, stop_event) tuple. The thread sets the stop_event
    if the licence becomes invalid, which the collector should monitor
    to gracefully stop logging.

    Usage:
        checker_thread, licence_invalid_event = create_periodic_checker()
        checker_thread.start()

        # In your main loop:
        if licence_invalid_event.is_set():
            logger.error("Licence invalidated — stopping data collection")
            break
    """
    import threading

    stop_event = threading.Event()
    licence_invalid = threading.Event()

    def _check_loop():
        validator = LicenceValidator(env_path=env_path, salt=salt)
        interval_seconds = interval_hours * 3600

        while not stop_event.is_set():
            stop_event.wait(interval_seconds)
            if stop_event.is_set():
                break

            result = validator.validate()
            if not result.valid:
                validator.logger.error(
                    f"Periodic check FAILED: {result.message} — "
                    f"signalling collector to stop"
                )
                licence_invalid.set()
                break
            else:
                validator.logger.debug(
                    f"Periodic check OK: {result.days_remaining} days remaining"
                )

    thread = threading.Thread(target=_check_loop, name="sonicscope-licence-checker",
                              daemon=True)

    return thread, licence_invalid, stop_event


# ---------------------------------------------------------------------------
# Self-test (run directly to test validation)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="SonicScope Licence Validator — test mode")
    parser.add_argument("--env", default=".env", help="Path to .env file")
    parser.add_argument("--mac", default=None, help="Override MAC address (for testing)")
    parser.add_argument("--salt", default=None, help="Secret salt (or set SONICSCOPE_SALT)")
    args = parser.parse_args()

    salt = args.salt or os.environ.get("SONICSCOPE_SALT", "")
    if not salt:
        print("Warning: No salt provided. Set --salt or SONICSCOPE_SALT env var.",
              file=sys.stderr)

    validator = LicenceValidator(env_path=args.env, salt=salt)
    result = validator.validate(mac_override=args.mac)

    print(f"\nValidation Result:")
    print(f"  Valid:          {result.valid}")
    print(f"  Message:        {result.message}")
    print(f"  Product:        {result.product}")
    print(f"  Customer:       {result.customer_id}")
    print(f"  Expiry:         {result.expiry_date}")
    print(f"  Days remaining: {result.days_remaining}")
    if result.warning:
        print(f"  ⚠ Warning:     {result.warning_message}")
    print()

    sys.exit(0 if result.valid else 1)
