"""
NormalizedEvent — the central data structure for ss-multivendor.

Every parser (IPFIX, syslog) produces a NormalizedEvent.
Every enricher augments one in place.
The db_writer inserts one into fw_events.

Column names mirror the fw_events schema exactly so the DB insert
is a direct field-to-column mapping with no translation layer.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class NormalizedEvent:
    # ── Required ───────────────────────────────────────────────────────────
    time:           datetime
    tenant_id:      int
    sensor_id:      int
    vendor:         str         # 'sonicwall' | 'fortinet' | 'sophos'
    data_source:    str         # 'ipfix' | 'syslog'
    event_type:     str         # 'traffic' | 'denied' | 'threat' | 'vpn' | 'auth' | 'admin' | 'web' | 'system'

    # ── Network ────────────────────────────────────────────────────────────
    action:         Optional[str]   = None  # 'allow' | 'deny' | 'drop' | 'reset'
    src_ip:         Optional[str]   = None
    dst_ip:         Optional[str]   = None
    src_port:       Optional[int]   = None
    dst_port:       Optional[int]   = None
    protocol:       Optional[str]   = None  # 'tcp' | 'udp' | 'icmp' etc.
    protocol_num:   Optional[int]   = None  # IP protocol number

    # ── Traffic metrics ────────────────────────────────────────────────────
    bytes_sent:     int             = 0
    bytes_received: int             = 0
    packets_sent:   int             = 0
    packets_received: int           = 0
    duration_ms:    Optional[int]   = None

    # ── Identity (enriched at ingest) ──────────────────────────────────────
    user_name:      Optional[str]   = None
    device_name:    Optional[str]   = None
    department:     Optional[str]   = None
    group_name:     Optional[str]   = None

    # ── Zones & interfaces ─────────────────────────────────────────────────
    zone_src:       Optional[str]   = None
    zone_dst:       Optional[str]   = None
    interface_src:  Optional[str]   = None
    interface_dst:  Optional[str]   = None

    # ── Firewall rule ──────────────────────────────────────────────────────
    rule_name:      Optional[str]   = None
    rule_id:        Optional[int]   = None

    # ── Application ────────────────────────────────────────────────────────
    app_name:       Optional[str]   = None
    app_category:   Optional[str]   = None
    app_risk:       Optional[int]   = None  # 0–100

    # ── Web / URL ──────────────────────────────────────────────────────────
    domain:         Optional[str]   = None
    url:            Optional[str]   = None
    web_category:   Optional[str]   = None
    web_category_id: Optional[int]  = None

    # ── Threat ─────────────────────────────────────────────────────────────
    threat_name:    Optional[str]   = None
    threat_category: Optional[str] = None
    threat_severity: Optional[str] = None
    threat_id:      Optional[int]   = None

    # ── Geographic (enriched) ──────────────────────────────────────────────
    geo_src_country:      Optional[str] = None
    geo_src_country_code: Optional[str] = None
    geo_src_city:         Optional[str] = None
    geo_dst_country:      Optional[str] = None
    geo_dst_country_code: Optional[str] = None
    geo_dst_city:         Optional[str] = None

    # ── VPN ────────────────────────────────────────────────────────────────
    vpn_policy_name: Optional[str]  = None
    vpn_client_ip:   Optional[str]  = None

    # ── Message (syslog) ───────────────────────────────────────────────────
    message_id:     Optional[int]   = None
    message:        Optional[str]   = None
    raw_message:    Optional[str]   = None

    # ── Vendor-specific overflow ───────────────────────────────────────────
    extra:          Optional[dict]  = None
