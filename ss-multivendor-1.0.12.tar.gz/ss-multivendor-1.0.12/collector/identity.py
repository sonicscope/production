"""
Identity enricher — resolves src_ip to user_name / device_name / department / group_name
using identity_users + identity_devices tables, with fallback to legacy identity_mappings.

Lookup priority per event:
  1. Exact IP match in identity_devices → identity_users (most specific wins for CIDR)
  2. CIDR range match in identity_devices → identity_users
  3. Exact IP / CIDR match in legacy identity_mappings
  4. No match → fields left as-is

All lookups use an in-memory cache refreshed every 5 minutes.
"""

from __future__ import annotations
import ipaddress
import logging
import threading
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger('ss.identity')

_CACHE_TTL  = timedelta(minutes=5)
_CACHE_MAX  = 20_000


class IdentityEnricher:

    def __init__(self, db_pool):
        self._pool   = db_pool
        self._cache: dict[str, tuple] = {}   # "tenant_id:ip" → (result_dict | None, expiry)
        self._lock   = threading.Lock()
        # Sorted longest-prefix-first so first match wins
        self._entries: list[tuple] = []       # (network, tenant_id, result_dict)
        self._loaded_at: Optional[datetime] = None
        self._reload()

    # ── Public ────────────────────────────────────────────────────────────

    def enrich(self, event) -> None:
        """Augment event identity fields in place. No-op if already set by syslog."""
        if not event.src_ip:
            return
        if event.user_name and event.department and event.group_name:
            return  # syslog already provided complete identity

        identity = self._lookup(event.src_ip, event.tenant_id)
        if identity:
            if not event.user_name:
                event.user_name   = identity.get('user_name')
            if not event.device_name:
                event.device_name = identity.get('device_name')
            if not event.department:
                event.department  = identity.get('department')
            if not event.group_name:
                event.group_name  = identity.get('group_name')

    # ── Internal lookup ───────────────────────────────────────────────────

    def _lookup(self, ip: str, tenant_id: int) -> Optional[dict]:
        key = f'{tenant_id}:{ip}'
        with self._lock:
            if key in self._cache:
                result, expiry = self._cache[key]
                if datetime.now(timezone.utc) < expiry:
                    return result
                del self._cache[key]

        if (self._loaded_at is None or
                datetime.now(timezone.utc) - self._loaded_at > _CACHE_TTL):
            self._reload()

        result = self._match(ip, tenant_id)
        self._cache_put(key, result)
        return result

    def _match(self, ip: str, tenant_id: int) -> Optional[dict]:
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return None

        best: Optional[dict] = None
        best_prefix = -1

        with self._lock:
            entries = list(self._entries)

        for network, tid, identity in entries:
            if tid != tenant_id:
                continue
            if addr in network:
                prefix = network.prefixlen
                if prefix > best_prefix:
                    best_prefix = prefix
                    best = identity

        return best

    # ── Reload from DB ────────────────────────────────────────────────────

    def _reload(self):
        try:
            conn = self._pool.getconn()
            try:
                entries = []

                with conn.cursor() as cur:
                    # ── New tables: identity_devices → identity_users ──────
                    cur.execute("""
                        SELECT
                            d.tenant_id,
                            host(d.ip_address)          AS ip_text,
                            masklen(d.ip_address)       AS prefix,
                            d.hostname                  AS device_name,
                            d.label                     AS device_label,
                            u.full_name,
                            u.username,
                            u.department,
                            u.group_name
                        FROM identity_devices d
                        LEFT JOIN identity_users u
                               ON u.id = d.user_id
                              AND u.tenant_id = d.tenant_id
                              AND u.active = true
                        WHERE d.ip_address IS NOT NULL
                          AND (d.valid_to IS NULL OR d.valid_to > now())
                        ORDER BY masklen(d.ip_address) DESC
                    """)
                    for row in cur.fetchall():
                        (tid, ip_text, prefix, dev_name,
                         dev_label, full_name, username,
                         department, group_name) = row
                        try:
                            # ip_text from host() is bare IP; reconstruct with prefix
                            network = ipaddress.ip_network(
                                f'{ip_text}/{prefix}', strict=False
                            )
                            entries.append((network, tid, {
                                'user_name':   full_name or username,
                                'device_name': dev_label or dev_name,
                                'department':  department,
                                'group_name':  group_name,
                            }))
                        except ValueError:
                            continue

                    # ── Legacy fallback: identity_mappings ────────────────
                    try:
                        cur.execute("""
                            SELECT tenant_id, ip_range::text,
                                   user_name, device_name, department
                            FROM   identity_mappings
                            ORDER  BY masklen(ip_range) DESC
                        """)
                        for tenant_id, cidr, user_name, device_name, department in cur.fetchall():
                            try:
                                network = ipaddress.ip_network(cidr, strict=False)
                                entries.append((network, tenant_id, {
                                    'user_name':   user_name,
                                    'device_name': device_name,
                                    'department':  department,
                                    'group_name':  None,
                                }))
                            except ValueError:
                                continue
                    except Exception as legacy_exc:
                        logger.debug(f"Legacy identity_mappings fallback skipped: {legacy_exc}")

                # Sort longest prefix first so _match() finds most-specific first
                entries.sort(key=lambda x: x[0].prefixlen, reverse=True)

                with self._lock:
                    self._entries    = entries
                    self._loaded_at  = datetime.now(timezone.utc)
                    self._cache.clear()

                new_count = len([e for e in entries if e[2].get('group_name') is not None
                                 or e[2].get('user_name') is not None])
                logger.info(f"Identity: loaded {len(entries)} device mappings "
                            f"({new_count} with user assignment)")

            finally:
                self._pool.putconn(conn)
        except Exception as exc:
            logger.warning(f"Identity reload failed: {exc}")

    def _cache_put(self, key: str, value: Optional[dict]):
        with self._lock:
            if len(self._cache) >= _CACHE_MAX:
                oldest = sorted(self._cache.items(), key=lambda x: x[1][1])
                for k, _ in oldest[:_CACHE_MAX // 4]:
                    del self._cache[k]
            self._cache[key] = (value, datetime.now(timezone.utc) + _CACHE_TTL)
