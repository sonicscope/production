"""
TimescaleDB writer — batches NormalizedEvent objects and inserts them into
the fw_events hypertable using psycopg2's execute_values for bulk inserts.

Respects the SonicScope licence event: if licence_invalid_event is set,
new writes are refused and a clear error is logged.
"""

from __future__ import annotations
import logging
import threading
import time
from queue import Queue, Empty, Full
from typing import Optional

import psycopg2
import psycopg2.pool
from psycopg2.extras import execute_values

from event import NormalizedEvent

logger = logging.getLogger('ss.db_writer')

# INSERT that maps every NormalizedEvent field to its fw_events column
_INSERT_SQL = """
INSERT INTO fw_events (
    time, tenant_id, sensor_id, vendor, data_source, event_type,
    action,
    src_ip, dst_ip, src_port, dst_port, protocol, protocol_num,
    bytes_sent, bytes_received, packets_sent, packets_received, duration_ms,
    user_name, device_name, department, group_name,
    zone_src, zone_dst, interface_src, interface_dst,
    rule_name, rule_id,
    app_name, app_category, app_risk,
    domain, url, web_category, web_category_id,
    threat_name, threat_category, threat_severity, threat_id,
    geo_src_country, geo_src_country_code, geo_src_city,
    geo_dst_country, geo_dst_country_code, geo_dst_city,
    vpn_policy_name, vpn_client_ip,
    message_id, message, raw_message,
    extra
) VALUES %s
ON CONFLICT DO NOTHING
"""

# Tuple factory — order must match the INSERT column list above
def _to_row(e: NormalizedEvent) -> tuple:
    import json
    return (
        e.time, e.tenant_id, e.sensor_id, e.vendor, e.data_source, e.event_type,
        e.action,
        e.src_ip, e.dst_ip, e.src_port, e.dst_port, e.protocol, e.protocol_num,
        e.bytes_sent, e.bytes_received, e.packets_sent, e.packets_received, e.duration_ms,
        e.user_name, e.device_name, e.department, e.group_name,
        e.zone_src, e.zone_dst, e.interface_src, e.interface_dst,
        e.rule_name, e.rule_id,
        e.app_name, e.app_category, e.app_risk,
        e.domain, e.url, e.web_category, e.web_category_id,
        e.threat_name, e.threat_category, e.threat_severity, e.threat_id,
        e.geo_src_country, e.geo_src_country_code, e.geo_src_city,
        e.geo_dst_country, e.geo_dst_country_code, e.geo_dst_city,
        e.vpn_policy_name, e.vpn_client_ip,
        e.message_id, e.message, e.raw_message,
        json.dumps(e.extra) if e.extra else None,
    )


class DBWriter:

    def __init__(self, dsn: str, batch_size: int = 500,
                 batch_timeout: float = 2.0, queue_max: int = 50_000):
        self._dsn           = dsn
        self._batch_size    = batch_size
        self._batch_timeout = batch_timeout
        self._queue: Queue  = Queue(maxsize=queue_max)
        self._running       = False
        self._thread: Optional[threading.Thread] = None
        self._pool          = None

        # Set externally by main.py after licence check
        self.licence_invalid_event: Optional[threading.Event] = None
        self._licence_blocked = False

        self._stats = {'inserted': 0, 'dropped': 0, 'errors': 0}
        self._init_pool()

    def _init_pool(self):
        self._pool = psycopg2.pool.ThreadedConnectionPool(
            minconn=1, maxconn=5, dsn=self._dsn
        )
        logger.info("Database connection pool initialised")

    # ── Public ────────────────────────────────────────────────────────────

    def enqueue(self, event: NormalizedEvent) -> None:
        """Add an event to the write queue. Drops silently if queue is full."""
        if self.licence_invalid_event and self.licence_invalid_event.is_set():
            if not self._licence_blocked:
                logger.error(
                    "SonicScope licence invalid — database writes blocked. "
                    "Contact sales@sonicscope.co.za to renew."
                )
                self._licence_blocked = True
            return

        try:
            self._queue.put_nowait(event)
        except Full:
            self._stats['dropped'] += 1
            if self._stats['dropped'] % 1000 == 1:
                logger.warning(
                    f"Write queue full — dropped {self._stats['dropped']} events total"
                )

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._writer_loop,
                                        name='ss-db-writer', daemon=True)
        self._thread.start()
        logger.info(f"DB writer started (batch={self._batch_size}, timeout={self._batch_timeout}s)")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=15)
        logger.info(f"DB writer stopped — inserted={self._stats['inserted']} "
                    f"dropped={self._stats['dropped']} errors={self._stats['errors']}")

    def get_pool(self):
        return self._pool

    # ── Writer loop ───────────────────────────────────────────────────────

    def _writer_loop(self):
        batch = []
        last_flush = time.monotonic()

        while self._running:
            try:
                event = self._queue.get(timeout=0.1)
                batch.append(event)
            except Empty:
                pass

            elapsed = time.monotonic() - last_flush
            if len(batch) >= self._batch_size or (batch and elapsed >= self._batch_timeout):
                self._flush(batch)
                batch = []
                last_flush = time.monotonic()

        # Drain remaining
        while not self._queue.empty():
            try:
                batch.append(self._queue.get_nowait())
            except Empty:
                break
        if batch:
            self._flush(batch)

    def _flush(self, batch: list[NormalizedEvent]):
        if not batch:
            return

        rows = [_to_row(e) for e in batch]
        conn = None
        try:
            conn = self._pool.getconn()
            with conn.cursor() as cur:
                execute_values(cur, _INSERT_SQL, rows, page_size=500)
            conn.commit()
            self._stats['inserted'] += len(rows)
            if self._stats['inserted'] % 10000 < len(rows):
                logger.info(f"DB writer: {self._stats['inserted']:,} events inserted total")
            logger.debug(f"Inserted {len(rows)} events")
        except Exception as e:
            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass
            self._stats['errors'] += 1
            logger.error(f"DB insert failed ({len(rows)} rows): {e}")
        finally:
            if conn:
                self._pool.putconn(conn)
