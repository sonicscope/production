"""
Async reverse-DNS enrichment — fills event.domain from dst_ip when the
syslog parser couldn't extract a hostname (e.g. pure IPFIX flows).

Uses a thread-safe in-memory cache so the same IP is only resolved once
per TTL period. Non-blocking: resolution runs in a background thread pool
and results populate the cache for the *next* event with that IP.
"""

from __future__ import annotations
import logging
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger('ss.enrichment.dns')

_CACHE_TTL  = timedelta(minutes=30)
_CACHE_MAX  = 50_000
_WORKERS    = 4

_PRIVATE_PREFIXES = (
    '10.', '172.16.', '172.17.', '172.18.', '172.19.', '172.20.',
    '172.21.', '172.22.', '172.23.', '172.24.', '172.25.', '172.26.',
    '172.27.', '172.28.', '172.29.', '172.30.', '172.31.',
    '192.168.', '127.', '169.254.',
)


def _is_private(ip: str) -> bool:
    return any(ip.startswith(p) for p in _PRIVATE_PREFIXES)


class DNSResolver:

    def __init__(self, timeout: float = 1.0):
        self._timeout   = timeout
        self._cache: dict[str, tuple] = {}   # ip → (name_or_None, expiry)
        self._pending: set[str]        = set()
        self._lock      = threading.Lock()
        self._executor  = ThreadPoolExecutor(max_workers=_WORKERS,
                                             thread_name_prefix='ss-dns')

    def enrich(self, event) -> None:
        """
        If event.domain is already set (from syslog dstname), do nothing.
        Otherwise serve from cache if available, and schedule a background
        lookup so future events for the same IP get a name.
        """
        if event.domain or not event.dst_ip or _is_private(event.dst_ip):
            return

        cached = self._cache_get(event.dst_ip)
        if cached is not None:
            event.domain = cached or None
            return

        # Not in cache — schedule background lookup, return immediately
        self._schedule(event.dst_ip)

    def _cache_get(self, ip: str) -> Optional[str]:
        with self._lock:
            entry = self._cache.get(ip)
            if entry is None:
                return None
            name, expiry = entry
            if datetime.now(timezone.utc) < expiry:
                return name
            del self._cache[ip]
            return None

    def _cache_set(self, ip: str, name: Optional[str]):
        with self._lock:
            if len(self._cache) >= _CACHE_MAX:
                # Evict oldest 10%
                oldest = sorted(self._cache.items(), key=lambda x: x[1][1])
                for k, _ in oldest[:_CACHE_MAX // 10]:
                    del self._cache[k]
            self._cache[ip] = (name, datetime.now(timezone.utc) + _CACHE_TTL)
            self._pending.discard(ip)

    def _schedule(self, ip: str):
        with self._lock:
            if ip in self._pending:
                return
            self._pending.add(ip)
        self._executor.submit(self._resolve, ip)

    def _resolve(self, ip: str):
        try:
            socket.setdefaulttimeout(self._timeout)
            name = socket.gethostbyaddr(ip)[0]
            self._cache_set(ip, name)
        except Exception:
            self._cache_set(ip, None)
