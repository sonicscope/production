"""
Application classifier — maps dst_port + protocol to an app name,
category, and risk score (0–100) when IPFIX doesn't supply them directly.

Only runs if event.app_name is not already set (e.g. from SonicWall IPFIX
field 18 or syslog proto field).
"""

from __future__ import annotations
import logging
from typing import Optional

logger = logging.getLogger('ss.enrichment.app')

# ── Port/protocol → (app_name, category, risk_0_to_100) ─────────────────────
# Risk scale:  0–20 = benign infrastructure
#             21–40 = general browsing / low risk
#             41–60 = business/productivity
#             61–80 = elevated (file transfer, cloud sync, social)
#             81–100 = high risk (P2P, anonymisers, known malware ports)

_PORT_MAP: dict[tuple, tuple] = {
    # Protocol: web
    (80,   'tcp'): ('HTTP',          'Web',              30),
    (443,  'tcp'): ('HTTPS',         'Web',              20),
    (8080, 'tcp'): ('HTTP-Alt',      'Web',              35),
    (8443, 'tcp'): ('HTTPS-Alt',     'Web',              25),

    # Email
    (25,   'tcp'): ('SMTP',          'Email',            40),
    (587,  'tcp'): ('SMTP-TLS',      'Email',            30),
    (465,  'tcp'): ('SMTPS',         'Email',            30),
    (110,  'tcp'): ('POP3',          'Email',            40),
    (995,  'tcp'): ('POP3S',         'Email',            30),
    (143,  'tcp'): ('IMAP',          'Email',            40),
    (993,  'tcp'): ('IMAPS',         'Email',            30),

    # File transfer
    (21,   'tcp'): ('FTP',           'File Transfer',    65),
    (22,   'tcp'): ('SSH',           'Remote Access',    45),
    (69,   'udp'): ('TFTP',          'File Transfer',    70),

    # Remote access
    (3389, 'tcp'): ('RDP',           'Remote Access',    70),
    (23,   'tcp'): ('Telnet',        'Remote Access',    85),
    (5900, 'tcp'): ('VNC',           'Remote Access',    75),

    # DNS / infrastructure
    (53,   'udp'): ('DNS',           'Infrastructure',   10),
    (53,   'tcp'): ('DNS-TCP',       'Infrastructure',   15),
    (67,   'udp'): ('DHCP',          'Infrastructure',    5),
    (123,  'udp'): ('NTP',           'Infrastructure',    5),
    (161,  'udp'): ('SNMP',          'Network Management', 20),
    (162,  'udp'): ('SNMP-Trap',     'Network Management', 20),

    # VoIP
    (5060, 'udp'): ('SIP',           'VoIP',             40),
    (5061, 'tcp'): ('SIP-TLS',       'VoIP',             35),

    # Collaboration / streaming
    (1935, 'tcp'): ('RTMP',          'Streaming',        55),
    (554,  'tcp'): ('RTSP',          'Streaming',        55),

    # P2P / high risk
    (6881, 'tcp'): ('BitTorrent',    'P2P',              85),
    (6881, 'udp'): ('BitTorrent',    'P2P',              85),
    (6969, 'tcp'): ('BitTorrent',    'P2P',              85),
    (4662, 'tcp'): ('eMule',         'P2P',              85),

    # Database (should not be internet-bound)
    (3306, 'tcp'): ('MySQL',         'Database',         80),
    (5432, 'tcp'): ('PostgreSQL',    'Database',         80),
    (1433, 'tcp'): ('MSSQL',         'Database',         80),
    (1521, 'tcp'): ('Oracle',        'Database',         80),
    (27017,'tcp'): ('MongoDB',       'Database',         80),

    # VPN protocols
    (500,  'udp'): ('IKE',           'VPN',              30),
    (4500, 'udp'): ('IPSec-NAT-T',   'VPN',              30),
    (1194, 'udp'): ('OpenVPN',       'VPN',              40),
    (1723, 'tcp'): ('PPTP',          'VPN',              50),
    (1701, 'udp'): ('L2TP',          'VPN',              40),

    # Proxies / anonymisers
    (1080, 'tcp'): ('SOCKS',         'Proxy',            80),
    (3128, 'tcp'): ('HTTP-Proxy',    'Proxy',            70),
    (8888, 'tcp'): ('HTTP-Proxy-Alt','Proxy',            70),

    # QUIC
    (443,  'udp'): ('QUIC',          'Web',              20),
}


class AppClassifier:

    def enrich(self, event) -> None:
        """Fill event.app_name, app_category, app_risk if not already set."""
        if event.app_name or not event.dst_port:
            return

        proto = (event.protocol or '').lower()
        result = (
            _PORT_MAP.get((event.dst_port, proto)) or
            _PORT_MAP.get((event.dst_port, 'tcp'))  or   # proto fallback
            _PORT_MAP.get((event.dst_port, 'udp'))
        )

        if result:
            name, category, risk = result
            event.app_name    = name
            event.app_category = category
            event.app_risk    = risk
