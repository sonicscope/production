"""
Threat intelligence enrichment — checks src_ip and dst_ip against
local blocklists and the Emerging Threats / Feodo / Spamhaus feeds
(same sources as ss-flow).

Blocklists are downloaded and refreshed in the background every 6 hours.
A local override file (one IP/CIDR per line) is also supported.

If an IP matches, sets event.threat_name, threat_category, threat_severity
and overrides event.event_type to 'threat'.
"""

from __future__ import annotations
import ipaddress
import logging
import os
import threading
import time
from typing import Optional

import requests

logger = logging.getLogger('ss.enrichment.threat')

_FEEDS = [
    {
        'name':     'Emerging Threats',
        'url':      'https://rules.emergingthreats.net/blockrules/compromised-ips.txt',
        'category': 'Compromised Host',
        'severity': 'high',
    },
    {
        'name':     'Feodo Tracker',
        'url':      'https://feodotracker.abuse.ch/downloads/ipblocklist.txt',
        'category': 'Botnet C2',
        'severity': 'critical',
    },
    {
        'name':     'Spamhaus DROP',
        'url':      'https://www.spamhaus.org/drop/drop.txt',
        'category': 'Spamhaus DROP',
        'severity': 'high',
    },
]

_REFRESH_INTERVAL = 6 * 3600   # seconds


class ThreatIntelligence:

    def __init__(self, blocklist_path: Optional[str] = None):
        # Each entry: (network_or_address, feed_name, category, severity)
        self._entries: list[tuple] = []
        self._lock    = threading.Lock()
        self._local_path = blocklist_path

        self._load_all()

        # Background refresh thread
        t = threading.Thread(target=self._refresh_loop, daemon=True,
                             name='ss-threat-intel')
        t.start()

    def enrich(self, event) -> None:
        """Check src and dst IPs; mark event as threat if matched."""
        match = self._check(event.dst_ip) or self._check(event.src_ip)
        if not match:
            return

        _, feed_name, category, severity = match
        if not event.threat_name:
            event.threat_name     = f'{feed_name} Blocklist'
            event.threat_category = category
            event.threat_severity = severity
            event.event_type      = 'threat'

    # ── Internals ─────────────────────────────────────────────────────────

    def _check(self, ip: Optional[str]) -> Optional[tuple]:
        if not ip:
            return None
        try:
            addr = ipaddress.ip_address(ip)
        except ValueError:
            return None
        with self._lock:
            for net, feed, cat, sev in self._entries:
                if addr == net or (hasattr(net, 'network_address') and addr in net):
                    return (net, feed, cat, sev)
        return None

    def _load_all(self):
        entries = []
        if self._local_path and os.path.exists(self._local_path):
            entries.extend(self._load_file(self._local_path,
                                           'Local Blocklist', 'Custom', 'high'))
        for feed in _FEEDS:
            entries.extend(self._download_feed(feed))
        with self._lock:
            self._entries = entries
        logger.info(f"Threat intel loaded: {len(entries)} entries")

    def _download_feed(self, feed: dict) -> list:
        results = []
        try:
            r = requests.get(feed['url'], timeout=30)
            r.raise_for_status()
            for line in r.text.splitlines():
                line = line.strip()
                if not line or line.startswith('#') or line.startswith(';'):
                    continue
                # Some feeds have "IP ; comment" format
                line = line.split(';')[0].split('#')[0].strip()
                try:
                    if '/' in line:
                        results.append((ipaddress.ip_network(line, strict=False),
                                        feed['name'], feed['category'], feed['severity']))
                    else:
                        results.append((ipaddress.ip_address(line),
                                        feed['name'], feed['category'], feed['severity']))
                except ValueError:
                    continue
        except Exception as e:
            logger.warning(f"Failed to download threat feed '{feed['name']}': {e}")
        return results

    def _load_file(self, path: str, name: str, category: str, severity: str) -> list:
        results = []
        try:
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    try:
                        if '/' in line:
                            results.append((ipaddress.ip_network(line, strict=False),
                                            name, category, severity))
                        else:
                            results.append((ipaddress.ip_address(line),
                                            name, category, severity))
                    except ValueError:
                        continue
        except Exception as e:
            logger.warning(f"Failed to load local blocklist {path}: {e}")
        return results

    def _refresh_loop(self):
        while True:
            time.sleep(_REFRESH_INTERVAL)
            logger.info("Refreshing threat intelligence feeds...")
            self._load_all()
