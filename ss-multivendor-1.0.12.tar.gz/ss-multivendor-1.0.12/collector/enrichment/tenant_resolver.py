"""
TenantResolver — maps incoming flows to (tenant_id, sensor_id).

Resolution priority (first match wins):
  1. source_ip (firewall sending IPFIX/syslog) matched against sensors.ip_address
  2. internal src_ip matched against tenant_subnets
  3. Fall back to (default_tenant_id, default_sensor_id) from config

Both tables are cached in memory and refreshed every 5 minutes so changes
made in the web UI take effect without a collector restart.
"""
from __future__ import annotations

import ipaddress
import logging
import threading
import time
from typing import Optional

log = logging.getLogger('ss.enrichment.tenant_resolver')

_Subnet = ipaddress.IPv4Network | ipaddress.IPv6Network


class TenantResolver:

    def __init__(self, pool, default_tenant_id: int, default_sensor_id: int,
                 refresh_interval: int = 300):
        self._pool = pool
        self._default_tenant = default_tenant_id
        self._default_sensor = default_sensor_id
        self._refresh_interval = refresh_interval
        self._lock = threading.RLock()
        # source_ip string → (tenant_id, sensor_id)
        self._sensor_map: dict[str, tuple[int, int]] = {}
        # (network, tenant_id) sorted most-specific first
        self._subnets: list[tuple[_Subnet, int]] = []
        self._load()
        self._start_refresh_thread()

    # ── Public ────────────────────────────────────────────────────────────

    def resolve(self, ip_str: Optional[str] = None,
                source_ip: Optional[str] = None) -> tuple[int, int]:
        """Return (tenant_id, sensor_id) for a flow.

        Checks firewall source IP first (most reliable), then internal
        subnet match, then falls back to configured defaults.
        """
        with self._lock:
            # 1. Firewall source IP → registered sensor
            if source_ip and source_ip in self._sensor_map:
                return self._sensor_map[source_ip]

            # 2. Internal src_ip → configured subnet
            if ip_str:
                try:
                    ip = ipaddress.ip_address(ip_str)
                    for net, tenant_id in self._subnets:
                        if ip in net:
                            return (tenant_id, self._default_sensor)
                except ValueError:
                    pass

        return (self._default_tenant, self._default_sensor)

    # ── Internal ──────────────────────────────────────────────────────────

    def _load(self) -> None:
        try:
            conn = self._pool.getconn()
            try:
                with conn.cursor() as cur:
                    # Load registered sensors — host() strips the /32 prefix
                    # so lookups match bare IPs from incoming IPFIX/syslog packets
                    cur.execute(
                        "SELECT id, host(ip_address), tenant_id "
                        "FROM sensors "
                        "WHERE ip_address IS NOT NULL"
                    )
                    sensor_rows = cur.fetchall()

                    # Load tenant subnets (internal IP ranges)
                    cur.execute(
                        "SELECT subnet::text, tenant_id "
                        "FROM tenant_subnets "
                        "ORDER BY masklen(subnet) DESC"
                    )
                    subnet_rows = cur.fetchall()
            finally:
                self._pool.putconn(conn)

            sensor_map: dict[str, tuple[int, int]] = {}
            for sensor_id, ip_str, tenant_id in sensor_rows:
                if ip_str:
                    sensor_map[ip_str] = (tenant_id, sensor_id)

            subnets: list[tuple[_Subnet, int]] = []
            for subnet_str, tenant_id in subnet_rows:
                try:
                    subnets.append((ipaddress.ip_network(subnet_str, strict=False), tenant_id))
                except ValueError:
                    log.warning("Ignoring invalid subnet in DB: %s", subnet_str)

            with self._lock:
                self._sensor_map = sensor_map
                self._subnets = subnets

            log.info(
                "TenantResolver: %d registered firewall(s), %d subnet(s)",
                len(sensor_map), len(subnets)
            )

        except Exception as exc:
            log.warning("TenantResolver load failed (will retry): %s", exc)

    def _start_refresh_thread(self) -> None:
        def _loop():
            while True:
                time.sleep(self._refresh_interval)
                self._load()
        t = threading.Thread(target=_loop, daemon=True,
                             name='tenant-resolver-refresh')
        t.start()
