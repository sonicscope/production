"""
GeoIP enrichment — adds country/city to src_ip and dst_ip using
MaxMind GeoLite2 databases.

Database files expected at GEOIP_DB_DIR:
  GeoLite2-City.mmdb
  GeoLite2-Country.mmdb  (fallback if City not present)

Download script: scripts/download-geoip.sh (same as ss-flow)
"""

from __future__ import annotations
import logging
import os
from typing import Optional

logger = logging.getLogger('ss.enrichment.geoip')

_PRIVATE_PREFIXES = (
    '10.', '172.16.', '172.17.', '172.18.', '172.19.', '172.20.',
    '172.21.', '172.22.', '172.23.', '172.24.', '172.25.', '172.26.',
    '172.27.', '172.28.', '172.29.', '172.30.', '172.31.',
    '192.168.', '127.', '169.254.', '::1', 'fc', 'fd',
)


def _is_private(ip: Optional[str]) -> bool:
    if not ip:
        return True
    return any(ip.startswith(p) for p in _PRIVATE_PREFIXES)


class GeoIPEnricher:

    def __init__(self, db_dir: str):
        self.enabled = False
        self._city_reader = None
        self._country_reader = None
        self._load(db_dir)

    def _load(self, db_dir: str):
        try:
            import geoip2.database
        except ImportError:
            logger.warning("geoip2 package not installed — GeoIP disabled")
            return

        city_db    = os.path.join(db_dir, 'GeoLite2-City.mmdb')
        country_db = os.path.join(db_dir, 'GeoLite2-Country.mmdb')

        if os.path.exists(city_db):
            try:
                self._city_reader = geoip2.database.Reader(city_db)
                self.enabled = True
                logger.info(f"GeoIP City database loaded: {city_db}")
            except Exception as e:
                logger.warning(f"Failed to load GeoIP City DB: {e}")

        if os.path.exists(country_db) and not self._city_reader:
            try:
                self._country_reader = geoip2.database.Reader(country_db)
                self.enabled = True
                logger.info(f"GeoIP Country database loaded: {country_db}")
            except Exception as e:
                logger.warning(f"Failed to load GeoIP Country DB: {e}")

    def enrich(self, event) -> None:
        """Add geo fields to event in place."""
        if not self.enabled:
            return

        if event.src_ip and not _is_private(event.src_ip):
            geo = self._lookup(event.src_ip)
            if geo:
                event.geo_src_country      = geo.get('country')
                event.geo_src_country_code = geo.get('country_code')
                event.geo_src_city         = geo.get('city')

        if event.dst_ip and not _is_private(event.dst_ip):
            geo = self._lookup(event.dst_ip)
            if geo:
                event.geo_dst_country      = geo.get('country')
                event.geo_dst_country_code = geo.get('country_code')
                event.geo_dst_city         = geo.get('city')

    def _lookup(self, ip: str) -> Optional[dict]:
        reader = self._city_reader or self._country_reader
        if not reader:
            return None
        try:
            r = reader.city(ip) if self._city_reader else reader.country(ip)
            result = {
                'country':      r.country.name,
                'country_code': r.country.iso_code,
            }
            if self._city_reader and r.city.name:
                result['city'] = r.city.name
            return result
        except Exception:
            return None
