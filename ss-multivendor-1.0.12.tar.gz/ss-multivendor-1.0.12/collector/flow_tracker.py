"""
IPFIX Flow Delta Tracker

The SonicWall exports cumulative byte counts for active (ongoing) flows at
regular intervals (~60 s). Summing these records without delta correction
inflates bandwidth figures dramatically — a 2.7 GB session exporting every
minute for an hour accumulates to ~160 GB in the raw totals.

This module maintains a per-flow byte-state cache and converts cumulative
counters to per-export deltas before events reach the DB writer.
"""
from __future__ import annotations

import threading
import time
import logging

logger = logging.getLogger('ss.flow_tracker')

_EVICT_TTL = 600  # evict flows not seen for 10 minutes


class FlowDeltaTracker:
    """
    Convert cumulative IPFIX byte counters to per-export deltas.

    Thread-safe. Keyed by (firewall_ip, src_ip, dst_ip, src_port, dst_port).
    """

    def __init__(self, evict_ttl: int = _EVICT_TTL):
        self._data: dict[tuple, tuple[int, int, float]] = {}  # key → (sent, recv, monotonic_ts)
        self._lock = threading.Lock()
        self._ttl = evict_ttl
        self._evict_counter = 0

    def delta(
        self,
        firewall_ip: str,
        src_ip: str | None,
        dst_ip: str | None,
        src_port: int | None,
        dst_port: int | None,
        bytes_sent: int,
        bytes_recv: int,
    ) -> tuple[int, int]:
        """
        Return (delta_bytes_sent, delta_bytes_recv) for this flow export.

        First export for a flow: returns the full byte counts (no prior state).
        Subsequent exports: returns only bytes transferred since the last export.
        If counters decrease (flow restart / SonicWall counter reset): treats
        the new value as the delta for that export.
        """
        key = (firewall_ip, src_ip or '', dst_ip or '', src_port or 0, dst_port or 0)
        now = time.monotonic()

        with self._lock:
            self._maybe_evict(now)

            if key in self._data:
                last_sent, last_recv, _ = self._data[key]
                delta_sent = bytes_sent - last_sent if bytes_sent >= last_sent else bytes_sent
                delta_recv = bytes_recv - last_recv if bytes_recv >= last_recv else bytes_recv
            else:
                # First export — no prior state, use full value
                delta_sent = bytes_sent
                delta_recv = bytes_recv

            self._data[key] = (bytes_sent, bytes_recv, now)
            return delta_sent, delta_recv

    def _maybe_evict(self, now: float) -> None:
        self._evict_counter += 1
        if self._evict_counter < 1000:
            return
        self._evict_counter = 0
        stale = [k for k, v in self._data.items() if now - v[2] > self._ttl]
        for k in stale:
            del self._data[k]
        if stale:
            logger.debug("FlowDeltaTracker: evicted %d stale entries, %d remain",
                         len(stale), len(self._data))
