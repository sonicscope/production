"""
Fortinet FortiGate Parser — normalizes FortiGate 7.x syslog events
into NormalizedEvent objects for the unified fw_events table.

FortiGate syslog format: key=value pairs with optional RFC 3164 priority prefix.
Confirmed field behaviour from live FortiGate VM data (May 2026):
  - eventtime is nanoseconds since Unix epoch (not seconds or milliseconds)
  - proto is the IP protocol number (17=UDP, 6=TCP, 1=ICMP)
  - sentbyte/rcvdbyte are per-session totals (not cumulative like SonicWall IPFIX)
  - srcintfrole/dstintfrole carry the interface role (lan/wan/dmz/undefined)
"""

from __future__ import annotations
import re
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from event import NormalizedEvent

logger = logging.getLogger('ss.parser.fortinet')

_KV_RE = re.compile(r'(\w+)=(?:"((?:[^"\\]|\\.)*)"|(\S+))')


def _parse_kv(text: str) -> dict:
    result = {}
    for m in _KV_RE.finditer(text):
        result[m.group(1)] = m.group(2) if m.group(2) is not None else m.group(3)
    return result


def _safe_int(val, default: int = 0) -> int:
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


_PROTOCOL_NAMES = {
    1: 'icmp', 6: 'tcp', 17: 'udp', 47: 'gre',
    50: 'esp', 51: 'ah', 58: 'icmpv6', 89: 'ospf',
}

_ACTION_MAP = {
    'accept':      'allow',
    'close':       'allow',
    'ip-conn':     'allow',
    'passthrough': 'allow',
    'detected':    'allow',
    'timeout':     'allow',
    'deny':        'deny',
    'block':       'deny',
    'blocked':     'deny',
    'dropped':     'deny',
    'client-rst':  'reset',
    'server-rst':  'reset',
}

_SEVERITY_MAP = {
    'critical':  'critical',
    'alert':     'critical',
    'emergency': 'critical',
    'high':      'high',
    'error':     'high',
    'medium':    'medium',
    'warning':   'medium',
    'low':       'low',
    'notice':    'low',
    'info':      'low',
    'information': 'low',
}

# Matches generic protocol/port service names that carry no useful app info
_GENERIC_SERVICE_RE = re.compile(r'^(tcp|udp)/\d+$', re.IGNORECASE)


def _event_type(kv: dict) -> str:
    """Map FortiGate type/subtype/action to the NormalizedEvent event_type taxonomy."""
    log_type = kv.get('type', '').lower()
    subtype  = kv.get('subtype', '').lower()
    action   = kv.get('action', '').lower()

    if log_type == 'traffic':
        if action in ('deny', 'block', 'blocked', 'dropped'):
            return 'denied'
        return 'traffic'

    if log_type == 'utm':
        if subtype in ('ips', 'virus', 'anomaly', 'dlp'):
            return 'threat'
        if subtype == 'webfilter':
            return 'web'
        return 'threat'

    if log_type == 'event':
        if subtype in ('vpn', 'ipsec', 'sslvpn'):
            return 'vpn'
        if subtype in ('user', 'authentication'):
            return 'auth'
        return 'system'

    if log_type in ('app-ctrl', 'application'):
        return 'traffic'

    return 'traffic'


def _parse_timestamp(kv: dict) -> datetime:
    """
    Extract the event timestamp from FortiGate syslog fields.

    eventtime is nanoseconds since Unix epoch on FortiGate 7.x.
    Fall back to date= + time= string fields if eventtime is absent or invalid.
    """
    eventtime_raw = kv.get('eventtime')
    if eventtime_raw:
        try:
            ns = int(eventtime_raw)
            # FortiGate 7.x eventtime: ~1.78e18 for year 2026 in nanoseconds.
            # Threshold: anything > 1e15 is sub-second precision; divide accordingly.
            if ns > 1_000_000_000_000_000_000:    # nanoseconds
                seconds = ns // 1_000_000_000
                micros  = (ns % 1_000_000_000) // 1_000
            elif ns > 1_000_000_000_000_000:       # microseconds
                seconds = ns // 1_000_000
                micros  = ns % 1_000_000
            elif ns > 1_000_000_000_000:           # milliseconds
                seconds = ns // 1_000
                micros  = (ns % 1_000) * 1_000
            else:                                  # seconds
                seconds = ns
                micros  = 0
            return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(
                seconds=seconds, microseconds=micros
            )
        except (ValueError, OverflowError, OSError):
            pass

    date_str = kv.get('date', '')
    time_str = kv.get('time', '')
    if date_str and time_str:
        try:
            return datetime.strptime(
                f"{date_str} {time_str}", '%Y-%m-%d %H:%M:%S'
            ).replace(tzinfo=timezone.utc)
        except ValueError:
            pass

    return datetime.now(timezone.utc)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def is_fortinet_syslog(raw: str) -> bool:
    """FortiGate syslog always contains devname= and logid= fields."""
    return 'devname=' in raw and 'logid=' in raw


def normalize_syslog(raw_message: str, source_ip: str,
                     tenant_id: int, sensor_id: int) -> Optional[NormalizedEvent]:
    """
    Parse a raw FortiGate syslog message and return a NormalizedEvent.
    Returns None if the message cannot be parsed or is not a relevant log type.
    """
    msg = raw_message if isinstance(raw_message, str) else raw_message.decode('utf-8', errors='replace')
    msg = re.sub(r'^<\d{1,3}>', '', msg).strip()

    kv = _parse_kv(msg)
    if not kv.get('devname'):
        return None

    # Skip log types that carry no network event data
    log_type = kv.get('type', '').lower()
    if log_type not in ('traffic', 'utm', 'event', 'app-ctrl', 'application', 'ips', 'anomaly'):
        return None

    time       = _parse_timestamp(kv)
    event_type = _event_type(kv)

    # Network endpoints
    src_ip   = kv.get('srcip') or None
    dst_ip   = kv.get('dstip') or None
    src_port = _safe_int(kv.get('srcport')) or None
    dst_port = _safe_int(kv.get('dstport')) or None

    # Protocol
    proto_num = _safe_int(kv.get('proto')) or None
    protocol  = _PROTOCOL_NAMES.get(proto_num, f'proto_{proto_num}') if proto_num else None

    # Action
    raw_action = kv.get('action', '').lower()
    action     = _ACTION_MAP.get(raw_action, 'allow')

    # Interfaces — srcintfrole/dstintfrole carry lan/wan/dmz (skip "undefined")
    interface_src = kv.get('srcintf') or None
    interface_dst = kv.get('dstintf') or None
    role_src      = kv.get('srcintfrole', '')
    role_dst      = kv.get('dstintfrole', '')
    zone_src      = role_src if role_src not in ('undefined', '') else None
    zone_dst      = role_dst if role_dst not in ('undefined', '') else None

    # Policy / rule
    rule_id   = _safe_int(kv.get('policyid')) or None
    rule_name = kv.get('policyname') or None

    # Application — strip generic "tcp/80" / "udp/6667" service descriptors
    app_name     = kv.get('app') or None
    app_category = kv.get('appcat') or None
    if app_name in ('N/A', 'n/a', ''):
        app_name = None
    if app_name and _GENERIC_SERVICE_RE.match(app_name):
        app_name = None

    # Fall back to named service (e.g. "DNS", "HTTPS") if no app name resolved
    if not app_name:
        svc = kv.get('service', '')
        if svc and svc not in ('N/A', 'n/a') and not _GENERIC_SERVICE_RE.match(svc):
            app_name = svc

    # Web filter
    domain       = kv.get('hostname') or kv.get('dstname') or None
    url          = kv.get('url') or None
    web_category = kv.get('catdesc') or None

    # Threat / IPS / AV
    threat_name     = kv.get('attack') or kv.get('virus') or kv.get('attackname') or None
    threat_id       = _safe_int(kv.get('attackid')) or None
    threat_severity = _SEVERITY_MAP.get(kv.get('severity', '').lower()) or None
    threat_category = kv.get('cat') or kv.get('attackcontext') or None

    # VPN
    vpn_policy_name = kv.get('tunnelid') or kv.get('tunneltype') or None
    vpn_client_ip   = kv.get('tunnelip') or kv.get('remip') or None

    # User identity
    user_name = kv.get('user') or kv.get('unauthuser') or None
    if user_name in ('N/A', 'n/a', ''):
        user_name = None

    # Traffic metrics (per-session totals — no delta correction needed)
    bytes_sent       = _safe_int(kv.get('sentbyte'))
    bytes_received   = _safe_int(kv.get('rcvdbyte'))
    packets_sent     = _safe_int(kv.get('sentpkt'))
    packets_received = _safe_int(kv.get('rcvdpkt'))
    duration_s       = _safe_int(kv.get('duration'))
    duration_ms      = duration_s * 1000 if duration_s else None

    return NormalizedEvent(
        time             = time,
        tenant_id        = tenant_id,
        sensor_id        = sensor_id,
        vendor           = 'fortinet',
        data_source      = 'syslog',
        event_type       = event_type,
        action           = action,
        src_ip           = src_ip,
        dst_ip           = dst_ip,
        src_port         = src_port,
        dst_port         = dst_port,
        protocol         = protocol,
        protocol_num     = proto_num,
        bytes_sent       = bytes_sent,
        bytes_received   = bytes_received,
        packets_sent     = packets_sent,
        packets_received = packets_received,
        duration_ms      = duration_ms,
        user_name        = user_name,
        interface_src    = interface_src,
        interface_dst    = interface_dst,
        zone_src         = zone_src,
        zone_dst         = zone_dst,
        rule_id          = rule_id,
        rule_name        = rule_name,
        app_name         = app_name,
        app_category     = app_category,
        domain           = domain,
        url              = url,
        web_category     = web_category,
        threat_name      = threat_name,
        threat_category  = threat_category,
        threat_severity  = threat_severity,
        threat_id        = threat_id,
        vpn_policy_name  = vpn_policy_name,
        vpn_client_ip    = vpn_client_ip,
        message          = kv.get('msg') or None,
        raw_message      = raw_message[:2000] if len(raw_message) > 2000 else raw_message,
    )
