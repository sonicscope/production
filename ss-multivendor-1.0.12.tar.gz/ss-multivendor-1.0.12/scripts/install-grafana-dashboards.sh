#!/usr/bin/env bash
# =============================================================================
# SonicScope V2 — Grafana Dashboard Installer
# Installs TimescaleDB datasource + all 10 SonicScope dashboards into Grafana.
#
# Prerequisites:
#   - Grafana is installed (grafana-server running)
#   - ss-multivendor collector is installed (/etc/ss-multivendor/collector.env exists)
#   - PostgreSQL + TimescaleDB is running with the sonicscope database
#
# Usage:
#   sudo bash scripts/install-grafana-dashboards.sh
# =============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
GRAFANA_DIR="$REPO_DIR/grafana"
ENV_FILE="/etc/ss-multivendor/collector.env"

GRAFANA_PROVISIONING="/etc/grafana/provisioning"
GRAFANA_DASHBOARDS="/var/lib/grafana/dashboards/sonicscope"

# ── Colour output ──────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
die()  { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Root check ─────────────────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && die "Run as root: sudo bash $0"

# ── Grafana check ──────────────────────────────────────────────────────────────
if ! systemctl is-active --quiet grafana-server 2>/dev/null; then
    warn "grafana-server is not running. Attempting to install Grafana..."
    apt-get update -q
    apt-get install -y -q apt-transport-https software-properties-common wget
    wget -q -O - https://apt.grafana.com/gpg.key | gpg --dearmor | tee /etc/apt/keyrings/grafana.gpg > /dev/null
    echo "deb [signed-by=/etc/apt/keyrings/grafana.gpg] https://apt.grafana.com stable main" > /etc/apt/sources.list.d/grafana.list
    apt-get update -q
    apt-get install -y -q grafana
    systemctl enable grafana-server
    systemctl start grafana-server
    sleep 3
    ok "Grafana installed and started"
fi

ok "Grafana is running"

# ── Read DB credentials from collector.env ─────────────────────────────────────
[[ ! -f "$ENV_FILE" ]] && die "collector.env not found at $ENV_FILE — install the collector first"

_get_env() { grep -E "^${1}=" "$ENV_FILE" | head -1 | cut -d'=' -f2- | tr -d '"' | tr -d "'"; }

DB_HOST="$(_get_env DB_HOST)"; DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="$(_get_env DB_PORT)"; DB_PORT="${DB_PORT:-5432}"
DB_NAME="$(_get_env DB_NAME)"; DB_NAME="${DB_NAME:-sonicscope}"
DB_USER="$(_get_env DB_USER)"; DB_USER="${DB_USER:-sonicscope}"
DB_PASSWORD="$(_get_env DB_PASSWORD)"

[[ -z "$DB_PASSWORD" ]] && die "DB_PASSWORD is empty in $ENV_FILE"

ok "DB credentials loaded (host=$DB_HOST db=$DB_NAME user=$DB_USER)"

# ── Create directories ─────────────────────────────────────────────────────────
mkdir -p "$GRAFANA_DASHBOARDS"
mkdir -p "$GRAFANA_PROVISIONING/datasources"
mkdir -p "$GRAFANA_PROVISIONING/dashboards"

# ── Write datasource provisioning ─────────────────────────────────────────────
cat > "$GRAFANA_PROVISIONING/datasources/sonicscope-timescaledb.yml" <<EOF
apiVersion: 1

datasources:
  - name: SonicScope TimescaleDB
    type: grafana-postgresql-datasource
    uid: sonicscope-tsdb
    url: ${DB_HOST}:${DB_PORT}
    user: ${DB_USER}
    secureJsonData:
      password: "${DB_PASSWORD}"
    jsonData:
      database: ${DB_NAME}
      sslmode: disable
      maxOpenConns: 10
      maxIdleConns: 5
      connMaxLifetime: 14400
      postgresVersion: 1600
      timescaledb: true
    isDefault: true
    editable: false
EOF

ok "Datasource provisioning written"

# ── Write dashboard provisioning ───────────────────────────────────────────────
cat > "$GRAFANA_PROVISIONING/dashboards/sonicscope.yml" <<'EOF'
apiVersion: 1

providers:
  - name: SonicScope
    orgId: 1
    folder: SonicScope
    folderUid: sonicscope-folder
    type: file
    disableDeletion: false
    updateIntervalSeconds: 30
    allowUiUpdates: true
    options:
      path: /var/lib/grafana/dashboards/sonicscope
EOF

ok "Dashboard provisioning written"

# ── Build tenant list from DB and patch dashboards ────────────────────────────
TENANT_JSON=$(sudo -u postgres psql -d "$DB_NAME" -tAc \
    "SELECT json_agg(json_build_object('selected', id=(SELECT id FROM tenants ORDER BY id LIMIT 1), 'text', name, 'value', id::text) ORDER BY id) FROM tenants;" \
    2>/dev/null | tr -d '\n\r')

if [[ -z "$TENANT_JSON" || "$TENANT_JSON" == "null" ]]; then
    warn "No tenants found in DB — dashboards will use placeholder 'Site 1 : 1'"
    TENANT_JSON='[{"selected":true,"text":"Site 1","value":"1"}]'
fi

FIRST_TEXT=$(echo "$TENANT_JSON" | python3 -c "import json,sys; t=json.load(sys.stdin); print(t[0]['text'])" 2>/dev/null || echo "Site 1")
FIRST_VAL=$(echo  "$TENANT_JSON" | python3 -c "import json,sys; t=json.load(sys.stdin); print(t[0]['value'])" 2>/dev/null || echo "1")

ok "Tenants loaded from DB — default: ${FIRST_TEXT} (id=${FIRST_VAL})"

# Patch each dashboard JSON with the live tenant list
DASHBOARD_COUNT=0
for f in "$GRAFANA_DIR/dashboards/"*.json; do
    [[ -f "$f" ]] || continue
    DEST="$GRAFANA_DASHBOARDS/$(basename "$f")"
    python3 - "$f" "$DEST" "$TENANT_JSON" "$FIRST_TEXT" "$FIRST_VAL" << 'PYEOF'
import json, sys
src, dst, tenant_json_str, first_text, first_val = sys.argv[1:]
tenants = json.loads(tenant_json_str)
with open(src) as fh:
    d = json.load(fh)
for v in d.get('templating', {}).get('list', []):
    if v.get('name') == 'tenant_id':
        v['options'] = tenants
        v['current'] = {'selected': True, 'text': first_text, 'value': first_val}
        v['query'] = ', '.join(f"{t['text']} : {t['value']}" for t in tenants)
with open(dst, 'w') as fh:
    json.dump(d, fh, indent=2)
PYEOF
    DASHBOARD_COUNT=$((DASHBOARD_COUNT + 1))
done

chown -R grafana:grafana "$GRAFANA_DASHBOARDS" 2>/dev/null || true
chmod 664 "$GRAFANA_DASHBOARDS"/*.json 2>/dev/null || true
chmod 775 "$GRAFANA_DASHBOARDS"
# Allow ss-reports (ss-collector user) to update dashboard JSONs when tenants change
usermod -aG grafana ss-collector 2>/dev/null || true

ok "Patched and copied $DASHBOARD_COUNT dashboard JSON files to $GRAFANA_DASHBOARDS"

# ── Fix permissions on provisioning files ─────────────────────────────────────
chown root:grafana "$GRAFANA_PROVISIONING/datasources/sonicscope-timescaledb.yml"
chmod 640 "$GRAFANA_PROVISIONING/datasources/sonicscope-timescaledb.yml"
chown root:grafana "$GRAFANA_PROVISIONING/dashboards/sonicscope.yml"
chmod 644 "$GRAFANA_PROVISIONING/dashboards/sonicscope.yml"

# ── Set Grafana admin password ────────────────────────────────────────────────
# Generate a strong random password on first install; preserve it on re-runs.
GF_PASS_FILE="/etc/ss-multivendor/grafana-admin-password"
if [[ -f "$GF_PASS_FILE" ]]; then
    GF_ADMIN_PASS=$(cat "$GF_PASS_FILE")
    ok "Grafana admin password already set (stored in $GF_PASS_FILE)"
else
    GF_ADMIN_PASS=$(openssl rand -base64 16 | tr -d '/+=')
    grafana-cli --config /etc/grafana/grafana.ini admin reset-admin-password "$GF_ADMIN_PASS" \
        >/dev/null 2>&1 && \
        echo "$GF_ADMIN_PASS" > "$GF_PASS_FILE" && \
        chmod 600 "$GF_PASS_FILE" && \
        chown root:root "$GF_PASS_FILE" && \
        ok "Grafana admin password set and saved to $GF_PASS_FILE" || \
        warn "Could not set Grafana password — change it manually from the UI"
fi

# ── Restart Grafana ────────────────────────────────────────────────────────────
systemctl restart grafana-server
sleep 3

if systemctl is-active --quiet grafana-server; then
    ok "Grafana restarted successfully"
else
    die "Grafana failed to restart — check: journalctl -u grafana-server"
fi

# ── Done ───────────────────────────────────────────────────────────────────────
GRAFANA_PORT=$(grep -E "^http_port" /etc/grafana/grafana.ini 2>/dev/null | awk '{print $3}' || echo "3000")

echo ""
echo "============================================================"
echo " SonicScope Grafana Dashboards Installed"
echo "============================================================"
echo ""
echo " Open Grafana:   http://$(hostname -I | awk '{print $1}'):${GRAFANA_PORT}"
echo " Login:          admin / $(cat $GF_PASS_FILE 2>/dev/null || echo 'see /etc/ss-multivendor/grafana-admin-password')"
echo ""
echo " Dashboards are in the 'SonicScope' folder."
echo " 10 dashboards installed:"
echo "   - Overview"
echo "   - Network Traffic"
echo "   - Users & Top Talkers"
echo "   - Applications"
echo "   - Top Sites & URLs"
echo "   - Firewall Rules"
echo "   - Security Overview"
echo "   - Threat Intelligence"
echo "   - GeoIP & World Map"
echo "   - Flow Explorer"
echo ""
echo " Datasource: SonicScope TimescaleDB (auto-configured)"
echo ""
echo " If panels show 'No data', verify the time range includes"
echo " when the collector was running and data was flowing."
echo "============================================================"
