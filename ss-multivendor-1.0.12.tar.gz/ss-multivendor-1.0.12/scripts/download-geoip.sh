#!/bin/bash
# Download MaxMind GeoLite2 databases for ss-multivendor GeoIP enrichment
#
# Requires a free MaxMind account and licence key.
# Sign up at: https://www.maxmind.com/en/geolite2/signup
#
# Usage:
#   bash download-geoip.sh <MaxMind_Licence_Key>
#
# After signing up:
#   1. Log in to maxmind.com
#   2. Go to Account → Manage Licence Keys
#   3. Generate a new licence key
#   4. Run: sudo bash download-geoip.sh YOUR_KEY_HERE

set -e

LICENCE_KEY="${1:-}"
DB_DIR="/opt/ss-multivendor/geoip"
SERVICE_USER="ss-collector"

RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'

if [ -z "$LICENCE_KEY" ]; then
    echo ""
    echo "Usage: sudo bash $0 <MaxMind_Licence_Key>"
    echo ""
    echo "Get a free licence key at: https://www.maxmind.com/en/geolite2/signup"
    echo ""
    echo "After signing up:"
    echo "  1. Go to Account → Manage Licence Keys"
    echo "  2. Generate a new licence key"
    echo "  3. Re-run this script with your key"
    echo ""
    exit 1
fi

[ "$(id -u)" -ne 0 ] && echo -e "${RED}Run as root: sudo bash $0 $LICENCE_KEY${NC}" && exit 1

mkdir -p "$DB_DIR"

download_db() {
    local edition="$1"
    local filename="$2"

    echo "  Downloading ${edition}..."

    curl -fsSL -o "/tmp/${edition}.tar.gz" \
        "https://download.maxmind.com/app/geoip_download?edition_id=${edition}&license_key=${LICENCE_KEY}&suffix=tar.gz"

    if [ ! -s "/tmp/${edition}.tar.gz" ]; then
        echo -e "  ${RED}Failed to download ${edition} — check your licence key${NC}"
        rm -f "/tmp/${edition}.tar.gz"
        return 1
    fi

    # Extract and move the .mmdb file
    tar -xzf "/tmp/${edition}.tar.gz" -C /tmp
    find /tmp -name "*.mmdb" -path "*${edition}*" -exec mv {} "$DB_DIR/$filename" \;

    # Cleanup
    rm -f "/tmp/${edition}.tar.gz"
    find /tmp -maxdepth 1 -name "${edition}_*" -type d -exec rm -rf {} + 2>/dev/null || true

    echo -e "  ${GREEN}✓ ${filename} installed${NC}"
}

echo ""
echo "Downloading GeoIP databases to ${DB_DIR}..."
echo ""

download_db "GeoLite2-City" "GeoLite2-City.mmdb"
download_db "GeoLite2-ASN"  "GeoLite2-ASN.mmdb"

# Fix ownership so the service user can read the files
chown -R ${SERVICE_USER}:${SERVICE_USER} "$DB_DIR" 2>/dev/null || \
    chown -R root:root "$DB_DIR"
chmod 755 "$DB_DIR"
chmod 644 "$DB_DIR"/*.mmdb 2>/dev/null || true

echo ""
echo -e "${GREEN}GeoIP databases ready:${NC}"
ls -lh "$DB_DIR"/*.mmdb 2>/dev/null

echo ""
echo "Restart the collector to enable GeoIP enrichment:"
echo "  sudo systemctl restart ss-collector"
echo ""
