#!/bin/bash
# =============================================================================
# SonicScope ss-multivendor — Uninstaller
# =============================================================================
# Removes ALL ss-multivendor components and leaves the machine clean.
# Safe to run before a fresh reinstall.
#
# What this removes:
#   - systemd services: ss-collector, ss-reports
#   - installed files:  /opt/ss-multivendor/
#   - configuration:   /etc/ss-multivendor/  (includes collector.env and TLS certs)
#   - data / reports:  /var/lib/ss-multivendor/
#   - logs:            /var/log/ss-multivendor/
#   - PostgreSQL:      database 'sonicscope' and user 'sonicscope'
#   - system user:     ss-collector
#   - WeasyPrint system packages (libpango, libcairo, libgdk-pixbuf, fonts-liberation)
#
# What this does NOT remove:
#   - PostgreSQL itself (may be shared with other services)
#   - Grafana itself (may be shared with other services)
#   - Python3, pip, venv tooling
#   - poppler-utils, tcpdump, or any other general utilities
#   - Any V1 products (ss-flow, ss-syslog, ss-cse)
#   - Source code in /home/devadmin/ss-multivendor/ (this repo)
#
# Usage:
#   sudo bash scripts/uninstall.sh          # interactive (prompts for confirmation)
#   sudo bash scripts/uninstall.sh --yes    # skip confirmation prompt
#
# =============================================================================

set -euo pipefail

RED='\033[0;31m'; YELLOW='\033[1;33m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
section() { echo; echo -e "${CYAN}── $* ──${NC}"; }

# ── Root check ────────────────────────────────────────────────────────────────
[ "$(id -u)" -ne 0 ] && { echo -e "${RED}[ERROR]${NC} Must be run as root: sudo bash $0"; exit 1; }

# ── Confirmation ──────────────────────────────────────────────────────────────
echo
echo -e "${RED}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${RED}║        SonicScope ss-multivendor — UNINSTALLER               ║${NC}"
echo -e "${RED}╚══════════════════════════════════════════════════════════════╝${NC}"
echo
echo "This will permanently delete:"
echo "  • Systemd services: ss-collector, ss-reports"
echo "  • /opt/ss-multivendor/      (installed application)"
echo "  • /etc/ss-multivendor/      (config, TLS certs, collector.env)"
echo "  • /var/lib/ss-multivendor/  (generated PDFs, logos)"
echo "  • /var/log/ss-multivendor/  (log files)"
echo "  • PostgreSQL database 'sonicscope' and all its data"
echo "  • PostgreSQL user 'sonicscope'"
echo "  • System user 'ss-collector'"
echo "  • WeasyPrint system library packages"
echo
echo -e "${YELLOW}Source code in ~/ss-multivendor/ is NOT touched.${NC}"
echo -e "${YELLOW}PostgreSQL itself is NOT removed.${NC}"
echo

if [[ "${1:-}" != "--yes" ]]; then
    read -r -p "Type UNINSTALL to confirm: " confirm
    if [[ "$confirm" != "UNINSTALL" ]]; then
        echo "Aborted."
        exit 0
    fi
fi

# ── Stop and disable services ─────────────────────────────────────────────────
section "Stopping services"

for svc in ss-collector ss-reports; do
    if systemctl is-active --quiet "$svc" 2>/dev/null; then
        systemctl stop "$svc" && info "Stopped $svc" || warn "Could not stop $svc"
    else
        info "$svc is not running"
    fi
    if systemctl is-enabled --quiet "$svc" 2>/dev/null; then
        systemctl disable "$svc" && info "Disabled $svc" || warn "Could not disable $svc"
    fi
done

# ── Remove systemd unit files ─────────────────────────────────────────────────
section "Removing systemd unit files"

for unit in /etc/systemd/system/ss-collector.service \
            /etc/systemd/system/ss-reports.service; do
    if [ -f "$unit" ]; then
        rm -f "$unit" && info "Removed $unit"
    fi
done

systemctl daemon-reload
info "systemd daemon reloaded"

# ── Remove installed directories ──────────────────────────────────────────────
section "Removing installed files"

for dir in /opt/ss-multivendor \
           /etc/ss-multivendor \
           /var/lib/ss-multivendor \
           /var/log/ss-multivendor; do
    if [ -d "$dir" ]; then
        rm -rf "$dir" && info "Removed $dir"
    else
        info "$dir not found — skipping"
    fi
done

# ── Drop PostgreSQL database and user ─────────────────────────────────────────
section "Removing PostgreSQL database and user"

if sudo -u postgres psql -lqt 2>/dev/null | cut -d \| -f 1 | grep -qw sonicscope; then
    sudo -u postgres psql -c "DROP DATABASE sonicscope;" 2>/dev/null \
        && info "Dropped database 'sonicscope'" \
        || warn "Could not drop database 'sonicscope' — may have active connections"
else
    info "Database 'sonicscope' not found — skipping"
fi

if sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='sonicscope';" 2>/dev/null | grep -q 1; then
    sudo -u postgres psql -c "DROP USER sonicscope;" 2>/dev/null \
        && info "Dropped user 'sonicscope'" \
        || warn "Could not drop user 'sonicscope'"
else
    info "PostgreSQL user 'sonicscope' not found — skipping"
fi

# ── Remove system user ────────────────────────────────────────────────────────
section "Removing system user"

if id ss-collector &>/dev/null; then
    userdel --remove ss-collector 2>/dev/null || userdel ss-collector 2>/dev/null \
        && info "Removed system user 'ss-collector'" \
        || warn "Could not remove user 'ss-collector' — may need manual removal"
else
    info "System user 'ss-collector' not found — skipping"
fi

# ── Remove WeasyPrint system packages ─────────────────────────────────────────
section "Removing WeasyPrint system packages"

WEASYPRINT_PKGS=(
    libpango-1.0-0
    libpangoft2-1.0-0
    libpangocairo-1.0-0
    libcairo2
    libgdk-pixbuf-2.0-0
    libgdk-pixbuf-xlib-2.0-0
    libgdk-pixbuf2.0-0
    libgdk-pixbuf2.0-bin
    libgdk-pixbuf2.0-common
    libgraphite2-3
    libharfbuzz0b
    fonts-liberation
    fonts-liberation-sans-narrow
    libffi-dev
    shared-mime-info
)

# Only remove packages that are actually installed
TO_REMOVE=()
for pkg in "${WEASYPRINT_PKGS[@]}"; do
    if dpkg -l "$pkg" &>/dev/null 2>&1 | grep -q "^ii"; then
        TO_REMOVE+=("$pkg")
    fi
done

if [ ${#TO_REMOVE[@]} -gt 0 ]; then
    apt-get remove -y --auto-remove "${TO_REMOVE[@]}" -qq \
        && info "Removed ${#TO_REMOVE[@]} WeasyPrint packages" \
        || warn "Some packages could not be removed — check manually"
else
    info "No WeasyPrint packages found — skipping"
fi

# ── Remove Grafana provisioning for SonicScope ────────────────────────────────
section "Removing Grafana SonicScope provisioning"

GRAFANA_DATASOURCE="/etc/grafana/provisioning/datasources/sonicscope-timescaledb.yml"
GRAFANA_DASHBOARD_PROV="/etc/grafana/provisioning/dashboards/sonicscope.yml"
GRAFANA_DASHBOARDS="/var/lib/grafana/dashboards/sonicscope"

for path in "$GRAFANA_DATASOURCE" "$GRAFANA_DASHBOARD_PROV"; do
    if [ -f "$path" ]; then
        rm -f "$path" && info "Removed $path"
    else
        info "$path not found — skipping"
    fi
done

if [ -d "$GRAFANA_DASHBOARDS" ]; then
    rm -rf "$GRAFANA_DASHBOARDS" && info "Removed $GRAFANA_DASHBOARDS"
else
    info "$GRAFANA_DASHBOARDS not found — skipping"
fi

if systemctl is-active --quiet grafana-server 2>/dev/null; then
    systemctl restart grafana-server && info "Grafana restarted (SonicScope dashboards removed)"
fi

# ── Final check ───────────────────────────────────────────────────────────────
section "Verification"

CLEAN=true

for path in /opt/ss-multivendor /etc/ss-multivendor \
            /var/lib/ss-multivendor /var/log/ss-multivendor \
            /etc/systemd/system/ss-collector.service \
            /etc/systemd/system/ss-reports.service; do
    if [ -e "$path" ]; then
        warn "Still present: $path"
        CLEAN=false
    fi
done

for svc in ss-collector ss-reports; do
    if systemctl list-unit-files "$svc.service" 2>/dev/null | grep -q "$svc"; then
        warn "Service still registered: $svc"
        CLEAN=false
    fi
done

if id ss-collector &>/dev/null; then
    warn "System user 'ss-collector' still exists"
    CLEAN=false
fi

echo
if $CLEAN; then
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  Uninstall complete — machine is clean for a fresh install.  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════╝${NC}"
else
    echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║  Uninstall complete with warnings — check items above.       ║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════╝${NC}"
fi

echo
echo "To reinstall:"
echo "  1. sudo bash scripts/install.sh"
echo "  2. sudo bash scripts/download-geoip.sh <MaxMind_key>"
echo "  3. sudo systemctl start ss-collector"
echo "  4. sudo bash scripts/install-grafana-dashboards.sh"
echo "  5. sudo bash scripts/install-reports.sh"
echo "     Then configure SMTP in /etc/ss-multivendor/collector.env"
echo
