-- =============================================================================
-- SonicScope Multi-Vendor Collector — Continuous Aggregates
-- Run AFTER schema.sql
--
-- Architecture:
--   Raw data (fw_events)
--     └─ Hourly aggregates   — power: real-time dashboard, last 7 days detail
--         └─ Daily rollups   — power: weekly/monthly reports (fast, tiny)
--
-- Reports NEVER scan fw_events for summary data. They query the daily rollup.
-- Only the HR investigation "full timeline" section queries fw_events directly,
-- and only with a tight (user + date range) filter.
-- =============================================================================


-- =============================================================================
-- USER TRAFFIC  —  who used how much bandwidth
-- =============================================================================

-- Hourly: bytes and connections per user per hour
CREATE MATERIALIZED VIEW hourly_user_traffic
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    src_ip,
    user_name,
    device_name,
    department,
    zone_src,
    SUM(bytes_sent)                 AS bytes_sent,
    SUM(bytes_received)             AS bytes_received,
    SUM(bytes_sent + bytes_received) AS bytes_total,
    COUNT(*)                        AS connection_count,
    SUM(CASE WHEN action = 'allow'                THEN 1 ELSE 0 END) AS allowed_count,
    SUM(CASE WHEN action IN ('deny','drop','reset') THEN 1 ELSE 0 END) AS denied_count,
    SUM(COALESCE(duration_ms, 0))   AS total_duration_ms
FROM fw_events
WHERE event_type IN ('traffic', 'web', 'denied')
GROUP BY bucket, tenant_id, sensor_id, vendor, src_ip, user_name, device_name, department, zone_src
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_user_traffic',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


-- Daily rollup from hourly (cagg-on-cagg — requires TimescaleDB 2.9+)
-- This is what weekly and monthly reports query. 1 row per user per day
-- instead of 24. A 30-day monthly report = 30 rows per user = milliseconds.
CREATE MATERIALIZED VIEW daily_user_traffic
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', bucket)    AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    src_ip,
    user_name,
    device_name,
    department,
    zone_src,
    SUM(bytes_sent)                 AS bytes_sent,
    SUM(bytes_received)             AS bytes_received,
    SUM(bytes_total)                AS bytes_total,
    SUM(connection_count)           AS connection_count,
    SUM(allowed_count)              AS allowed_count,
    SUM(denied_count)               AS denied_count,
    SUM(total_duration_ms)          AS total_duration_ms
FROM hourly_user_traffic
GROUP BY time_bucket('1 day', bucket), tenant_id, sensor_id, vendor,
         src_ip, user_name, device_name, department, zone_src
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_user_traffic',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- APPLICATION STATS  —  which apps used how much bandwidth
-- =============================================================================

CREATE MATERIALIZED VIEW hourly_app_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    app_name,
    app_category,
    app_risk,
    SUM(bytes_sent + bytes_received) AS bytes_total,
    COUNT(*)                        AS session_count
FROM fw_events
WHERE event_type IN ('traffic', 'web')
  AND app_name IS NOT NULL
GROUP BY bucket, tenant_id, sensor_id, vendor, app_name, app_category, app_risk
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_app_stats',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


CREATE MATERIALIZED VIEW daily_app_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', bucket)    AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    app_name,
    app_category,
    app_risk,
    SUM(bytes_total)                AS bytes_total,
    SUM(session_count)              AS session_count
FROM hourly_app_stats
GROUP BY time_bucket('1 day', bucket), tenant_id, sensor_id, vendor,
         app_name, app_category, app_risk
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_app_stats',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- WEB CATEGORY STATS  —  what categories were browsed/blocked
-- =============================================================================

CREATE MATERIALIZED VIEW hourly_web_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    web_category,
    action,
    COUNT(*)                        AS request_count,
    SUM(bytes_sent + bytes_received) AS bytes_total
FROM fw_events
WHERE web_category IS NOT NULL
GROUP BY bucket, tenant_id, sensor_id, vendor, web_category, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_web_stats',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


CREATE MATERIALIZED VIEW daily_web_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', bucket)    AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    web_category,
    action,
    SUM(request_count)              AS request_count,
    SUM(bytes_total)                AS bytes_total
FROM hourly_web_stats
GROUP BY time_bucket('1 day', bucket), tenant_id, sensor_id, vendor, web_category, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_web_stats',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- DOMAIN STATS  —  top destinations (for "Top Sites" report section)
-- =============================================================================

CREATE MATERIALIZED VIEW hourly_domain_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    domain,
    web_category,
    action,
    COUNT(*)                        AS request_count,
    SUM(bytes_sent + bytes_received) AS bytes_total
FROM fw_events
WHERE domain IS NOT NULL
GROUP BY bucket, tenant_id, sensor_id, vendor, domain, web_category, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_domain_stats',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


CREATE MATERIALIZED VIEW daily_domain_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', bucket)    AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    domain,
    web_category,
    action,
    SUM(request_count)              AS request_count,
    SUM(bytes_total)                AS bytes_total
FROM hourly_domain_stats
GROUP BY time_bucket('1 day', bucket), tenant_id, sensor_id, vendor,
         domain, web_category, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_domain_stats',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- THREAT STATS  —  security events over time
-- =============================================================================

CREATE MATERIALIZED VIEW hourly_threat_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    threat_category,
    threat_severity,
    COUNT(*)                        AS event_count
FROM fw_events
WHERE event_type = 'threat'
GROUP BY bucket, tenant_id, sensor_id, vendor, threat_category, threat_severity
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_threat_stats',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


CREATE MATERIALIZED VIEW daily_threat_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', bucket)    AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    threat_category,
    threat_severity,
    SUM(event_count)                AS event_count
FROM hourly_threat_stats
GROUP BY time_bucket('1 day', bucket), tenant_id, sensor_id, vendor,
         threat_category, threat_severity
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_threat_stats',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- GEO STATS  —  traffic by destination country (for world map)
-- =============================================================================

CREATE MATERIALIZED VIEW hourly_geo_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    geo_dst_country,
    geo_dst_country_code,
    action,
    COUNT(*)                        AS connection_count,
    SUM(bytes_sent + bytes_received) AS bytes_total
FROM fw_events
WHERE geo_dst_country IS NOT NULL
GROUP BY bucket, tenant_id, sensor_id, vendor, geo_dst_country, geo_dst_country_code, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_geo_stats',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


CREATE MATERIALIZED VIEW daily_geo_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', bucket)    AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    geo_dst_country,
    geo_dst_country_code,
    action,
    SUM(connection_count)           AS connection_count,
    SUM(bytes_total)                AS bytes_total
FROM hourly_geo_stats
GROUP BY time_bucket('1 day', bucket), tenant_id, sensor_id, vendor,
         geo_dst_country, geo_dst_country_code, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_geo_stats',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- FIREWALL RULE STATS  —  which rules are being hit
-- =============================================================================

CREATE MATERIALIZED VIEW daily_rule_stats
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 day', time)      AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    rule_name,
    rule_id,
    action,
    COUNT(*)                        AS hit_count,
    SUM(bytes_sent + bytes_received) AS bytes_total
FROM fw_events
WHERE rule_name IS NOT NULL
GROUP BY time_bucket('1 day', time), tenant_id, sensor_id, vendor,
         rule_name, rule_id, action
WITH NO DATA;

SELECT add_continuous_aggregate_policy('daily_rule_stats',
    start_offset      => INTERVAL '3 days',
    end_offset        => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day'
);


-- =============================================================================
-- BANDWIDTH TIMELINE  —  total throughput over time (for trend charts)
-- Used by: Executive Summary chart, Bandwidth section
-- =============================================================================

CREATE MATERIALIZED VIEW hourly_bandwidth_timeline
WITH (timescaledb.continuous, timescaledb.materialized_only = false) AS
SELECT
    time_bucket('1 hour', time)     AS bucket,
    tenant_id,
    sensor_id,
    vendor,
    SUM(bytes_sent)                 AS bytes_sent,
    SUM(bytes_received)             AS bytes_received,
    SUM(bytes_sent + bytes_received) AS bytes_total,
    COUNT(*)                        AS event_count
FROM fw_events
WHERE event_type IN ('traffic', 'web', 'denied')
GROUP BY bucket, tenant_id, sensor_id, vendor
WITH NO DATA;

SELECT add_continuous_aggregate_policy('hourly_bandwidth_timeline',
    start_offset      => INTERVAL '3 hours',
    end_offset        => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour'
);


-- =============================================================================
-- Refresh all aggregates immediately after creation
-- (so dashboards have data straight away after install)
-- =============================================================================

CALL refresh_continuous_aggregate('hourly_user_traffic',      NULL, NULL);
CALL refresh_continuous_aggregate('hourly_app_stats',         NULL, NULL);
CALL refresh_continuous_aggregate('hourly_web_stats',         NULL, NULL);
CALL refresh_continuous_aggregate('hourly_domain_stats',      NULL, NULL);
CALL refresh_continuous_aggregate('hourly_threat_stats',      NULL, NULL);
CALL refresh_continuous_aggregate('hourly_geo_stats',         NULL, NULL);
CALL refresh_continuous_aggregate('hourly_bandwidth_timeline', NULL, NULL);
CALL refresh_continuous_aggregate('daily_rule_stats',         NULL, NULL);

-- Daily rollups (must refresh after their hourly sources)
CALL refresh_continuous_aggregate('daily_user_traffic',       NULL, NULL);
CALL refresh_continuous_aggregate('daily_app_stats',          NULL, NULL);
CALL refresh_continuous_aggregate('daily_web_stats',          NULL, NULL);
CALL refresh_continuous_aggregate('daily_domain_stats',       NULL, NULL);
CALL refresh_continuous_aggregate('daily_threat_stats',       NULL, NULL);
CALL refresh_continuous_aggregate('daily_geo_stats',          NULL, NULL);
