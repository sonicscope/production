-- Migration 003: Password-based authentication
-- Adds password_hash column to ui_users for email+password login.
-- OTP (ui_login_codes) is kept for password reset only.
--
-- Run on existing installs:
--   cp database/migrations/003_passwords.sql /tmp/ && \
--   sudo -u postgres psql sonicscope -f /tmp/003_passwords.sql

ALTER TABLE ui_users ADD COLUMN IF NOT EXISTS password_hash TEXT;
