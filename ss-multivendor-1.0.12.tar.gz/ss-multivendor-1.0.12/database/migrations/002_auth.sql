-- Migration 002: UI authentication — users, tenant access, login codes
-- Run once on existing installs:
--   cp database/migrations/002_auth.sql /tmp/ && \
--   sudo -u postgres psql sonicscope -f /tmp/002_auth.sql

-- ── UI users ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ui_users (
    id          SERIAL PRIMARY KEY,
    email       TEXT UNIQUE NOT NULL,
    full_name   TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'user'   -- 'admin' | 'user'
                CHECK (role IN ('admin', 'user')),
    is_active   BOOLEAN NOT NULL DEFAULT true,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_login  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS ui_users_email_idx ON ui_users (email);

-- ── Tenant access grants (non-admin users only) ───────────────────────────────
CREATE TABLE IF NOT EXISTS ui_user_tenants (
    user_id     INTEGER NOT NULL REFERENCES ui_users(id) ON DELETE CASCADE,
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id)  ON DELETE CASCADE,
    PRIMARY KEY (user_id, tenant_id)
);

-- ── Email login codes ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ui_login_codes (
    id          SERIAL PRIMARY KEY,
    email       TEXT NOT NULL,
    code_hash   TEXT NOT NULL,   -- SHA-256 of the 6-digit code
    attempts    SMALLINT NOT NULL DEFAULT 0,
    expires_at  TIMESTAMPTZ NOT NULL,
    used        BOOLEAN NOT NULL DEFAULT false,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ui_login_codes_email_idx
    ON ui_login_codes (email, expires_at)
    WHERE NOT used;

-- ── Permissions ───────────────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE ON ui_users        TO sonicscope;
GRANT SELECT, INSERT, UPDATE, DELETE ON ui_user_tenants TO sonicscope;
GRANT SELECT, INSERT, UPDATE, DELETE ON ui_login_codes  TO sonicscope;
GRANT USAGE, SELECT ON SEQUENCE ui_users_id_seq        TO sonicscope;
GRANT USAGE, SELECT ON SEQUENCE ui_login_codes_id_seq  TO sonicscope;

-- Default admin is created by scripts/install-reports.sh using the
-- Grafana admin password. No bootstrap required here.
