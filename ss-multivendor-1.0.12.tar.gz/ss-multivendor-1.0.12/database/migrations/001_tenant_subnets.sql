-- Migration 001: Add tenant_subnets table
-- Run once on existing installs:
--   sudo -u postgres psql sonicscope -f database/migrations/001_tenant_subnets.sql

CREATE TABLE IF NOT EXISTS tenant_subnets (
    id          SERIAL PRIMARY KEY,
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    subnet      CIDR NOT NULL,
    description TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, subnet)
);

CREATE INDEX IF NOT EXISTS tenant_subnets_tenant_id_idx
    ON tenant_subnets (tenant_id);

CREATE INDEX IF NOT EXISTS tenant_subnets_subnet_gist_idx
    ON tenant_subnets USING gist (subnet inet_ops);

GRANT SELECT, INSERT, UPDATE, DELETE ON tenant_subnets TO sonicscope;
GRANT USAGE, SELECT ON SEQUENCE tenant_subnets_id_seq TO sonicscope;
