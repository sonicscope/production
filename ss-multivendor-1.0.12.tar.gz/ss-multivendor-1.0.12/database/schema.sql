-- =============================================================================
-- SonicScope Multi-Vendor Collector — Database Schema
-- PostgreSQL + TimescaleDB
--
-- Run as superuser on a fresh database:
--   CREATE DATABASE sonicscope;
--   \c sonicscope
--   \i schema.sql
-- =============================================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS pg_trgm;   -- fast LIKE/regex on domain and URL columns


-- =============================================================================
-- SECTION 1: Supporting tables (tenants, sensors, identity, MSP branding)
-- =============================================================================

-- MSP profile — branding for white-label reports
CREATE TABLE msp_profiles (
    id              SERIAL PRIMARY KEY,
    name            TEXT NOT NULL,
    logo_path       TEXT,                           -- path to uploaded logo file
    primary_color   TEXT NOT NULL DEFAULT '#378ADD',
    secondary_color TEXT NOT NULL DEFAULT '#00C9A7',
    contact_name    TEXT,
    contact_email   TEXT,
    contact_phone   TEXT,
    website         TEXT,
    footer_text     TEXT,                           -- optional custom footer line
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Tenant — one row per customer site (firewall deployment)
-- In a single-site install this will have exactly one row.
-- In the future MSP portal, one MSP manages many tenants.
CREATE TABLE tenants (
    id              SERIAL PRIMARY KEY,
    msp_profile_id  INTEGER REFERENCES msp_profiles(id),
    name            TEXT NOT NULL,                  -- customer company name
    slug            TEXT UNIQUE NOT NULL,           -- used in file paths, e.g. "acme-corp"
    contact_name    TEXT,
    contact_email   TEXT,
    timezone        TEXT NOT NULL DEFAULT 'Africa/Johannesburg',
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Sensor — one row per physical/virtual firewall
-- A tenant may have more than one (branch offices, HA pairs)
CREATE TABLE sensors (
    id              SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    name            TEXT NOT NULL,                  -- friendly name, e.g. "HQ Firewall"
    vendor          TEXT NOT NULL,                  -- 'sonicwall' | 'fortinet' | 'sophos' | 'checkpoint'
    model           TEXT,                           -- e.g. "NSa 2700"
    serial_number   TEXT,
    ip_address      INET,                           -- management IP (for display only)
    data_sources    TEXT[] NOT NULL DEFAULT '{}',   -- ['ipfix','syslog'] — which inputs are active
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Identity mapping — maps an IP or subnet to a device/user name
-- Used to enrich src_ip with a human-readable name in reports
CREATE TABLE identity_mappings (
    id              SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    ip_range        CIDR NOT NULL,                  -- single IP (/32) or subnet (/24 etc.)
    device_name     TEXT,                           -- e.g. "John Smith's PC"
    user_name       TEXT,                           -- e.g. "jsmith" or "John Smith"
    department      TEXT,                           -- e.g. "Finance"
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX ON identity_mappings (tenant_id);
CREATE INDEX ON identity_mappings USING gist (ip_range inet_ops);

-- Tenant subnets — IP ranges assigned to a tenant for automatic flow routing
-- When a flow's src_ip falls within one of these subnets, it is assigned to
-- that tenant regardless of the SS_TENANT_ID config value.
CREATE TABLE tenant_subnets (
    id          SERIAL PRIMARY KEY,
    tenant_id   INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    subnet      CIDR NOT NULL,
    description TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (tenant_id, subnet)
);
CREATE INDEX ON tenant_subnets (tenant_id);
-- GiST index for fast subnet containment queries (ip <<= subnet)
CREATE INDEX ON tenant_subnets USING gist (subnet inet_ops);


-- =============================================================================
-- SECTION 2: Main events hypertable
-- =============================================================================
-- This is the central table. Every log entry from every vendor and every
-- data source (IPFIX or syslog) lands here in a normalized form.
--
-- Design principles:
--   - Columns used in WHERE clauses, JOINs, or GROUP BY are native columns
--   - High-cardinality text (URLs, raw messages) is stored but not indexed by default
--   - Vendor-specific fields that don't map to the common schema go in `extra` JSONB
--   - NULL means "not available for this event/vendor/source" — not an error
-- =============================================================================

CREATE TABLE fw_events (

    -- ── Time & Source ───────────────────────────────────────────────────────
    time            TIMESTAMPTZ     NOT NULL,
    tenant_id       INTEGER         NOT NULL,       -- FK to tenants(id)
    sensor_id       INTEGER         NOT NULL,       -- FK to sensors(id)
    vendor          TEXT            NOT NULL,       -- 'sonicwall' | 'fortinet' | 'sophos'
    data_source     TEXT            NOT NULL,       -- 'ipfix' | 'syslog'

    -- ── Event Classification ────────────────────────────────────────────────
    event_type      TEXT            NOT NULL,
    -- Values: 'traffic' | 'denied' | 'threat' | 'vpn' | 'auth' | 'admin'
    --         | 'web' | 'system'
    -- 'traffic' = allowed flow; 'denied' = blocked flow; 'threat' = IPS/AV/malware;
    -- 'vpn' = VPN session events; 'auth' = login/logoff; 'admin' = config changes

    action          TEXT,
    -- Values: 'allow' | 'deny' | 'drop' | 'reset' | 'tunnel'

    -- ── Network (Layer 3/4) ─────────────────────────────────────────────────
    src_ip          INET,
    dst_ip          INET,
    src_port        INTEGER,
    dst_port        INTEGER,
    protocol        TEXT,                           -- 'tcp' | 'udp' | 'icmp' | 'esp' etc.
    protocol_num    SMALLINT,                       -- IP protocol number (6=tcp, 17=udp)

    -- ── Traffic Metrics ─────────────────────────────────────────────────────
    -- Both IPFIX and syslog Enhanced provide these.
    -- IPFIX: exact values from the flow record
    -- Syslog: 'sent'/'rcvd' fields from SonicWall Enhanced Syslog
    bytes_sent      BIGINT          NOT NULL DEFAULT 0,   -- src → dst
    bytes_received  BIGINT          NOT NULL DEFAULT 0,   -- dst → src
    packets_sent    BIGINT          NOT NULL DEFAULT 0,
    packets_received BIGINT         NOT NULL DEFAULT 0,
    duration_ms     INTEGER,                        -- connection duration in milliseconds

    -- ── Identity (enriched at ingest time) ──────────────────────────────────
    -- Populated by looking up src_ip in identity_mappings
    user_name       TEXT,                           -- 'jsmith' or 'John Smith'
    device_name     TEXT,                           -- 'John Smith's Laptop'
    department      TEXT,                           -- 'Finance'

    -- ── Zones & Interfaces ──────────────────────────────────────────────────
    zone_src        TEXT,                           -- 'LAN' | 'DMZ' | 'WAN' | 'VPN'
    zone_dst        TEXT,
    interface_src   TEXT,                           -- 'X0' | 'port1' etc.
    interface_dst   TEXT,

    -- ── Firewall Rule ───────────────────────────────────────────────────────
    rule_name       TEXT,
    rule_id         INTEGER,

    -- ── Application ─────────────────────────────────────────────────────────
    -- IPFIX: from app_classifier enrichment (port/protocol mapping)
    -- Syslog: from vendor-supplied 'app' field
    app_name        TEXT,                           -- 'HTTPS' | 'Netflix' | 'Dropbox'
    app_category    TEXT,                           -- 'Streaming' | 'Cloud Storage'
    app_risk        SMALLINT,                       -- 0–100 risk score

    -- ── Web / URL ───────────────────────────────────────────────────────────
    -- Syslog provides these for HTTP/HTTPS traffic via content inspection
    -- IPFIX: domain populated via reverse DNS enrichment
    domain          TEXT,                           -- 'www.example.com'
    url             TEXT,                           -- full URL if available
    web_category    TEXT,                           -- 'Social Media' | 'Gambling' | 'News'
    web_category_id INTEGER,                        -- vendor numeric category ID

    -- ── Threat / Security ───────────────────────────────────────────────────
    threat_name     TEXT,                           -- 'ET.TROJAN.Agent' | 'Conficker'
    threat_category TEXT,                           -- 'Botnet' | 'Exploit' | 'Virus'
    threat_severity TEXT,                           -- 'low' | 'medium' | 'high' | 'critical'
    threat_id       INTEGER,                        -- vendor threat/signature ID

    -- ── Geographic Enrichment ───────────────────────────────────────────────
    geo_src_country      TEXT,
    geo_src_country_code CHAR(2),
    geo_src_city         TEXT,
    geo_dst_country      TEXT,
    geo_dst_country_code CHAR(2),
    geo_dst_city         TEXT,

    -- ── VPN ─────────────────────────────────────────────────────────────────
    vpn_policy_name TEXT,
    vpn_client_ip   INET,                           -- assigned tunnel IP

    -- ── Message (syslog sources) ────────────────────────────────────────────
    message_id      INTEGER,                        -- vendor message/event ID (e.g. SonicWall m=97)
    message         TEXT,                           -- human-readable event description
    raw_message     TEXT,                           -- original syslog line (omitted for IPFIX)

    -- ── Vendor-specific overflow ────────────────────────────────────────────
    -- Fields that are vendor-specific and don't map to the schema above.
    -- Stored for completeness and drill-down; not used in aggregate queries.
    extra           JSONB

);

-- Convert to TimescaleDB hypertable, partitioned by day.
-- 1-day chunks balance query performance vs number of files on disk.
SELECT create_hypertable('fw_events', 'time',
    chunk_time_interval => INTERVAL '1 day'
);

-- ── Indexes ───────────────────────────────────────────────────────────────────
-- Each index includes tenant_id first so multi-tenant queries never scan
-- another tenant's data. time DESC means the most recent data is found first.

CREATE INDEX ON fw_events (tenant_id, time DESC);
CREATE INDEX ON fw_events (tenant_id, src_ip, time DESC);
CREATE INDEX ON fw_events (tenant_id, user_name, time DESC);
CREATE INDEX ON fw_events (tenant_id, event_type, time DESC);
CREATE INDEX ON fw_events (tenant_id, action, time DESC);
CREATE INDEX ON fw_events (tenant_id, sensor_id, time DESC);

-- Partial indexes — only built for rows where the column is populated.
-- Keeps index size small; these are used by specific report sections only.
CREATE INDEX ON fw_events (tenant_id, threat_name, time DESC)
    WHERE threat_name IS NOT NULL;
CREATE INDEX ON fw_events (tenant_id, domain, time DESC)
    WHERE domain IS NOT NULL;
CREATE INDEX ON fw_events (tenant_id, app_name, time DESC)
    WHERE app_name IS NOT NULL;
CREATE INDEX ON fw_events (tenant_id, web_category, time DESC)
    WHERE web_category IS NOT NULL;
CREATE INDEX ON fw_events (tenant_id, vpn_policy_name, time DESC)
    WHERE vpn_policy_name IS NOT NULL;

-- Trigram index for substring search on domain (used by HR report site search)
CREATE INDEX ON fw_events USING gin (domain gin_trgm_ops)
    WHERE domain IS NOT NULL;


-- ── Compression ───────────────────────────────────────────────────────────────
-- Chunks older than 7 days are compressed automatically.
-- Compression rate is typically 90–95% for log data.
-- Segmenting by tenant_id + sensor_id means each segment compresses
-- independently and decompresses only the relevant tenant's data on query.

ALTER TABLE fw_events SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'tenant_id, sensor_id, event_type',
    timescaledb.compress_orderby   = 'time DESC'
);

SELECT add_compression_policy('fw_events', INTERVAL '7 days');


-- ── Retention ─────────────────────────────────────────────────────────────────
-- Default: keep raw events for 90 days. MSPs can request this be extended.
-- Continuous aggregates (in aggregates.sql) are kept indefinitely —
-- they are tiny and power the long-range trend views in reports.

SELECT add_retention_policy('fw_events', INTERVAL '90 days');


-- =============================================================================
-- SECTION 3: Reporting tables
-- =============================================================================

-- Scheduled report configuration — one row per recurring report
CREATE TABLE report_schedules (
    id              SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    msp_profile_id  INTEGER NOT NULL REFERENCES msp_profiles(id),
    report_type     TEXT NOT NULL,
    -- Values: 'daily' | 'weekly' | 'monthly'
    schedule_cron   TEXT NOT NULL,                  -- cron expression, e.g. '0 7 * * 1' (Mon 07:00)
    recipient_name  TEXT NOT NULL,                  -- customer contact name (goes on cover page)
    recipient_emails TEXT[] NOT NULL,               -- delivery address(es)
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    last_run_at     TIMESTAMPTZ,
    next_run_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Generated report archive — every PDF that has been produced
CREATE TABLE generated_reports (
    id              SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id),
    schedule_id     INTEGER REFERENCES report_schedules(id),  -- NULL if on-demand
    report_type     TEXT NOT NULL,                  -- 'daily' | 'weekly' | 'monthly' | 'hr_investigation'
    period_start    TIMESTAMPTZ NOT NULL,
    period_end      TIMESTAMPTZ NOT NULL,
    subject_user    TEXT,                           -- populated for HR investigation reports only
    file_path       TEXT,                           -- absolute path to generated PDF
    file_size_bytes INTEGER,
    generated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    delivered_at    TIMESTAMPTZ,                    -- NULL until email is sent
    delivery_status TEXT NOT NULL DEFAULT 'pending' -- 'pending' | 'sent' | 'failed'
);

CREATE INDEX ON generated_reports (tenant_id, generated_at DESC);
CREATE INDEX ON generated_reports (tenant_id, subject_user, generated_at DESC)
    WHERE subject_user IS NOT NULL;


-- =============================================================================
-- SECTION 4: Helper function — identity lookup
-- =============================================================================
-- Called at ingest time to resolve src_ip to user_name/device_name.
-- Uses CIDR containment so a /24 mapping matches all IPs in that subnet.

CREATE OR REPLACE FUNCTION lookup_identity(p_tenant_id INTEGER, p_ip INET)
RETURNS TABLE (user_name TEXT, device_name TEXT, department TEXT)
LANGUAGE sql STABLE AS $$
    SELECT user_name, device_name, department
    FROM   identity_mappings
    WHERE  tenant_id = p_tenant_id
      AND  ip_range  >>= p_ip        -- ip_range contains p_ip
    ORDER BY masklen(ip_range) DESC  -- most specific match first (/32 beats /24)
    LIMIT  1;
$$;
