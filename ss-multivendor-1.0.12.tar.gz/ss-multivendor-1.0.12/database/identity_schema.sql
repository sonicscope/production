-- SonicScope Identity Database
-- User → Device(s) hierarchy for IP-to-name resolution
-- Department > Group > User > Device
--
-- MUST run as postgres superuser (sonicscope user lacks CREATE TABLE / ALTER TABLE rights):
--   cp identity_schema.sql /tmp/ && sudo -u postgres psql -d sonicscope -f /tmp/identity_schema.sql

-- ── Users ─────────────────────────────────────────────────────────────────────
-- One row per person. department and group_name are plain text (no FK tables)
-- to keep imports simple. The UI suggests existing values as autocomplete.

CREATE TABLE IF NOT EXISTS identity_users (
    id              SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    username        TEXT,                           -- AD/SSO login or employee ID (optional)
    full_name       TEXT NOT NULL,
    email           TEXT,
    department      TEXT,                           -- e.g. "Finance"
    group_name      TEXT,                           -- e.g. "Finance-Accounts"
    notes           TEXT,
    active          BOOLEAN NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_identity_users_username
    ON identity_users(tenant_id, username)
    WHERE username IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_identity_users_tenant
    ON identity_users(tenant_id);

CREATE INDEX IF NOT EXISTS idx_identity_users_department
    ON identity_users(tenant_id, department)
    WHERE department IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_identity_users_group
    ON identity_users(tenant_id, group_name)
    WHERE group_name IS NOT NULL;


-- ── Devices ───────────────────────────────────────────────────────────────────
-- One row per IP or MAC record. One user can have many devices.
-- valid_from/valid_to enables historical DHCP tracking:
--   valid_to = NULL means currently active.
--   For DHCP imports, set valid_to = lease expiry when known.
-- ip_address stores both host IPs (192.168.1.10) and CIDR ranges (192.168.1.0/24).

CREATE TABLE IF NOT EXISTS identity_devices (
    id              SERIAL PRIMARY KEY,
    tenant_id       INTEGER NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id         INTEGER REFERENCES identity_users(id) ON DELETE SET NULL,
    ip_address      INET,                           -- host IP or CIDR range
    mac_address     MACADDR,                        -- normalized MAC (aa:bb:cc:dd:ee:ff)
    hostname        TEXT,                           -- device hostname
    label           TEXT,                           -- friendly name: "John's MacBook"
    source          TEXT NOT NULL DEFAULT 'manual', -- manual | dhcp | sso | ldap
    valid_from      TIMESTAMPTZ NOT NULL DEFAULT '-infinity',
    valid_to        TIMESTAMPTZ,                    -- NULL = currently active
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT identity_devices_at_least_one CHECK (
        ip_address IS NOT NULL OR mac_address IS NOT NULL OR hostname IS NOT NULL
    )
);

CREATE INDEX IF NOT EXISTS idx_identity_devices_tenant_ip
    ON identity_devices(tenant_id, ip_address)
    WHERE ip_address IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_identity_devices_tenant_mac
    ON identity_devices(tenant_id, mac_address)
    WHERE mac_address IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_identity_devices_tenant_user
    ON identity_devices(tenant_id, user_id)
    WHERE user_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_identity_devices_active
    ON identity_devices(tenant_id, ip_address, valid_to)
    WHERE ip_address IS NOT NULL AND valid_to IS NULL;


-- ── Extend fw_events with group_name ─────────────────────────────────────────
-- Safe ALTER TABLE — adding a nullable column never affects existing rows,
-- continuous aggregates, or indexes that don't reference it.

ALTER TABLE fw_events ADD COLUMN IF NOT EXISTS group_name TEXT;

CREATE INDEX IF NOT EXISTS idx_fw_events_group
    ON fw_events(tenant_id, group_name, time DESC)
    WHERE group_name IS NOT NULL;


-- ── Permissions ───────────────────────────────────────────────────────────────
GRANT SELECT, INSERT, UPDATE, DELETE ON identity_users  TO sonicscope;
GRANT SELECT, INSERT, UPDATE, DELETE ON identity_devices TO sonicscope;
GRANT USAGE, SELECT ON SEQUENCE identity_users_id_seq   TO sonicscope;
GRANT USAGE, SELECT ON SEQUENCE identity_devices_id_seq TO sonicscope;
