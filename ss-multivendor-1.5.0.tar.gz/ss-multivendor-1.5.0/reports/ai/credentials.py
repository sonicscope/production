"""AES-GCM encryption of the partner's AI API key (spec §5.2).

The key lives in its own 0600 file (not collector.env, not FLASK_SECRET) so a
config backup never contains ciphertext and key together. Fail closed.
"""
from __future__ import annotations

import base64
import binascii
import os
import stat

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

KEY_BYTES = 32
NONCE_BYTES = 12


class CredentialError(Exception):
    """Raised for any key-file or decrypt problem. Messages never contain secrets."""


def _path_for(path: str, version: int) -> str:
    return path if version == 1 else f'{path}.{version}'


def load_key(path: str, version: int = 1) -> bytes:
    """Load the 32-byte data key for ``version`` from a strictly-0600 file."""
    p = _path_for(path, version)
    try:
        st = os.stat(p)
    except OSError as exc:
        raise CredentialError(f'AI key file not found: {p}') from exc
    if st.st_mode & (stat.S_IRWXG | stat.S_IRWXO):
        raise CredentialError(f'AI key file {p} must not be accessible by group/other (chmod 600)')
    try:
        with open(p, 'r', encoding='ascii') as fh:
            raw = fh.read().strip()
        key = base64.urlsafe_b64decode(raw.encode('ascii'))
    except (OSError, UnicodeError, binascii.Error, ValueError) as exc:
        raise CredentialError(f'AI key file {p} is unreadable or malformed') from exc
    if len(key) != KEY_BYTES:
        raise CredentialError(f'AI key file {p} must contain a base64url 32-byte key')
    return key


def generate_key_file(path: str) -> None:
    """Create ``path`` (mode 0600) holding a fresh key. Never overwrites."""
    key = base64.urlsafe_b64encode(os.urandom(KEY_BYTES)).decode('ascii')
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as exc:
        raise CredentialError(f'refusing to overwrite existing key file {path}') from exc
    with os.fdopen(fd, 'w', encoding='ascii') as fh:
        fh.write(key + '\n')


def encrypt_secret(plaintext: str, key: bytes, aad: bytes) -> bytes:
    nonce = os.urandom(NONCE_BYTES)
    return nonce + AESGCM(key).encrypt(nonce, plaintext.encode('utf-8'), aad)


def decrypt_secret(blob: bytes, key: bytes, aad: bytes) -> str:
    blob = bytes(blob)
    if len(blob) <= NONCE_BYTES:
        raise CredentialError('stored AI key is corrupt')
    try:
        return AESGCM(key).decrypt(blob[:NONCE_BYTES], blob[NONCE_BYTES:], aad).decode('utf-8')
    except (InvalidTag, UnicodeError) as exc:
        raise CredentialError('stored AI key cannot be decrypted (re-enter the API key)') from exc
