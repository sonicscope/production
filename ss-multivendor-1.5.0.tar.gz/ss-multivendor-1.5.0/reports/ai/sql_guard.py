"""Validate and rewrite model-written SQL (spec §4.1, §4.2).

Deny-by-default: the statement must parse (libpg_query via pglast) to exactly
one SELECT, every AST node type must be on ALLOWED_NODES, every function
written in call syntax (``f(...)``, incl. SQL-syntax forms such as extract) on
ALLOWED_FUNCTIONS, every cast target on ALLOWED_TYPES, every operator on
ALLOWED_OPERATORS, and every relation either a CTE that is *in scope* at that
point of the statement or ``ai.<ALLOWED_RELATIONS>`` written unquoted.
Accepted queries are rewritten so each ai.<view> becomes a subquery with a
SERVER-INJECTED literal tenant filter (the model cannot change it) and, for the
raw-events view, a bounded time window. Comments and statement terminators are
dropped from the rewrite, and the rewrite is re-parsed and verified before it
is returned.

Known gap -- attribute-notation function calls: PostgreSQL resolves
``x.f`` as ``f(x)`` when ``f`` is not a column of ``x``. The parser cannot tell
``e.to_json`` (a function call) from ``e.domain`` (a column) -- both are a
plain ColumnRef -- so such calls are NOT checked against ALLOWED_FUNCTIONS.
Reachable functions are limited to single-argument functions visible on the
role's search_path whose argument is a row/record of an already tenant-filtered
view (or a subquery over one); the tenant filter therefore still applies to
everything they can see. Blocking this fully would need view column-name
knowledge inside the guard. Mitigation lives in the executor/DB layer: the
ss_ai_ro role's pinned search_path (pg_catalog, public), read-only
transactions, statement_timeout and its minimal grants/EXECUTE privileges.
See test_attribute_notation_function_call_is_known_gap.
"""
from __future__ import annotations

from dataclasses import dataclass

from pglast import ast, parse_sql
from pglast.enums import SQLValueFunctionOp, SubLinkType
from pglast.parser import ParseError, scan

MAX_SQL_CHARS = 4000
RAW_TIME_WINDOW_DAYS = 31
MAX_NODE_DEPTH = 128     # AST nesting; legit queries stay far below this
MAX_NODES = 5000
MAX_SELECT_COLUMNS = 100  # select-list targets per SELECT (stops SELECT *,*,* x rows blowup)

ALLOWED_RELATIONS = frozenset({
    'events', 'hourly_bandwidth', 'hourly_threat', 'daily_threat', 'daily_app',
    'daily_web', 'daily_domain', 'daily_geo', 'daily_rule',
})

ALLOWED_FUNCTIONS = frozenset({
    'count', 'sum', 'avg', 'min', 'max', 'round', 'ceil', 'floor', 'abs',
    'date_trunc', 'date_part', 'extract', 'time_bucket', 'now', 'timezone',
    'host', 'family', 'masklen', 'network', 'abbrev',
    'lower', 'upper', 'length', 'substr', 'substring', 'split_part', 'left', 'right',
    'concat', 'to_char', 'row_number', 'rank', 'dense_rank', 'lag', 'lead',
    'percentile_cont', 'btrim',
})

ALLOWED_NODES = frozenset({
    'RawStmt', 'SelectStmt', 'ResTarget', 'ColumnRef', 'String', 'A_Star', 'A_Const',
    'Integer', 'Float', 'Boolean', 'A_Expr', 'BoolExpr', 'NullTest', 'BooleanTest',
    'TypeCast', 'TypeName', 'FuncCall', 'RangeVar', 'Alias', 'JoinExpr', 'SortBy',
    'CaseExpr', 'CaseWhen', 'CoalesceExpr', 'MinMaxExpr', 'SubLink', 'RangeSubselect',
    'WithClause', 'CommonTableExpr', 'WindowDef', 'List',
    # Additions over the original plan (pure, no catalog/file/network access):
    'SQLValueFunction',   # CURRENT_DATE / CURRENT_TIMESTAMP ... (op-checked below)
    'GroupingSet',        # GROUP BY ROLLUP / CUBE / GROUPING SETS
})

# Cast / literal type targets. Catalog-reading types (regclass, regproc, ...),
# table row types, xml etc. are excluded on purpose.
ALLOWED_TYPES = frozenset({
    'int2', 'int4', 'int8', 'float4', 'float8', 'numeric', 'bool', 'text', 'varchar',
    'bpchar', 'date', 'time', 'timetz', 'timestamp', 'timestamptz', 'interval',
    'inet', 'cidr', 'macaddr',
})

# Unqualified operator names only (OPERATOR(schema.op) is rejected).
ALLOWED_OPERATORS = frozenset({
    '=', '<>', '<', '>', '<=', '>=', '+', '-', '*', '/', '%', '^', '||',
    '~~', '!~~', '~~*', '!~~*', '~', '!~', '~*', '!~*',
    '<<', '<<=', '>>', '>>=', '&&', '&', '|', '#', '|/', '@',
    'BETWEEN', 'NOT BETWEEN', 'BETWEEN SYMMETRIC', 'NOT BETWEEN SYMMETRIC',
})

_ALLOWED_SVF_OPS = frozenset({
    SQLValueFunctionOp.SVFOP_CURRENT_DATE, SQLValueFunctionOp.SVFOP_CURRENT_TIME,
    SQLValueFunctionOp.SVFOP_CURRENT_TIME_N, SQLValueFunctionOp.SVFOP_CURRENT_TIMESTAMP,
    SQLValueFunctionOp.SVFOP_CURRENT_TIMESTAMP_N, SQLValueFunctionOp.SVFOP_LOCALTIME,
    SQLValueFunctionOp.SVFOP_LOCALTIME_N, SQLValueFunctionOp.SVFOP_LOCALTIMESTAMP,
    SQLValueFunctionOp.SVFOP_LOCALTIMESTAMP_N,
})

_ALLOWED_CONTROL_CHARS = frozenset('\t\n\r')


class GuardError(ValueError):
    """The SQL was rejected. The message is safe to show to the model and user."""


@dataclass(frozen=True)
class GuardedQuery:
    original: str
    sql: str
    relations: tuple[str, ...]


def _names(parts: tuple | None) -> tuple[str, ...]:
    """Identifier parts (tuple of ast.String) as plain strings."""
    return tuple(str(getattr(p, 'sval', '')) for p in (parts or ()))


def _unqualified(names: tuple[str, ...]) -> str | None:
    """``x`` or ``pg_catalog.x`` -> ``x``; anything else -> None."""
    if len(names) == 1:
        return names[0]
    if len(names) == 2 and names[0] == 'pg_catalog':
        return names[1]
    return None


def _check_operator(parts: tuple | None) -> None:
    names = _names(parts)
    if len(names) != 1 or names[0] not in ALLOWED_OPERATORS:
        raise GuardError(f'operator not allowed: {".".join(names)}')


_MAX_TENANT_ID = 2**63 - 1   # bigint range


def _tenant_literal(tenant_id: object) -> str:
    """Canonical SQL literal for the tenant id, or GuardError.

    ``type(...) is int`` (not isinstance) rejects bool and int subclasses whose
    __format__/__str__/__repr__ could inject SQL; the literal is produced with
    ``int.__repr__`` so no method of the object itself is ever called.
    """
    if type(tenant_id) is not int or not 1 <= tenant_id <= _MAX_TENANT_ID:
        raise GuardError('invalid tenant')
    return int.__repr__(tenant_id)


def _wrapper(rel: str, tenant_literal: str) -> str:
    window = (f" AND time >= now() - interval '{RAW_TIME_WINDOW_DAYS} days'"
              if rel == 'events' else '')
    return f'(SELECT * FROM ai.{rel} WHERE tenant_id = {tenant_literal}{window})'


class _Validator:
    """Scope-aware recursive walk over the parse tree.

    Collects ``(start, end, relname, has_alias)`` spans for every ai.<view>
    reference. CTE names are tracked per scope with PostgreSQL's
    non-recursive WITH semantics: a CTE is visible to later siblings and to
    the rest of its SELECT (including nested subqueries), but NOT to itself,
    earlier siblings, or anything outside that SELECT -- there the same name
    would resolve to a real table.
    """

    def __init__(self, text: str) -> None:
        self.text = text
        self.spans: list[tuple[int, int, str, bool]] = []
        self.count = 0

    def walk(self, value: object, ctes: frozenset[str], depth: int) -> None:
        if isinstance(value, tuple):
            for item in value:
                self.walk(item, ctes, depth)
        elif isinstance(value, ast.Node):
            self.node(value, ctes, depth + 1)
        # scalars (str/int/bool/enum/None) carry no structure

    def node(self, node: ast.Node, ctes: frozenset[str], depth: int) -> None:
        if depth > MAX_NODE_DEPTH:
            raise GuardError('query is nested too deeply')
        self.count += 1
        if self.count > MAX_NODES:
            raise GuardError('query is too complex')
        kind = type(node).__name__
        if kind not in ALLOWED_NODES:
            raise GuardError(f'SQL construct not allowed: {kind}')

        if isinstance(node, ast.SelectStmt):
            self._select(node, ctes, depth)
            return
        if isinstance(node, ast.FuncCall):
            self._function(node)
        elif isinstance(node, ast.RangeVar):
            self._range_var(node, ctes)
        elif isinstance(node, ast.TypeName):
            self._type_name(node)
        elif isinstance(node, ast.A_Expr):
            _check_operator(node.name)
        elif isinstance(node, ast.SubLink):
            if node.subLinkType in (SubLinkType.ROWCOMPARE_SUBLINK,
                                    SubLinkType.MULTIEXPR_SUBLINK,
                                    SubLinkType.CTE_SUBLINK):
                raise GuardError('SQL construct not allowed: row subquery comparison')
            if node.operName:
                _check_operator(node.operName)
        elif isinstance(node, ast.SortBy):
            if node.useOp:
                raise GuardError('ORDER BY ... USING is not allowed')
        elif isinstance(node, ast.SQLValueFunction):
            if node.op not in _ALLOWED_SVF_OPS:
                raise GuardError('SQL construct not allowed: session/role functions')
        self._children(node, ctes, depth)

    def _children(self, node: ast.Node, ctes: frozenset[str], depth: int,
                  skip: str | None = None) -> None:
        for member in node:
            if member != skip:
                self.walk(getattr(node, member), ctes, depth)

    def _select(self, node: ast.SelectStmt, ctes: frozenset[str], depth: int) -> None:
        if node.intoClause is not None:
            raise GuardError('SELECT INTO not allowed')
        if node.lockingClause:
            raise GuardError('row locking (FOR UPDATE/SHARE) not allowed')
        if node.valuesLists:
            raise GuardError('VALUES lists not allowed')
        if len(node.targetList or ()) > MAX_SELECT_COLUMNS:
            raise GuardError(f'too many columns in SELECT (max {MAX_SELECT_COLUMNS})')
        with_clause = node.withClause
        if with_clause is None:
            self._children(node, ctes, depth)
            return
        if not isinstance(with_clause, ast.WithClause):
            raise GuardError('SQL construct not allowed: WITH')
        if with_clause.recursive:
            raise GuardError('WITH RECURSIVE not allowed')
        visible = set(ctes)
        for cte in with_clause.ctes or ():
            if not isinstance(cte, ast.CommonTableExpr):
                raise GuardError(f'SQL construct not allowed: {type(cte).__name__}')
            # The CTE body sees only outer CTEs and earlier siblings.
            self.node(cte, frozenset(visible), depth + 1)
            visible.add(cte.ctename)
        self._children(node, frozenset(visible), depth, skip='withClause')

    @staticmethod
    def _function(node: ast.FuncCall) -> None:
        names = _names(node.funcname)
        # Exact match: the parser already lower-cases unquoted identifiers;
        # SQL-syntax functions (extract, substring, trim...) parse to pg_catalog.<name>.
        name = _unqualified(names)
        if name is None or name not in ALLOWED_FUNCTIONS:
            raise GuardError(f'function not allowed: {".".join(names)}')

    @staticmethod
    def _type_name(node: ast.TypeName) -> None:
        names = _names(node.names)
        name = _unqualified(names)
        if node.setof or node.pct_type or name not in ALLOWED_TYPES:
            raise GuardError(f'type not allowed: {".".join(names)}')

    def _range_var(self, node: ast.RangeVar, ctes: frozenset[str]) -> None:
        if node.catalogname is None and node.schemaname is None and node.relname in ctes:
            return
        if (node.catalogname or node.schemaname != 'ai'
                or node.relname not in ALLOWED_RELATIONS):
            shown = '.'.join(p for p in (node.catalogname, node.schemaname, node.relname) if p)
            raise GuardError(
                f'relation not allowed: {shown} (use ai.<view> from describe_schema)')
        if not node.inh:
            raise GuardError('ONLY / inheritance markers are not allowed')
        expected = f'ai.{node.relname}'
        loc = node.location
        if (not isinstance(loc, int) or loc < 0
                or self.text[loc:loc + len(expected)].lower() != expected):
            raise GuardError('write relations unquoted as ai.<view>')
        self.spans.append((loc, loc + len(expected), node.relname, node.alias is not None))


def _parse(text: str) -> tuple:
    try:
        return parse_sql(text)
    except ParseError as exc:
        raise GuardError(f'SQL syntax error: {exc}') from exc
    except Exception as exc:  # noqa: BLE001 - never leak a raw parser failure
        raise GuardError('SQL could not be parsed') from exc


def _verify_rewrite(sql: str, tenant_id: int, expected_wrapped: int) -> None:
    """Defence in depth: re-parse the rewrite and prove that every schema-qualified
    relation sits alone in the FROM of an exact server-generated wrapper."""
    try:
        stmts = parse_sql(sql)
    except Exception as exc:  # noqa: BLE001 - offsets would refer to the rewrite
        raise GuardError('query cannot be safely rewritten '
                         '(TABLE, ONLY and * after a view name are not supported)') from exc
    if len(stmts) != 1 or not isinstance(stmts[0].stmt, ast.SelectStmt):
        raise GuardError('query cannot be safely rewritten')
    tenant_literal = _tenant_literal(tenant_id)
    wrappers = {rel: _parse(_wrapper(rel, tenant_literal)[1:-1])[0].stmt
                for rel in ALLOWED_RELATIONS}
    found = 0

    def walk(value: object, from_of: ast.SelectStmt | None) -> None:
        nonlocal found
        if isinstance(value, tuple):
            for item in value:
                walk(item, from_of)
            return
        if not isinstance(value, ast.Node):
            return
        if isinstance(value, ast.RangeVar) and (value.schemaname or value.catalogname):
            if from_of is None or from_of != wrappers.get(value.relname):
                raise GuardError('query cannot be safely rewritten')
            found += 1
        for member in value:
            child_from = (value if isinstance(value, ast.SelectStmt)
                          and member == 'fromClause' else None)
            walk(getattr(value, member), child_from)

    walk(stmts[0].stmt, None)
    if found != expected_wrapped:
        raise GuardError('query cannot be safely rewritten')


def check_sql(sql: str, tenant_id: int) -> GuardedQuery:
    """Validate ``sql`` and return the tenant-locked rewrite. Raises GuardError only."""
    tenant_literal = _tenant_literal(tenant_id)
    if not isinstance(sql, str):
        raise GuardError('SQL must be text')
    text = sql.strip()
    if not text:
        raise GuardError('empty SQL')
    if len(text) > MAX_SQL_CHARS:
        raise GuardError(f'SQL too long (max {MAX_SQL_CHARS} characters)')
    if not text.isascii():
        raise GuardError('only ASCII characters are allowed in SQL')
    # NUL truncates the C-string the parser sees (text after it would be
    # invisible to validation but still sent to the server); reject all
    # control characters other than ordinary whitespace.
    if any((ord(c) < 32 and c not in _ALLOWED_CONTROL_CHARS) or ord(c) == 127 for c in text):
        raise GuardError('control characters are not allowed in SQL')

    stmts = _parse(text)
    if len(stmts) != 1:
        raise GuardError('exactly one statement is allowed')
    root = stmts[0].stmt
    if not isinstance(root, ast.SelectStmt):
        raise GuardError('only a single SELECT statement is allowed')

    validator = _Validator(text)
    try:
        validator.node(root, frozenset(), 0)
        tokens = scan(text)
    except GuardError:
        raise
    except RecursionError as exc:
        raise GuardError('query is nested too deeply') from exc
    except Exception as exc:  # noqa: BLE001 - never leak a raw exception
        raise GuardError('SQL could not be validated') from exc

    # Edits applied right-to-left: wrap each ai.<view>, blank out comments
    # (a single space so neighbouring tokens never merge) and drop ';'.
    edits: list[tuple[int, int, str]] = []
    for start, end, rel, has_alias in validator.spans:
        alias = '' if has_alias else f' AS {rel}'
        edits.append((start, end, _wrapper(rel, tenant_literal) + alias))
    for tok in tokens:
        if tok.name in ('SQL_COMMENT', 'C_COMMENT'):
            edits.append((tok.start, tok.end + 1, ' '))
        elif tok.name == 'ASCII_59':          # ';' -- only terminators can remain here
            edits.append((tok.start, tok.end + 1, ''))
    out = text
    for start, end, replacement in sorted(edits, key=lambda e: e[0], reverse=True):
        out = out[:start] + replacement + out[end:]
    out = out.strip()

    try:
        _verify_rewrite(out, tenant_id, len(validator.spans))
    except GuardError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise GuardError('query cannot be safely rewritten') from exc

    return GuardedQuery(original=text, sql=out,
                        relations=tuple(sorted({rel for _, _, rel, _ in validator.spans})))
