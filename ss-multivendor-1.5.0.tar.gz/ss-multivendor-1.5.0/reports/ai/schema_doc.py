"""Model-facing schema documentation, generated from the live ai.* views."""
from __future__ import annotations

from reports.ai.sql_guard import ALLOWED_FUNCTIONS, ALLOWED_RELATIONS, RAW_TIME_WINDOW_DAYS

# One entry per ALLOWED_RELATIONS view. Notes mirror database/aggregates.sql and
# database/migrations/010_ai_investigate.sql (WHERE filters per aggregate).
VIEW_NOTES = {
    'events': f'Raw firewall events for the LAST {RAW_TIME_WINDOW_DAYS} DAYS ONLY. Use for evidence '
              'and detail; always filter on time and aggregate. url_path has no query string.',
    'hourly_bandwidth': 'Bandwidth per hour per sensor (traffic, web and denied events only).',
    'hourly_threat': 'Threat event counts per hour by category/severity (threat events only).',
    'daily_threat': 'Threat event counts per day by category/severity (threat events only; '
                    'use for ranges > 31 days).',
    'daily_app': 'Application usage per day (traffic and web events only; only events with an '
                 'app_name are counted, so app_name is never NULL here).',
    'daily_web': 'Web category requests per day by action; only events with a web category are '
                 'counted.',
    'daily_domain': 'Requests per domain per day by category/action; only events with a domain '
                    'are counted.',
    'daily_geo': 'Destination country connections per day by action; only events with a '
                 'destination country are counted.',
    'daily_rule': 'Firewall rule hits per day; only events with a rule name are counted.',
}

GUIDE = (
    'You query ONE tenant through these views. Rules:\n'
    '- Write each relation as ai.<view> (unquoted) and give it an alias; refer to columns by '
    'alias, never write ai.<view>.column. The tenant is applied for you: never filter by '
    'tenant_id.\n'
    '- Only a single SELECT is allowed. Functions are limited to this allowlist: '
    + ', '.join(sorted(ALLOWED_FUNCTIONS)) + '.\n'
    '- Stored timestamps are UTC. Call resolve_time to turn "yesterday", "last Tuesday 14:00" etc. '
    'into UTC bounds, and describe results in the tenant timezone. last_hours and last_days are '
    'exact 1-hour and 24-hour multiples back from now, not calendar days.\n'
    '- hourly_*/daily_* views are pre-aggregated and cheap; ai.events is detailed but limited to '
    f'the last {RAW_TIME_WINDOW_DAYS} days. Prefer aggregates for long ranges.\n'
    '- The aggregate views only count the events matching the filters named in their description; a count of '
    'zero there does not prove nothing happened (check threats in *_threat views).\n'
    '- sensor_id identifies a firewall. Results shown to you are capped at 200 rows.'
)


def build_schema_doc(cur) -> str:
    cur.execute("SELECT table_name, column_name, data_type FROM information_schema.columns "
                "WHERE table_schema = 'ai' ORDER BY table_name, ordinal_position")
    by_view: dict[str, list[str]] = {}
    for table, column, dtype in cur.fetchall():
        # Only views the SQL guard accepts may be documented to the model.
        if table not in ALLOWED_RELATIONS:
            continue
        by_view.setdefault(table, []).append(f'{column} {dtype}')
    parts = [GUIDE]
    for view in sorted(by_view):
        parts.append(f'\nai.{view} — {VIEW_NOTES.get(view, "")}\n  columns: '
                     + ', '.join(by_view[view]))
    return '\n'.join(parts)
