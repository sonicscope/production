"""HTML for the Investigate and AI-settings pages.

All model/log-derived text is rendered with textContent in JS (never innerHTML)
and all server-side interpolation is html.escape()d. The page runs under a
nonce-based CSP, so there are no inline event handlers.

Signature element: the "evidence strip" under every answer -- a monospace
ledger line (QUERY · N rows · X s) that expands to the SQL and the result table,
so verifying an answer is the default, not an afterthought.
"""
from __future__ import annotations

from html import escape

from reports.ai.store import AISettings

CHART_JS = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js'

STARTERS = [
    'What was the busiest hour yesterday?',
    'Which hosts hit the most blocked traffic this week?',
    'Top 10 destination countries in the last 7 days',
    'Show threat events by severity for the last 24 hours',
]

_MONO = 'ui-monospace,SFMono-Regular,Menlo,Consolas,monospace'

_CSS = """
<style>
#inv .msgs{min-height:50vh;max-height:65vh;overflow-y:auto;padding:.5rem 0;}
#inv .empty{padding:2rem 0 1rem;}
#inv .empty h4{font-size:1.15rem;margin-bottom:.35rem;}
#inv .empty p{color:#8BA3C0;margin-bottom:1rem;}
#inv .chips{display:flex;flex-wrap:wrap;gap:.5rem;margin:.5rem 0;}
#inv .bubble{padding:.6rem .85rem;border-radius:8px;margin:.5rem 0;white-space:pre-wrap;
  overflow-wrap:anywhere;background:#131F38;border:1px solid #1A2A4A;color:#E8EFF8;}
#inv .bubble.me{background:#0D1629;border-color:#378ADD;margin-left:auto;max-width:85%;width:fit-content;}
#inv .bubble.err{border-color:#dc3545;}
#inv .status{color:#8BA3C0;font-size:.85rem;margin:.3rem 0;}
#inv .evidence{margin:.35rem 0 .75rem;border-left:2px solid #00C9A7;padding-left:.75rem;}
#inv .evidence>summary{font-family:@@MONO@@;font-size:.8rem;color:#8BA3C0;cursor:pointer;
  padding:.35rem 0;list-style:none;letter-spacing:.02em;}
#inv .evidence>summary::-webkit-details-marker{display:none;}
#inv .evidence>summary::before{content:'\\25B8';display:inline-block;width:1.1em;color:#00C9A7;}
#inv .evidence[open]>summary::before{content:'\\25BE';}
#inv .evidence.rejected{border-left-color:#dc3545;}
#inv pre.sql{background:#070D1A;border:1px solid #1A2A4A;border-radius:6px;padding:.6rem;
  font-family:@@MONO@@;font-size:.8rem;color:#E8EFF8;white-space:pre-wrap;word-break:break-word;
  margin:.4rem 0;}
#inv .tablewrap{overflow-x:auto;max-height:320px;margin-top:.5rem;border:1px solid #1A2A4A;
  border-radius:6px;}
#inv .tablewrap table{margin:0;font-size:.85rem;}
#inv .tablewrap td{white-space:nowrap;}
#inv .chartbox{background:#0D1629;border:1px solid #1A2A4A;border-radius:8px;padding:.75rem;
  max-width:720px;margin:.5rem 0;}
#inv .btn-outline-secondary,#settings .btn-outline-secondary{color:#E8EFF8;border-color:#8BA3C0;}
#inv .btn-outline-secondary:hover,#settings .btn-outline-secondary:hover{background:#131F38;color:#E8EFF8;border-color:#00C9A7;}
#inv .composer{display:flex;gap:.5rem;margin-top:.5rem;}
#inv .btn:focus-visible,#inv input:focus-visible,#inv select:focus-visible,
#inv summary:focus-visible,#settings .btn:focus-visible,#settings input:focus-visible,
#settings select:focus-visible{outline:2px solid #378ADD;outline-offset:2px;}
#inv .visually-hidden-label{position:absolute;width:1px;height:1px;overflow:hidden;
  clip:rect(0 0 0 0);white-space:nowrap;}
@media (max-width:575.98px){
  #inv .btn-ss,#inv .composer .form-control{min-height:44px;}
  #inv .chips .btn{min-height:40px;text-align:left;}
  #inv .bubble.me{max-width:95%;}
  #inv .msgs{min-height:40vh;}
  #inv .btn-sm,#settings .btn,#settings .form-control,#settings .form-select{min-height:40px;}
}
@media (min-width:768px){#settings .tenant-grid{columns:2;column-gap:2rem;}}
#settings .tenant-grid .form-check{break-inside:avoid;}
@media (prefers-reduced-motion:reduce){#inv *,#settings *{animation:none !important;
  transition:none !important;scroll-behavior:auto !important;}}
</style>
""".replace('@@MONO@@', _MONO)

_JS = r"""
(function () {
  var root = document.getElementById('inv');
  var csrf = root.getAttribute('data-csrf');
  var msgs = document.getElementById('inv-msgs');
  var input = document.getElementById('inv-input');
  var sendBtn = document.getElementById('inv-send');
  var tenantSel = document.getElementById('inv-tenant');
  var history = [];
  var busy = false;
  var gen = 0;            // bumped on tenant change; stale sends drop their results
  var controller = null;
  var MAX_TURN = 4000;

  // The shared navbar tenant selector uses an inline onchange (blocked by this
  // page's nonce CSP); re-attach the same behaviour without inline JS.
  document.querySelectorAll('select[name="tenant_id"][onchange]').forEach(function (s) {
    s.addEventListener('change', function () { if (s.form) { s.form.submit(); } });
  });

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) { e.className = cls; }
    if (text !== undefined) { e.textContent = text; }
    return e;
  }
  function scroll() { msgs.scrollTop = msgs.scrollHeight; }
  function clearEmpty() { var s = document.getElementById('inv-starters'); if (s) { s.remove(); } }
  function bubble(text, cls) { var b = el('div', 'bubble ' + (cls || ''), text); msgs.appendChild(b); scroll(); return b; }

  function table(columns, rows, truncated) {
    var wrap = el('div', 'tablewrap');
    var t = el('table', 'table table-sm');
    var head = el('tr');
    columns.forEach(function (c) { head.appendChild(el('th', '', c)); });
    var threatIdx = columns.indexOf('threat_name');
    if (threatIdx >= 0) { head.appendChild(el('th', '', '')); }
    var thead = el('thead'); thead.appendChild(head); t.appendChild(thead);
    var tb = el('tbody');
    rows.slice(0, 500).forEach(function (r) {
      var tr = el('tr');
      r.forEach(function (v) { tr.appendChild(el('td', '', v === null ? '' : String(v))); });
      if (threatIdx >= 0) {
        var td = el('td');
        if (r[threatIdx]) {
          var b = el('button', 'btn btn-sm btn-outline-secondary', 'Explain');
          b.type = 'button';
          b.addEventListener('click', function () {
            var name = String(r[threatIdx]);
            send({ explain_threat: name }, 'Explain: ' + name.slice(0, 100));
          });
          td.appendChild(b);
        }
        tr.appendChild(td);
      }
      tb.appendChild(tr);
    });
    t.appendChild(tb); wrap.appendChild(t);
    if (rows.length > 500 || truncated) { wrap.appendChild(el('div', 'status px-2', 'Showing the first 500 rows.')); }
    return wrap;
  }

  // Evidence strip: ledger line that expands to the SQL and the result table.
  function evidence(ev) {
    var d = el('details', ev.error ? 'evidence rejected' : 'evidence');
    var n = (typeof ev.row_count === 'number') ? ev.row_count : (ev.rows || []).length;
    var label = ev.error ? 'QUERY · rejected'
      : 'QUERY · ' + n + (n === 1 ? ' row' : ' rows') +
        ' · ' + (ev.duration_ms / 1000).toFixed(1) + ' s';
    d.appendChild(el('summary', '', label));
    d.appendChild(el('pre', 'sql', ev.sql));
    var copy = el('button', 'btn btn-sm btn-outline-secondary', 'Copy SQL'); copy.type = 'button';
    function copyResult(label) {
      copy.textContent = label;
      setTimeout(function () { copy.textContent = 'Copy SQL'; }, 2000);
    }
    copy.addEventListener('click', function () {
      if (!navigator.clipboard || !navigator.clipboard.writeText) { copyResult('Copy failed'); return; }
      try {
        navigator.clipboard.writeText(ev.sql).then(function () { copyResult('Copied'); },
          function () { copyResult('Copy failed'); });
      } catch (e) { copyResult('Copy failed'); }
    });
    d.appendChild(copy);
    if (ev.error) { d.appendChild(el('div', 'status', ev.error)); }
    else { d.appendChild(table(ev.columns, ev.rows, ev.truncated)); }
    return d;
  }

  function chart(ev) {
    var box = el('div', 'chartbox');
    if (!window.Chart || (ev.kind !== 'bar' && ev.kind !== 'line')) {
      box.appendChild(el('div', 'status', 'Chart unavailable')); msgs.appendChild(box); return box;
    }
    var canvas = el('canvas');
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', ev.title || 'Chart');
    box.appendChild(canvas);
    msgs.appendChild(box);
    try { new window.Chart(canvas, {
      type: ev.kind,
      data: { labels: ev.labels, datasets: [{ label: ev.y, data: ev.values, borderColor: '#00C9A7', backgroundColor: '#00C9A7' }] },
      options: { plugins: { title: { display: !!ev.title, text: ev.title, color: '#E8EFF8' }, legend: { labels: { color: '#8BA3C0' } } },
                 scales: { x: { ticks: { color: '#8BA3C0' } }, y: { ticks: { color: '#8BA3C0' } } } }
    }); } catch (e) {
      while (box.firstChild) { box.removeChild(box.firstChild); }
      box.appendChild(el('div', 'status', 'Chart unavailable'));
    }
    return box;
  }

  function followups(items) {
    var box = el('div', 'chips');
    items.forEach(function (q) {
      var b = el('button', 'btn btn-sm btn-outline-secondary', q); b.type = 'button';
      b.addEventListener('click', function () { send({ question: q }, q); });
      box.appendChild(b);
    });
    msgs.appendChild(box); scroll();
  }

  // Evidence is built as SQL events arrive but shown after the answer text.
  function flush(state) {
    state.pending.forEach(function (n) { msgs.appendChild(n); });
    state.pending = []; scroll();
  }

  function handle(ev, state) {
    if (state.gen !== gen) { return; }
    if (ev.type === 'status') { state.status.textContent = ev.message; }
    else if (ev.type === 'sql') { state.pending.push(evidence(ev)); }
    else if (ev.type === 'chart') { state.charts.push(ev); }
    else if (ev.type === 'text') {
      bubble(ev.text); state.answer = ev.text;
      state.charts.forEach(chart); state.charts = []; flush(state);
    }
    else if (ev.type === 'followups') { flush(state); followups(ev.items); }
    else if (ev.type === 'error') { flush(state); bubble(ev.message, 'err'); }
    else if (ev.type === 'done') { flush(state); }
  }

  async function send(payload, shown) {
    if (busy) { return; }
    var myGen = gen;
    busy = true; sendBtn.disabled = true; tenantSel.disabled = true; clearEmpty();
    bubble(shown, 'me');
    var state = { gen: myGen, status: el('div', 'status', 'Thinking…'), answer: '', pending: [], charts: [] };
    sendBtn.textContent = 'Thinking…';
    msgs.appendChild(state.status); scroll();
    var ctl = new AbortController(); controller = ctl;
    var body = Object.assign({ tenant_id: Number(tenantSel.value), history: history.slice(-10) }, payload);
    try {
      var resp = await fetch('/investigate/chat', {
        method: 'POST', credentials: 'same-origin', signal: ctl.signal,
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
        body: JSON.stringify(body)
      });
      if (myGen !== gen) { return; }
      if (!resp.ok) {
        var msg = 'Request failed (' + resp.status + ').';
        try { msg = (await resp.json()).error || msg; } catch (e) { /* keep default */ }
        if (myGen !== gen) { return; }
        bubble(resp.status === 429 ? msg + ' Try again in a minute.' : msg, 'err');
      } else {
        var reader = resp.body.getReader(); var dec = new TextDecoder(); var buf = '';
        for (;;) {
          var chunk = await reader.read();
          if (myGen !== gen) { return; }
          if (chunk.done) { break; }
          buf += dec.decode(chunk.value, { stream: true });
          var frames = buf.split('\n\n'); buf = frames.pop();
          frames.forEach(function (f) {
            if (f.indexOf('data: ') === 0) { try { handle(JSON.parse(f.slice(6)), state); } catch (e) { /* skip bad frame */ } }
          });
        }
        flush(state);
        // Only a completed answer enters the history (keeps user/assistant turns paired).
        if (state.answer) {
          history.push({ role: 'user', content: shown.slice(0, MAX_TURN) });
          history.push({ role: 'assistant', content: state.answer.slice(0, MAX_TURN) });
        }
      }
    } catch (e) {
      if (myGen !== gen || (e && e.name === 'AbortError')) { return; }
      flush(state);
      bubble('Could not reach the server. Check your connection and try again.', 'err');
    } finally {
      if (myGen === gen) {
        state.status.remove(); busy = false; sendBtn.disabled = false; tenantSel.disabled = false;
        sendBtn.textContent = 'Ask'; input.focus();
      }
    }
  }

  document.getElementById('inv-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var q = input.value.trim();
    if (q) { input.value = ''; send({ question: q }, q); }
  });
  document.querySelectorAll('#inv-starters button').forEach(function (b) {
    b.addEventListener('click', function () { send({ question: b.textContent }, b.textContent); });
  });
  tenantSel.addEventListener('change', function () {
    gen += 1; history = [];
    if (controller) { controller.abort(); controller = null; }
    busy = false; sendBtn.disabled = false; tenantSel.disabled = false; sendBtn.textContent = 'Ask';
    while (msgs.firstChild) { msgs.removeChild(msgs.firstChild); }
  });
})();
"""


def investigate_html(*, configured: bool, is_admin: bool, tenants: list[tuple[int, str]],
                     has_tenants: bool, csrf: str, nonce: str) -> str:
    head = '<h3 class="mb-3">🔬 Investigate</h3>'
    if not configured:
        if is_admin:
            return head + ('<div class="card"><div class="card-body">The AI assistant is not set '
                           'up yet. <a class="btn btn-ss btn-sm ms-2" href="/settings/ai">'
                           'Set up AI assistant</a></div></div>')
        return head + ('<div class="card"><div class="card-body">The AI assistant is not set up '
                       'yet — please ask an administrator.</div></div>')
    if not tenants:
        hint = (' Enable tenants on the <a href="/settings/ai">AI Assistant settings</a> page.'
                if is_admin else ' Ask an administrator to enable one.')
        msg = ('No tenant is enabled for AI yet.' if has_tenants
               else 'You have no tenants assigned.')
        return head + f'<div class="card"><div class="card-body">{escape(msg)}{hint}</div></div>'
    options = ''.join(f'<option value="{int(tid)}">{escape(name)}</option>' for tid, name in tenants)
    starters = ''.join(
        f'<button type="button" class="btn btn-sm btn-outline-secondary" data-starter>{escape(s)}</button>'
        for s in STARTERS)
    return (
        head + _CSS +
        f'<div id="inv" data-csrf="{escape(csrf)}">'
        '<div class="card mb-3"><div class="card-body d-flex flex-wrap gap-3 align-items-center">'
        '<label for="inv-tenant" class="text-muted small mb-0">Tenant</label>'
        f'<select id="inv-tenant" class="form-select" style="max-width:320px">{options}</select>'
        '<span class="text-muted small">Answers use the tenant\'s timezone. Changing tenant '
        'starts a new conversation.</span></div></div>'
        '<div id="inv-msgs" class="msgs" role="log" aria-live="polite" aria-label="Conversation">'
        '<div id="inv-starters" class="empty"><h4>Ask about this customer\'s network</h4>'
        '<p>Start with one of these, or type your own question.</p>'
        f'<div class="chips">{starters}</div></div>'
        '</div>'
        '<form id="inv-form" class="composer">'
        '<label for="inv-input" class="visually-hidden-label">Your question</label>'
        '<input id="inv-input" class="form-control" maxlength="2000" autocomplete="off" '
        'placeholder="Ask about traffic, threats, apps or countries">'
        '<button id="inv-send" class="btn btn-ss" type="submit">Ask</button></form>'
        '<div class="text-muted small mt-2">Query results are sent to your configured AI '
        'provider. Check the SQL before you rely on an answer.</div></div>'
        f'<script src="{CHART_JS}"></script>'
        f'<script nonce="{escape(nonce)}">{_JS}</script>'
    )


def settings_html(*, settings: AISettings | None, providers: tuple[str, ...],
                  tenants: list[tuple[int, str, bool]]) -> str:
    cur_provider = settings.provider if settings else providers[0]
    popts = ''.join(f'<option value="{escape(p)}"{" selected" if p == cur_provider else ""}>'
                    f'{escape(p.capitalize())}</option>' for p in providers)
    key_hint = f'••••{escape(settings.api_key_last4)}' if settings else 'Paste your API key'
    model = escape(settings.model) if settings else ''
    consent = ''
    if settings and settings.consent_at:
        consent = (f'<div class="text-muted small mb-2">Consent recorded '
                   f'{escape(settings.consent_at.strftime("%Y-%m-%d %H:%M"))} for '
                   f'{escape(settings.consent_provider or "")}.</div>')
    trows = ''.join(
        f'<div class="form-check"><input class="form-check-input" type="checkbox" '
        f'name="tenant_ids" id="t{int(tid)}" value="{int(tid)}"{" checked" if on else ""}>'
        f'<label class="form-check-label" for="t{int(tid)}">{escape(name)}</label></div>'
        for tid, name, on in tenants) or '<div class="text-muted small">No tenants yet.</div>'
    return (
        _CSS +
        '<div id="settings">'
        '<h3 class="mb-3">🤖 AI Assistant</h3>'
        '<div class="card mb-3"><div class="card-body">'
        '<form method="post" action="/settings/ai">'
        '<div class="mb-3"><label class="form-label" for="provider">Provider</label>'
        f'<select class="form-select" id="provider" name="provider" style="max-width:320px">{popts}</select></div>'
        '<div class="mb-3"><label class="form-label" for="model">Model</label>'
        f'<input class="form-control" id="model" name="model" value="{model}" required '
        'style="max-width:320px" placeholder="Your provider\'s current flagship model">'
        '<div class="form-text">Small models write unreliable SQL. Use a capable model.</div></div>'
        '<div class="mb-3"><label class="form-label" for="api_key">API key</label>'
        '<input class="form-control" id="api_key" name="api_key" type="password" '
        f'autocomplete="new-password" placeholder="{key_hint}" style="max-width:420px">'
        '<div class="form-text">Write-only. Leave blank to keep the saved key.</div></div>'
        f'{consent}'
        '<div class="form-check mb-3"><input class="form-check-input" type="checkbox" '
        'name="consent" id="consent"><label class="form-check-label" for="consent">'
        'Query results (network metadata such as IP addresses and hostnames) are sent to the '
        'provider selected above, which processes them in its own regions. I am responsible '
        'for the provider\'s data handling and for POPIA compliance, including cross-border '
        'transfer.</label></div>'
        f'<div class="mb-3"><div class="form-label">Enable for tenants</div>'
        f'<div class="tenant-grid">{trows}</div></div>'
        '<button class="btn btn-ss" type="submit">Save</button></form></div></div>'
        '<form method="post" action="/settings/ai/test">'
        '<button class="btn btn-outline-secondary" type="submit">Test connection</button></form>'
        '</div>'
    )
