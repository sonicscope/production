"""OpenAI Chat Completions adapter (function calling)."""
from __future__ import annotations

import json

from reports.ai import net
from reports.ai.providers.base import (
    ToolCall, ToolSpec, Turn, Usage, as_int, make_tool_call, unexpected, validate_model)

URL = 'https://api.openai.com/v1/chat/completions'


def _call_of(c: dict) -> ToolCall:
    fn = c['function']
    # OpenAI sends arguments as a JSON string; make_tool_call rejects non-object results.
    args = json.loads(fn.get('arguments') or '{}')
    return make_tool_call(c.get('id'), fn.get('name'), args)


class OpenAIProvider:
    name = 'openai'

    def build_request(self, model: str, system: str, messages: list[dict],
                      tools: list[ToolSpec], max_tokens: int) -> dict:
        out: list[dict] = [{'role': 'system', 'content': system}]
        for m in messages:
            role = m['role']
            if role == 'user':
                out.append({'role': 'user', 'content': m['content']})
            elif role == 'assistant':
                calls = m.get('tool_calls', ())
                if not m.get('content') and not calls:
                    continue  # the API rejects empty assistant turns
                msg: dict = {'role': 'assistant', 'content': m.get('content') or None}
                if calls:
                    msg['tool_calls'] = [
                        {'id': c.id, 'type': 'function',
                         'function': {'name': c.name, 'arguments': json.dumps(c.arguments)}}
                        for c in calls]
                out.append(msg)
            else:
                out.append({'role': 'tool', 'tool_call_id': m['tool_call_id'],
                            'content': m['content']})
        body: dict = {'model': model, 'messages': out, 'max_completion_tokens': max_tokens}
        if tools:
            body['tools'] = [{'type': 'function', 'function': {
                'name': t.name, 'description': t.description, 'parameters': t.parameters}}
                for t in tools]
        return body

    def parse_response(self, data: dict) -> Turn:
        try:
            msg = data['choices'][0]['message']
            text = msg.get('content') or ''
            if not isinstance(text, str):
                raise unexpected()
            calls = tuple(_call_of(c) for c in (msg.get('tool_calls') or []))
            usage = data.get('usage') or {}
            return Turn(text=text, tool_calls=calls,
                        usage=Usage(as_int(usage.get('prompt_tokens', 0)),
                                    as_int(usage.get('completion_tokens', 0))))
        except (KeyError, IndexError, TypeError, ValueError, AttributeError, OverflowError,
                RecursionError):
            raise unexpected() from None

    def complete(self, *, api_key: str, model: str, system: str, messages: list[dict],
                 tools: list[ToolSpec], max_tokens: int = 2048) -> Turn:
        validate_model(model)
        body = self.build_request(model, system, messages, tools, max_tokens)
        data = net.post_json(URL, {'Authorization': f'Bearer {api_key}'}, body,
                             secrets=[api_key])
        return self.parse_response(data)

    def test(self, *, api_key: str, model: str) -> None:
        self.complete(api_key=api_key, model=model, system='Reply with OK.',
                      messages=[{'role': 'user', 'content': 'ping'}], tools=[], max_tokens=16)
