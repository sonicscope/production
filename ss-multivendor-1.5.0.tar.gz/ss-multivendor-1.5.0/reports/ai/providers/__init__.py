"""AI provider adapters (Anthropic, OpenAI, Gemini)."""
from __future__ import annotations

import importlib

from reports.ai.providers.base import Provider

PROVIDER_NAMES = ('anthropic', 'openai', 'gemini')
_CLASSES = {
    'anthropic': ('reports.ai.providers.anthropic', 'AnthropicProvider'),
    'openai': ('reports.ai.providers.openai', 'OpenAIProvider'),
    'gemini': ('reports.ai.providers.gemini', 'GeminiProvider'),
}


def get_provider(name: str) -> Provider:
    if name not in _CLASSES:
        raise ValueError(f'unknown provider: {name}')
    module, cls = _CLASSES[name]
    return getattr(importlib.import_module(module), cls)()
