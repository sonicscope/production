"""Google Gemini generateContent adapter (function calling)."""
from __future__ import annotations

from reports.ai import net
from reports.ai.providers.base import (
    ToolCall, ToolSpec, Turn, Usage, as_int, make_tool_call, unexpected, validate_model)

URL = 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'
MAX_TOKENS_MSG = 'the model ran out of output tokens — use a model/limit with more headroom'
_NO_ANSWER_MSG = 'the model returned no answer (the request may have been blocked)'


def _function_call_part(call: ToolCall) -> dict:
    part: dict = {'functionCall': {'name': call.name, 'args': call.arguments}}
    sig = (call.meta or {}).get('thoughtSignature')
    if isinstance(sig, str):
        # Gemini 3 rejects replayed function calls that lack their thought signature.
        part['thoughtSignature'] = sig
    return part


def _declaration(tool: ToolSpec) -> dict:
    decl: dict = {'name': tool.name, 'description': tool.description}
    if tool.parameters.get('properties'):
        decl['parameters'] = tool.parameters  # Gemini rejects an empty object schema
    return decl


class GeminiProvider:
    name = 'gemini'

    def build_request(self, system: str, messages: list[dict], tools: list[ToolSpec],
                      max_tokens: int) -> dict:
        contents: list[dict] = []
        responses: list[dict] = []

        def flush() -> None:
            if responses:
                contents.append({'role': 'user', 'parts': list(responses)})
                responses.clear()

        for m in messages:
            role = m['role']
            if role == 'tool':
                responses.append({'functionResponse': {
                    'name': m['name'], 'response': {'result': m['content']}}})
                continue
            flush()
            if role == 'user':
                contents.append({'role': 'user', 'parts': [{'text': m['content']}]})
            else:
                if not m.get('content') and not m.get('tool_calls'):
                    continue  # the API rejects empty model turns
                parts: list[dict] = []
                if m.get('content'):
                    parts.append({'text': m['content']})
                for call in m.get('tool_calls', ()):
                    parts.append(_function_call_part(call))
                contents.append({'role': 'model', 'parts': parts})
        flush()
        body: dict = {'systemInstruction': {'parts': [{'text': system}]},
                      'contents': contents,
                      'generationConfig': {'maxOutputTokens': max_tokens}}
        if tools:
            body['tools'] = [{'functionDeclarations': [_declaration(t) for t in tools]}]
        return body

    def parse_response(self, data: dict) -> Turn:
        try:
            candidates = data.get('candidates') or []
            if not candidates:
                raise net.ProviderError(_NO_ANSWER_MSG)
            candidate = candidates[0]
            parts = (candidate.get('content') or {}).get('parts') or []
            if not parts:
                if candidate.get('finishReason') == 'MAX_TOKENS':
                    raise net.ProviderError(MAX_TOKENS_MSG)
                raise net.ProviderError('the model returned an empty answer')
            text = ''.join(p.get('text', '') for p in parts
                           if 'text' in p and not p.get('thought'))
            calls: list[ToolCall] = []
            function_parts = [p for p in parts if 'functionCall' in p]
            for i, p in enumerate(function_parts):
                fc = p['functionCall']
                args = fc.get('args')
                sig = p.get('thoughtSignature')
                meta = {'thoughtSignature': sig} if isinstance(sig, str) else None
                calls.append(make_tool_call(f"{fc.get('name')}-{i}", fc.get('name'),
                                            {} if args is None else args, meta))
            usage = data.get('usageMetadata') or {}
            return Turn(text=text, tool_calls=tuple(calls),
                        usage=Usage(as_int(usage.get('promptTokenCount', 0)),
                                    as_int(usage.get('candidatesTokenCount', 0))))
        except net.ProviderError:
            raise
        except (KeyError, IndexError, TypeError, ValueError, AttributeError, OverflowError,
                RecursionError):
            raise unexpected() from None

    def complete(self, *, api_key: str, model: str, system: str, messages: list[dict],
                 tools: list[ToolSpec], max_tokens: int = 2048) -> Turn:
        validate_model(model)
        body = self.build_request(system, messages, tools, max_tokens)
        data = net.post_json(URL.format(model=model), {'x-goog-api-key': api_key}, body,
                             secrets=[api_key])
        return self.parse_response(data)

    def test(self, *, api_key: str, model: str) -> None:
        # A MAX_TOKENS stop still proves the key and model reached the API.
        try:
            self.complete(api_key=api_key, model=model, system='Reply with OK.',
                          messages=[{'role': 'user', 'content': 'ping'}], tools=[],
                          max_tokens=256)
        except net.ProviderError as exc:
            if str(exc) != MAX_TOKENS_MSG:
                raise
