"""Anthropic Messages API adapter (tool use)."""
from __future__ import annotations

from reports.ai import net
from reports.ai.providers.base import (
    ToolSpec, Turn, Usage, as_int, make_tool_call, unexpected, validate_model)

URL = 'https://api.anthropic.com/v1/messages'


def _input_of(block: dict) -> object:
    args = block.get('input')
    return {} if args is None else args


class AnthropicProvider:
    name = 'anthropic'

    def build_request(self, model: str, system: str, messages: list[dict],
                      tools: list[ToolSpec], max_tokens: int) -> dict:
        out: list[dict] = []
        results: list[dict] = []

        def flush() -> None:
            if results:
                out.append({'role': 'user', 'content': list(results)})
                results.clear()

        for m in messages:
            role = m['role']
            if role == 'tool':
                results.append({'type': 'tool_result', 'tool_use_id': m['tool_call_id'],
                                'content': m['content']})
                continue
            flush()
            if role == 'user':
                out.append({'role': 'user', 'content': m['content']})
            else:
                if not m.get('content') and not m.get('tool_calls'):
                    continue  # the API rejects empty assistant turns
                blocks: list[dict] = []
                if m.get('content'):
                    blocks.append({'type': 'text', 'text': m['content']})
                for call in m.get('tool_calls', ()):
                    blocks.append({'type': 'tool_use', 'id': call.id, 'name': call.name,
                                   'input': call.arguments})
                out.append({'role': 'assistant', 'content': blocks})
        flush()
        body: dict = {'model': model, 'max_tokens': max_tokens, 'system': system,
                      'messages': out}
        if tools:
            body['tools'] = [{'name': t.name, 'description': t.description,
                              'input_schema': t.parameters} for t in tools]
        return body

    def parse_response(self, data: dict) -> Turn:
        try:
            blocks = data.get('content') or []
            text = ''.join(b.get('text', '') for b in blocks if b.get('type') == 'text')
            calls = tuple(make_tool_call(b.get('id'), b.get('name'), _input_of(b))
                          for b in blocks if b.get('type') == 'tool_use')
            usage = data.get('usage') or {}
            return Turn(text=text, tool_calls=calls,
                        usage=Usage(as_int(usage.get('input_tokens', 0)),
                                    as_int(usage.get('output_tokens', 0))))
        except (KeyError, TypeError, ValueError, AttributeError, OverflowError,
                RecursionError):
            raise unexpected() from None

    def complete(self, *, api_key: str, model: str, system: str, messages: list[dict],
                 tools: list[ToolSpec], max_tokens: int = 2048) -> Turn:
        validate_model(model)
        body = self.build_request(model, system, messages, tools, max_tokens)
        data = net.post_json(URL, {'x-api-key': api_key, 'anthropic-version': '2023-06-01'},
                             body, secrets=[api_key])
        return self.parse_response(data)

    def test(self, *, api_key: str, model: str) -> None:
        self.complete(api_key=api_key, model=model, system='Reply with OK.',
                      messages=[{'role': 'user', 'content': 'ping'}], tools=[], max_tokens=8)
