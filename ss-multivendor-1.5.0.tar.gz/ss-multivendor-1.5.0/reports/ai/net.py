"""Outbound HTTPS to the three fixed AI provider hosts (spec §5.5).

HTTPS only, fixed host allowlist, no userinfo/custom port, resolved addresses
must be globally routable, redirects refused, bounded time and size. Errors are
generic: neither the key nor the response body ever reaches the UI.

Known limits, accepted for fixed public provider hosts:
- DNS is resolved in validate_url and again by urllib when it connects. There is
  no IP pinning, so an answer that changes between the two lookups is not caught.
- urllib honours https_proxy-style environment variables. When a proxy is set,
  the proxy resolves the provider host, and the address check here only covers
  the local lookup.
- ``timeout`` applies to each socket operation, not to the whole request, so a
  slow trickle can exceed it in wall-clock time.
- Callers must not log request URLs or headers. This module logs only redacted,
  control-character-free, truncated provider error text.
"""
from __future__ import annotations

import contextlib
import http.client
import ipaddress
import json
import logging
import re
import socket
import urllib.error
import urllib.request
from typing import Iterable
from urllib.parse import quote, urlsplit

log = logging.getLogger('ss.ai.net')

ALLOWED_HOSTS = frozenset({
    'api.anthropic.com', 'api.openai.com', 'generativelanguage.googleapis.com',
})

_MAX_ERROR_READ = 4096   # bytes read from a provider error body
_MAX_LOG_CHARS = 500     # characters of provider text kept in a log line
_CONTROL_CHARS = re.compile(r'[\x00-\x1f\x7f]')


class ProviderError(Exception):
    """Provider/network failure. The message is safe to show to users."""


def _secret_forms(secret: str) -> set[str]:
    """Return the raw, JSON-escaped and URL-encoded spellings of ``secret``."""
    forms = {secret, json.dumps(secret)[1:-1], quote(secret, safe='')}
    return {form for form in forms if form}


def redact(text: str, secrets: Iterable[str | None]) -> str:
    variants: set[str] = set()
    for secret in secrets:
        if secret:
            variants |= _secret_forms(secret)
    # Longest first, so a shorter form cannot break up a longer one.
    for variant in sorted(variants, key=len, reverse=True):
        text = text.replace(variant, '***')
    return text


def _log_text(text: str, secrets: Iterable[str | None]) -> str:
    """Redact, strip control characters, then truncate. Safe for log lines."""
    text = redact(text, secrets)
    text = _CONTROL_CHARS.sub(' ', text)
    return text[:_MAX_LOG_CHARS]


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401
        return None


def _open(req: urllib.request.Request, timeout: float):
    return urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout)


def _header_ok(text: str) -> bool:
    try:
        text.encode('latin-1')
    except UnicodeEncodeError:
        return False
    return _CONTROL_CHARS.search(text) is None


def _check_headers(headers: dict[str, str]) -> None:
    """Reject header names/values that http.client would refuse.

    Checked up front so the rejected value (which may be a key) is never
    embedded in an exception message.
    """
    for name, value in headers.items():
        for part in (name, value):
            if not isinstance(part, str) or not _header_ok(part):
                raise ProviderError('invalid API key or header value')


def validate_url(url: str, allowed_hosts: frozenset[str] = ALLOWED_HOSTS) -> str:
    """Return the host if ``url`` is acceptable, else raise ProviderError."""
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise ProviderError('provider URL is malformed') from None
    if parts.scheme != 'https':
        raise ProviderError('provider URL must use https')
    if parts.username or parts.password or port not in (None, 443):
        raise ProviderError('provider URL must not contain credentials or a custom port')
    host = (parts.hostname or '').lower()
    if host not in allowed_hosts:
        raise ProviderError('provider host is not allowed')
    try:
        infos = socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)
    except OSError as exc:
        raise ProviderError('could not resolve the provider host') from exc
    for info in infos:
        try:
            ip = ipaddress.ip_address(info[4][0])
        except ValueError:
            raise ProviderError('provider host resolved to an invalid address') from None
        if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped is not None:
            ip = ip.ipv4_mapped
        if not ip.is_global:
            raise ProviderError('provider host resolves to a non-public address')
    return host


def _status_error(exc: urllib.error.HTTPError, secrets: Iterable[str]) -> ProviderError:
    """Log a redacted excerpt of the error body and build the generic error."""
    try:
        raw = exc.read(_MAX_ERROR_READ)
    except (OSError, http.client.HTTPException, ValueError):
        raw = b''
    finally:
        with contextlib.suppress(OSError):
            exc.close()
    # Redact the full chunk before truncating, so a key that straddles the
    # truncation point is never left as a prefix in the log.
    log.warning('provider HTTP %s: %s', exc.code,
                _log_text(raw.decode('utf-8', 'replace'), secrets))
    if exc.code in (401, 403):
        return ProviderError('provider rejected the credentials — check the API key')
    if exc.code == 429:
        return ProviderError('provider rate limit reached — try again shortly')
    return ProviderError(f'provider returned HTTP {exc.code}')


def post_json(url: str, headers: dict[str, str], payload: dict, *,
              secrets: Iterable[str] = (), timeout: float = 40.0,
              max_bytes: int = 4_000_000,
              allowed_hosts: frozenset[str] = ALLOWED_HOSTS) -> dict:
    """POST ``payload`` as JSON and return the decoded JSON object.

    Every failure is raised as ProviderError. Header values are treated as
    secrets for redaction, so a bad key cannot leak through logs either.
    """
    validate_url(url, allowed_hosts)
    _check_headers(headers)
    secret_values = tuple(s for s in (*secrets, *headers.values()) if s)
    try:
        data = json.dumps(payload).encode('utf-8')
    except (TypeError, ValueError, RecursionError):
        raise ProviderError('could not encode the provider request') from None
    try:
        req = urllib.request.Request(
            url, data=data, method='POST',
            headers={**headers, 'Content-Type': 'application/json'})
        with _open(req, timeout) as resp:
            body = resp.read(max_bytes + 1)
    except urllib.error.HTTPError as exc:
        raise _status_error(exc, secret_values) from None
    except (OSError, http.client.HTTPException, ValueError) as exc:
        log.warning('provider unreachable (%s): %s', type(exc).__name__,
                    _log_text(str(exc), secret_values))
        raise ProviderError('could not reach the AI provider') from None
    if len(body) > max_bytes:
        raise ProviderError('provider response too large')
    try:
        out = json.loads(body)
    except (ValueError, RecursionError):
        raise ProviderError('provider returned an unreadable response') from None
    if not isinstance(out, dict):
        raise ProviderError('provider returned an unexpected response')
    return out
