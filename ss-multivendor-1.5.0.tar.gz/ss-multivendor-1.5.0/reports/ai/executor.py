"""Execute guarded SQL as the restricted ss_ai_ro role (spec §4.2, §4.3).

A fresh connection per query (no pooling => no session-state leakage between
users/tenants), a read-only transaction, the tenant GUC set by THIS trusted
code (defence in depth behind the guard's literal tenant rewrite), a plain
EXPLAIN cost cap, and a hard row cap. The transaction is always rolled back
and the connection always closed, including on errors.
"""
from __future__ import annotations

import datetime as dt
import decimal
import logging
import math
import time
from dataclasses import dataclass
from typing import Mapping

import psycopg2
import psycopg2.errors
from pglast import ast, parse_sql

from reports.ai.sql_guard import GuardedQuery

MAX_ROWS = 5000
COST_LIMIT = 2_000_000.0
_MAX_TENANT_ID = 2**63 - 1
_SAFE_INT = 2**53
_MAX_SQL_CHARS = 20_000      # pglast can segfault (no exception) on huge expressions
_log = logging.getLogger('ss.ai.executor')


class ExecutorError(Exception):
    """Query failed. The message is safe to show to the model and the user."""


@dataclass(frozen=True)
class QueryResult:
    columns: tuple[str, ...]
    rows: tuple[tuple, ...]
    truncated: bool
    duration_ms: int


def ai_db_config(env: Mapping[str, str]) -> dict:
    """psycopg2 kwargs for the ss_ai_ro role; ExecutorError if no password."""
    password = env.get('AI_DB_PASSWORD', '')
    if not password:
        raise ExecutorError('AI database role is not configured (AI_DB_PASSWORD missing)')
    try:
        port = int(env.get('DB_PORT', '5432'))
    except (TypeError, ValueError):
        raise ExecutorError('AI database port is invalid (DB_PORT)') from None
    return {'host': env.get('DB_HOST', '127.0.0.1'), 'port': port,
            'dbname': env.get('DB_NAME', 'sonicscope'), 'user': 'ss_ai_ro',
            'password': password}


def _jsonable(value):
    """Convert a DB value to a JSON-safe one (never NaN/Infinity, no precision loss)."""
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value if abs(value) <= _SAFE_INT else str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return 'NaN'
        if math.isinf(value):
            return 'Infinity' if value > 0 else '-Infinity'
        return value
    if isinstance(value, decimal.Decimal):
        if value.is_nan():
            return 'NaN'
        if value.is_infinite():
            return 'Infinity' if value > 0 else '-Infinity'
        if abs(value) > _SAFE_INT:
            return str(value)
        as_float = float(value)
        if not math.isfinite(as_float) or decimal.Decimal(repr(as_float)) != value:
            return str(value)             # float would lose exactness
        return as_float
    if isinstance(value, str):
        return value
    if isinstance(value, (bytes, bytearray, memoryview)):
        return '\\x' + bytes(value).hex()
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, dt.timedelta):
        return str(value)
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return str(value)


def _require_single_select(sql: str) -> None:
    """Defence in depth: exactly one plain SELECT statement, else ExecutorError."""
    if len(sql) > _MAX_SQL_CHARS:
        raise ExecutorError('query rejected')
    try:
        stmts = parse_sql(sql)
        ok = len(stmts) == 1 and isinstance(stmts[0].stmt, ast.SelectStmt)
    except Exception:  # noqa: BLE001 - any parser failure means reject
        ok = False
    if not ok:
        raise ExecutorError('query rejected')


def _validate_inputs(tenant_id: object, max_rows: object, cost_limit: object) -> None:
    if type(tenant_id) is not int or not 1 <= tenant_id <= _MAX_TENANT_ID:
        raise ExecutorError('invalid tenant')
    if type(max_rows) is not int or max_rows < 1:
        raise ExecutorError('invalid row limit')
    try:
        valid = (type(cost_limit) in (int, float) and math.isfinite(cost_limit)
                 and cost_limit > 0)
    except (OverflowError, TypeError, ValueError):
        valid = False
    if not valid:
        raise ExecutorError('invalid cost limit')


def run_query(config: dict, tenant_id: int, guarded: GuardedQuery, *,
              max_rows: int = MAX_ROWS, cost_limit: float = COST_LIMIT) -> QueryResult:
    """Run guarded SQL as ss_ai_ro, tenant-locked, cost- and row-capped.

    The GUC tenant lock is defence in depth that holds against guard bugs which
    do NOT also let set_config through (a single SELECT calling set_config
    before reading a view can switch the GUC); the primary lock is the guard's
    literal tenant rewrite. Result rows may contain list/dict values (arrays,
    json), all JSON-safe.
    """
    _validate_inputs(tenant_id, max_rows, cost_limit)
    sql = getattr(guarded, 'sql', None)
    if not isinstance(sql, str):
        raise ExecutorError('query rejected')
    _require_single_select(sql)
    wrapped = f'SELECT * FROM (\n{sql}\n) AS q LIMIT {max_rows + 1}'
    _require_single_select(wrapped)
    try:
        conn = psycopg2.connect(connect_timeout=5, **config)
    except Exception:  # noqa: BLE001 - bad config types, encoding errors, etc.
        raise ExecutorError('could not connect to the database') from None
    try:
        conn.set_session(readonly=True, autocommit=False)
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('ss.tenant_id', %s, true)", (str(tenant_id),))
            # Plain EXPLAIN still plans (and may constant-fold) the query; that
            # is acceptable under the guard's function allowlist. It explains
            # the exact wrapped text that is executed below.
            cur.execute('EXPLAIN (FORMAT JSON) ' + wrapped)
            try:
                cost = float(cur.fetchone()[0][0]['Plan']['Total Cost'])
            except (KeyError, IndexError, TypeError, ValueError):
                raise ExecutorError('could not estimate query cost') from None
            if cost > cost_limit:
                raise ExecutorError(
                    'query is too expensive — narrow the time range or use a daily_* view')
            started = time.monotonic()
            cur.execute(wrapped)
            fetched = cur.fetchmany(max_rows + 1)
            columns = tuple(d[0] for d in cur.description)
            elapsed = int((time.monotonic() - started) * 1000)
        truncated = len(fetched) > max_rows
        rows = tuple(tuple(_jsonable(v) for v in row) for row in fetched[:max_rows])
        return QueryResult(columns=columns, rows=rows, truncated=truncated, duration_ms=elapsed)
    except ExecutorError:
        raise
    except psycopg2.errors.QueryCanceled:
        raise ExecutorError('query exceeded the time limit') from None
    except psycopg2.Error as exc:
        message = getattr(getattr(exc, 'diag', None), 'message_primary', None)
        raise ExecutorError(message or 'database error') from None
    except Exception:  # noqa: BLE001 - safety net: never leak raw exceptions
        _log.exception('unexpected failure running AI query')
        raise ExecutorError('query failed') from None
    finally:
        try:
            conn.rollback()
        except psycopg2.Error:
            pass                              # connection already broken; close() below
        finally:
            conn.close()
