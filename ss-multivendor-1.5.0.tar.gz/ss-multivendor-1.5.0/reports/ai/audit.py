"""Immutable audit log + DB-backed rate/budget limits (correct across workers)."""
from __future__ import annotations

from typing import Mapping

DEFAULT_RATE_PER_MIN = 10
DEFAULT_DAILY_TOKEN_BUDGET = 2_000_000


class LimitError(Exception):
    """A usage limit was hit. The message is safe to show to the user."""


def _nonneg_int(value: object) -> int:
    """Coerce to an int >= 0; an upstream bug must never break auditing."""
    try:
        return max(0, int(value))  # type: ignore[call-overload]
    except (TypeError, ValueError, OverflowError):
        return 0


def log_event(cur, *, kind: str, user_id: int | None, tenant_id: int | None,
              provider: str | None, model: str | None, question: str | None = None,
              sql: str | None = None, row_count: int | None = None,
              duration_ms: int | None = None, error: str | None = None,
              tokens_in: int = 0, tokens_out: int = 0) -> None:
    cur.execute(
        'INSERT INTO ai_audit (kind, user_id, tenant_id, provider, model, question, sql, '
        'row_count, duration_ms, error, tokens_in, tokens_out) '
        'VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
        (kind[:40], user_id, tenant_id, provider[:40] if provider else None,
         model[:100] if model else None,
         question[:2000] if question else None, sql[:4000] if sql else None,
         row_count, duration_ms, error[:500] if error else None,
         _nonneg_int(tokens_in), _nonneg_int(tokens_out)))


def check_limits(cur, user_id: int, *, per_minute: int, daily_token_budget: int) -> None:
    """Raise LimitError over the limits.

    Rate: count of this user's 'chat_start' rows (written by the route right after this check,
    before the provider call) in the last minute. Budget: tokens of ALL kinds/users since local
    midnight; the day boundary uses the DB server timezone.
    """
    if type(user_id) is not int:
        raise ValueError('user_id must be an integer')
    if per_minute <= 0 or daily_token_budget <= 0:
        raise ValueError('limits must be positive')
    cur.execute("SELECT count(*) FROM ai_audit WHERE kind = 'chat_start' AND user_id = %s "
                "AND ts > now() - interval '1 minute'", (user_id,))
    if cur.fetchone()[0] >= per_minute:
        raise LimitError('Too many requests — wait a minute and try again.')
    cur.execute("SELECT COALESCE(sum(tokens_in + tokens_out), 0) FROM ai_audit "
                "WHERE ts >= date_trunc('day', now())")
    if cur.fetchone()[0] >= daily_token_budget:
        raise LimitError('The AI token budget for today (server time) has been reached.')


def _positive_int(raw: str | None, default: int) -> int:
    try:
        value = int(raw) if raw is not None else default
    except ValueError:
        return default
    return value if value > 0 else default


def limits_from_env(env: Mapping[str, str]) -> tuple[int, int]:
    return (_positive_int(env.get('AI_RATE_PER_MIN'), DEFAULT_RATE_PER_MIN),
            _positive_int(env.get('AI_DAILY_TOKEN_BUDGET'), DEFAULT_DAILY_TOKEN_BUDGET))
