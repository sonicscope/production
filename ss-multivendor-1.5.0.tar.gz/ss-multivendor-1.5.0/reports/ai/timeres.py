"""resolve_time tool: tenant-local natural ranges -> UTC bounds (spec §4, H2).

Contract: resolve_time raises only TimeResolveError (never OverflowError,
TypeError, ValueError, ... from the stdlib), so the tool layer can show the
message to the model.
"""
from __future__ import annotations

from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

DEFAULT_TZ = 'Africa/Johannesburg'
_FMT = '%Y-%m-%d %H:%M:%S+00'
MIN_YEAR = 2000
MAX_YEAR = 2100
MAX_SPAN = timedelta(days=5 * 366)   # 'between' may cover at most about 5 years


class TimeResolveError(ValueError):
    """Bad arguments to resolve_time. The message is shown to the model."""


def _zone(name) -> ZoneInfo:
    """Tenant zone; anything unusable (None, non-str, unknown, empty) falls back."""
    if not isinstance(name, str) or not name:
        return ZoneInfo(DEFAULT_TZ)
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, TypeError, OSError):
        return ZoneInfo(DEFAULT_TZ)


def _int(value, lo: int, hi: int, label: str) -> int:
    """Accept an int or a string of ASCII digits; reject bool, float, NaN, inf, other strings."""
    if isinstance(value, bool):
        raise TimeResolveError(f'{label}: n must be an integer')
    if isinstance(value, int):
        n = value
    elif isinstance(value, str) and value.isascii() and value.isdigit():
        n = int(value)
    else:
        raise TimeResolveError(f'{label}: n must be an integer')
    if not lo <= n <= hi:
        raise TimeResolveError(f'{label}: n must be between {lo} and {hi}')
    return n


def _now_utc(now: datetime | None) -> datetime:
    if now is None:
        return datetime.now(timezone.utc)
    if not isinstance(now, datetime) or now.utcoffset() is None:
        raise TimeResolveError('now must be a timezone-aware datetime')
    return now.astimezone(timezone.utc)


def _midnight(day: date, zone: ZoneInfo) -> datetime:
    """Local midnight at the start of ``day`` as a UTC instant."""
    return datetime.combine(day, time(0), tzinfo=zone).astimezone(timezone.utc)


def _parse_local(value, label: str) -> tuple[datetime, bool]:
    """Parse 'YYYY-MM-DD' (date_only=True) or 'YYYY-MM-DD HH:MM' as a naive local time."""
    hint = f'between: {label} must be YYYY-MM-DD or YYYY-MM-DD HH:MM (tenant local time)'
    if not isinstance(value, str):
        raise TimeResolveError(hint)
    for fmt, date_only in (('%Y-%m-%d %H:%M', False), ('%Y-%m-%d', True)):
        try:
            parsed = datetime.strptime(value, fmt)
        except ValueError:
            continue
        if not MIN_YEAR <= parsed.year <= MAX_YEAR:
            raise TimeResolveError(
                f'between: {label} year must be between {MIN_YEAR} and {MAX_YEAR}')
        return parsed, date_only
    raise TimeResolveError(hint)


def _local_to_utc(naive: datetime, zone: ZoneInfo) -> datetime:
    """Convert a naive local wall time to UTC, rejecting times that do not exist.

    Ambiguous times (fall-back hour) resolve to the first occurrence (fold=0),
    i.e. the earlier, DST-offset instant.
    """
    aware = naive.replace(tzinfo=zone)
    round_trip = aware.astimezone(timezone.utc).astimezone(zone).replace(tzinfo=None)
    if round_trip != naive:
        raise TimeResolveError('that local time does not exist (daylight-saving gap)')
    return aware.astimezone(timezone.utc)


def _between(args: dict, zone: ZoneInfo) -> tuple[datetime, datetime]:
    start_naive, start_date_only = _parse_local(args.get('start'), 'start')
    end_naive, end_date_only = _parse_local(args.get('end'), 'end')
    # A date-only value means the first valid instant of that local day, which is
    # not 00:00 on days where midnight is skipped by DST (Cairo, Beirut, Havana).
    # An explicit HH:MM must exist locally, so a time in a DST gap is refused.
    if start_date_only:
        start = _midnight(start_naive.date(), zone)
    else:
        start = _local_to_utc(start_naive, zone)
    if end_date_only:
        # A date-only end covers that whole day: exclusive end is the next local day start.
        end = _midnight(end_naive.date() + timedelta(days=1), zone)
    else:
        end = _local_to_utc(end_naive, zone)
    if start >= end:
        raise TimeResolveError('between: start must be before end')
    if end - start > MAX_SPAN:
        raise TimeResolveError('between: a range may span at most 5 years')
    return start, end


def _resolve(args: dict, tz_name, now: datetime | None) -> dict:
    zone = _zone(tz_name)
    now_utc = _now_utc(now)
    now_local = now_utc.astimezone(zone)
    kind = args.get('kind') if isinstance(args, dict) else None

    if kind == 'last_hours':
        start, end = now_utc - timedelta(hours=_int(args.get('n'), 1, 744, kind)), now_utc
    elif kind == 'last_days':
        start, end = now_utc - timedelta(days=_int(args.get('n'), 1, 90, kind)), now_utc
    elif kind == 'today':
        start, end = _midnight(now_local.date(), zone), now_utc
    elif kind == 'yesterday':
        today = now_local.date()
        start, end = _midnight(today - timedelta(days=1), zone), _midnight(today, zone)
    elif kind == 'between':
        start, end = _between(args, zone)
    else:
        raise TimeResolveError(
            'kind must be one of last_hours, last_days, today, yesterday, between')

    s_local, e_local = start.astimezone(zone), end.astimezone(zone)
    return {
        'start_utc': start.astimezone(timezone.utc).strftime(_FMT),
        'end_utc': end.astimezone(timezone.utc).strftime(_FMT),
        'timezone': zone.key,
        'label': f'{s_local:%Y-%m-%d %H:%M} to {e_local:%Y-%m-%d %H:%M} ({zone.key})',
    }


def resolve_time(args: dict, tz_name: str, now: datetime | None = None) -> dict:
    """Return UTC bounds for a tenant-local range. Raises only TimeResolveError."""
    try:
        return _resolve(args, tz_name, now)
    except TimeResolveError:
        raise
    except (OverflowError, ValueError, TypeError, OSError):
        raise TimeResolveError('time range out of supported bounds') from None
