"""No 'SonicScope' in report output; footer + stat accent are MSP-driven."""
import pytest

from reports.tests.branding_util import (
    make_msp, make_tenant, render_hr, render_periodic, render_security,
)

RENDERERS = [render_periodic, render_security, render_hr]


@pytest.mark.parametrize('render', RENDERERS)
def test_no_sonicscope_string_in_output(render):
    html = render(make_msp(), make_tenant())
    assert 'SonicScope' not in html


def test_footer_uses_msp_name_when_no_footer_text():
    html = render_periodic(make_msp(name='ACME MSP', footer_text=None), make_tenant())
    assert 'content: "ACME MSP"' in html


def test_footer_prefers_footer_text_when_set():
    html = render_periodic(make_msp(footer_text='ACME Managed IT'), make_tenant())
    assert 'content: "ACME Managed IT"' in html


@pytest.mark.parametrize('render', RENDERERS)
def test_report_declares_brand_accent_variable(render):
    html = render(make_msp(primary_color='#123456'), make_tenant())
    assert '--accent: #123456' in html
