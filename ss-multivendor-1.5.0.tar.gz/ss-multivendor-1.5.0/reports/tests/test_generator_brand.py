"""Unit tests for reports.generator._brand (pure, no DB/WeasyPrint)."""
from reports.generator import _brand


def test_brand_light_color_black_text():
    assert _brand({'primary_color': '#ffff00'}) == {
        'primary_color': '#ffff00', 'accent_text_color': '#000000',
    }


def test_brand_dark_color_white_text():
    assert _brand({'primary_color': '#001133'}) == {
        'primary_color': '#001133', 'accent_text_color': '#ffffff',
    }


def test_brand_malformed_falls_back_to_default_accent():
    out = _brand({'primary_color': 'not-a-color'})
    assert out['primary_color'] == '#378ADD'
    assert out['accent_text_color'] == '#ffffff'  # #378ADD luminance < 128


def test_brand_missing_key_uses_default():
    out = _brand({})
    assert out['primary_color'] == '#378ADD'
    assert out['accent_text_color'] == '#ffffff'
