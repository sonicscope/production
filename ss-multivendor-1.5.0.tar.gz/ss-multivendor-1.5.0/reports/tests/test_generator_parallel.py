"""Regression test for the PG16 parallel-worker report bug.

Once a tenant has enough data, PostgreSQL 16 could raise
`InternalError: subplan "SubPlan 1" was not initialized  CONTEXT: parallel
worker` on the periodic report's analytics queries (hit live on snwlrep2,
2026-07-15). generator.py now issues `SET LOCAL max_parallel_workers_per_gather
= 0` at the start of each report transaction so the planner never goes parallel
for report queries (correctness is unaffected; reports aren't latency-critical).

This test drives generate_periodic_report end-to-end against the ephemeral test
DB (empty data) through a recording connection, asserting both that the report
still generates a PDF and that the SET LOCAL is the first statement issued — so
the guard can't be silently dropped."""
from __future__ import annotations

import os
from datetime import datetime, timezone

import psycopg2

from reports.generator import generate_periodic_report


class _RecCursor:
    """Proxies a real psycopg2 cursor, recording every executed statement."""

    def __init__(self, real, sink):
        self._real = real
        self._sink = sink

    def execute(self, query, vars=None):  # noqa: A002 - matches psycopg2 signature
        self._sink.append(query if isinstance(query, str) else str(query))
        return self._real.execute(query, vars)

    def __enter__(self):
        self._real.__enter__()
        return self

    def __exit__(self, *exc):
        return self._real.__exit__(*exc)

    def __iter__(self):
        return iter(self._real)

    def __getattr__(self, name):
        return getattr(self._real, name)


class _RecConn:
    def __init__(self, real):
        self._real = real
        self.executed: list[str] = []

    def cursor(self, *a, **k):
        return _RecCursor(self._real.cursor(*a, **k), self.executed)

    def __getattr__(self, name):
        return getattr(self._real, name)


def test_periodic_report_disables_parallel_gather_and_still_generates(
        app_module, seed_tenants, seed_msp_profile, tmp_path):
    (tenant_id,) = seed_tenants('Acme Corp')
    msp_id = seed_msp_profile('Acme MSP')

    raw = psycopg2.connect(**app_module.DB_CONFIG)
    conn = _RecConn(raw)
    try:
        start = datetime(2026, 1, 1, tzinfo=timezone.utc)
        end = datetime(2026, 2, 1, tzinfo=timezone.utc)
        path = generate_periodic_report(
            conn, tenant_id, msp_id, 'monthly', start, end, str(tmp_path))

        # 1. the report still generates (the SET LOCAL didn't break the path)
        assert path.endswith('.pdf')
        assert os.path.exists(path) and os.path.getsize(path) > 0

        # 2. parallel gather is disabled, transaction-scoped, BEFORE any query
        stmts = [s.strip().lower() for s in conn.executed]
        assert stmts, 'no statements were executed'
        assert stmts[0] == 'set local max_parallel_workers_per_gather = 0', (
            f'first statement was {stmts[0]!r}, expected the parallel-off guard')
    finally:
        raw.close()
