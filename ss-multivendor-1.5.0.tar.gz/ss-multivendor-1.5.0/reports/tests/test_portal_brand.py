"""Unit tests for the pure _portal_brand() helper (reports/web/app.py).

No DB, no Flask client — just the colour-context computation. Imports the
app module the same lightweight way the login-branding tests do (the module
imports cleanly without a DB connection; DB_CONFIG is only used lazily)."""
from __future__ import annotations

import os
import sys

import pytest

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'web')
if WEB_DIR not in sys.path:
    sys.path.insert(0, WEB_DIR)

import app as appmod  # noqa: E402


def test_dark_accent_gets_white_text_and_light_overlays():
    b = appmod._portal_brand({'primary_color': '#001133'})
    assert b['primary_color'] == '#001133'
    assert b['accent_text_color'] == '#ffffff'
    assert b['on_band_muted'] == 'rgba(255,255,255,.8)'
    assert b['on_band_overlay'] == 'rgba(255,255,255,.2)'


def test_light_accent_gets_black_text_and_dark_overlays():
    b = appmod._portal_brand({'primary_color': '#ffff00'})
    assert b['primary_color'] == '#ffff00'
    assert b['accent_text_color'] == '#000000'
    assert b['on_band_muted'] == 'rgba(0,0,0,.65)'
    assert b['on_band_overlay'] == 'rgba(0,0,0,.15)'


@pytest.mark.parametrize('bad', [None, '', 'not-a-color', 'red', '#12', '#12345'])
def test_malformed_primary_falls_back_to_default_accent(bad):
    b = appmod._portal_brand({'primary_color': bad})
    assert b['primary_color'] == appmod._DEFAULT_ACCENT_COLOR
    # default accent (#378ADD) is dark -> white text
    assert b['accent_text_color'] == '#ffffff'


def test_absent_primary_key_falls_back():
    b = appmod._portal_brand({})
    assert b['primary_color'] == appmod._DEFAULT_ACCENT_COLOR
