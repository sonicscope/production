"""Tenant edit page — sensor vendor <select> choices."""


def test_sensor_form_offers_opnsense_vendor(client, seed_tenants, login_as):
    (tid,) = seed_tenants('Acme')
    login_as('admin')
    resp = client.get(f'/tenants/{tid}/edit')
    assert resp.status_code == 200
    assert b'<option value="opnsense">OPNsense</option>' in resp.data
