"""DB-backed test for migration 008 (ipfix_templates)."""
from contextlib import closing

import psycopg2


def _fetch(app_module, sql, params=()):
    with closing(psycopg2.connect(**app_module.DB_CONFIG)) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall()


def test_ipfix_templates_table_exists_and_is_logged(app_module):
    rows = _fetch(
        app_module,
        "SELECT relpersistence FROM pg_class "
        "WHERE relname = 'ipfix_templates' AND relkind = 'r'")
    assert rows == [('p',)]


def test_ipfix_templates_primary_key_upsert(app_module):
    with closing(psycopg2.connect(**app_module.DB_CONFIG)) as conn:
        with conn.cursor() as cur:
            for fields in ('[[8,4,null]]', '[[8,4,null],[12,4,null]]'):
                cur.execute(
                    "INSERT INTO ipfix_templates "
                    "(source_ip, domain_id, template_id, fields, updated_at) "
                    "VALUES ('192.0.2.1', 0, 256, %s::jsonb, now()) "
                    "ON CONFLICT (source_ip, domain_id, template_id) "
                    "DO UPDATE SET fields = EXCLUDED.fields", (fields,))
            cur.execute("SELECT count(*), max(jsonb_array_length(fields)) "
                        "FROM ipfix_templates WHERE source_ip = '192.0.2.1'")
            assert cur.fetchone() == (1, 2)
        conn.rollback()


import os
import sys

_COLLECTOR = os.path.join(os.path.dirname(__file__), '..', '..', 'collector')
if _COLLECTOR not in sys.path:
    sys.path.insert(0, _COLLECTOR)

from template_store import TemplateStore


def _store(app_module):
    return TemplateStore('unused', connect=lambda dsn: psycopg2.connect(**app_module.DB_CONFIG))


def test_store_roundtrip_against_real_schema(app_module):
    import time
    store = _store(app_module)
    store.start()
    try:
        store.submit('192.0.2.77', 5, 300, [(8, 4, None), (12, 4, 9)])
        for _ in range(100):
            rows = [r for r in store.load() if r[0] == '192.0.2.77']
            if rows:
                break
            time.sleep(0.05)
    finally:
        store.stop()
    assert rows == [('192.0.2.77', 5, 300, [(8, 4, None), (12, 4, 9)])]


def test_store_load_prunes_rows_older_than_7_days(app_module):
    with closing(psycopg2.connect(**app_module.DB_CONFIG)) as conn:
        with conn.cursor() as cur:
            cur.execute("INSERT INTO ipfix_templates VALUES "
                        "('192.0.2.88', 0, 256, '[[8,4,null]]', now() - interval '8 days')")
        conn.commit()
    assert [r for r in _store(app_module).load() if r[0] == '192.0.2.88'] == []
    assert _fetch(app_module, "SELECT count(*) FROM ipfix_templates "
                              "WHERE source_ip = '192.0.2.88'") == [(0,)]
