import psycopg2
import pytest

from reports.ai import credentials, store
from reports.ai.net import ProviderError


@pytest.fixture
def cur(app_module):
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    yield conn.cursor()
    conn.rollback()
    conn.close()


@pytest.fixture
def key_path(tmp_path):
    p = str(tmp_path / 'ai.key')
    credentials.generate_key_file(p)
    return p


def test_empty_returns_none(cur):
    assert store.load_settings(cur) is None


def test_save_and_load_roundtrip_hides_key(cur, key_path):
    store.save_settings(cur, provider='anthropic', model='claude-x', api_key='sk-secret-1234',
                        consent_user_id=7, key_path=key_path)
    s = store.load_settings(cur)
    assert (s.provider, s.model, s.api_key_last4, s.key_version) == ('anthropic', 'claude-x',
                                                                      '1234', 1)
    assert s.consent_at is not None and s.consent_provider == 'anthropic'
    assert store.load_api_key(cur, key_path) == 'sk-secret-1234'
    cur.execute('SELECT api_key_enc FROM ai_settings')
    assert b'sk-secret' not in bytes(cur.fetchone()[0])


def test_model_only_update_keeps_key(cur, key_path):
    store.save_settings(cur, provider='openai', model='m1', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    store.save_settings(cur, provider='openai', model='m2', api_key=None,
                        consent_user_id=None, key_path=key_path)
    assert store.load_settings(cur).model == 'm2'
    assert store.load_api_key(cur, key_path) == 'sk-aaaa1111'


def test_validation(cur, key_path):
    with pytest.raises(ValueError):
        store.save_settings(cur, provider='nope', model='m', api_key='sk-valid-key1',
                            consent_user_id=1, key_path=key_path)
    with pytest.raises(ValueError):                                 # new key needs consent
        store.save_settings(cur, provider='openai', model='m', api_key='sk-valid-key1',
                            consent_user_id=None, key_path=key_path)
    with pytest.raises(ValueError):                                 # nothing saved yet, no key
        store.save_settings(cur, provider='openai', model='m', api_key=None,
                            consent_user_id=None, key_path=key_path)
    with pytest.raises(ProviderError):
        store.save_settings(cur, provider='openai', model='bad model!', api_key='sk-valid-key1',
                            consent_user_id=1, key_path=key_path)


def test_changing_provider_requires_new_key(cur, key_path):
    store.save_settings(cur, provider='openai', model='m', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    with pytest.raises(ValueError):
        store.save_settings(cur, provider='gemini', model='m', api_key=None,
                            consent_user_id=None, key_path=key_path)


def test_missing_key_file_fails_closed(cur, key_path, tmp_path):
    store.save_settings(cur, provider='openai', model='m', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    with pytest.raises(credentials.CredentialError):
        store.load_api_key(cur, str(tmp_path / 'other.key'))


def test_tenant_flags(cur, seed_tenants):
    a, b = seed_tenants('A', 'B')
    cur.connection.commit()
    store.set_enabled_tenants(cur, {a})
    flags = {tid: enabled for tid, _, enabled in store.tenant_ai_flags(cur)}
    assert flags[a] is True and flags[b] is False


def _row(cur):
    cur.execute('SELECT api_key_enc, api_key_last4, key_version, consent_user_id, consent_at, '
                'consent_provider FROM ai_settings WHERE id = 1')
    r = cur.fetchone()
    return (bytes(r[0]),) + tuple(r[1:])


@pytest.mark.parametrize('bad', ['short', 'x' * 513, 'sk-abc def-1234', 'sk-abc\ndef-1234',
                                 'sk-\x00abcdef1234', 'sk-é-abcdef1234', '   ', ''])
def test_api_key_shape_rejected_without_leaking(cur, key_path, bad):
    with pytest.raises(ValueError) as e:
        store.save_settings(cur, provider='openai', model='m', api_key=bad,
                            consent_user_id=1, key_path=key_path)
    if bad.strip():
        assert bad.strip() not in str(e.value)
    if bad:  # empty string is treated as "no key" and fails with a different ValueError
        assert str(e.value) in ('the API key does not look valid', 'an API key is required')
    assert store.load_settings(cur) is None


def test_api_key_whitespace_stripped_and_last4(cur, key_path):
    store.save_settings(cur, provider='openai', model='m', api_key='  sk-abcd9876 \n',
                        consent_user_id=1, key_path=key_path)
    assert store.load_settings(cur).api_key_last4 == '9876'
    assert store.load_api_key(cur, key_path) == 'sk-abcd9876'


def test_api_key_length_bounds_accepted(cur, key_path):
    store.save_settings(cur, provider='openai', model='m', api_key='a' * 8,
                        consent_user_id=1, key_path=key_path)
    store.save_settings(cur, provider='openai', model='m', api_key='b' * 512,
                        consent_user_id=1, key_path=key_path)
    assert store.load_api_key(cur, key_path) == 'b' * 512


def test_model_only_update_leaves_key_and_consent_untouched(cur, key_path):
    store.save_settings(cur, provider='openai', model='m1', api_key='sk-aaaa1111',
                        consent_user_id=3, key_path=key_path)
    before = _row(cur)
    store.save_settings(cur, provider='openai', model='m2', api_key=None,
                        consent_user_id=99, key_path=key_path)
    assert _row(cur) == before
    assert store.load_settings(cur).model == 'm2'


def test_set_enabled_tenants_empty_disables_all(cur, seed_tenants):
    a, b = seed_tenants('A', 'B')
    cur.connection.commit()
    store.set_enabled_tenants(cur, {a, b})
    store.set_enabled_tenants(cur, set())
    assert not any(e for _, _, e in store.tenant_ai_flags(cur))


def test_set_enabled_tenants_ignores_unknown_ids(cur, seed_tenants):
    a, b = seed_tenants('A', 'B')
    cur.connection.commit()
    store.set_enabled_tenants(cur, {a, 999999})
    flags = {tid: e for tid, _, e in store.tenant_ai_flags(cur)}
    assert flags == {a: True, b: False}


@pytest.mark.parametrize('bad', [{'1'}, {1.5}, {None}, {True}])
def test_set_enabled_tenants_rejects_non_int(cur, bad):
    with pytest.raises(ValueError):
        store.set_enabled_tenants(cur, bad)


def test_model_only_update_provider_mismatch_message(cur, key_path):
    store.save_settings(cur, provider='openai', model='m1', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    with pytest.raises(ValueError, match='changing provider'):
        store.save_settings(cur, provider='gemini', model='m2', api_key=None,
                            consent_user_id=None, key_path=key_path)


def test_model_only_update_race_detected(cur, key_path, monkeypatch):
    store.save_settings(cur, provider='openai', model='m1', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    stale = store.AISettings('anthropic', 'm1', '1111', 1, None, None)
    monkeypatch.setattr(store, 'load_settings', lambda c: stale)
    with pytest.raises(ValueError, match='settings changed'):
        store.save_settings(cur, provider='anthropic', model='m2', api_key=None,
                            consent_user_id=None, key_path=key_path)
    monkeypatch.undo()
    assert store.load_settings(cur).model == 'm1'


def test_model_only_update_row_missing_race(cur, key_path, monkeypatch):
    stale = store.AISettings('openai', 'm1', '1111', 1, None, None)
    monkeypatch.setattr(store, 'load_settings', lambda c: stale)
    with pytest.raises(ValueError, match='settings changed'):
        store.save_settings(cur, provider='openai', model='m2', api_key=None,
                            consent_user_id=None, key_path=key_path)


def test_wrong_key_file_raises_credential_error(cur, key_path):
    store.save_settings(cur, provider='openai', model='m', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    import os
    os.remove(key_path)
    credentials.generate_key_file(key_path)
    with pytest.raises(credentials.CredentialError):
        store.load_api_key(cur, key_path)


def test_rekey_refreshes_consent(cur, key_path):
    store.save_settings(cur, provider='openai', model='m', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    cur.execute("UPDATE ai_settings SET consent_at = now() - interval '1 day'")
    before = _row(cur)
    store.save_settings(cur, provider='openai', model='m', api_key='sk-bbbb2222',
                        consent_user_id=2, key_path=key_path)
    after = _row(cur)
    assert after[3] == 2 and after[4] > before[4] and after[1] == '2222'


def test_provider_change_with_new_key_succeeds(cur, key_path):
    store.save_settings(cur, provider='openai', model='m', api_key='sk-aaaa1111',
                        consent_user_id=1, key_path=key_path)
    store.save_settings(cur, provider='gemini', model='g1', api_key='gk-cccc3333',
                        consent_user_id=1, key_path=key_path)
    s = store.load_settings(cur)
    assert (s.provider, s.model, s.consent_provider) == ('gemini', 'g1', 'gemini')
    assert store.load_api_key(cur, key_path) == 'gk-cccc3333'
