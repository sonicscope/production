"""Pure render tests for _portal_page() — call it directly with hand-built
dicts (no DB, no Flask client) and assert on the returned HTML."""
from __future__ import annotations

import os
import sys

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'web')
if WEB_DIR not in sys.path:
    sys.path.insert(0, WEB_DIR)

import app as appmod  # noqa: E402


def _msp(**over):
    base = {'id': 1, 'name': 'Acme MSP', 'footer_text': '',
            'logo_path': None, 'contact_email': None, 'website': None}
    base.update(appmod._portal_brand({'primary_color': over.pop('primary_color', '#001133')}))
    base.update(over)
    return base


def _render(**over):
    tenant = {'id': 1, 'name': 'Acme Corp', 'contact_email': None, 'timezone': 'UTC'}
    # current_user() reads flask session; render inside a request/app context
    # with no user -> user_name resolves to '' (the branch is guarded).
    with appmod.app.test_request_context('/portal'):
        return appmod._portal_page('Dashboard', '<p>x</p>', _msp(**over), tenant)


def test_no_sonicscope_anywhere():
    html = _render()
    assert 'SonicScope' not in html
    assert 'Powered by SonicScope' not in html


def test_footer_prefers_footer_text_then_name():
    assert 'Acme IT Services' in _render(footer_text='Acme IT Services')
    html = _render(footer_text='', name='Acme MSP')
    assert 'Acme MSP' in html


def test_light_accent_uses_black_on_band_text():
    html = _render(primary_color='#ffff00')
    # accent_text_color is #000000 for yellow; verify black is actually wired
    # into each on-band text rule, not just present somewhere in the page.
    assert '.portal-brand{display:flex;align-items:center;color:#000000;' in html
    assert '.portal-hero h1{color:#000000;' in html
    assert '.portal-nav a:hover,.portal-nav a.active{background:rgba(0,0,0,.15);color:#000000;}' in html


def test_logo_uses_white_chip_not_flatten_filter():
    # a logo_path that _validated_logo_path accepts is hard to fake without a
    # file; assert the flatten filter is gone from the template regardless of
    # whether a logo renders, and that a rendered logo (when present) is chipped.
    html = _render()
    assert 'brightness(0) invert(1)' not in html


def test_logo_renders_in_white_chip(tmp_path, monkeypatch):
    # _validated_logo_path() requires logo_path to be a real file that resolves
    # (via realpath) inside LOGO_DIR — point LOGO_DIR at a tmp dir holding one.
    logo_dir = tmp_path / 'logos'
    logo_dir.mkdir()
    logo_file = logo_dir / 'brand.png'
    logo_file.write_bytes(b'\x89PNG\r\n\x1a\n\x00fake')
    monkeypatch.setattr(appmod, 'LOGO_DIR', str(logo_dir))

    html = _render(logo_path=str(logo_file))

    assert 'brightness(0) invert(1)' not in html
    assert 'background:#fff;border-radius:6px' in html  # the white chip
    assert '<img src="/logos/brand.png"' in html  # the logo actually rendered


def test_neutral_name_when_msp_name_missing():
    html = _render(name='')
    assert 'SonicScope' not in html
    assert appmod.APP_BRAND in html
