"""DB-backed tests for the live-tap tables (migration 007) and the real
TapFlusher SQL. Imports collector/live_tap.py by adding collector/ to sys.path
(it is deployed in a different package, but its SQL is only provable here
against the real schema)."""
import os
import sys

import psycopg2

_COLLECTOR = os.path.join(os.path.dirname(__file__), '..', '..', 'collector')
if _COLLECTOR not in sys.path:
    sys.path.insert(0, _COLLECTOR)


def _fetch(app_module, sql, params=()):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall()


def test_tap_tables_exist_and_are_unlogged(app_module):
    rows = _fetch(
        app_module,
        "SELECT relname, relpersistence FROM pg_class "
        "WHERE relname IN ('live_tap_feed','live_tap_sample','live_tap_watch') "
        "AND relkind = 'r' ORDER BY relname",
    )
    assert rows == [('live_tap_feed', 'u'), ('live_tap_sample', 'u'),
                    ('live_tap_watch', 'u')]


from live_tap import LiveTap, TapFlusher


def _watch(app_module, seconds_ago):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO live_tap_watch (id, last_poll) "
                "VALUES (1, now() - make_interval(secs => %s)) "
                "ON CONFLICT (id) DO UPDATE SET last_poll = EXCLUDED.last_poll",
                (seconds_ago,))
        conn.commit()


def _flusher(app_module, tap):
    return TapFlusher(tap, dsn='unused',
                      connect=lambda dsn: psycopg2.connect(**app_module.DB_CONFIG))


def test_flush_writes_feed_and_samples_when_watched(app_module):
    tap = LiveTap()
    tap.record('10.9.9.9', 'syslog', 'ok', raw='hello')
    tap.record('10.9.9.9', 'syslog', 'rejected', 'unknown_format', raw='junk')
    _watch(app_module, 1)
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    try:
        assert _flusher(app_module, tap).flush_once(conn) == 'flushed'
    finally:
        conn.close()
    feed = _fetch(app_module,
                  "SELECT host(source_ip), feed, received, ok, rejected "
                  "FROM live_tap_feed")
    assert feed == [('10.9.9.9', 'syslog', 2, 1, {'unknown_format': 1})]
    samples = _fetch(app_module,
                     "SELECT outcome, reason, text FROM live_tap_sample ORDER BY outcome")
    assert samples == [('ok', '', 'hello'), ('rejected', 'unknown_format', 'junk')]


def test_flush_is_idle_when_watch_stale(app_module):
    tap = LiveTap()
    tap.record('10.9.9.9', 'syslog', 'ok', raw='hello')
    _watch(app_module, 120)                      # older than the 30 s window
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    try:
        assert _flusher(app_module, tap).flush_once(conn) == 'idle'
    finally:
        conn.close()
    assert _fetch(app_module, "SELECT count(*) FROM live_tap_feed") == [(0,)]


def test_flush_replaces_samples_not_accumulates(app_module):
    tap = LiveTap()
    _watch(app_module, 1)
    for i in range(2):
        tap.record('10.9.9.9', 'syslog', 'ok', raw=f'x{i}')
        tap._entries[('10.9.9.9', 'syslog')].last_sample.clear()   # bypass limiter
        conn = psycopg2.connect(**app_module.DB_CONFIG)
        try:
            _flusher(app_module, tap).flush_once(conn)
        finally:
            conn.close()
    n = _fetch(app_module, "SELECT count(*) FROM live_tap_sample")
    assert n == [(2,)]       # ring holds 2 distinct samples, rewritten not doubled
