"""Tests for the AI Investigate SQL guard (reports/ai/sql_guard.py).

The guard is the security boundary between model-written SQL and the
database: deny-by-default AST allowlisting plus a server-side tenant rewrite.
"""
import pytest

from reports.ai.sql_guard import (
    ALLOWED_FUNCTIONS,
    ALLOWED_NODES,
    ALLOWED_RELATIONS,
    MAX_SQL_CHARS,
    RAW_TIME_WINDOW_DAYS,
    GuardedQuery,
    GuardError,
    check_sql,
)


def test_pglast_visitor_api_shape():
    """Fails fast if the installed pglast changes the Visitor API this module relies on."""
    from pglast import parse_sql
    from pglast.visitors import Visitor

    seen = []

    class V(Visitor):
        def visit(self, ancestors, node):
            seen.append(type(node).__name__)

    V()(parse_sql('SELECT 1')[0])
    assert 'SelectStmt' in seen


def test_pglast_node_iteration_and_scan_api_shape():
    """The guard walks nodes via ``for member in node`` + getattr, uses
    RangeVar.location as a character offset, AST equality that ignores
    locations, and scan() comment tokens. Fail fast if any of that changes."""
    from pglast import ast, parse_sql
    from pglast.parser import scan

    sql = 'SELECT 1 /* c */ FROM   ai.events'
    stmt = parse_sql(sql)[0].stmt
    assert 'fromClause' in list(stmt)
    rv = stmt.fromClause[0]
    assert isinstance(rv, ast.RangeVar)
    assert sql[rv.location:rv.location + len('ai.events')] == 'ai.events'
    assert parse_sql('SELECT  1')[0].stmt == parse_sql('SELECT 1')[0].stmt
    kinds = {(t.name, sql[t.start:t.end + 1]) for t in scan(sql)}
    assert ('C_COMMENT', '/* c */') in kinds


def test_public_constants():
    assert RAW_TIME_WINDOW_DAYS == 31
    assert MAX_SQL_CHARS == 4000
    assert 'events' in ALLOWED_RELATIONS
    assert 'count' in ALLOWED_FUNCTIONS
    assert 'SelectStmt' in ALLOWED_NODES
    assert issubclass(GuardError, ValueError)
    q = check_sql('SELECT 1', 1)
    assert isinstance(q, GuardedQuery)
    with pytest.raises(Exception):
        q.sql = 'x'  # frozen


GOOD = [
    "SELECT domain, count(*) FROM ai.events GROUP BY domain ORDER BY 2 DESC LIMIT 10",
    "SELECT date_trunc('hour', time) AS h, sum(bytes_sent + bytes_received) FROM ai.events "
    "WHERE time >= now() - interval '1 day' GROUP BY 1 ORDER BY 1",
    "SELECT e.src_ip, host(e.dst_ip) FROM ai.events e WHERE e.src_ip << '10.0.0.0/8'::inet",
    "WITH t AS (SELECT domain, count(*) c FROM ai.events GROUP BY domain) "
    "SELECT * FROM t ORDER BY c DESC LIMIT 5",
    "SELECT a.app_name FROM ai.daily_app a JOIN ai.daily_web w ON w.bucket = a.bucket",
    "SELECT count(*) FILTER (WHERE action = 'deny') FROM ai.events",
    "SELECT CASE WHEN action = 'deny' THEN 1 ELSE 0 END, rank() OVER (ORDER BY bucket) "
    "FROM ai.daily_rule",
    "SELECT * FROM ai.events WHERE time > now() -- trailing comment",
    "select * from AI.EVENTS",
    "SELECT * FROM (SELECT domain FROM ai.events) s",
    "SELECT extract(hour FROM time) FROM ai.events",
    # --- additional legitimate shapes (each exercises an allowlisted construct)
    "SELECT * FROM ai.events WHERE time >= current_date",              # SQLValueFunction
    "SELECT count(*) FROM ai.events WHERE time > current_timestamp - interval '2 hours'",
    "SELECT app_name, sum(bytes) FROM ai.daily_app GROUP BY ROLLUP (app_name)",  # GroupingSet
    "SELECT domain FROM ai.events WHERE action IN ('deny', 'drop') AND domain NOT IN ('x') "
    "AND domain LIKE '%.ru' AND domain ILIKE '%TOR%' AND bytes_sent BETWEEN 1 AND 9",
    "SELECT coalesce(domain, '?'), nullif(action, ''), greatest(bytes_sent, 0) FROM ai.events "
    "WHERE src_ip IS DISTINCT FROM dst_ip AND domain IS NOT NULL",
    "SELECT * FROM ai.daily_app a WHERE EXISTS (SELECT 1 FROM ai.daily_web w "
    "WHERE w.bucket = a.bucket)",
    "SELECT bucket FROM ai.daily_app UNION ALL SELECT bucket FROM ai.daily_web",
    "WITH a AS (SELECT * FROM ai.daily_app), b AS (SELECT * FROM a) SELECT * FROM b",
    "SELECT time AT TIME ZONE 'Africa/Johannesburg' FROM ai.events",
    "SELECT percentile_cont(0.95) WITHIN GROUP (ORDER BY bytes_sent) FROM ai.events",
    "SELECT * FROM ai.events;",
    "SELECT /* a ) comment */ domain FROM ai.events",
    "SELECT * FROM ai.daily_app a LEFT JOIN ai.daily_web w USING (bucket)",
    "SELECT * FROM ai.daily_app a, LATERAL (SELECT * FROM ai.daily_web w "
    "WHERE w.bucket = a.bucket LIMIT 1) l",
    "SELECT sum(bytes) OVER (PARTITION BY app_name ORDER BY bucket "
    "ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) FROM ai.daily_app",
    "SELECT CAST(bytes_sent AS bigint), domain::varchar(10), bytes_sent::numeric(10, 2) "
    "FROM ai.events",
    "SELECT domain FROM ai.events WHERE domain ~ '^ads\\.' AND NOT (action = 'allow')",
    "SELECT * FROM ai.events AS ev(t, tid) WHERE true IS TRUE",
    "SELECT substring(domain FROM 1 FOR 3), trim(domain), lower(domain) FROM ai.events",
    "SELECT DISTINCT domain FROM ai.events ORDER BY domain NULLS LAST",
    "SELECT * FROM ai.events WHERE time > now() - '1 day'::interval OFFSET 5",
    "SELECT * FROM ai.Events",
    "SELECT sum(x) OVER w FROM ai.daily_rule WINDOW w AS (PARTITION BY rule_name)",
    "SELECT * FROM ai.events WHERE src_ip = ANY (SELECT src_ip FROM ai.events LIMIT 3)",
]


@pytest.mark.parametrize('sql', GOOD)
def test_good_queries_pass(sql):
    q = check_sql(sql, 7)
    assert q.original == sql.strip()
    assert 'tenant_id = 7' in q.sql


BAD = [
    ('', 'empty'),
    ('SELECT 1; SELECT 2', 'one statement'),
    ('DROP TABLE tenants', 'SELECT'),
    ("INSERT INTO ai_audit (kind) VALUES ('x')", 'SELECT'),
    ("UPDATE tenants SET name='x'", 'SELECT'),
    ('DELETE FROM tenants', 'SELECT'),
    ("COPY ai.events TO '/tmp/x'", 'SELECT'),
    ('EXPLAIN ANALYZE SELECT * FROM ai.events', 'SELECT'),
    ("SELECT set_config('ss.tenant_id', '2', false)", 'function'),
    ("SELECT current_setting('ss.tenant_id')", 'function'),
    ('SELECT pg_sleep(100)', 'function'),
    ("SELECT pg_read_file('/etc/passwd')", 'function'),
    ("SELECT lo_import('/etc/passwd')", 'function'),
    ('SELECT version()', 'function'),
    ('SELECT current_user', 'not allowed'),
    ('SELECT * FROM public.fw_events', 'relation'),
    ('SELECT * FROM fw_events', 'relation'),
    ('SELECT * FROM pg_catalog.pg_class', 'relation'),
    ('SELECT * FROM information_schema.tables', 'relation'),
    ('SELECT * FROM ai.not_a_view', 'relation'),
    ('SELECT * INTO x FROM ai.events', 'not allowed'),
    ('SELECT * FROM ai.events FOR UPDATE', 'not allowed'),
    ('WITH x AS (DELETE FROM ai.events RETURNING *) SELECT * FROM x', 'not allowed'),
    ('SELECT * FROM generate_series(1, 10)', 'not allowed'),
    ("SELECT 'café'", 'ASCII'),
    ('SELECT $1', 'not allowed'),
    ('SELECT * FROM "ai"."events"', 'unquoted'),
    ('SELECT x' + 'x' * 5000, 'too long'),
]


@pytest.mark.parametrize('sql,fragment', BAD)
def test_bad_queries_rejected(sql, fragment):
    with pytest.raises(GuardError) as exc:
        check_sql(sql, 7)
    assert fragment.lower() in str(exc.value).lower()


# Adversarial cases beyond the brief. Each must raise GuardError (message
# content is not asserted: rejection is what matters).
ATTACKS = [
    # schema-qualified / quoted function names
    'SELECT pg_catalog.pg_sleep(1)',
    "SELECT pg_catalog.set_config('ss.tenant_id', '2', false)",
    'SELECT public.count(*) FROM ai.events',
    'SELECT ai.count(*) FROM ai.events',
    'SELECT "COUNT"(*) FROM ai.events',
    'SELECT x.y.count(*) FROM ai.events',
    "SELECT 'x' || pg_read_file('/etc/passwd')",
    'SELECT * FROM ai.events WHERE pg_sleep(1) IS NULL',
    'SELECT txid_current()',
    'SELECT pg_advisory_lock(1)',
    "SELECT nextval('s')",
    "SELECT dblink('host=x', 'select 1')",
    "SELECT lo_export(1, '/tmp/x')",
    'SELECT pg_terminate_backend(1)',
    "SELECT query_to_xml('select * from tenants', true, true, '')",
    "SELECT domain FROM ai.events WHERE domain SIMILAR TO 'x'",  # similar_to_escape()
    "SELECT position('a' IN domain) FROM ai.events",
    # relation spelling tricks around ai.events
    'SELECT * FROM ai/**/.events',
    'SELECT * FROM ai . events',
    'SELECT * FROM ai.\n events',
    'SELECT * FROM ai."events"',
    'SELECT * FROM "ai".events',
    'SELECT * FROM AI."Events"',
    'SELECT * FROM U&"ai".events',
    'SELECT * FROM ss.ai.events',
    'SELECT * FROM ai.events.x',
    'SELECT * FROM ONLY ai.events',
    'SELECT * FROM ai.events*',
    'TABLE ai.events',
    'SELECT * FROM /* ai.events */ fw_events',
    'SELECT * FROM ai.events e JOIN pg_catalog.pg_authid a ON true',
    'SELECT * FROM ai.events, tenants',
    'SELECT * FROM ai.ai_credentials',
    'SELECT * FROM ai.daily_app WHERE bucket IN (SELECT created_at FROM public.users)',
    'SELECT (SELECT count(*) FROM tenants) FROM ai.events',
    'SELECT * FROM (SELECT * FROM fw_events) s',
    'SELECT ARRAY(SELECT relname FROM pg_class)',
    'SELECT * FROM ai.daily_app WHERE EXISTS (SELECT 1 FROM pg_shadow)',
    # CTE scoping tricks: a non-recursive CTE is NOT visible to itself, to
    # earlier siblings, or outside the subquery that defines it -- those names
    # resolve to real tables.
    'WITH fw_events AS (SELECT * FROM fw_events) SELECT * FROM fw_events',
    'WITH a AS (SELECT * FROM tenants), tenants AS (SELECT * FROM ai.events) SELECT * FROM a',
    'SELECT * FROM (WITH tenants AS (SELECT 1) SELECT * FROM tenants) s, tenants',
    '(WITH users AS (SELECT 1) SELECT * FROM users) UNION SELECT * FROM users',
    'SELECT (WITH users AS (SELECT 1) SELECT 1), * FROM users',
    'WITH RECURSIVE r(n) AS (SELECT 1 UNION ALL SELECT n + 1 FROM r) SELECT * FROM r',
    'WITH t AS (SELECT * FROM ai.events) SELECT * FROM t CROSS JOIN '
    '(WITH u AS (SELECT 1) SELECT 1) x, u',
    # other statement types
    'CREATE TABLE x AS SELECT 1',
    'SELECT 1; DROP TABLE tenants',
    'BEGIN', 'COMMIT', "SET ss.tenant_id = '2'", 'RESET ALL', 'SHOW ALL',
    'DO $$ BEGIN END $$', 'CALL p()', 'LISTEN x', "NOTIFY x, 'y'",
    'PREPARE p AS SELECT 1', 'EXECUTE p', 'DECLARE c CURSOR FOR SELECT 1',
    'VACUUM', 'LOCK TABLE ai.events', 'ANALYZE ai.events',
    'SELECT 1 UNION SELECT * FROM tenants',
    'VALUES (1)',
    'SELECT * FROM (VALUES (1)) v',
    # FROM-clause constructs
    'SELECT * FROM ai.events TABLESAMPLE system(50)',
    'SELECT * FROM unnest(ARRAY[1])',
    "SELECT * FROM pg_ls_dir('.')",
    'SELECT * FROM ROWS FROM (generate_series(1, 2))',
    "SELECT 1 FROM ai.events e, LATERAL pg_ls_dir('.') f",
    "SELECT * FROM XMLTABLE('/a' PASSING '<a/>' COLUMNS x int)",
    # locking anywhere
    'SELECT * FROM ai.events FOR SHARE',
    'SELECT * FROM ai.events LIMIT 1 FOR NO KEY UPDATE',
    'SELECT * FROM (SELECT * FROM ai.events FOR UPDATE) s',
    # constructors / indirection / collation / misc expression nodes
    'SELECT ARRAY[pg_sleep(1)]',
    'SELECT ARRAY[1, 2]',
    'SELECT ROW(version())',
    'SELECT (ROW(1, 2)).f1',
    'SELECT domain COLLATE "C" FROM ai.events',
    'SELECT time AT TIME ZONE pg_sleep(1)::text FROM ai.events',
    "SELECT time AT TIME ZONE current_setting('x') FROM ai.events",
    'SELECT xmlelement(name x)',
    "SELECT JSON_OBJECT('a': 1)",
    'SELECT * FROM ai.events ORDER BY 1 USING <',
    'SELECT GROUPING(domain) FROM ai.events GROUP BY domain',
    # casts to catalog-reading / non-scalar types
    "SELECT 'pg_class'::regclass",
    "SELECT 'fw_events'::regclass::oid",
    "SELECT CAST('now' AS regproc)",
    "SELECT 'x'::pg_catalog.regnamespace",
    "SELECT '1'::\"regclass\"",
    "SELECT 'postgres'::regrole",
    'SELECT NULL::tenants',
    'SELECT NULL::public.tenants',
    "SELECT 'a'::xml",
    "SELECT 'x'::text::regtype",
    'SELECT bytes_sent::int8::regclass FROM ai.events',
    # operators
    'SELECT 1 OPERATOR(pg_catalog.+) 1',
    'SELECT 1 OPERATOR(public.===) 1',
    'SELECT 1 === 1',
    'SELECT 1 FROM ai.events WHERE 1 OPERATOR(public.=) ANY (SELECT 1)',
    'SELECT 1 FROM ai.events WHERE 1 @@@ ANY (SELECT 1)',
    # session / role introspection
    'SELECT session_user', 'SELECT current_role', 'SELECT user',
    'SELECT current_schema', 'SELECT current_catalog',
    # parameters / NUL / control characters
    'SELECT $1 FROM ai.events',
    'SELECT * FROM ai.events\x00; DROP TABLE tenants',
    'SELECT 1\x00',
    'SELECT 1\x0bFROM ai.events',
    'SELECT 1\x1b FROM ai.events',
    # length and nesting bombs
    'SELECT 1 FROM ai.events WHERE src_ip IN (' + ', '.join(['1'] * 1500) + ')',
    'SELECT ' + '(SELECT ' * 300 + '1' + ')' * 300,
    'SELECT ' + 'abs(' * 700 + '1' + ')' * 700,
    'SELECT 1' + ' + 1' * 990,
    'SELECT 1 FROM ai.events WHERE ' + 'NOT ' * 900 + 'true',
    # syntax errors of all kinds surface as GuardError
    'SELEC * FRO ai.events',
    "SELECT 'unterminated",
    'SELECT /* unterminated comment',
    '   \n\t  ',
    ';',
]


@pytest.mark.parametrize('sql', ATTACKS)
def test_attacks_rejected(sql):
    with pytest.raises(GuardError):
        check_sql(sql, 7)


@pytest.mark.parametrize('bad_sql', [None, 7, b'SELECT 1', ['SELECT 1'], object()])
def test_non_string_sql_is_guard_error(bad_sql):
    with pytest.raises(GuardError):
        check_sql(bad_sql, 7)


def test_syntax_error_is_guard_error():
    with pytest.raises(GuardError):
        check_sql('SELEC * FRO ai.events', 7)


_BAD_TENANTS = [0, -1, True, False, '7', None, 7.0, 2**63, 10**5000, -(10**5000)]


@pytest.mark.parametrize('bad', _BAD_TENANTS,
                         ids=['0', '-1', 'True', 'False', 'str', 'None', 'float', '2**63',
                              '10**5000', '-10**5000'])
def test_tenant_id_must_be_positive_int(bad):
    # pytest.raises(GuardError) fails if any OTHER exception type escapes.
    with pytest.raises(GuardError):
        check_sql('SELECT * FROM ai.daily_app', bad)


class _HostileFormat(int):
    def __format__(self, spec):
        return '7 OR true'


class _HostileStr(int):
    def __str__(self):
        return '7 OR true'


class _HostileRepr(int):
    def __repr__(self):
        return '7 OR true'


class _HostileCompare(int):
    def __lt__(self, other):
        return False

    def __le__(self, other):
        return True

    def __ge__(self, other):
        return True


@pytest.mark.parametrize('cls', [_HostileFormat, _HostileStr, _HostileRepr, _HostileCompare])
def test_int_subclass_tenant_is_rejected(cls):
    with pytest.raises(GuardError, match='invalid tenant'):
        check_sql('SELECT * FROM ai.daily_app', cls(7))


def test_max_bigint_tenant_is_accepted():
    q = check_sql('SELECT * FROM ai.daily_app', 2**63 - 1)
    assert q.sql == ('SELECT * FROM (SELECT * FROM ai.daily_app WHERE tenant_id = '
                     '9223372036854775807) AS daily_app')


def test_verifier_rejects_hostile_tenant_too():
    from reports.ai.sql_guard import _verify_rewrite
    with pytest.raises(GuardError, match='invalid tenant'):
        _verify_rewrite('SELECT * FROM (SELECT * FROM ai.daily_app WHERE tenant_id = 7 '
                        'OR true) x', _HostileFormat(7), 1)


def test_attribute_notation_function_call_is_known_gap():
    """KNOWN GAP (documented in the sql_guard module docstring): PostgreSQL
    resolves ``e.to_json`` as ``to_json(e)``; the parser cannot distinguish it
    from a column reference, so it is NOT checked against ALLOWED_FUNCTIONS.
    The argument is a row of an already tenant-filtered view, and the residual
    exposure is bounded by the ss_ai_ro role (search_path, grants, read-only,
    timeout). If the guard ever learns view column names and closes this gap,
    flip this test to expect GuardError -- deliberately."""
    q = check_sql('SELECT e.to_json FROM ai.events e', 7)
    assert '(SELECT * FROM ai.events WHERE tenant_id = 7' in q.sql


def test_rewrite_injects_tenant_and_time_window_for_events():
    q = check_sql('SELECT domain, count(*) FROM ai.events GROUP BY domain', 7)
    assert q.sql == (
        "SELECT domain, count(*) FROM (SELECT * FROM ai.events WHERE tenant_id = 7 "
        "AND time >= now() - interval '31 days') AS events GROUP BY domain")
    assert q.relations == ('events',)


def test_rewrite_keeps_user_alias_and_no_time_window_on_aggregates():
    q = check_sql('SELECT a.app_name FROM ai.daily_app a', 3)
    assert q.sql == ('SELECT a.app_name FROM (SELECT * FROM ai.daily_app '
                     'WHERE tenant_id = 3) a')


def test_rewrite_handles_multiple_relations_and_cte_names():
    q = check_sql(
        'WITH t AS (SELECT * FROM ai.daily_web) SELECT * FROM t, ai.daily_geo g', 9)
    assert q.sql.count('tenant_id = 9') == 2
    assert 'FROM t,' in q.sql
    assert q.relations == ('daily_geo', 'daily_web')


def test_model_cannot_choose_tenant():
    # A WHERE clause naming another tenant only intersects with the injected one.
    q = check_sql('SELECT * FROM ai.daily_app WHERE tenant_id = 99', 4)
    assert 'tenant_id = 4' in q.sql


def test_model_cannot_widen_tenant_with_or():
    q = check_sql('SELECT * FROM ai.daily_app WHERE tenant_id = 99 OR true', 4)
    assert q.sql == ('SELECT * FROM (SELECT * FROM ai.daily_app WHERE tenant_id = 4) '
                     'AS daily_app WHERE tenant_id = 99 OR true')


def test_every_view_reference_is_wrapped():
    q = check_sql('SELECT * FROM ai.daily_app a WHERE EXISTS '
                  '(SELECT 1 FROM ai.daily_app b WHERE b.bucket = a.bucket)', 5)
    assert q.sql.count('FROM ai.daily_app WHERE tenant_id = 5)') == 2
    assert q.relations == ('daily_app',)


def test_comments_and_trailing_semicolon_are_stripped_from_rewrite():
    """The executor may wrap q.sql (e.g. in a LIMITing subquery): a trailing
    `--` comment or `;` must not survive into the rewrite."""
    q = check_sql('SELECT * /* x */ FROM ai.daily_app -- tail ) ;\n;', 2)
    assert '--' not in q.sql and '/*' not in q.sql
    assert not q.sql.rstrip().endswith(';')
    assert q.sql == ('SELECT *   FROM (SELECT * FROM ai.daily_app WHERE tenant_id = 2) '
                     'AS daily_app')
    assert q.original == 'SELECT * /* x */ FROM ai.daily_app -- tail ) ;\n;'


def test_relations_are_case_folded():
    q = check_sql('SELECT * FROM AI.Daily_Geo', 1)
    assert q.relations == ('daily_geo',)
    assert '(SELECT * FROM ai.daily_geo WHERE tenant_id = 1) AS daily_geo' in q.sql


def test_cte_named_like_a_view_is_not_wrapped():
    q = check_sql('WITH events AS (SELECT * FROM ai.daily_app) SELECT * FROM events', 6)
    assert q.sql.count('tenant_id = 6') == 1
    assert q.relations == ('daily_app',)


def test_negation_bomb_folds_to_a_single_constant():
    """libpg_query folds repeated unary minus on a literal into one A_Const,
    so this cannot nest; it is accepted and harmless."""
    q = check_sql('SELECT ' + '- ' * 1900 + '1', 7)
    assert q.relations == ()
    assert 'tenant_id' not in q.sql


def test_many_nested_view_subqueries_are_all_wrapped():
    """Deep-but-legal nesting within MAX_SQL_CHARS is accepted only because
    every one of the view references is tenant-wrapped."""
    sql = ('SELECT * FROM ai.daily_app WHERE '
           + 'EXISTS (SELECT 1 FROM ai.daily_app WHERE ' * 60 + 'true' + ')' * 60)
    q = check_sql(sql, 7)
    assert q.sql.count('FROM ai.daily_app WHERE tenant_id = 7)') == 61
    assert q.sql.count('ai.daily_app') == 61


def test_large_tenant_id_is_literal_integer():
    q = check_sql('SELECT * FROM ai.daily_app', 2**40)
    assert f'tenant_id = {2**40})' in q.sql


@pytest.mark.parametrize('sql', ['TABLE ai.events', 'SELECT * FROM ai.events*'])
def test_unrewritable_shapes_get_a_clear_message(sql):
    with pytest.raises(GuardError, match='cannot be safely rewritten'):
        check_sql(sql, 7)


@pytest.mark.parametrize('rewritten,count', [
    ('SELECT * FROM ai.daily_app', 1),                                         # unwrapped
    ('SELECT * FROM (SELECT * FROM ai.daily_app WHERE tenant_id = 8) x', 1),   # wrong tenant
    ('SELECT * FROM (SELECT * FROM ai.daily_app WHERE tenant_id = 7 OR true) x', 1),
    ('SELECT * FROM (SELECT * FROM ai.events WHERE tenant_id = 7) x', 1),      # no window
    ('SELECT * FROM (SELECT * FROM ai.daily_app, ai.daily_web '
     'WHERE tenant_id = 7) x', 2),                                             # extra relation
    ('SELECT * FROM (SELECT * FROM ai.daily_app WHERE tenant_id = 7) x', 2),   # count mismatch
    ('SELECT * FROM (SELECT * FROM public.daily_app WHERE tenant_id = 7) x', 1),
    ('SELECT 1; SELECT 2', 0),
    ('SELECT (', 0),
])
def test_post_rewrite_verifier_rejects_tampered_output(rewritten, count):
    from reports.ai.sql_guard import _verify_rewrite
    with pytest.raises(GuardError):
        _verify_rewrite(rewritten, 7, count)


def test_post_rewrite_verifier_accepts_exact_wrappers():
    from reports.ai.sql_guard import _verify_rewrite
    _verify_rewrite("SELECT * FROM (SELECT * FROM ai.events WHERE tenant_id = 7 AND "
                    "time >= now() - interval '31 days') e JOIN (SELECT * FROM "
                    "ai.daily_app WHERE tenant_id = 7) a ON true", 7, 2)


def test_rewrite_output_is_a_single_select():
    from pglast import ast, parse_sql
    for sql in GOOD:
        stmts = parse_sql(check_sql(sql, 7).sql)
        assert len(stmts) == 1 and isinstance(stmts[0].stmt, ast.SelectStmt)


def _cols(n: int) -> str:
    return ', '.join(f'{i} AS c{i}' for i in range(n))


def test_select_column_cap_accepts_100_and_rejects_101():
    check_sql(f'SELECT {_cols(100)} FROM ai.events', 1)
    with pytest.raises(GuardError, match='too many columns'):
        check_sql(f'SELECT {_cols(101)} FROM ai.events', 1)


def test_select_column_cap_rejects_repeated_star():
    with pytest.raises(GuardError, match='too many columns'):
        check_sql('SELECT ' + ', '.join(['*'] * 101) + ' FROM ai.events', 1)
    check_sql('SELECT ' + ', '.join(['*'] * 100) + ' FROM ai.events', 1)


def test_select_column_cap_applies_to_subselects_and_ctes():
    wide = f'SELECT {_cols(101)} FROM ai.events'
    with pytest.raises(GuardError, match='too many columns'):
        check_sql(f'SELECT 1 FROM ({wide}) s', 1)
    with pytest.raises(GuardError, match='too many columns'):
        check_sql(f'WITH w AS ({wide}) SELECT 1 FROM w', 1)
