import json
import time

import psycopg2
import psycopg2.errors
import pytest

from reports.ai import executor
from reports.ai.sql_guard import GuardedQuery, check_sql


def run(cfg, tenant, sql, **kw):
    return executor.run_query(cfg, tenant, check_sql(sql, tenant), **kw)


def _ai_sessions(app_module) -> int:
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute("SELECT count(*) FROM pg_stat_activity WHERE usename = 'ss_ai_ro'")
        return cur.fetchone()[0]


def _wait_no_sessions(app_module, seconds: float = 3.0) -> int:
    deadline = time.monotonic() + seconds
    n = _ai_sessions(app_module)
    while n and time.monotonic() < deadline:
        time.sleep(0.1)
        n = _ai_sessions(app_module)
    return n


def test_ai_db_config_requires_password():
    with pytest.raises(executor.ExecutorError):
        executor.ai_db_config({'DB_HOST': 'h'})
    cfg = executor.ai_db_config({'AI_DB_PASSWORD': 'pw', 'DB_HOST': 'h', 'DB_PORT': '5433',
                                 'DB_NAME': 'd'})
    assert cfg == {'host': 'h', 'port': 5433, 'dbname': 'd', 'user': 'ss_ai_ro',
                   'password': 'pw'}


def test_returns_only_the_locked_tenant(ai_ro_config, seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example', bytes_sent=5)
    seed_fw_event(b, domain='b.example', bytes_sent=7)
    res = run(ai_ro_config, a, 'SELECT domain, bytes_sent FROM ai.events')
    assert res.columns == ('domain', 'bytes_sent')
    assert res.rows == (('a.example', 5),)
    assert res.truncated is False


def test_model_tenant_filter_cannot_widen(ai_ro_config, seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example')
    seed_fw_event(b, domain='b.example')
    res = run(ai_ro_config, a, f'SELECT domain FROM ai.events WHERE tenant_id = {b} OR true')
    assert res.rows == (('a.example',),)


def test_row_cap_truncates(ai_ro_config, seed_tenants, seed_fw_event):
    a, = seed_tenants('A')
    for i in range(5):
        seed_fw_event(a, domain=f'd{i}.example')
    res = run(ai_ro_config, a, 'SELECT domain FROM ai.events ORDER BY domain', max_rows=3)
    assert len(res.rows) == 3 and res.truncated is True


def test_values_are_json_safe(ai_ro_config, seed_tenants, seed_fw_event):
    a, = seed_tenants('A')
    seed_fw_event(a, domain='a.example', src_ip='10.1.2.3')
    res = run(ai_ro_config, a, 'SELECT time, src_ip, sum(bytes_sent) FROM ai.events '
                               'GROUP BY time, src_ip')
    assert res.rows
    json.dumps(res.rows)                      # must not raise


def test_cost_cap_rejects_expensive_plan(ai_ro_config, seed_tenants):
    a, = seed_tenants('A')
    with pytest.raises(executor.ExecutorError) as exc:
        run(ai_ro_config, a, 'SELECT count(*) FROM ai.events', cost_limit=0.001)
    assert 'too expensive' in str(exc.value)


def test_unrewritten_query_still_fails_closed_without_tenant_guc(ai_ro_config, seed_tenants,
                                                                 seed_fw_event):
    """Defence in depth: even a guard-bypassing raw view query sees only the GUC tenant."""
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example')
    seed_fw_event(b, domain='b.example')
    raw = GuardedQuery('x', 'SELECT domain FROM ai.events', ('events',))
    res = executor.run_query(ai_ro_config, a, raw)
    assert res.rows == (('a.example',),)


def test_database_errors_are_safe_messages(ai_ro_config, seed_tenants):
    a, = seed_tenants('A')
    bad = GuardedQuery('x', 'SELECT nonexistent_col FROM ai.events', ('events',))
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query(ai_ro_config, a, bad)
    assert 'nonexistent_col' in str(exc.value)


def test_connection_failure_is_safe(seed_tenants):
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query({'host': '127.0.0.1', 'port': 1, 'dbname': 'x', 'user': 'u',
                            'password': 'p'}, 1, GuardedQuery('x', 'SELECT 1', ()))
    assert str(exc.value) == 'could not connect to the database'
    assert '127.0.0.1' not in str(exc.value)
    assert exc.value.__cause__ is None


def test_time_bucket_runs_as_ai_role(ai_ro_config, seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example', bytes_sent=5)
    seed_fw_event(a, domain='a2.example', bytes_sent=6)
    seed_fw_event(b, domain='b.example', bytes_sent=100)
    res = run(ai_ro_config, a,
              "SELECT time_bucket('1 hour', time) AS hour, sum(bytes_sent) AS total "
              "FROM ai.events GROUP BY 1 ORDER BY 1")
    assert res.columns == ('hour', 'total')
    assert len(res.rows) == 1 and res.rows[0][1] == 11
    json.dumps(res.rows)


def test_cte_and_join_of_two_views_is_tenant_locked(ai_ro_config, seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example', bytes_sent=5)
    seed_fw_event(b, domain='b.example', bytes_sent=7)
    sql = ('WITH recent AS (SELECT sensor_id, domain FROM ai.events) '
           'SELECT r.domain, h.bytes_total FROM recent r '
           'LEFT JOIN ai.hourly_bandwidth h ON h.sensor_id = r.sensor_id')
    res = run(ai_ro_config, a, sql)
    assert [r[0] for r in res.rows] == ['a.example']


@pytest.mark.parametrize('kind', ['cost', 'sql_error'])
def test_connection_closed_after_errors(app_module, ai_ro_config, seed_tenants, kind):
    a, = seed_tenants('A')
    with pytest.raises(executor.ExecutorError):
        if kind == 'cost':
            run(ai_ro_config, a, 'SELECT count(*) FROM ai.events', cost_limit=0.001)
        else:
            executor.run_query(ai_ro_config, a,
                               GuardedQuery('x', 'SELECT nope FROM ai.events', ('events',)))
    assert _wait_no_sessions(app_module) == 0


def test_connection_closed_after_success(app_module, ai_ro_config, seed_tenants):
    a, = seed_tenants('A')
    run(ai_ro_config, a, 'SELECT count(*) FROM ai.events')
    assert _wait_no_sessions(app_module) == 0


def test_timeout_maps_to_safe_message(monkeypatch):
    """The role's 10s statement_timeout is not altered in tests; instead a fake
    connection raises QueryCanceled and we assert the mapping + cleanup."""
    state = {'rolled_back': False, 'closed': False}

    class Cur:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def execute(self, sql, params=None):
            raise psycopg2.errors.QueryCanceled('canceling statement due to statement timeout')

    class Conn:
        def set_session(self, **kw):
            pass

        def cursor(self):
            return Cur()

        def rollback(self):
            state['rolled_back'] = True

        def close(self):
            state['closed'] = True

    monkeypatch.setattr(executor.psycopg2, 'connect', lambda **kw: Conn())
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query({}, 1, GuardedQuery('x', 'SELECT 1', ()))
    assert 'time limit' in str(exc.value)
    assert state == {'rolled_back': True, 'closed': True}


@pytest.mark.parametrize('sql', [
    "SELECT 1; SELECT 'abc'",
    'SELECT 1; SELECT pg_sleep(0.2)',
    'SELECT 1) AS z; SELECT 2 FROM (SELECT 1',
    'SELECT 1;',
    'INSERT INTO t VALUES (1)',
    'SELEC',
])
def test_multi_statement_and_non_select_rejected(ai_ro_config, seed_tenants, sql):
    a, = seed_tenants('A')
    with pytest.raises(executor.ExecutorError):
        executor.run_query(ai_ro_config, a, GuardedQuery('x', sql, ()))


def test_set_config_leak_is_blocked(ai_ro_config, seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example')
    seed_fw_event(b, domain='secret-b.example')
    leak = (f"SELECT 1; SELECT set_config('ss.tenant_id','{b}',true); "
            "SELECT CAST((SELECT string_agg(domain, ',') FROM ai.events) AS int)")
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query(ai_ro_config, a, GuardedQuery('x', leak, ('events',)))
    assert 'secret-b' not in str(exc.value)


@pytest.mark.parametrize('bad', [True, '1', 1.0, None, 0, -1, 2**63])
def test_bad_tenant_rejected(bad):
    with pytest.raises(executor.ExecutorError):
        executor.run_query({}, bad, GuardedQuery('x', 'SELECT 1', ()))


@pytest.mark.parametrize('kw', [
    {'max_rows': 0}, {'max_rows': True}, {'max_rows': '5'},
    {'cost_limit': float('nan')}, {'cost_limit': float('inf')}, {'cost_limit': -1.0},
    {'cost_limit': True}, {'cost_limit': 0},
])
def test_bad_limits_rejected(kw):
    with pytest.raises(executor.ExecutorError):
        executor.run_query({}, 1, GuardedQuery('x', 'SELECT 1', ()), **kw)


def test_bad_db_port_is_executor_error():
    with pytest.raises(executor.ExecutorError):
        executor.ai_db_config({'AI_DB_PASSWORD': 'pw', 'DB_PORT': 'abc'})


class _FakeConn:
    def __init__(self, cur_factory):
        self._cur = cur_factory
        self.closed = False

    def set_session(self, **kw):
        pass

    def cursor(self):
        return self._cur()

    def rollback(self):
        pass

    def close(self):
        self.closed = True


def _fake_cursor(plan_result=None, boom=None):
    class Cur:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def execute(self, sql, params=None):
            if boom is not None:
                raise boom

        def fetchone(self):
            return plan_result
    return Cur


@pytest.mark.parametrize('plan', [[], [[]], [[{}]], [[{'Plan': {}}]], [[{'Plan': {'Total Cost': 'x'}}]],
                                  None])
def test_malformed_plan_is_safe(monkeypatch, plan):
    monkeypatch.setattr(executor.psycopg2, 'connect',
                        lambda **kw: _FakeConn(_fake_cursor(plan_result=plan)))
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query({}, 1, GuardedQuery('x', 'SELECT 1', ()))
    assert str(exc.value) == 'could not estimate query cost'


def test_unexpected_exception_is_masked_and_logged(monkeypatch, caplog):
    conns = []

    def connect(**kw):
        c = _FakeConn(_fake_cursor(boom=RuntimeError('secret internal detail')))
        conns.append(c)
        return c

    monkeypatch.setattr(executor.psycopg2, 'connect', connect)
    with caplog.at_level('ERROR', logger='ss.ai.executor'):
        with pytest.raises(executor.ExecutorError) as exc:
            executor.run_query({}, 1, GuardedQuery('x', 'SELECT 1', ()))
    assert str(exc.value) == 'query failed'
    assert 'secret' not in str(exc.value) and exc.value.__cause__ is None
    assert any(r.name == 'ss.ai.executor' for r in caplog.records)
    assert conns[0].closed


def test_jsonable_edge_values(ai_ro_config, seed_tenants):
    a, = seed_tenants('A')
    sql = ("SELECT 'NaN'::numeric AS n1, 'Infinity'::float8 AS n2, '-Infinity'::float8 AS n3, "
           "'NaN'::float8 AS n4, 1e400::numeric AS n5, 10::numeric ^ 1000 AS n6, "
           "'\\xdeadbeef'::bytea AS n7, ARRAY[1,2] AS n8, '{\"a\":1}'::jsonb AS n9, "
           "interval '1 day 2 hours' AS n10, 9007199254740993::bigint AS n11, "
           "1.5::numeric AS n12")
    res = executor.run_query(ai_ro_config, a, GuardedQuery('x', sql, ()))
    json.dumps(res.rows, allow_nan=False)
    row = dict(zip(res.columns, res.rows[0]))
    assert row['n1'] == 'NaN' and row['n2'] == 'Infinity' and row['n3'] == '-Infinity'
    assert row['n4'] == 'NaN'
    assert isinstance(row['n5'], str) and isinstance(row['n6'], str)
    assert row['n7'] == '\\xdeadbeef'
    assert row['n8'] == [1, 2] and row['n9'] == {'a': 1}
    assert row['n10'] == '1 day, 2:00:00'
    assert row['n11'] == '9007199254740993'
    assert row['n12'] == 1.5


def test_oversized_sql_rejected_before_parsing(monkeypatch):
    parsed, connected = [], []
    monkeypatch.setattr(executor, 'parse_sql', lambda t: parsed.append(t))
    monkeypatch.setattr(executor.psycopg2, 'connect', lambda **kw: connected.append(1))
    big = 'SELECT 1' + ' + 1' * 6000
    assert len(big) > 20_000
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query({}, 1, GuardedQuery('x', big, ()))
    assert str(exc.value) == 'query rejected'
    assert parsed == [] and connected == []


def test_normal_4000_char_query_runs(ai_ro_config, seed_tenants):
    a, = seed_tenants('A')
    sql = 'SELECT 1 AS x /* ' + 'p' * 3900 + ' */'
    res = run(ai_ro_config, a, sql)
    assert res.rows == ((1,),)


@pytest.mark.parametrize('cfg', [None, 5, {'host': 'h', 'password': 'p\udc80'}])
def test_connect_failures_with_odd_config_are_safe(cfg):
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query(cfg, 1, GuardedQuery('x', 'SELECT 1', ()))
    assert str(exc.value) == 'could not connect to the database'
    assert exc.value.__cause__ is None


def test_huge_cost_limit_is_executor_error():
    with pytest.raises(executor.ExecutorError) as exc:
        executor.run_query({}, 1, GuardedQuery('x', 'SELECT 1', ()), cost_limit=10**400)
    assert str(exc.value) == 'invalid cost limit'


def test_decimal_precision_preserved():
    from decimal import Decimal
    j = executor._jsonable
    assert j(Decimal('1.000000000000000001')) == '1.000000000000000001'
    assert j(Decimal('1e-400')) == '1E-400'
    assert j(Decimal('0.1')) == 0.1 and isinstance(j(Decimal('0.1')), float)
    assert j(Decimal('12.5')) == 12.5
