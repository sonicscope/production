"""/live/data — payload + access control (DB-backed)."""
import psycopg2


def _exec(app_module, sql, params=()):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
        conn.commit()


def _sensor(app_module, tenant_id, name, ip, vendor='sonicwall'):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO sensors (tenant_id, name, vendor, ip_address, data_sources) "
                "VALUES (%s, %s, %s, %s::inet, %s) RETURNING id",
                (tenant_id, name, vendor, ip, ['ipfix', 'syslog']))
            sid = cur.fetchone()[0]
        conn.commit()
    return sid


def _tap_feed(app_module, ip, feed='syslog', received=10, ok=9, skipped=0,
              rejected='{}', age_s=2):
    _exec(app_module,
          "INSERT INTO live_tap_feed (source_ip, feed, received, ok, skipped, "
          "rejected, last_seen) VALUES (%s::inet, %s, %s, %s, %s, %s::jsonb, "
          "now() - make_interval(secs => %s))",
          (ip, feed, received, ok, skipped, rejected, age_s))


def _tap_sample(app_module, ip, text, feed='syslog', outcome='ok', reason=''):
    _exec(app_module,
          "INSERT INTO live_tap_sample (source_ip, feed, ts, outcome, reason, text) "
          "VALUES (%s::inet, %s, now(), %s, %s, %s)",
          (ip, feed, outcome, reason, text))


def test_admin_gets_feeds_samples_and_marks_watched(client, app_module,
                                                    seed_tenants, login_as):
    t, = seed_tenants('Acme')
    sid = _sensor(app_module, t, 'HQ', '10.0.8.1')
    _tap_feed(app_module, '10.0.8.1', 'syslog', received=50, ok=48,
              rejected='{"unparseable": 2}')
    _tap_sample(app_module, '10.0.8.1', 'filterlog: 5,,,')
    login_as('admin')

    resp = client.get(f'/live/data?fw={sid}')
    assert resp.status_code == 200
    data = resp.get_json()
    assert data['mode'] == 'registered'
    assert data['needs_migration'] is False
    assert data['feeds'][0]['feed'] == 'syslog'
    assert data['feeds'][0]['status'] == 'live'
    assert data['feeds'][0]['rejected'] == {'unparseable': 2}
    assert data['samples'][0]['text'] == 'filterlog: 5,,,'
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT last_poll > now() - interval '5 seconds' "
                        "FROM live_tap_watch WHERE id = 1")
            assert cur.fetchone() == (True,)


def test_registered_view_includes_recent_stored_events(client, app_module,
                                                      seed_tenants, login_as):
    t, = seed_tenants('Acme')
    sid = _sensor(app_module, t, 'HQ', '10.0.8.1')
    _exec(app_module,
          "INSERT INTO fw_events (time, tenant_id, sensor_id, vendor, data_source, "
          "event_type, action, src_ip, dst_ip, dst_port, protocol) VALUES "
          "(now(), %s, %s, 'sonicwall', 'ipfix', 'traffic', 'allow', "
          "'192.168.8.40', '1.1.1.1', 443, 'tcp')", (t, sid))
    login_as('admin')
    data = client.get(f'/live/data?fw={sid}').get_json()
    assert len(data['events']) == 1
    assert data['events'][0]['dst_port'] == 443


def test_admin_unregistered_group_lists_only_unregistered_sources(
        client, app_module, seed_tenants, login_as):
    t, = seed_tenants('Acme')
    _sensor(app_module, t, 'HQ', '10.0.8.1')
    _tap_feed(app_module, '10.0.8.1')                       # registered
    _tap_feed(app_module, '10.0.8.77', received=3, ok=0,
              rejected='{"not_allowlisted": 3}', age_s=1)    # unregistered
    _tap_sample(app_module, '10.0.8.77', 'raw junk', outcome='rejected',
                reason='not_allowlisted')
    login_as('admin')
    data = client.get('/live/data?fw=unregistered').get_json()
    assert data['mode'] == 'unregistered'
    assert [f['source_ip'] for f in data['feeds']] == ['10.0.8.77']
    assert data['feeds'][0]['rejected'] == {'not_allowlisted': 3}
    assert data['samples'][0]['source_ip'] == '10.0.8.77'
    assert data['events'] == []


def test_user_cannot_see_other_tenants_firewall(client, app_module,
                                                seed_tenants, login_as):
    a, b = seed_tenants('A', 'B')
    sid_b = _sensor(app_module, b, 'B-fw', '10.0.9.1')
    _tap_feed(app_module, '10.0.9.1')
    _tap_sample(app_module, '10.0.9.1', 'SECRET-B-user=jdoe')
    login_as('user', tenant_ids=[a])
    resp = client.get(f'/live/data?fw={sid_b}')
    assert resp.status_code == 404
    assert 'SECRET-B-user=jdoe' not in resp.get_data(as_text=True)


def test_user_can_see_own_tenants_firewall(client, app_module, seed_tenants,
                                           login_as):
    a, = seed_tenants('A')
    sid = _sensor(app_module, a, 'A-fw', '10.0.9.2')
    login_as('user', tenant_ids=[a])
    assert client.get(f'/live/data?fw={sid}').status_code == 200


def test_user_cannot_see_unregistered_group(client, app_module, seed_tenants,
                                            login_as):
    a, = seed_tenants('A')
    login_as('user', tenant_ids=[a])
    assert client.get('/live/data?fw=unregistered').status_code == 404


def test_customer_is_kept_out(client, app_module, seed_tenants, login_as):
    a, = seed_tenants('A')
    sid = _sensor(app_module, a, 'A-fw', '10.0.9.3')
    login_as('customer', tenant_ids=[a])
    resp = client.get(f'/live/data?fw={sid}')
    assert resp.status_code == 302 and '/portal' in resp.headers['Location']


def test_anonymous_redirected_to_login(client):
    assert client.get('/live/data?fw=1').status_code == 302


def test_bad_fw_param_is_404(client, login_as):
    login_as('admin')
    assert client.get('/live/data?fw=abc').status_code == 404
    assert client.get('/live/data').status_code == 404
    assert client.get('/live/data?fw=999999').status_code == 404


def test_missing_migration_returns_friendly_flag_not_500(client, app_module,
                                                        seed_tenants, login_as):
    t, = seed_tenants('Acme')
    sid = _sensor(app_module, t, 'HQ', '10.0.8.1')
    _exec(app_module, "DROP TABLE live_tap_watch")
    try:
        login_as('admin')
        resp = client.get(f'/live/data?fw={sid}')
        assert resp.status_code == 200
        assert resp.get_json()['needs_migration'] is True
    finally:
        _exec(app_module,
              "CREATE UNLOGGED TABLE live_tap_watch (id integer PRIMARY KEY "
              "DEFAULT 1 CHECK (id = 1), last_poll timestamptz NOT NULL)")


def test_html_in_sample_is_returned_as_data(client, app_module, seed_tenants,
                                            login_as):
    t, = seed_tenants('Acme')
    sid = _sensor(app_module, t, 'HQ', '10.0.8.1')
    _tap_feed(app_module, '10.0.8.1')
    _tap_sample(app_module, '10.0.8.1', '<script>alert(1)</script>')
    login_as('admin')
    data = client.get(f'/live/data?fw={sid}').get_json()
    assert data['samples'][0]['text'] == '<script>alert(1)</script>'


def test_duplicate_ip_hides_tap_data_from_other_tenant_user(
        client, app_module, seed_tenants, login_as):
    a, b = seed_tenants('A', 'B')
    _sensor(app_module, a, 'A-fw', '10.0.7.1')
    sid_b = _sensor(app_module, b, 'B-fw', '10.0.7.1')
    _tap_feed(app_module, '10.0.7.1')
    _tap_sample(app_module, '10.0.7.1', 'TENANT-A-SECRET user=alice')
    login_as('user', tenant_ids=[b])
    resp = client.get(f'/live/data?fw={sid_b}')
    assert resp.status_code == 200
    data = resp.get_json()
    assert data['feeds'] == [] and data['samples'] == []
    assert data['ip_shared'] is True and data['withheld'] is True
    assert 'TENANT-A-SECRET' not in resp.get_data(as_text=True)


def test_duplicate_ip_admin_still_gets_data(client, app_module, seed_tenants,
                                            login_as):
    a, b = seed_tenants('A', 'B')
    _sensor(app_module, a, 'A-fw', '10.0.7.2')
    sid_b = _sensor(app_module, b, 'B-fw', '10.0.7.2')
    _tap_feed(app_module, '10.0.7.2')
    _tap_sample(app_module, '10.0.7.2', 'visible to admin')
    login_as('admin')
    data = client.get(f'/live/data?fw={sid_b}').get_json()
    assert data['ip_shared'] is True and data['withheld'] is False
    assert len(data['feeds']) == 1 and len(data['samples']) == 1


def test_unshared_ip_user_still_gets_data(client, app_module, seed_tenants,
                                          login_as):
    a, b = seed_tenants('A', 'B')
    sid_a = _sensor(app_module, a, 'A-fw', '10.0.7.3')
    _sensor(app_module, b, 'B-fw', '10.0.7.4')
    _tap_feed(app_module, '10.0.7.3')
    _tap_sample(app_module, '10.0.7.3', 'mine')
    login_as('user', tenant_ids=[a])
    data = client.get(f'/live/data?fw={sid_a}').get_json()
    assert data['ip_shared'] is False and data['withheld'] is False
    assert len(data['feeds']) == 1 and len(data['samples']) == 1


def test_same_tenant_duplicate_ip_is_not_shared(client, app_module,
                                                seed_tenants, login_as):
    a, = seed_tenants('A')
    sid = _sensor(app_module, a, 'A-fw1', '10.0.7.5')
    _sensor(app_module, a, 'A-fw2', '10.0.7.5')
    _tap_feed(app_module, '10.0.7.5')
    login_as('user', tenant_ids=[a])
    data = client.get(f'/live/data?fw={sid}').get_json()
    assert data['ip_shared'] is False and data['withheld'] is False
    assert len(data['feeds']) == 1


def test_events_scoped_to_authorised_sensor(client, app_module, seed_tenants,
                                            login_as):
    a, b = seed_tenants('A', 'B')
    sid_a = _sensor(app_module, a, 'A-fw', '10.0.7.6')
    sid_b = _sensor(app_module, b, 'B-fw', '10.0.7.7')
    for tid, sid, dst in ((a, sid_a, '1.1.1.1'), (b, sid_b, '8.8.8.8')):
        _exec(app_module,
              "INSERT INTO fw_events (time, tenant_id, sensor_id, vendor, "
              "data_source, event_type, action, src_ip, dst_ip, dst_port, "
              "protocol) VALUES (now(), %s, %s, 'sonicwall', 'ipfix', "
              "'traffic', 'allow', '192.168.8.40', %s, 443, 'tcp')",
              (tid, sid, dst))
    login_as('user', tenant_ids=[a])
    resp = client.get(f'/live/data?fw={sid_a}')
    assert [e['dst_ip'] for e in resp.get_json()['events']] == ['1.1.1.1']
    assert '8.8.8.8' not in resp.get_data(as_text=True)


def test_crafted_fw_values_are_404_for_user(client, app_module, seed_tenants,
                                            login_as):
    a, = seed_tenants('A')
    login_as('user', tenant_ids=[a])
    for val in ('Unregistered', 'UNREGISTERED', '-1', '99999999999999999999'):
        assert client.get(f'/live/data?fw={val}').status_code == 404, val


def test_live_page_renders_for_admin_with_firewall_options(client, app_module,
                                                          seed_tenants, login_as):
    t, = seed_tenants('Acme')
    _sensor(app_module, t, 'HQ <b>FW</b>', '10.0.8.1')
    login_as('admin')
    resp = client.get('/live')
    assert resp.status_code == 200
    body = resp.get_data(as_text=True)
    assert 'Live Monitor' in body
    assert 'value="unregistered"' in body               # admin-only entry
    assert 'HQ &lt;b&gt;FW&lt;/b&gt;' in body             # name is escaped
    assert '<b>FW</b>' not in body
    assert 'href="/live"' in body                        # nav entry


def test_live_page_user_has_no_unregistered_option(client, app_module,
                                                  seed_tenants, login_as):
    a, = seed_tenants('A')
    _sensor(app_module, a, 'A-fw', '10.0.9.2')
    login_as('user', tenant_ids=[a])
    body = client.get('/live').get_data(as_text=True)
    assert 'A-fw' in body
    assert 'value="unregistered"' not in body


def test_live_page_user_does_not_list_other_tenants_firewalls(
        client, app_module, seed_tenants, login_as):
    a, b = seed_tenants('A', 'B')
    _sensor(app_module, b, 'SECRET-B-FW', '10.0.9.9')
    login_as('user', tenant_ids=[a])
    assert 'SECRET-B-FW' not in client.get('/live').get_data(as_text=True)


def test_live_page_customer_redirected_to_portal(client, app_module,
                                                seed_tenants, login_as):
    a, = seed_tenants('A')
    login_as('customer', tenant_ids=[a])
    resp = client.get('/live')
    assert resp.status_code == 302 and '/portal' in resp.headers['Location']


def test_live_page_script_never_uses_innerhtml():
    import live_page
    assert 'innerHTML' not in live_page.LIVE_PAGE
    assert 'outerHTML' not in live_page.LIVE_PAGE
    assert 'insertAdjacentHTML' not in live_page.LIVE_PAGE


def test_live_page_empty_state_when_no_firewalls(client, login_as):
    login_as('admin')
    body = client.get('/live').get_data(as_text=True)
    assert 'No firewalls registered yet' in body


def test_live_page_script_guards_non_json_and_shared_ip():
    import live_page
    js = live_page.LIVE_PAGE
    assert 'r.ok' in js and 'content-type' in js.lower()
    assert 'ip_shared' in js
    assert 'another customer registered the same source IP' in js
    assert 'This source IP is also registered under another tenant.' in js
    body = _render_fn('poll')
    # hide-panels logic must key on `withheld`, never on ip_shared
    assert 'd.withheld' in body
    assert 'hidden = !!d.ip_shared' not in body and 'if (d.ip_shared)' not in body


def test_live_page_resets_banners_on_every_early_return():
    body = _render_fn('poll')
    first_return = body.index('return; }')
    reset = body.index("'lv-shared'")
    assert body.index('hideLoading()') < reset < body.index('needs_migration) {')
    assert "'lv-shared-note'" in body


def test_live_page_silent_checklist_shown_for_silent_feeds():
    body = _render_fn('renderFeeds')
    assert "status === 'silent'" in body
    assert 'lv-feeds-empty' in body


def test_live_data_unreachable_db_returns_json_503(client, app_module,
                                                   login_as, monkeypatch):
    import psycopg2
    login_as('admin')
    def boom(*a, **k):
        raise psycopg2.OperationalError('db down')
    monkeypatch.setattr(app_module, 'qone', boom)
    resp = client.get('/live/data?fw=1')
    assert resp.status_code == 503 and resp.get_json() == {'error': 'query_failed'}


def test_live_data_unknown_firewall_still_404(client, login_as):
    login_as('admin')
    assert client.get('/live/data?fw=99999999').status_code == 404


def _render_fn(name):
    import live_page
    js = live_page.LIVE_PAGE
    start = js.index('function ' + name)
    return js[start:js.index('\n  function ', start + 1)]


def test_render_tail_clears_old_lines_before_empty_early_return():
    body = _render_fn('renderTail')
    assert body.index("querySelectorAll('.lv-line')") < body.index('if (!lines.length)')


def test_selector_change_clears_panels_and_shows_loading():
    import live_page
    js = live_page.LIVE_PAGE
    handler = js[js.index("fw.addEventListener('change'"):]
    handler = handler[:handler.index('});') + 3]
    assert 'clearPanels' in handler and 'Loading' in js


def test_live_page_has_noscript_notice():
    import live_page
    assert '<noscript>' in live_page.LIVE_PAGE
    assert 'The Live Monitor needs JavaScript to show live data.' in live_page.LIVE_PAGE


def test_live_page_has_no_hex_colour_literals_outside_variable_block():
    import re
    import live_page
    css = live_page.LIVE_PAGE
    block_start = css.index('.live-wrap{--lv-bar')
    rest = css[:block_start] + css[css.index('}', block_start) + 1:]
    assert re.findall(r'#[0-9A-Fa-f]{3,8}\b', rest) == []


def test_live_page_ignores_superseded_abort_and_skips_inflight():
    import live_page
    js = live_page.LIVE_PAGE
    assert 'AbortError' in js
    assert 'if (inflight) return' in js


def test_live_page_selector_escapes_script_breakout_name(client, app_module,
                                                        seed_tenants, login_as):
    t, = seed_tenants('Acme')
    _sensor(app_module, t, '</script><img src=x onerror=alert(1)>', '10.0.8.7')
    login_as('admin')
    body = client.get('/live').get_data(as_text=True)
    assert '</script><img src=x onerror=alert(1)>' not in body
    assert '&lt;/script&gt;&lt;img src=x onerror=alert(1)&gt;' in body


def test_pages_carry_ut1_attribution(client, login_as):
    login_as('admin')
    resp = client.get('/live')
    assert resp.status_code == 200
    assert b'UT1 blacklists' in resp.data and b'CC BY-SA 4.0' in resp.data
    assert b'https://dsi.ut-capitole.fr/blacklists/' in resp.data
    assert b'rel="noopener noreferrer"' in resp.data
