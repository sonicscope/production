"""Regression test for app._load_env() robustness (reports/web/app.py).

An `/etc/ss-multivendor/collector.env` that exists but is unreadable by the
current OS user (permission drift, or the collector's 0640 root:ss-collector
file read by another user) must:
  * NOT crash the app at import time, AND
  * be logged LOUDLY, so it can never silently fall back to defaulted
    DB/SMTP credentials without a trace.

This test FAILS against the pre-fix `except FileNotFoundError` behaviour
(where an unreadable file raised PermissionError out of _load_env) and
against a silent `except OSError: pass` (which logs nothing). It passes only
with the split FileNotFoundError / OSError+log.warning handling.
"""
import logging
import os

import pytest


@pytest.mark.skipif(
    os.geteuid() == 0,
    reason="root bypasses file permission bits, so a 0o000 file is still "
           "readable and this scenario cannot be reproduced as root.",
)
def test_load_env_unreadable_file_warns_but_does_not_raise(app_module, tmp_path, caplog):
    env_file = tmp_path / "collector.env"
    env_file.write_text("SECRET_SHOULD_NOT_LOAD=leaked\n")
    os.chmod(env_file, 0o000)
    try:
        with caplog.at_level(logging.WARNING, logger='ss.reports.web'):
            # Must not raise even though the file cannot be read.
            app_module._load_env(str(env_file))

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        assert warnings, "expected a WARNING to be logged for an unreadable env file"
        assert any(str(env_file) in r.getMessage() for r in warnings), \
            "the warning should name the unreadable file path"
        # And nothing from the unreadable file may have leaked into os.environ.
        assert 'SECRET_SHOULD_NOT_LOAD' not in os.environ
    finally:
        os.chmod(env_file, 0o600)  # allow tmp_path cleanup to remove it
