"""End-to-end portal route tests against the ephemeral test DB.

These are the regression that would have caught the `msp_profiles.company_name`
bug: before the fix, GET /portal 500s (UndefinedColumn); after it, 200 with the
MSP brand and no SonicScope leak."""
from __future__ import annotations

import psycopg2


def _link_tenant_to_msp(app_module, tenant_id: int, msp_id: int) -> None:
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute('UPDATE tenants SET msp_profile_id = %s WHERE id = %s',
                        (msp_id, tenant_id))
        conn.commit()


def _make_customer(app_module, client, seed_tenants, seed_msp_profile, login_as,
                   **msp_kwargs):
    msp_id = seed_msp_profile(msp_kwargs.pop('name', 'Acme MSP'), **msp_kwargs)
    (tid,) = seed_tenants('Acme Corp')
    _link_tenant_to_msp(app_module, tid, msp_id)
    login_as('customer', tenant_ids=[tid])
    return tid, msp_id


def test_portal_dashboard_renders_200_and_brand(
        app_module, client, seed_tenants, seed_msp_profile, login_as):
    _make_customer(app_module, client, seed_tenants, seed_msp_profile, login_as,
                   name='Acme MSP', primary_color='#ffff00', footer_text='Acme IT Services')
    resp = client.get('/portal')
    assert resp.status_code == 200
    body = resp.get_data(as_text=True)
    assert 'Acme MSP' in body
    assert 'Acme IT Services' in body          # custom footer_text
    assert 'SonicScope' not in body
    assert 'Powered by SonicScope' not in body


def test_portal_reports_and_generate_render_200(
        app_module, client, seed_tenants, seed_msp_profile, login_as):
    _make_customer(app_module, client, seed_tenants, seed_msp_profile, login_as,
                   name='Beta MSP', primary_color='#0055aa')
    for path in ('/portal/reports', '/portal/generate'):
        resp = client.get(path)
        assert resp.status_code == 200, f'{path} -> {resp.status_code}'
        assert 'SonicScope' not in resp.get_data(as_text=True)


def test_portal_footer_falls_back_to_msp_name_without_footer_text(
        app_module, client, seed_tenants, seed_msp_profile, login_as):
    _make_customer(app_module, client, seed_tenants, seed_msp_profile, login_as,
                   name='Gamma Managed', primary_color='#003366')  # no footer_text
    body = client.get('/portal').get_data(as_text=True)
    assert 'Gamma Managed' in body
    assert 'SonicScope' not in body
