"""Regression tests for the unauthenticated auth-page layout (Task 5, P0
launch remediation).

`_render_auth_page` previously claimed "no sidebar" in its own docstring
but actually rendered through `_BASE` — the same layout the authenticated
operator console uses, complete with the operator sidebar nav, a "Sign
out" button, and a hardcoded "⬡ SonicScope" wordmark. Every logged-out
visitor (including MSP end-customers, who authenticate through this same
`/login`) saw a broken, SonicScope-branded screen full of nav links they
had no access to. These tests pin down that `/login`, `/forgot-password`,
and `/reset-password` render through a dedicated, minimal `_AUTH_BASE`
instead: no operator chrome, and a brand string pulled from the
`APP_BRAND` constant rather than a literal hardcoded wordmark.
"""


def test_login_page_has_no_operator_chrome(client):
    html = client.get('/login').get_data(as_text=True)
    assert 'Sign out' not in html
    assert '/tenants' not in html          # sidebar nav must be absent
    assert 'class="sidebar"' not in html


def test_login_page_is_not_hardcoded_sonicscope(client):
    html = client.get('/login').get_data(as_text=True)
    # neutral/product-configurable brand, not the literal SonicScope
    # wordmark on the customer's door
    assert '⬡ SonicScope' not in html


def test_forgot_password_page_has_no_operator_chrome(client):
    html = client.get('/forgot-password').get_data(as_text=True)
    assert 'Sign out' not in html
    assert '/tenants' not in html
    assert 'class="sidebar"' not in html
    assert '⬡ SonicScope' not in html


def test_reset_password_page_has_no_operator_chrome(client):
    html = client.get('/reset-password').get_data(as_text=True)
    assert 'Sign out' not in html
    assert '/tenants' not in html
    assert 'class="sidebar"' not in html
    assert '⬡ SonicScope' not in html


def test_login_page_retains_csrf_field(client):
    """The dedicated auth layout must keep the CSRF auto-injection that
    `_render_auth_page` performs on every POST form."""
    html = client.get('/login').get_data(as_text=True)
    assert 'name="_csrf"' in html


def test_login_page_brand_is_configurable(app_module, client):
    """The auth card renders the module's APP_BRAND constant, so the
    default build never ships the hardcoded SonicScope wordmark and an
    operator could override it via the PORTAL_BRAND env var (P1 will wire
    per-MSP resolution; here we just confirm the constant is in play)."""
    html = client.get('/login').get_data(as_text=True)
    assert app_module.APP_BRAND in html


def test_login_page_brand_honours_portal_brand_env(monkeypatch, _test_db_dsn):
    """PORTAL_BRAND must actually override the login-page brand. Reload the
    app module with a distinctive PORTAL_BRAND set (same reload pattern the
    security-config test uses) and prove that value — and NOT the default
    'Network Reports' — is what /login renders. This is RED the moment the
    brand is hardcoded again instead of read from _e('PORTAL_BRAND', ...).

    Depends on `_test_db_dsn` (not just copying whatever happens to already
    be in os.environ) because GET /login now also resolves per-MSP login
    branding (_login_branding(), Task: per-MSP login branding), which
    queries msp_profiles — so the reloaded module needs a genuinely
    reachable DB, not just whatever DB_* env a previous test's monkeypatch
    left behind (nothing, in practice: monkeypatch reverts per test).

    Restores the module to the conftest test-DB / default-brand env in
    teardown so no leaked config or scheduler bleeds into later tests."""
    import importlib
    import os
    import sys

    import psycopg2

    tests_dir = os.path.dirname(os.path.abspath(__file__))
    web_dir = os.path.join(os.path.dirname(tests_dir), 'web')
    if web_dir not in sys.path:
        sys.path.insert(0, web_dir)

    # This test does not go through the app_module fixture (which truncates
    # app tables before yielding), so guarantee zero msp_profiles rows here
    # directly rather than relying on suite run order — a leftover row from
    # another test would make _login_branding() auto-detect that MSP instead
    # of exercising the neutral/PORTAL_BRAND fallback path this test checks.
    with psycopg2.connect(**_test_db_dsn) as conn:
        with conn.cursor() as cur:
            cur.execute('TRUNCATE TABLE msp_profiles CASCADE;')
        conn.commit()

    monkeypatch.setenv('DB_HOST', _test_db_dsn['host'])
    monkeypatch.setenv('DB_PORT', str(_test_db_dsn['port']))
    monkeypatch.setenv('DB_NAME', _test_db_dsn['dbname'])
    monkeypatch.setenv('DB_USER', _test_db_dsn['user'])
    monkeypatch.setenv('DB_PASSWORD', _test_db_dsn['password'])
    monkeypatch.setenv('FLASK_SECRET', 'test-secret')
    monkeypatch.setenv('COOKIE_SECURE', 'false')
    monkeypatch.setenv('SMTP_HOST', '')
    monkeypatch.setenv('SMTP_USER', '')
    monkeypatch.setenv('SMTP_PASSWORD', '')
    monkeypatch.setenv('SMTP_FROM', '')

    distinctive = 'ACME Secure Reports'
    monkeypatch.setenv('PORTAL_BRAND', distinctive)

    if 'app' in sys.modules:
        mod = importlib.reload(sys.modules['app'])
    else:
        mod = importlib.import_module('app')
    mod.app.config.update(TESTING=True)

    try:
        assert mod.APP_BRAND == distinctive
        html = mod.app.test_client().get('/login').get_data(as_text=True)
        assert distinctive in html
        assert 'Network Reports' not in html
    finally:
        if getattr(mod, '_scheduler', None) is not None:
            try:
                mod.stop_scheduler(mod._scheduler)
            except Exception:
                pass
        # Restore the default-brand module state for subsequent tests.
        monkeypatch.delenv('PORTAL_BRAND', raising=False)
        try:
            restored = importlib.reload(sys.modules['app'])
            if getattr(restored, '_scheduler', None) is not None:
                try:
                    restored.stop_scheduler(restored._scheduler)
                except Exception:
                    pass
        except Exception:
            pass
