"""Tests for the white-labelled password-reset email.

- The pure _reset_email_content() builder: branded vs neutral, no SonicScope leak.
- A wiring test proving _send_reset_code() calls the builder and preserves SMTP_FROM.
No real SMTP, no DB (branding is passed in / monkeypatched)."""
from __future__ import annotations

import email as email_lib
import os
import sys

import pytest

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'web')
if WEB_DIR not in sys.path:
    sys.path.insert(0, WEB_DIR)

import app as appmod  # noqa: E402

_LEAKS = ('SonicScope', 'Network Visibility Platform', 'sonicscope.co.za')


def _branded(**over):
    b = {'id': 1, 'name': 'Acme MSP', 'primary_color': '#ffff00',
         'text_color': '#000000', 'has_logo': False, 'footer_text': 'Acme IT Services'}
    b.update(over)
    return b


def test_branded_subject_and_bodies():
    subject, html, text = appmod._reset_email_content('654321', 'Jane Doe', _branded())
    assert subject == 'Acme MSP — Password Reset Code'
    for body in (html, text):
        assert 'Acme MSP' in body
        assert '654321' in body
        for leak in _LEAKS:
            assert leak not in body
    # accent + contrast text + custom footer present in the html
    assert '#ffff00' in html
    assert '#000000' in html            # accent_text for the light band
    assert 'Acme IT Services' in html


def _footer_region(html: str) -> str:
    """The footer cell onward (isolated by its distinctive background colour),
    so a footer assertion can't be satisfied by the brand name appearing in the
    header wordmark / body line instead."""
    assert '#f0f3f8' in html, 'footer cell background marker missing'
    return html.split('#f0f3f8', 1)[1]


def test_branded_footer_falls_back_to_name_without_footer_text():
    # custom footer_text present -> the footer shows it (and it is NOT in the
    # header/body, so isolating the footer region proves it landed in the footer)
    _, html_ft, _ = appmod._reset_email_content('111222', 'Jane',
                                                _branded(footer_text='Acme IT Services'))
    assert 'Acme IT Services' in _footer_region(html_ft)

    # no footer_text -> the footer specifically falls back to the brand name
    _, html, _ = appmod._reset_email_content('111222', 'Jane', _branded(footer_text=None))
    assert 'Acme MSP' in _footer_region(html)
    for leak in _LEAKS:
        assert leak not in html


def test_neutral_branding_uses_app_brand_no_sonicscope():
    subject, html, text = appmod._reset_email_content('999000', 'Sam', None)
    assert appmod.APP_BRAND in subject
    for body in (html, text):
        assert '999000' in body
        for leak in _LEAKS:
            assert leak not in body
    assert appmod._DEFAULT_ACCENT_COLOR in html


def test_code_appears_in_both_bodies():
    _, html, text = appmod._reset_email_content('424242', '', _branded())
    assert '424242' in html and '424242' in text


class _FakeSMTP:
    """Captures the raw message + envelope sender instead of sending."""
    captured: dict = {}

    def __init__(self, *a, **k):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def ehlo(self):
        pass

    def starttls(self):
        pass

    def login(self, *a):
        pass

    def sendmail(self, from_addr, to_addrs, raw):
        _FakeSMTP.captured = {'from': from_addr, 'to': to_addrs, 'raw': raw}


def test_send_reset_code_wiring(monkeypatch):
    _FakeSMTP.captured = {}
    monkeypatch.setattr(appmod.smtplib, 'SMTP', _FakeSMTP)
    monkeypatch.setattr(appmod, 'SMTP_CONFIG',
                        {'host': 'smtp.test', 'port': 587, 'user': 'u',
                         'password': 'p', 'from_addr': 'mailer@relay.test'})
    monkeypatch.setattr(appmod, '_login_branding', lambda: _branded())

    appmod._send_reset_code('user@example.test', '123456', 'Jane')

    cap = _FakeSMTP.captured
    assert cap, 'sendmail was never called'
    # Python's email lib always base64-encodes utf-8 text bodies (even pure-ASCII
    # ones), so a plain decode('utf-8') of the raw bytes never surfaces the
    # literal content — parse the MIME message and decode each text part instead.
    msg = email_lib.message_from_bytes(cap['raw'])
    subject_header = str(email_lib.header.make_header(email_lib.header.decode_header(msg.get('Subject', ''))))
    parts = [subject_header]
    for part in msg.walk():
        if part.get_content_maintype() == 'text':
            payload = part.get_payload(decode=True) or b''
            parts.append(payload.decode(part.get_content_charset() or 'utf-8', 'replace'))
    raw = '\n'.join(parts)
    assert 'Acme MSP' in raw
    assert '123456' in raw
    assert 'SonicScope' not in raw
    assert cap['from'] == 'mailer@relay.test'     # SMTP_FROM preserved
