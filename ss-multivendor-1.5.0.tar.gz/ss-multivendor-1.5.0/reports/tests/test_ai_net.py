import http.client
import http.server
import io
import json
import logging
import socket
import ssl
import threading
import urllib.error
import urllib.request
from urllib.parse import quote

import pytest

from reports.ai import net

# Captured before the autouse fixture patches socket.getaddrinfo globally.
_REAL_GETADDRINFO = socket.getaddrinfo


class FakeResp:
    def __init__(self, body: bytes):
        self._b = io.BytesIO(body)

    def read(self, n=-1):
        return self._b.read(n)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class BrokenResp:
    """Response whose body read fails with the given exception."""

    def __init__(self, exc: BaseException):
        self._exc = exc

    def read(self, n=-1):
        raise self._exc

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeHTTPError(urllib.error.HTTPError):
    """HTTPError whose body read can fail and that records close()."""

    def __init__(self, code: int, body: bytes = b'', read_exc: BaseException | None = None):
        super().__init__('https://api.openai.com/v1/x', code, 'x', {}, None)
        self._body = body
        self._read_exc = read_exc
        self.closed = False

    def read(self, n=-1):
        if self._read_exc is not None:
            raise self._read_exc
        return self._body[:n] if n >= 0 else self._body

    def close(self):
        self.closed = True


def _raiser(exc: BaseException):
    def fake_open(req, timeout):
        raise exc
    return fake_open


@pytest.fixture(autouse=True)
def public_dns(monkeypatch):
    monkeypatch.setattr(net.socket, 'getaddrinfo',
                        lambda *a, **k: [(2, 1, 6, '', ('93.184.216.34', 443))])


def test_rejects_non_https():
    with pytest.raises(net.ProviderError):
        net.validate_url('http://api.openai.com/v1/x')


def test_rejects_unknown_host():
    with pytest.raises(net.ProviderError):
        net.validate_url('https://evil.example/v1/x')


@pytest.mark.parametrize('url', [
    'https://api.openai.com:8443/v1/x',
    'https://user:pw@api.openai.com/v1/x',
])
def test_rejects_port_and_userinfo(url):
    with pytest.raises(net.ProviderError):
        net.validate_url(url)


@pytest.mark.parametrize('url', [
    'https://[::1/x',
    'https://api.openai.com:abc/x',
    'https://api.openai.com:99999/x',
])
def test_malformed_url_is_provider_error(url):
    with pytest.raises(net.ProviderError):
        net.validate_url(url)


@pytest.mark.parametrize('ip', [
    '169.254.169.254', '127.0.0.1', '10.0.0.5', '::1',
    '::ffff:127.0.0.1', '::ffff:169.254.169.254', 'fe80::1%eth0',
])
def test_rejects_non_public_resolution(monkeypatch, ip):
    monkeypatch.setattr(net.socket, 'getaddrinfo',
                        lambda *a, **k: [(2, 1, 6, '', (ip, 443))])
    with pytest.raises(net.ProviderError):
        net.validate_url('https://api.openai.com/v1/x')


def test_accepts_public_ipv4_mapped_resolution(monkeypatch):
    monkeypatch.setattr(net.socket, 'getaddrinfo',
                        lambda *a, **k: [(2, 1, 6, '', ('::ffff:93.184.216.34', 443))])
    assert net.validate_url('https://api.openai.com/v1/x') == 'api.openai.com'


@pytest.mark.parametrize('addr', ['not-an-ip', ''])
def test_unparseable_resolution_is_provider_error(monkeypatch, addr):
    monkeypatch.setattr(net.socket, 'getaddrinfo',
                        lambda *a, **k: [(2, 1, 6, '', (addr, 443))])
    with pytest.raises(net.ProviderError):
        net.validate_url('https://api.openai.com/v1/x')


def test_post_json_ok(monkeypatch):
    seen = {}

    def fake_open(req, timeout):
        seen['url'] = req.full_url
        seen['body'] = json.loads(req.data)
        return FakeResp(b'{"ok": true}')

    monkeypatch.setattr(net, '_open', fake_open)
    out = net.post_json('https://api.openai.com/v1/chat/completions',
                        {'Authorization': 'Bearer sk-x'}, {'a': 1}, secrets=['sk-x'])
    assert out == {'ok': True}
    assert seen['body'] == {'a': 1}


@pytest.mark.parametrize('code,fragment', [
    (401, 'API key'), (403, 'API key'), (429, 'rate'), (500, 'HTTP 500'),
])
def test_http_errors_are_generic(monkeypatch, code, fragment):
    def fake_open(req, timeout):
        raise urllib.error.HTTPError(req.full_url, code, 'x', {},
                                     io.BytesIO(b'{"error":"key sk-SECRET is bad"}'))
    monkeypatch.setattr(net, '_open', fake_open)
    with pytest.raises(net.ProviderError) as exc:
        net.post_json('https://api.openai.com/v1/x', {}, {}, secrets=['sk-SECRET'])
    assert fragment.lower() in str(exc.value).lower()
    assert 'sk-SECRET' not in str(exc.value)


def test_network_error_is_generic(monkeypatch):
    def fake_open(req, timeout):
        raise urllib.error.URLError('connection refused to 10.1.2.3')
    monkeypatch.setattr(net, '_open', fake_open)
    with pytest.raises(net.ProviderError) as exc:
        net.post_json('https://api.openai.com/v1/x', {}, {})
    assert '10.1.2.3' not in str(exc.value)


def test_oversized_and_non_json_responses_rejected(monkeypatch):
    monkeypatch.setattr(net, '_open', lambda req, timeout: FakeResp(b'x' * 100))
    with pytest.raises(net.ProviderError):
        net.post_json('https://api.openai.com/v1/x', {}, {}, max_bytes=10)
    monkeypatch.setattr(net, '_open', lambda req, timeout: FakeResp(b'not json'))
    with pytest.raises(net.ProviderError):
        net.post_json('https://api.openai.com/v1/x', {}, {})


def test_deeply_nested_json_is_provider_error(monkeypatch):
    monkeypatch.setattr(net, '_open', lambda req, timeout: FakeResp(b'[' * 100000))
    with pytest.raises(net.ProviderError):
        net.post_json('https://api.openai.com/v1/x', {}, {})


def test_redirects_are_refused():
    handler = net._NoRedirect()
    assert handler.redirect_request(None, None, 302, 'Found', {}, 'https://evil.example') is None


def test_redirect_is_not_followed_over_real_socket(monkeypatch):
    """Integrated check: a real 302 from a local server surfaces as HTTPError."""
    for var in ('http_proxy', 'HTTP_PROXY', 'https_proxy', 'HTTPS_PROXY',
                'all_proxy', 'ALL_PROXY'):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setenv('no_proxy', '127.0.0.1,localhost')
    monkeypatch.setenv('NO_PROXY', '127.0.0.1,localhost')
    # The autouse fixture patches DNS globally; loopback needs the real resolver.
    monkeypatch.setattr(net.socket, 'getaddrinfo', _REAL_GETADDRINFO)

    class _Redirect(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(302)
            self.send_header('Location', 'http://127.0.0.1:1/never')
            self.send_header('Content-Length', '0')
            self.end_headers()

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer(('127.0.0.1', 0), _Redirect)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        port = server.server_address[1]
        req = urllib.request.Request(f'http://127.0.0.1:{port}/x')
        with pytest.raises(urllib.error.HTTPError) as exc:
            net._open(req, 5.0)
        assert exc.value.code == 302
    finally:
        server.shutdown()
        server.server_close()
        thread.join(5)


@pytest.mark.parametrize('key', [
    'sk-SECRET\n',
    'sk-SECRET\r\nX-Evil: 1',
    'sk-SECRET☃',
])
def test_bad_header_values_rejected_without_leaking(monkeypatch, caplog, key):
    def fake_open(req, timeout):
        raise AssertionError('invalid headers must not reach the transport')
    monkeypatch.setattr(net, '_open', fake_open)
    caplog.set_level(logging.DEBUG)
    with pytest.raises(net.ProviderError) as exc:
        net.post_json('https://api.openai.com/v1/x', {'Authorization': f'Bearer {key}'}, {})
    assert 'sk-SECRET' not in str(exc.value)
    assert 'sk-SECRET' not in repr(exc.value)
    assert not any('sk-SECRET' in r.getMessage() for r in caplog.records)


def test_value_error_from_transport_is_generic_and_not_logged(monkeypatch, caplog):
    monkeypatch.setattr(net, '_open', _raiser(
        ValueError("Invalid header value b'Bearer sk-SECRET'")))
    caplog.set_level(logging.DEBUG)
    with pytest.raises(net.ProviderError) as exc:
        net.post_json('https://api.openai.com/v1/x', {'Authorization': 'Bearer sk-SECRET'}, {})
    assert 'sk-SECRET' not in repr(exc.value)
    assert not any('sk-SECRET' in r.getMessage() for r in caplog.records)


@pytest.mark.parametrize('exc', [
    http.client.IncompleteRead(b'partial'),
    http.client.RemoteDisconnected('closed by peer'),
    http.client.LineTooLong('header line'),
    http.client.BadStatusLine('garbage sk-SECRET'),
    TimeoutError('timed out'),
    socket.timeout('timed out'),
    ssl.SSLError('handshake failure sk-SECRET'),
])
@pytest.mark.parametrize('stage', ['open', 'read'])
def test_transport_failures_are_provider_errors(monkeypatch, caplog, exc, stage):
    if stage == 'open':
        monkeypatch.setattr(net, '_open', _raiser(exc))
    else:
        monkeypatch.setattr(net, '_open', lambda req, timeout: BrokenResp(exc))
    caplog.set_level(logging.DEBUG)
    with pytest.raises(net.ProviderError) as info:
        net.post_json('https://api.openai.com/v1/x', {'Authorization': 'Bearer sk-SECRET'},
                      {}, secrets=['sk-SECRET'])
    assert 'sk-SECRET' not in str(info.value)
    assert 'sk-SECRET' not in repr(info.value)
    assert not any('sk-SECRET' in r.getMessage() for r in caplog.records)


def test_http_error_body_read_failure_is_generic(monkeypatch):
    err = FakeHTTPError(500, read_exc=http.client.IncompleteRead(b''))
    monkeypatch.setattr(net, '_open', _raiser(err))
    with pytest.raises(net.ProviderError) as exc:
        net.post_json('https://api.openai.com/v1/x', {}, {})
    assert 'HTTP 500' in str(exc.value)
    assert err.closed


def test_http_error_response_is_closed(monkeypatch):
    err = FakeHTTPError(401, body=b'{"error":"bad"}')
    monkeypatch.setattr(net, '_open', _raiser(err))
    with pytest.raises(net.ProviderError) as exc:
        net.post_json('https://api.openai.com/v1/x', {}, {})
    assert 'API key' in str(exc.value)
    assert err.closed


def test_error_body_log_redacts_before_truncating(monkeypatch, caplog):
    secret = 'sk-SECRET'
    # The key starts at byte 495, so it straddles the 500-character log cut.
    body = b'x' * 495 + secret.encode() + b'\r\nFAKE LOG LINE\n' + b'y' * 600
    monkeypatch.setattr(net, '_open', _raiser(FakeHTTPError(500, body=body)))
    caplog.set_level(logging.DEBUG)
    with pytest.raises(net.ProviderError):
        net.post_json('https://api.openai.com/v1/x', {}, {}, secrets=[secret])
    messages = [r.getMessage() for r in caplog.records]
    assert messages
    for message in messages:
        assert 'sk-' not in message
        assert '\n' not in message and '\r' not in message


def test_escaped_and_encoded_secret_forms_redacted(monkeypatch, caplog):
    secret = 'a"b/c+d'
    json_form = json.dumps(secret)[1:-1]
    url_form = quote(secret, safe='')
    body = ('{"echo": "' + json_form + '", "q": "' + url_form + '"}').encode()
    monkeypatch.setattr(net, '_open', _raiser(FakeHTTPError(500, body=body)))
    caplog.set_level(logging.DEBUG)
    # Generator input: secrets must be usable more than once.
    with pytest.raises(net.ProviderError):
        net.post_json('https://api.openai.com/v1/x', {}, {},
                      secrets=(s for s in [secret]))
    for record in caplog.records:
        message = record.getMessage()
        assert secret not in message
        assert json_form not in message
        assert url_form not in message


def test_redact_covers_escaped_and_encoded_forms():
    secret = 'a"b/c+d'
    text = ('raw ' + secret + ' json ' + json.dumps(secret)[1:-1]
            + ' url ' + quote(secret, safe=''))
    assert net.redact(text, [secret]) == 'raw *** json *** url ***'


def test_redact():
    assert net.redact('key=abcd1234 and abcd1234', ['abcd1234']) == 'key=*** and ***'
    assert net.redact('nothing', ['', None]) == 'nothing'
