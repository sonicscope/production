"""Tests for GET /healthz (reports/web/app.py) — collector health endpoint.

Approach A design: the collector's db_writer UPSERTs a single-row
`collector_health` heartbeat; this unauthenticated endpoint reads it plus a
live DB check to report overall health for a monitor/uptime check.
See docs/superpowers/specs/2026-07-14-healthz-metrics-design.md.
"""
from datetime import datetime, timedelta, timezone

import psycopg2


def _insert_health_row(app_module, **overrides):
    """Insert/replace the single collector_health row (id=1) directly via SQL
    (bypassing the collector's own UPSERT, which lives in a different
    process) so each test can control last_seen/last_insert_at/counters."""
    now = datetime.now(timezone.utc)
    row = {
        'last_seen': now,
        'last_insert_at': now,
        'events_inserted': 100,
        'events_dropped': 2,
        'events_poison': 1,
        'events_errors': 0,
        'queue_depth': 5,
        'queue_max': 50_000,
    }
    row.update(overrides)
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO collector_health (
                    id, last_seen, last_insert_at, events_inserted,
                    events_dropped, events_poison, events_errors,
                    queue_depth, queue_max
                ) VALUES (1, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    last_seen       = EXCLUDED.last_seen,
                    last_insert_at  = EXCLUDED.last_insert_at,
                    events_inserted = EXCLUDED.events_inserted,
                    events_dropped  = EXCLUDED.events_dropped,
                    events_poison   = EXCLUDED.events_poison,
                    events_errors   = EXCLUDED.events_errors,
                    queue_depth     = EXCLUDED.queue_depth,
                    queue_max       = EXCLUDED.queue_max
                """,
                (row['last_seen'], row['last_insert_at'], row['events_inserted'],
                 row['events_dropped'], row['events_poison'], row['events_errors'],
                 row['queue_depth'], row['queue_max']),
            )
        conn.commit()


def test_fresh_row_returns_200_healthy_with_counters(client, app_module):
    _insert_health_row(app_module, events_dropped=7, events_poison=3, events_errors=1)

    resp = client.get('/healthz')

    assert resp.status_code == 200
    assert resp.content_type.startswith('application/json')
    body = resp.get_json()
    assert body['status'] == 'healthy'
    assert body['checks'] == {'database': 'ok', 'collector': 'ok', 'ingest': 'ok'}
    assert body['collector']['events_dropped'] == 7
    assert body['collector']['events_poison'] == 3
    assert body['collector']['events_errors'] == 1
    assert body['collector']['events_inserted'] == 100
    assert body['collector']['queue_depth'] == 5
    assert body['collector']['queue_max'] == 50_000
    assert isinstance(body['collector']['seconds_since_last_seen'], int)


def test_stale_row_returns_503_collector_stale(client, app_module):
    stale = datetime.now(timezone.utc) - timedelta(seconds=120)
    _insert_health_row(app_module, last_seen=stale, last_insert_at=stale)

    resp = client.get('/healthz')

    assert resp.status_code == 503
    body = resp.get_json()
    assert body['status'] == 'degraded'
    assert body['checks']['collector'] == 'stale'


def test_no_row_returns_503_collector_unknown(client, app_module):
    resp = client.get('/healthz')

    assert resp.status_code == 503
    body = resp.get_json()
    assert body['status'] == 'degraded'
    assert body['checks']['collector'] == 'unknown'


def test_no_recent_events_stays_healthy_when_last_seen_fresh(client, app_module):
    """A fresh heartbeat (last_seen recent) with a stale last_insert_at means
    the collector is alive but ingest has been quiet — that's informational,
    NOT degraded (a quiet network is legitimate)."""
    now = datetime.now(timezone.utc)
    stale_insert = now - timedelta(seconds=120)
    _insert_health_row(app_module, last_seen=now, last_insert_at=stale_insert)

    resp = client.get('/healthz')

    assert resp.status_code == 200
    body = resp.get_json()
    assert body['status'] == 'healthy'
    assert body['checks']['collector'] == 'ok'
    assert body['checks']['ingest'] == 'no_recent_events'


def test_healthz_reachable_without_a_session(client, app_module):
    """Proves /healthz is in _PUBLIC_ENDPOINTS — no login redirect, even
    with no session cookie set at all."""
    _insert_health_row(app_module)

    resp = client.get('/healthz', follow_redirects=False)

    assert resp.status_code != 302
    assert resp.status_code in (200, 503)


def test_db_unreachable_returns_503_unhealthy_without_leaking(client, app_module,
                                                              monkeypatch):
    """If the collector_health read raises (DB down / query error), the
    handler must return 503 {"status":"unhealthy","checks":{"database":
    "unreachable"}} and must NOT leak the raw exception text, DSN, schema, or
    any stack detail into the response body."""
    secret_marker = 'dbname=sonicscope host=127.0.0.1 password=SUPERSECRET'

    def boom(*_args, **_kwargs):
        raise psycopg2.OperationalError(
            f"could not connect to server: {secret_marker}"
        )

    # The route reads the row via the module-level qone() helper.
    monkeypatch.setattr(app_module, 'qone', boom)

    resp = client.get('/healthz')

    assert resp.status_code == 503
    assert resp.content_type.startswith('application/json')
    body = resp.get_json()
    assert body == {"status": "unhealthy", "checks": {"database": "unreachable"}}

    # No raw exception text / DSN / password / schema names leak to the client.
    raw = resp.get_data(as_text=True)
    assert secret_marker not in raw
    assert 'SUPERSECRET' not in raw
    assert 'password' not in raw
    assert 'OperationalError' not in raw
    assert 'collector_health' not in raw
    assert 'Traceback' not in raw
