"""Unit tests for the shared colour helpers (reports/color_utils.py)."""
from reports.color_utils import (
    _DEFAULT_ACCENT_COLOR,
    _hex_to_rgb,
    _readable_text_color,
    _valid_hex_color,
)


def test_valid_hex_accepts_rgb_and_rrggbb():
    assert _valid_hex_color('#abc') == '#abc'
    assert _valid_hex_color('#00C9A7') == '#00C9A7'
    assert _valid_hex_color('  #123456  ') == '#123456'  # stripped


def test_valid_hex_rejects_malformed():
    assert _valid_hex_color('teal') is None
    assert _valid_hex_color('') is None
    assert _valid_hex_color(None) is None
    assert _valid_hex_color('#12') is None


def test_hex_to_rgb():
    assert _hex_to_rgb('#ffffff') == (255, 255, 255)
    assert _hex_to_rgb('#000') == (0, 0, 0)
    assert _hex_to_rgb('nope') is None


def test_readable_text_color_light_bg_black_text():
    assert _readable_text_color('#ffff00') == '#000000'


def test_readable_text_color_dark_bg_white_text():
    assert _readable_text_color('#001133') == '#ffffff'


def test_readable_text_color_malformed_safe_default():
    assert _readable_text_color('bogus') == '#ffffff'


def test_default_accent_is_schema_default():
    assert _DEFAULT_ACCENT_COLOR == '#378ADD'
