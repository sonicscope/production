"""UT1 refresh job against the real test schema, with a fake download."""
import contextlib
import io
import tarfile

import psycopg2
import pytest

from reports import category_lists as cl

MAPPING = cl.Mapping(
    version='test',
    folders={'phishing': 'Phishing and Other Frauds', 'adult': 'Pornography',
             'gambling': 'Gambling'},
    priority=['phishing', 'adult', 'gambling'])


def make_archive(path, folders: dict):
    """folders: {name: [lines]} -> tar.gz laid out like UT1 (blacklists/<f>/domains)."""
    with tarfile.open(path, 'w:gz') as tar:
        for name, lines in folders.items():
            data = ('\n'.join(lines) + '\n').encode()
            info = tarfile.TarInfo(f'blacklists/{name}/domains')
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
        # an unrelated file must be ignored
        data = b'x'
        info = tarfile.TarInfo('blacklists/README')
        info.size = 1
        tar.addfile(info, io.BytesIO(data))


@pytest.fixture
def connect(app_module):
    return lambda: psycopg2.connect(**app_module.DB_CONFIG)


def rows(connect, sql, params=()):
    with contextlib.closing(connect()) as c, c.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall()


def reset(connect):
    with contextlib.closing(connect()) as c, c.cursor() as cur:
        cur.execute("TRUNCATE domain_category, domain_category_stage")
        cur.execute("UPDATE category_list_state SET list_version=NULL, domains=0, "
                    "refreshed_at=NULL, last_attempt_at=NULL, last_error=NULL")
        c.commit()


def fetcher(tmp_path, folders):
    def fetch(dest):
        make_archive(dest, folders)
    return fetch


def test_refresh_loads_mapped_folders_and_counts(connect, tmp_path):
    reset(connect)
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': ['porn.example', 'bad..example', 'UPPER.Example.', '1.2.3.4'],
        'gambling': ['bet.example'],
        'recipes': ['cook.example'],                    # unmapped folder
    }))
    assert r['status'] == 'ok' and r['domains'] == 3
    assert r['invalid'] == 2                            # 'bad..example', '1.2.3.4'
    assert r['unmapped_folders'] == ['recipes']
    got = dict(rows(connect, "SELECT domain, category FROM domain_category"))
    assert got == {'porn.example': 'Pornography', 'upper.example': 'Pornography',
                   'bet.example': 'Gambling'}


def test_priority_resolves_a_domain_in_two_folders(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'gambling': ['both.example'], 'phishing': ['both.example']}))
    assert rows(connect, "SELECT category FROM domain_category WHERE domain='both.example'") \
        == [('Phishing and Other Frauds',)]


def test_state_row_updated(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['a.example']}))
    v, n, err, ref = rows(connect, "SELECT list_version, domains, last_error, refreshed_at "
                                   "FROM category_list_state")[0]
    assert (v, n, err) == ('test', 1, None) and ref is not None


def test_two_refreshes_keep_swap_contract_and_replace_content(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['one.example']}))
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['two.example']}))
    assert rows(connect, "SELECT domain FROM domain_category") == [('two.example',)]
    names = {r[0] for r in rows(connect,
        "SELECT indexname FROM pg_indexes WHERE tablename IN "
        "('domain_category','domain_category_stage')")}
    assert names == {'domain_category_pkey', 'domain_category_stage_pkey'}


def test_fetch_failure_keeps_previous_table_and_records_error(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['keep.example']}))

    def boom(dest):
        raise OSError('network down')
    r = cl.refresh_categories(connect, MAPPING, boom)
    assert r['status'] == 'kept' and 'network down' in r['error']
    assert rows(connect, "SELECT domain FROM domain_category") == [('keep.example',)]
    assert 'network down' in rows(connect, "SELECT last_error FROM category_list_state")[0][0]


def test_corrupt_archive_keeps_previous(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['keep.example']}))

    def junk(dest):
        open(dest, 'wb').write(b'not a tarball')
    r = cl.refresh_categories(connect, MAPPING, junk)
    assert r['status'] == 'kept'
    assert rows(connect, "SELECT count(*) FROM domain_category") == [(1,)]


def test_shrink_below_floor_keeps_previous(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': [f'd{i}.example' for i in range(10)]}))
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['d0.example']}))
    assert r['status'] == 'kept' and 'shrank' in r['error']
    assert rows(connect, "SELECT count(*) FROM domain_category") == [(10,)]


def test_empty_result_keeps_previous(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['keep.example']}))
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'recipes': ['x.example']}))
    assert r['status'] == 'kept'


def test_https_fetch_refuses_non_https(tmp_path):
    with pytest.raises(ValueError):
        cl.https_fetch('http://example.com/x.tar.gz', str(tmp_path / 'x'))
    with pytest.raises(ValueError):
        cl.https_fetch('file:///etc/passwd', str(tmp_path / 'x'))


def test_https_fetch_enforces_size_cap(tmp_path):
    class Resp:
        status = 200
        headers = {}
        def __init__(self): self._d = io.BytesIO(b'x' * 5000)
        def read(self, n=-1): return self._d.read(n)
        def __enter__(self): return self
        def __exit__(self, *a): return False
    with pytest.raises(ValueError):
        cl.https_fetch('https://example.com/a', str(tmp_path / 'x'), max_bytes=1000,
                       opener=lambda req, timeout: Resp())


def make_raw_archive(path, members: dict):
    """members: {folder: bytes} -> tar.gz with raw (possibly odd) domains files."""
    with tarfile.open(path, 'w:gz') as tar:
        for name, data in members.items():
            info = tarfile.TarInfo(f'blacklists/{name}/domains')
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))


def raw_fetcher(members):
    return lambda dest: make_raw_archive(dest, members)


def seed_previous(connect, tmp_path, n=3):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': [f'keep{i}.example' for i in range(n)]}))


def test_oversize_member_rejected_and_previous_list_kept(connect, tmp_path):
    seed_previous(connect, tmp_path)
    r = cl.refresh_categories(
        connect, MAPPING, raw_fetcher({'adult': b'big.example\n' * 50}), max_member_bytes=100)
    assert r['status'] == 'kept'
    assert rows(connect, "SELECT count(*) FROM domain_category") == [(3,)]


def test_oversize_member_is_counted_in_extract_stats(tmp_path):
    arc, tsv = str(tmp_path / 'a.tgz'), str(tmp_path / 'o.tsv')
    make_raw_archive(arc, {'adult': b'big.example\n' * 50, 'gambling': b'ok.example\n'})
    st = cl._extract_rows(arc, MAPPING, tsv, max_member_bytes=100)
    assert st['rejected_members'] == 1 and st['written'] == 1


def test_row_cap_exceeded_keeps_previous(connect, tmp_path):
    seed_previous(connect, tmp_path)
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': [f'n{i}.example' for i in range(20)]}), max_rows=10)
    assert r['status'] == 'kept' and 'rows' in r['error']
    assert rows(connect, "SELECT count(*) FROM domain_category") == [(3,)]


def test_total_bytes_cap_keeps_previous(connect, tmp_path):
    seed_previous(connect, tmp_path)
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': [f'n{i}.example' for i in range(20)]}), max_unpacked_bytes=50)
    assert r['status'] == 'kept' and 'bytes' in r['error']


def test_huge_single_line_counted_invalid_and_following_lines_load(tmp_path):
    arc, tsv = str(tmp_path / 'a.tgz'), str(tmp_path / 'o.tsv')
    data = b'first.example\n' + b'a' * 80_000_000 + b'\nsecond.example\n' + b'z' * 600 + b'\nlast.example'
    make_raw_archive(arc, {'adult': data})
    import tracemalloc
    tracemalloc.start()
    st = cl._extract_rows(arc, MAPPING, tsv)
    peak = tracemalloc.get_traced_memory()[1]
    tracemalloc.stop()
    assert peak < 60_000_000     # stdlib inflate buffer is ~32 MB; a whole-line read is >80 MB
    assert st['written'] == 3 and st['invalid'] == 2
    assert [l.split('\t')[0] for l in open(tsv)] == ['first.example', 'second.example', 'last.example']


def test_missing_state_row_is_recreated_and_refresh_works(connect, tmp_path):
    reset(connect)
    with contextlib.closing(connect()) as c, c.cursor() as cur:
        cur.execute("DELETE FROM category_list_state")
        c.commit()
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['a.example']}))
    assert r['status'] == 'ok'
    assert rows(connect, "SELECT domains FROM category_list_state WHERE id=1") == [(1,)]
    with contextlib.closing(connect()) as c, c.cursor() as cur:
        cur.execute("DELETE FROM category_list_state")
        c.commit()

    def boom(dest):
        raise OSError('down')
    cl.refresh_categories(connect, MAPPING, boom)
    assert 'down' in rows(connect, "SELECT last_error FROM category_list_state WHERE id=1")[0][0]


def test_shrink_floor_zero_disables_guard(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': [f'd{i}.example' for i in range(10)]}))
    r = cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['d0.example']}),
                              shrink_floor=0)
    assert r['status'] == 'ok'


def test_swap_truncates_old_list_from_stage(connect, tmp_path):
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['one.example']}))
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {'adult': ['two.example']}))
    assert rows(connect, "SELECT count(*) FROM domain_category_stage") == [(0,)]
    assert rows(connect, "SELECT domain FROM domain_category") == [('two.example',)]


class RecordingCursor:
    def __init__(self, log): self.log = log
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def execute(self, sql, params=None): self.log.append(' '.join(sql.split()))
    def fetchone(self): return (5,)
    def copy_expert(self, sql, fh): self.log.append('COPY')


class RecordingConn:
    def __init__(self): self.log = []
    def cursor(self): return RecordingCursor(self.log)
    def commit(self): self.log.append('commit')
    def rollback(self): self.log.append('rollback')
    def close(self): pass


def test_swap_sets_lock_timeout_right_before_renames(tmp_path):
    conn = RecordingConn()
    r = cl.refresh_categories(lambda: conn, MAPPING, fetcher(tmp_path, {'adult': ['a.example'] * 1}),
                              shrink_floor=0)
    assert r['status'] == 'ok', r
    log = conn.log
    lt = next(i for i, s in enumerate(log) if s == "SET LOCAL lock_timeout = '2s'")
    first_rename = next(i for i, s in enumerate(log) if s.startswith('ALTER TABLE'))
    assert lt == first_rename - 1
    assert any(s == 'TRUNCATE domain_category_stage' for s in log[first_rename:])


def test_https_fetch_refuses_redirect_to_non_https():
    handler = cl._HttpsOnlyRedirect()
    req = cl.urllib.request.Request('https://example.com/a')
    with pytest.raises(ValueError):
        handler.redirect_request(req, None, 302, 'Found', {}, 'http://evil.example/x')
    ok = handler.redirect_request(req, None, 302, 'Found', {}, 'https://example.com/b')
    assert ok is not None


def test_scheduled_job_skips_when_list_is_fresh(connect, tmp_path):
    from reports import scheduler_service as ss
    reset(connect)
    with contextlib.closing(connect()) as c, c.cursor() as cur:
        cur.execute("UPDATE category_list_state SET refreshed_at = now() - interval '1 hour'")
        c.commit()
    calls = []
    r = ss._category_job(connect, MAPPING, lambda dest: calls.append(dest), 24, 0.5)
    assert calls == [] and r is None


def test_scheduled_job_runs_when_stale_or_never_refreshed(connect, tmp_path):
    from reports import scheduler_service as ss
    reset(connect)                                       # refreshed_at NULL
    r = ss._category_job(connect, MAPPING, fetcher(tmp_path, {'adult': ['a.example']}), 24, 0.5)
    assert r['status'] == 'ok'
    with contextlib.closing(connect()) as c, c.cursor() as cur:
        cur.execute("UPDATE category_list_state SET refreshed_at = now() - interval '25 hours'")
        c.commit()
    r = ss._category_job(connect, MAPPING, fetcher(tmp_path, {'adult': ['b.example']}), 24, 0.5)
    assert r['status'] == 'ok'


def test_scheduled_job_passes_shrink_floor(connect, tmp_path):
    from reports import scheduler_service as ss
    reset(connect)
    cl.refresh_categories(connect, MAPPING, fetcher(tmp_path, {
        'adult': [f'd{i}.example' for i in range(10)]}))
    r = ss._category_job(connect, MAPPING, fetcher(tmp_path, {'adult': ['d0.example']}), 0, 0)
    assert r['status'] == 'ok'                           # floor 0 disables the guard
