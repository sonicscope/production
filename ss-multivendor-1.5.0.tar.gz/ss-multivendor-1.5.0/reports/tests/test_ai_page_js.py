"""Behavioural tests for the Investigate page script, run in jsdom via Node.

Skipped when `node` is not on PATH or jsdom cannot be resolved. To run locally:

    cd /tmp && npm install jsdom
    JSDOM_NODE_MODULES=/tmp/node_modules venv/bin/pytest reports/tests/test_ai_page_js.py

(jsdom is looked up in $JSDOM_NODE_MODULES, falling back to ./node_modules.)
"""
import json
import os
import shutil
import subprocess

import pytest

from reports.ai import page as ai_page

HARNESS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'js', 'investigate_harness.js')


def _jsdom_dir():
    cand = os.environ.get('JSDOM_NODE_MODULES') or os.path.join(os.getcwd(), 'node_modules')
    return cand if os.path.isdir(os.path.join(cand, 'jsdom')) else None


@pytest.fixture(scope='module')
def R():
    if shutil.which('node') is None:
        pytest.skip('node is not on PATH — set JSDOM_NODE_MODULES — required at release gate')
    nm = _jsdom_dir()
    if nm is None:
        pytest.skip('set JSDOM_NODE_MODULES — required at release gate (node_modules dir containing jsdom)')
    html = ai_page.investigate_html(configured=True, is_admin=True,
                                    tenants=[(1, 'Acme'), (2, 'Beta')], has_tenants=True,
                                    csrf='CSRF', nonce='N')
    # Drop the external Chart.js script (jsdom must not fetch it); tests stub window.Chart.
    html = html.replace(f'<script src="{ai_page.CHART_JS}"></script>', '')
    page = '<!doctype html><html><body>' + html + '</body></html>'
    proc = subprocess.run(['node', HARNESS], input=page, capture_output=True, text=True,
                          timeout=120, env={**os.environ, 'JSDOM_NODE_MODULES': nm})
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


def test_success_stream_split_chunks_and_text_nodes(R):
    r = R['success']
    assert r['errs'] == []
    assert r['bubbles'][0] == 'ME:hello'
    assert 'A:Answer ✓ ünï 日本語 <b>x</b>' in r['bubbles']
    assert r['scripts'] == 0 and r['details'] == 1
    assert r['summary'] == 'QUERY · 1234 rows · 1.2 s'  # row_count, not rows.length
    assert '<script>alert(1)</script>"\'><img src=x onerror=1>' in r['tds']
    o = r['order']
    assert o.index('bubble ') < o.index('chartbox') < o.index('evidence') < o.index('chips')
    assert r['chartCfg'] == 'bar' and r['canvasLabel'] == 'T"<b>'
    assert r['chips'] == ['Next 1?', 'Next <i>2</i>?']
    assert r['calls'][0]['question'] == 'hello' and r['calls'][0]['tenant_id'] == 1
    assert not r['sendDisabled'] and r['label'] == 'Ask'


def test_chart_unavailable_note(R):
    assert R['success_nochart']['chartNote'] == ['Chart unavailable']
    assert R['chart_throws']['chartNote'] == ['Chart unavailable']


def test_copy_sql(R):
    assert R['copy']['clip'].startswith('SELECT <script>')
    assert R['copy']['copyLabel'] == 'Copied'
    assert R['copy_fail']['copyLabel'] == 'Copy failed'
    assert R['copy_none']['copyLabel'] == 'Copy failed'


def test_error_event_and_http_errors(R):
    assert R['error_event']['bubbles'][-1] == 'ERR:Model failed <b>'
    assert R['http_429']['bubbles'][-1] == 'ERR:Rate limited Try again in a minute.'
    assert R['http_409']['bubbles'][-1] == 'ERR:Busy'
    assert R['http_502']['bubbles'][-1] == 'ERR:Request failed (502).'
    for k in ('error_event', 'http_429', 'http_409', 'http_502', 'fetch_reject'):
        assert not R[k]['sendDisabled'] and R[k]['label'] == 'Ask', k


def test_fetch_rejection(R):
    assert R['fetch_reject']['bubbles'][-1] == \
        'ERR:Could not reach the server. Check your connection and try again.'


def test_history_only_for_completed_answers(R):
    assert R['no_done']['calls'][1]['history'] == [
        {'role': 'user', 'content': 'q'}, {'role': 'assistant', 'content': 'hi'}]
    assert R['empty_stream']['calls'][1]['history'] == []
    assert R['stream_error_no_answer']['calls'][1]['history'] == []


def test_double_submit_while_busy(R):
    assert len(R['double_submit']['calls']) == 1


def test_history_bounded_and_capped(R):
    h = R['history_bound']['calls'][7]['history']
    assert len(h) == 10
    assert max(len(x['content']) for x in h) == 4000


def test_followup_and_explain_requests(R):
    calls = R['followup_explain']['calls']
    assert calls[1]['question'] == 'Next 1?'
    assert calls[2]['explain_threat'] == 'Evil.Threat'
    users = [h['content'] for h in calls[2]['history'] if h['role'] == 'user']
    assert users == ['q', 'Next 1?']
    last = R['followup_explain']['bubbles']
    assert 'ME:Explain: Evil.Threat' in last


def test_tenant_switch_during_request_does_not_leak(R):
    r = R['tenant_race']
    assert 'OLDTENANT' not in r['msgsText']
    assert r['calls'][1]['tenant_id'] == 2
    assert r['calls'][1]['history'] == []
    assert not r['sendDisabled'] and r['label'] == 'Ask'


def test_tenant_select_disabled_while_in_flight(R):
    assert R['_sel_disabled_mid'] is True
    assert R['tenant_select_disabled_in_flight']['tenantDisabled'] is False
