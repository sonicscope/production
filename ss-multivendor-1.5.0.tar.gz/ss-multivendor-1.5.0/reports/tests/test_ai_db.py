"""Migration 010: ss_ai_ro role, ai.* views, ai_audit immutability."""
import psycopg2
import pytest

AI_VIEWS = ['events', 'hourly_bandwidth', 'hourly_threat', 'daily_app', 'daily_web',
            'daily_domain', 'daily_geo', 'daily_rule', 'daily_threat']
FORBIDDEN_COLUMNS = {'user_name', 'device_name', 'department', 'message', 'raw_message',
                     'extra', 'vpn_client_ip', 'url'}


def _q(app_module, sql, params=()):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall() if cur.description else None


def test_all_views_exist(app_module):
    rows = _q(app_module, "SELECT table_name FROM information_schema.views WHERE table_schema='ai'")
    assert {r[0] for r in rows} == set(AI_VIEWS)


def test_no_identity_or_free_text_columns(app_module):
    rows = _q(app_module, "SELECT table_name, column_name FROM information_schema.columns "
                          "WHERE table_schema='ai'")
    leaked = [(t, c) for t, c in rows if c in FORBIDDEN_COLUMNS]
    assert leaked == []


def test_events_url_path_strips_query_string(app_module, seed_tenants, seed_fw_event):
    t, = seed_tenants('Acme')
    seed_fw_event(t, url='https://x.example/p?token=SECRET#frag', domain='x.example')
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('ss.tenant_id', %s, true)", (str(t),))
            cur.execute("SELECT url_path FROM ai.events")
            assert cur.fetchone()[0] == 'https://x.example/p'


def test_every_ai_view_is_granted_to_role(app_module):
    rows = _q(app_module,
              "SELECT table_name FROM information_schema.table_privileges "
              "WHERE table_schema='ai' AND grantee='ss_ai_ro' AND privilege_type='SELECT'")
    assert {r[0] for r in rows} == set(AI_VIEWS)


def test_role_cannot_read_base_or_sensitive_tables(ai_ro_config):
    for table in ('fw_events', 'ai_settings', 'ai_audit', 'ui_users', 'msp_profiles',
                  'hourly_user_traffic', 'identity_mappings'):
        with psycopg2.connect(**ai_ro_config) as conn:
            with conn.cursor() as cur:
                with pytest.raises(psycopg2.errors.InsufficientPrivilege):
                    cur.execute(f'SELECT * FROM public.{table} LIMIT 1')


def test_role_is_read_only_with_limits(ai_ro_config):
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            cur.execute('SHOW default_transaction_read_only')
            assert cur.fetchone()[0] == 'on'
            cur.execute('SHOW statement_timeout')
            assert cur.fetchone()[0] == '10s'
            cur.execute('SHOW search_path')
            assert cur.fetchone()[0].replace(' ', '') == 'pg_catalog,public'
            with pytest.raises(psycopg2.errors.ReadOnlySqlTransaction):
                cur.execute('CREATE TEMP TABLE t (a int)')


def test_views_filter_on_tenant_guc(app_module, ai_ro_config, seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example')
    seed_fw_event(b, domain='b.example')
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            cur.execute('SELECT count(*) FROM ai.events')          # GUC unset -> fail closed
            assert cur.fetchone()[0] == 0
            cur.execute("SELECT set_config('ss.tenant_id', %s, true)", (str(a),))
            cur.execute('SELECT domain FROM ai.events')
            assert [r[0] for r in cur.fetchall()] == ['a.example']


def test_time_bucket_resolves_on_role_search_path(app_module, ai_ro_config, seed_tenants,
                                                  seed_fw_event):
    """time_bucket (allowlisted by the SQL guard) lives in the TimescaleDB
    extension schema; it must resolve unqualified for ss_ai_ro."""
    (a,) = seed_tenants('A')
    seed_fw_event(a, domain='a.example')
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('ss.tenant_id', %s, true)", (str(a),))
            cur.execute("SELECT time_bucket('1 hour', time) FROM ai.events LIMIT 1")
            assert cur.fetchone()[0] is not None
            cur.execute("SELECT n.nspname FROM pg_proc p JOIN pg_namespace n "
                        "ON n.oid = p.pronamespace WHERE p.proname = 'time_bucket' LIMIT 1")
            assert cur.fetchone()[0] in ('pg_catalog', 'public')


def test_view_owner_is_not_superuser(app_module):
    rows = _q(app_module,
              "SELECT r.rolsuper FROM pg_views v JOIN pg_roles r ON r.rolname = v.viewowner "
              "WHERE v.schemaname='ai'")
    assert rows and not any(r[0] for r in rows)


def test_ai_audit_is_immutable(app_module):
    _q(app_module, "INSERT INTO ai_audit (kind) VALUES ('chat')")
    with pytest.raises(psycopg2.errors.RaiseException, match='immutable'):
        _q(app_module, "UPDATE ai_audit SET kind='x'")
    with pytest.raises(psycopg2.errors.RaiseException, match='cannot be deleted'):
        _q(app_module, "DELETE FROM ai_audit")


def test_ai_audit_old_rows_can_be_deleted(app_module):
    _q(app_module, "INSERT INTO ai_audit (kind, ts) VALUES ('chat', now() - interval '400 days')")
    _q(app_module, "DELETE FROM ai_audit WHERE ts < now() - interval '365 days'")
    assert _q(app_module, "SELECT count(*) FROM ai_audit")[0][0] == 0


@pytest.mark.parametrize('view', AI_VIEWS)
def test_role_can_select_every_ai_view(ai_ro_config, view):
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('ss.tenant_id', '1', true)")
            cur.execute(f'SELECT count(*) FROM ai.{view}')
            assert cur.fetchone()[0] == 0


def test_role_cannot_execute_lookup_identity(ai_ro_config):
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            with pytest.raises(psycopg2.errors.InsufficientPrivilege):
                cur.execute("SELECT public.lookup_identity(1, '10.0.0.1'::inet)")


def test_tenants_ai_enabled_defaults_false(app_module, seed_tenants):
    t, = seed_tenants('Acme')
    assert _q(app_module, "SELECT ai_enabled FROM tenants WHERE id=%s", (t,))[0][0] is False
