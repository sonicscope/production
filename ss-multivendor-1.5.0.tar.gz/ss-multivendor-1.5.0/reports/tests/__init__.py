"""Test package for the reports Flask app (reports/web/app.py).

See conftest.py for the test-DB / fixture strategy.
"""
