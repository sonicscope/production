def test_pglast_parses_select():
    from pglast import parse_sql
    stmts = parse_sql('SELECT 1')
    assert len(stmts) == 1


def test_aesgcm_roundtrip():
    import os
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    key = AESGCM.generate_key(bit_length=256)
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, b'secret', b'aad')
    assert AESGCM(key).decrypt(nonce, ct, b'aad') == b'secret'
