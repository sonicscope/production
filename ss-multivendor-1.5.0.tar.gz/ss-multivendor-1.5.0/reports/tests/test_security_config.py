"""Regression tests for the Task 3 transport-security hardening.

These lock in the two production-security guarantees that Task 3 exists to
make, and which NO other test exercises: every other test runs under
conftest.py's blanket ``COOKIE_SECURE=false`` (so the werkzeug http test
client can round-trip the session cookie), meaning nothing else would catch
a regression that flips the production default back to insecure or drops the
reverse-proxy trust wiring.

1. With ``COOKIE_SECURE`` absent from the environment (the real production
   case — the installer sets nothing that overrides it), the app MUST default
   ``SESSION_COOKIE_SECURE`` to True, so session cookies are only ever sent
   over TLS.
2. ``app.wsgi_app`` MUST be wrapped in werkzeug's ``ProxyFix`` so Flask
   honours nginx's ``X-Forwarded-Proto: https`` — without it, ``request.is_secure``
   is False behind the proxy and secure cookies/absolute https URLs break.

Both deliberately bypass the ``app_module`` fixture (which forces
``COOKIE_SECURE=false``) and reload the module themselves with a clean env so
the assertions reflect genuine production defaults. Module state is restored in
teardown so the reload does not leak insecure config into other tests.
"""
from __future__ import annotations

import importlib
import os
import sys

import pytest
from werkzeug.middleware.proxy_fix import ProxyFix

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_WEB_DIR = os.path.join(os.path.dirname(_TESTS_DIR), 'web')


@pytest.fixture
def app_prod_default(monkeypatch):
    """Reload reports/web/app.py with COOKIE_SECURE removed from the env,
    reproducing the production default. Stops any scheduler the reload starts
    and reloads the module back under a safe (COOKIE_SECURE=false) env in
    teardown so no insecure/duplicate state leaks into later tests."""
    # Production case: nothing sets COOKIE_SECURE, so the app's own default
    # ('true') must win. Delete it rather than set it, so the test genuinely
    # exercises the default branch.
    monkeypatch.delenv('COOKIE_SECURE', raising=False)
    # Point DB/SMTP at nothing reachable and blank secrets so the reload's
    # import-time scheduler start fails gracefully (app.py guards it) and no
    # real collector.env creds leak into the test process.
    monkeypatch.setenv('FLASK_SECRET', 'test-secret')
    monkeypatch.setenv('SMTP_HOST', '')
    monkeypatch.setenv('SMTP_USER', '')
    monkeypatch.setenv('SMTP_PASSWORD', '')
    monkeypatch.setenv('SMTP_FROM', '')

    if _WEB_DIR not in sys.path:
        sys.path.insert(0, _WEB_DIR)

    if 'app' in sys.modules:
        mod = importlib.reload(sys.modules['app'])
    else:
        mod = importlib.import_module('app')

    yield mod

    # Teardown: stop the scheduler this reload started, then reload the module
    # back under COOKIE_SECURE=false so subsequent app_module-based tests (and
    # any leftover import) never inherit the secure-by-default config.
    if getattr(mod, '_scheduler', None) is not None:
        try:
            mod.stop_scheduler(mod._scheduler)
        except Exception:
            pass
    monkeypatch.setenv('COOKIE_SECURE', 'false')
    try:
        restored = importlib.reload(sys.modules['app'])
        if getattr(restored, '_scheduler', None) is not None:
            try:
                restored.stop_scheduler(restored._scheduler)
            except Exception:
                pass
    except Exception:
        pass


def test_session_cookie_secure_defaults_true_in_production(app_prod_default):
    """With COOKIE_SECURE unset, the app must default to secure cookies.

    RED if someone flips app.py's default back to 'false' — that would
    silently restore cleartext-cookie exposure the moment the app runs
    without an explicit COOKIE_SECURE.
    """
    assert app_prod_default.app.config['SESSION_COOKIE_SECURE'] is True


def test_wsgi_app_is_wrapped_in_proxyfix(app_prod_default):
    """The app must trust the reverse proxy's X-Forwarded-* headers.

    RED if the ProxyFix wrap is dropped — Flask would then see every request
    as plain http behind nginx and refuse to set the Secure session cookie /
    emit https absolute URLs.
    """
    assert isinstance(app_prod_default.app.wsgi_app, ProxyFix)
