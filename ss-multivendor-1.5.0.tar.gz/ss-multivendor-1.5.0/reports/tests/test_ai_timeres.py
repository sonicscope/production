from datetime import datetime, timezone

import pytest

from reports.ai.timeres import TimeResolveError, resolve_time

NOW = datetime(2026, 11, 17, 10, 0, tzinfo=timezone.utc)      # 12:00 in Johannesburg
JNB = 'Africa/Johannesburg'
NY = 'America/New_York'
LON = 'Europe/London'


def utc(y, mo, d, h=0, mi=0):
    return datetime(y, mo, d, h, mi, tzinfo=timezone.utc)


# --- Johannesburg baseline -------------------------------------------------

def test_today_uses_tenant_midnight():
    r = resolve_time({'kind': 'today'}, JNB, NOW)
    assert r['start_utc'] == '2026-11-16 22:00:00+00'
    assert r['end_utc'] == '2026-11-17 10:00:00+00'
    assert r['timezone'] == JNB


def test_yesterday_is_a_full_local_day():
    r = resolve_time({'kind': 'yesterday'}, JNB, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-11-15 22:00:00+00', '2026-11-16 22:00:00+00')


def test_last_hours_and_days():
    assert resolve_time({'kind': 'last_hours', 'n': 3}, JNB, NOW)['start_utc'] == '2026-11-17 07:00:00+00'
    assert resolve_time({'kind': 'last_days', 'n': 2}, JNB, NOW)['start_utc'] == '2026-11-15 10:00:00+00'


def test_between_local_times():
    r = resolve_time({'kind': 'between', 'start': '2026-11-14 14:00',
                      'end': '2026-11-14 16:00'}, JNB, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-11-14 12:00:00+00', '2026-11-14 14:00:00+00')
    assert '2026-11-14 14:00' in r['label']


@pytest.mark.parametrize('args', [
    {'kind': 'last_hours', 'n': 0}, {'kind': 'last_hours', 'n': 745},
    {'kind': 'last_days', 'n': 91}, {'kind': 'last_days', 'n': 'x'},
    {'kind': 'between', 'start': '2026-11-15', 'end': '2026-11-14'},
    {'kind': 'between', 'start': 'junk', 'end': '2026-11-14'},
    {'kind': 'next_week'}, {},
])
def test_invalid_arguments(args):
    with pytest.raises(TimeResolveError):
        resolve_time(args, JNB, NOW)


def test_bad_timezone_falls_back():
    assert resolve_time({'kind': 'today'}, 'Not/AZone', NOW)['timezone'] == JNB


@pytest.mark.parametrize('tz', [None, 42, '', ['Africa/Johannesburg']])
def test_unusable_timezone_values_fall_back(tz):
    assert resolve_time({'kind': 'today'}, tz, NOW)['timezone'] == JNB


# --- DST: today / yesterday on spring-forward and fall-back days ----------

@pytest.mark.parametrize('kind, now, start, end, hours', [
    # New York spring forward 2026-03-08 (23h day on 03-08 once it is over)
    ('today', utc(2026, 3, 8, 16), utc(2026, 3, 8, 5), utc(2026, 3, 8, 16), 11),
    ('yesterday', utc(2026, 3, 9, 16), utc(2026, 3, 8, 5), utc(2026, 3, 9, 4), 23),
    # New York fall back 2026-11-01 (25h day)
    ('yesterday', utc(2026, 11, 2, 17), utc(2026, 11, 1, 4), utc(2026, 11, 2, 5), 25),
])
def test_ny_dst_days(kind, now, start, end, hours):
    r = resolve_time({'kind': kind}, NY, now)
    assert r['start_utc'] == start.strftime('%Y-%m-%d %H:%M:%S+00')
    assert r['end_utc'] == end.strftime('%Y-%m-%d %H:%M:%S+00')
    assert (end - start).total_seconds() == hours * 3600


@pytest.mark.parametrize('kind, now, start, end, hours', [
    # London spring forward 2026-03-29 (23h day)
    ('yesterday', utc(2026, 3, 30, 11), utc(2026, 3, 29, 0), utc(2026, 3, 29, 23), 23),
    # London fall back 2026-10-25 (25h day)
    ('yesterday', utc(2026, 10, 26, 12), utc(2026, 10, 24, 23), utc(2026, 10, 26, 0), 25),
])
def test_london_dst_days(kind, now, start, end, hours):
    r = resolve_time({'kind': kind}, LON, now)
    assert r['start_utc'] == start.strftime('%Y-%m-%d %H:%M:%S+00')
    assert r['end_utc'] == end.strftime('%Y-%m-%d %H:%M:%S+00')
    assert (end - start).total_seconds() == hours * 3600


# --- between: DST, gap, ambiguity, date-only semantics ---------------------

def test_between_across_spring_forward_uses_real_elapsed_time():
    # 01:00 EST -> 04:00 EDT is 2 real hours, not 3
    r = resolve_time({'kind': 'between', 'start': '2026-03-08 01:00',
                      'end': '2026-03-08 04:00'}, NY, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-03-08 06:00:00+00', '2026-03-08 08:00:00+00')


@pytest.mark.parametrize('args', [
    {'kind': 'between', 'start': '2026-03-08 02:30', 'end': '2026-03-08 03:30'},
    {'kind': 'between', 'start': '2026-03-08 01:30', 'end': '2026-03-08 02:30'},
])
def test_between_rejects_nonexistent_local_time(args):
    with pytest.raises(TimeResolveError, match='daylight-saving gap'):
        resolve_time(args, NY, NOW)


def test_between_ambiguous_time_uses_first_occurrence():
    # 01:30 happens twice on 2026-11-01 in New York; the first (EDT, UTC-4) is used.
    r = resolve_time({'kind': 'between', 'start': '2026-11-01 01:30',
                      'end': '2026-11-01 01:45'}, NY, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-11-01 05:30:00+00', '2026-11-01 05:45:00+00')


def test_date_only_start_and_end_cover_whole_local_day():
    r = resolve_time({'kind': 'between', 'start': '2026-11-14', 'end': '2026-11-14'}, JNB, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-11-13 22:00:00+00', '2026-11-14 22:00:00+00')
    assert '2026-11-14 00:00' in r['label']


def test_date_only_end_with_explicit_start_time():
    r = resolve_time({'kind': 'between', 'start': '2026-11-14 06:00', 'end': '2026-11-14'}, JNB, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-11-14 04:00:00+00', '2026-11-14 22:00:00+00')


def test_explicit_end_time_is_exact():
    r = resolve_time({'kind': 'between', 'start': '2026-11-14', 'end': '2026-11-14 12:00'}, JNB, NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-11-13 22:00:00+00', '2026-11-14 10:00:00+00')


def test_between_span_limit():
    ok = resolve_time({'kind': 'between', 'start': '2000-01-01', 'end': '2005-01-01'}, JNB, NOW)
    assert ok['start_utc'].startswith('1999-12-31')
    with pytest.raises(TimeResolveError, match='5 years'):
        resolve_time({'kind': 'between', 'start': '2000-01-01', 'end': '2006-01-01'}, JNB, NOW)


@pytest.mark.parametrize('args', [
    {'kind': 'between', 'start': '0001-01-01', 'end': '0001-01-02'},
    {'kind': 'between', 'start': '2026-11-14', 'end': '9999-12-31'},
    {'kind': 'between', 'start': '1999-12-31', 'end': '2026-11-14'},
    {'kind': 'between', 'start': '2101-01-01', 'end': '2101-01-02'},
])
def test_between_year_clamp(args):
    with pytest.raises(TimeResolveError, match='year'):
        resolve_time(args, JNB, NOW)


def test_between_year_limit_in_new_york_is_refused_not_raised():
    with pytest.raises(TimeResolveError):
        resolve_time({'kind': 'between', 'start': '9999-12-31 20:00',
                      'end': '9999-12-31 23:59'}, NY, NOW)


@pytest.mark.parametrize('args', [
    {'kind': 'between', 'start': None, 'end': '2026-11-14'},
    {'kind': 'between', 'start': '2026-11-14', 'end': 20261114},
    {'kind': 'between', 'start': '2026-13-01', 'end': '2026-13-02'},
])
def test_between_rejects_non_string_or_impossible_dates(args):
    with pytest.raises(TimeResolveError):
        resolve_time(args, JNB, NOW)


# --- raw-exception inputs: only TimeResolveError may escape ----------------

@pytest.mark.parametrize('n', [float('inf'), float('-inf'), float('nan'), 2.5, 10 ** 400,
                               True, False, ' 3', '٣', '-1', '1e3', None])
def test_bad_n_values_raise_time_resolve_error(n):
    with pytest.raises(TimeResolveError):
        resolve_time({'kind': 'last_hours', 'n': n}, JNB, NOW)
    with pytest.raises(TimeResolveError):
        resolve_time({'kind': 'last_days', 'n': n}, JNB, NOW)


def test_integer_string_n_is_accepted():
    r = resolve_time({'kind': 'last_hours', 'n': '3'}, JNB, NOW)
    assert r['start_utc'] == '2026-11-17 07:00:00+00'


def test_naive_now_is_rejected():
    with pytest.raises(TimeResolveError, match='timezone-aware'):
        resolve_time({'kind': 'today'}, JNB, datetime(2026, 11, 17, 10, 0))


def test_overflow_near_datetime_minimum_is_refused():
    with pytest.raises(TimeResolveError, match='out of supported bounds'):
        resolve_time({'kind': 'today'}, JNB, datetime(1, 1, 1, 1, tzinfo=timezone.utc))
    with pytest.raises(TimeResolveError):
        resolve_time({'kind': 'last_hours', 'n': 1}, JNB, datetime(1, 1, 1, 0, 30, tzinfo=timezone.utc))


# --- date-only between on days where local midnight does not exist ---------

@pytest.mark.parametrize('zone, day, start, end', [
    # Egypt, DST starts 2026-04-24 00:00 -> 01:00 (first valid instant 01:00 EEST)
    ('Africa/Cairo', '2026-04-24', '2026-04-23 22:00:00+00', '2026-04-24 21:00:00+00'),
    # Lebanon, DST starts 2026-03-29 00:00 -> 01:00
    ('Asia/Beirut', '2026-03-29', '2026-03-28 22:00:00+00', '2026-03-29 21:00:00+00'),
    # Cuba, DST starts 2026-03-08 00:00 -> 01:00
    ('America/Havana', '2026-03-08', '2026-03-08 05:00:00+00', '2026-03-09 04:00:00+00'),
])
def test_date_only_between_on_midnight_gap_day_starts_at_first_valid_instant(zone, day, start, end):
    r = resolve_time({'kind': 'between', 'start': day, 'end': day}, zone, NOW)
    assert (r['start_utc'], r['end_utc']) == (start, end)


@pytest.mark.parametrize('zone, start_text', [
    ('Africa/Cairo', '2026-04-24 00:30'),
    ('Asia/Beirut', '2026-03-29 00:30'),
    ('America/Havana', '2026-03-08 00:30'),
])
def test_explicit_time_in_midnight_gap_is_refused(zone, start_text):
    with pytest.raises(TimeResolveError, match='daylight-saving gap'):
        resolve_time({'kind': 'between', 'start': start_text, 'end': start_text[:10] + ' 12:00'},
                     zone, NOW)
    with pytest.raises(TimeResolveError, match='daylight-saving gap'):
        resolve_time({'kind': 'between', 'start': start_text[:10], 'end': start_text},
                     zone, NOW)


def test_date_only_end_on_gap_day_covers_through_that_day():
    r = resolve_time({'kind': 'between', 'start': '2026-04-20', 'end': '2026-04-24'}, 'Africa/Cairo', NOW)
    assert (r['start_utc'], r['end_utc']) == ('2026-04-19 22:00:00+00', '2026-04-24 21:00:00+00')
