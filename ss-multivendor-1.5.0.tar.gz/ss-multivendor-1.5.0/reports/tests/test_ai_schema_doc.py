import psycopg2

from reports.ai.schema_doc import VIEW_NOTES, build_schema_doc
from reports.ai.sql_guard import ALLOWED_FUNCTIONS, ALLOWED_RELATIONS


class _FakeCursor:
    """Stands in for information_schema.columns rows: (table, column, type)."""

    def __init__(self, rows):
        self._rows = rows

    def execute(self, _sql):
        pass

    def fetchall(self):
        return self._rows


def test_doc_covers_views_functions_and_hides_identity(app_module):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            doc = build_schema_doc(cur)
    for view in ALLOWED_RELATIONS:
        assert f'ai.{view}' in doc
    for fn in ('date_trunc', 'count', 'time_bucket'):
        assert fn in ALLOWED_FUNCTIONS and fn in doc
    for word in ('user_name', 'device_name', 'department', 'raw_message', 'vpn_client_ip'):
        assert word not in doc
    assert 'resolve_time' in doc and 'UTC' in doc and 'never filter by tenant' in doc
    assert 'give it an alias' in doc and 'never write ai.<view>.column' in doc
    for fn in ALLOWED_FUNCTIONS:
        assert fn in doc


def test_view_notes_cover_exactly_the_allowed_relations():
    assert set(VIEW_NOTES) == set(ALLOWED_RELATIONS)


def test_aggregate_notes_state_their_filters():
    assert 'only events with a web category' in VIEW_NOTES['daily_web']
    assert 'only events with a domain' in VIEW_NOTES['daily_domain']
    assert 'only events with a destination country' in VIEW_NOTES['daily_geo']
    assert 'only events with a rule name' in VIEW_NOTES['daily_rule']


def test_undocumented_or_unallowed_views_are_not_emitted():
    rows = [
        ('events', 'time', 'timestamp with time zone'),
        ('daily_web', 'web_category', 'text'),
        ('secret_helper', 'user_name', 'text'),   # in ai schema but not allowlisted
    ]
    doc = build_schema_doc(_FakeCursor(rows))
    assert 'ai.events' in doc and 'ai.daily_web' in doc
    assert 'secret_helper' not in doc and 'user_name' not in doc


def test_daily_app_note_states_app_name_is_never_null():
    assert 'app_name is never NULL' in VIEW_NOTES['daily_app']
    assert 'may be NULL' not in VIEW_NOTES['daily_app']


def test_guide_states_rolling_windows_are_exact_hours():
    doc = build_schema_doc(_FakeCursor([]))
    assert 'last_hours and last_days are exact 1-hour and 24-hour multiples' in doc
    assert 'Results shown to you are capped at 200 rows.' in doc


def test_guide_says_aggregates_count_events_matching_filters():
    doc = build_schema_doc(_FakeCursor([]))
    assert 'only count the events matching the filters named in their description' in doc
    assert 'only count the event types' not in doc
