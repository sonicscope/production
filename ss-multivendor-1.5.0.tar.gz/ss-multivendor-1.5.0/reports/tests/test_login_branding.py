"""Per-MSP login branding (P1 white-label item).

Covers docs/superpowers/specs/2026-07-14-msp-login-branding-design.md:
the unauthenticated /login, /forgot-password and /reset-password pages
brand for the install's single MSP (`_login_branding()`), a public
`/brand/logo` route serves that MSP's logo without a session, and
`_readable_text_color()` keeps the "Sign In" button text readable against
an arbitrary MSP `primary_color`.

One MSP per install — no hostname/subdomain resolution (see spec). Tests
below therefore cover: auto-detect (exactly one `msp_profiles` row),
explicit `LOGIN_MSP_ID` env override (two rows), and neutral fallback
(zero rows, or more than one with no `LOGIN_MSP_ID`).
"""
from __future__ import annotations

import importlib
import os
import sys

import pytest


# ── _readable_text_color: pure unit tests ──────────────────────────────────────

def test_readable_text_color_light_background_gets_black_text(app_module):
    assert app_module._readable_text_color('#ffff00') == '#000000'


def test_readable_text_color_dark_background_gets_white_text(app_module):
    assert app_module._readable_text_color('#001133') == '#ffffff'


def test_readable_text_color_shorthand_hex_is_supported(app_module):
    assert app_module._readable_text_color('#fff') == '#000000'
    assert app_module._readable_text_color('#000') == '#ffffff'


@pytest.mark.parametrize('bad', [None, '', 'not-a-color', '#12', '#gggggg', 'red'])
def test_readable_text_color_malformed_input_returns_safe_default(app_module, bad):
    # Safe default = white text, matching the existing hardcoded teal button.
    assert app_module._readable_text_color(bad) == '#ffffff'


# ── _login_branding: resolution order ──────────────────────────────────────────

def test_login_branding_none_when_zero_profiles(app_module):
    with app_module.app.app_context():
        assert app_module._login_branding() is None


def test_login_branding_auto_detects_sole_profile(app_module, seed_msp_profile):
    seed_msp_profile('ACME', primary_color='#123456')
    with app_module.app.app_context():
        branding = app_module._login_branding()
    assert branding is not None
    assert branding['name'] == 'ACME'
    assert branding['primary_color'] == '#123456'
    assert branding['has_logo'] is False


def test_login_branding_none_when_multiple_profiles_and_no_config(app_module, seed_msp_profile):
    seed_msp_profile('Acme')
    seed_msp_profile('Globex')
    with app_module.app.app_context():
        assert app_module._login_branding() is None


def test_login_branding_has_logo_true_when_logo_file_present(
    app_module, seed_msp_profile, write_logo_file,
):
    logo_path = write_logo_file('acme-logo.png')
    seed_msp_profile('ACME', logo_path=logo_path)
    with app_module.app.app_context():
        branding = app_module._login_branding()
    assert branding['has_logo'] is True


# ── /login, /forgot-password, /reset-password: auto-brand (one MSP) ───────────

def test_login_page_shows_msp_name_when_one_profile(client, seed_msp_profile, app_module):
    seed_msp_profile('ACME', primary_color='#123456')
    html = client.get('/login').get_data(as_text=True)
    assert 'ACME' in html
    assert app_module.APP_BRAND not in html


def test_login_page_uses_primary_color_for_button(client, seed_msp_profile):
    seed_msp_profile('ACME', primary_color='#123456')
    html = client.get('/login').get_data(as_text=True)
    assert '#123456' in html


def test_login_page_title_uses_msp_name(client, seed_msp_profile):
    seed_msp_profile('ACME', primary_color='#123456')
    html = client.get('/login').get_data(as_text=True)
    assert '<title>ACME — Reports</title>' in html


def test_login_page_renders_logo_img_when_msp_has_logo(
    client, seed_msp_profile, write_logo_file,
):
    logo_path = write_logo_file('acme-logo.png')
    seed_msp_profile('ACME', logo_path=logo_path)
    html = client.get('/login').get_data(as_text=True)
    assert '<img src="/brand/logo"' in html


def test_login_page_shows_footer_text_when_set(client, seed_msp_profile):
    seed_msp_profile('ACME', footer_text='Powered by Acme IT')
    html = client.get('/login').get_data(as_text=True)
    assert 'Powered by Acme IT' in html


def test_forgot_password_page_shows_msp_name(client, seed_msp_profile):
    seed_msp_profile('ACME', primary_color='#123456')
    html = client.get('/forgot-password').get_data(as_text=True)
    assert 'ACME' in html


def test_reset_password_page_shows_msp_name(client, seed_msp_profile):
    seed_msp_profile('ACME', primary_color='#123456')
    html = client.get('/reset-password').get_data(as_text=True)
    assert 'ACME' in html


# ── Neutral fallback (no regression) ───────────────────────────────────────────

def test_login_page_neutral_when_zero_profiles(client, app_module):
    html = client.get('/login').get_data(as_text=True)
    assert app_module.APP_BRAND in html


def test_login_page_neutral_when_multiple_profiles_and_no_config(
    client, seed_msp_profile, app_module,
):
    seed_msp_profile('Acme')
    seed_msp_profile('Globex')
    html = client.get('/login').get_data(as_text=True)
    assert app_module.APP_BRAND in html
    assert 'Acme' not in html
    assert 'Globex' not in html


def test_login_still_authenticates_when_branded(client, csrf_of, seed_msp_profile, app_module):
    """No regression: a real login POST must still succeed when the page
    is branded — branding must not interfere with CSRF or auth."""
    import secrets as _secrets
    import psycopg2
    from werkzeug.security import generate_password_hash

    seed_msp_profile('ACME', primary_color='#123456')
    email = f"branded-{_secrets.token_hex(4)}@example.test"
    password = 'correct horse battery staple'
    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute(
                'INSERT INTO ui_users (email, full_name, role, is_active, password_hash) '
                'VALUES (%s, %s, %s, true, %s)',
                (email, 'Branded Test User', 'admin', generate_password_hash(password)),
            )
        conn.commit()

    resp = client.post('/login', data={
        '_csrf': csrf_of(client), 'email': email, 'password': password,
    })
    assert resp.status_code == 302


# ── /brand/logo: public route ───────────────────────────────────────────────────

def test_brand_logo_reachable_without_session_when_logo_set(
    client, seed_msp_profile, write_logo_file,
):
    logo_path = write_logo_file('acme-logo.png', content=b'\x89PNG\r\n\x1a\nfake-bytes')
    seed_msp_profile('ACME', logo_path=logo_path)
    resp = client.get('/brand/logo')
    assert resp.status_code == 200
    assert resp.data == b'\x89PNG\r\n\x1a\nfake-bytes'


def test_brand_logo_404_when_no_logo_configured(client, seed_msp_profile):
    seed_msp_profile('ACME')  # no logo_path
    resp = client.get('/brand/logo')
    assert resp.status_code == 404


def test_brand_logo_404_when_neutral(client):
    resp = client.get('/brand/logo')
    assert resp.status_code == 404


def test_brand_logo_is_in_public_endpoints(app_module):
    assert 'brand_logo' in app_module._PUBLIC_ENDPOINTS


# ── Contrast in a real render ───────────────────────────────────────────────────

def test_login_button_text_is_dark_for_light_primary_color(client, seed_msp_profile):
    seed_msp_profile('ACME', primary_color='#ffff00')
    html = client.get('/login').get_data(as_text=True)
    assert '#000000' in html


# ── Availability: DB outage must not 500 the login page ────────────────────────

def test_login_degrades_to_neutral_when_branding_query_raises(
    client, app_module, monkeypatch,
):
    """A DB hiccup while resolving login branding must NOT 500 the login
    page — the pre-auth pages touched no DB before this feature, and the
    one page every user needs to reach must degrade gracefully to the
    neutral APP_BRAND layout, not hard-crash (graceful-failure standard).

    Force the branding read to raise a real psycopg2 error and assert
    /login still returns 200 with the neutral wordmark. RED against an
    unguarded _login_branding_row(); GREEN with the try/except fallback."""
    import psycopg2

    def _boom(*_a, **_k):
        raise psycopg2.OperationalError('simulated DB outage')

    # _login_branding_row() uses qall() (no LOGIN_MSP_ID set in tests);
    # patch both qall and qone so the guard is exercised regardless.
    monkeypatch.setattr(app_module, 'qall', _boom)
    monkeypatch.setattr(app_module, 'qone', _boom)

    resp = client.get('/login')
    assert resp.status_code == 200
    html = resp.get_data(as_text=True)
    assert app_module.APP_BRAND in html


# ── XSS/CSS-injection: hostile primary_color neutralised at render ─────────────

@pytest.mark.parametrize('hostile', [
    'red;}</style><script>alert(1)</script>',
    '#fff" onmouseover=x',
])
def test_login_neutralises_hostile_primary_color(client, seed_msp_profile, hostile):
    """A malicious `primary_color` saved into msp_profiles must never reach
    the rendered CSS/HTML raw — _valid_hex_color() rejects it and
    _login_branding() falls back to the safe default teal (#00C9A7). Seeds
    the payload through the REAL render path (not just the unit helper) and
    asserts the raw payload is absent and the safe default colour is used.
    RED against an unsanitised colour concatenation; GREEN now."""
    seed_msp_profile('ACME', primary_color=hostile)
    html = client.get('/login').get_data(as_text=True)
    # Raw payload must not appear anywhere in the rendered page.
    assert hostile not in html
    assert '<script>alert(1)</script>' not in html
    assert 'onmouseover=x' not in html
    # Falls back to the safe default accent, so the button/wordmark still render.
    assert '#00C9A7' in html


# ── Explicit LOGIN_MSP_ID env override (two MSPs) ──────────────────────────────

def _reload_app_preserving_db_env(monkeypatch):
    """Reload reports/web/app.py after an env change, preserving the
    ephemeral test-DB connection env the conftest app_module fixture set up
    (same pattern as test_auth_layout.py's PORTAL_BRAND-reload test and
    test_security_config.py). Returns the freshly reloaded module."""
    tests_dir = os.path.dirname(os.path.abspath(__file__))
    web_dir = os.path.join(os.path.dirname(tests_dir), 'web')
    if web_dir not in sys.path:
        sys.path.insert(0, web_dir)

    for key in ('DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD',
                'FLASK_SECRET', 'COOKIE_SECURE', 'REPORT_LOGO_DIR', 'REPORT_OUTPUT_DIR'):
        val = os.environ.get(key)
        if val is not None:
            monkeypatch.setenv(key, val)
    monkeypatch.setenv('SMTP_HOST', '')
    monkeypatch.setenv('SMTP_USER', '')
    monkeypatch.setenv('SMTP_PASSWORD', '')
    monkeypatch.setenv('SMTP_FROM', '')

    mod = importlib.reload(sys.modules['app'])
    mod.app.config.update(TESTING=True)
    return mod


def test_explicit_login_msp_id_selects_that_profile(
    app_module, monkeypatch, seed_msp_profile,
):
    acme_id = seed_msp_profile('Acme', primary_color='#111111')
    seed_msp_profile('Globex', primary_color='#222222')

    monkeypatch.setenv('LOGIN_MSP_ID', str(acme_id))
    mod = _reload_app_preserving_db_env(monkeypatch)
    try:
        html = mod.app.test_client().get('/login').get_data(as_text=True)
        assert 'Acme' in html
        assert 'Globex' not in html
        assert '#111111' in html
    finally:
        if getattr(mod, '_scheduler', None) is not None:
            try:
                mod.stop_scheduler(mod._scheduler)
            except Exception:
                pass
        monkeypatch.delenv('LOGIN_MSP_ID', raising=False)
        restored = importlib.reload(sys.modules['app'])
        if getattr(restored, '_scheduler', None) is not None:
            try:
                restored.stop_scheduler(restored._scheduler)
            except Exception:
                pass
