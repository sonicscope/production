// Runs the Investigate page script in jsdom against stubbed fetch/clipboard and
// prints one JSON object {scenario: observations}. Page HTML arrives on stdin.
// jsdom is resolved from JSDOM_NODE_MODULES (a node_modules dir) or ./node_modules.
'use strict';
const path = require('path');
const fs = require('fs');
const base = process.env.JSDOM_NODE_MODULES || path.join(process.cwd(), 'node_modules');
const { JSDOM } = require(require.resolve('jsdom', { paths: [base, process.cwd()] }));

const html = fs.readFileSync(0, 'utf8');
const enc = new TextEncoder();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fr = (o) => 'data: ' + JSON.stringify(o) + '\n\n';

function stream(chunks, fail) {
  let i = 0;
  return new ReadableStream({
    pull(c) {
      if (i < chunks.length) { c.enqueue(chunks[i++]); }
      else if (fail) { c.error(new Error('boom')); }
      else { c.close(); }
    },
  });
}
const okStream = (frames, fail) => ({ ok: true, status: 200, body: stream([enc.encode(frames.join(''))], fail) });

async function run(fetchImpl, act, opts = {}) {
  const errs = [];
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/investigate',
    beforeParse(w) {
      w.TextDecoder = TextDecoder;
      w.__calls = [];
      w.fetch = async (u, o) => {
        const body = JSON.parse(o.body);
        w.__calls.push(body);
        if (o.signal) {
          const aborted = new Promise((_, rej) => o.signal.addEventListener('abort', () => {
            const e = new Error('aborted'); e.name = 'AbortError'; rej(e);
          }));
          return Promise.race([Promise.resolve(fetchImpl(w.__calls.length, body, w)), aborted]);
        }
        return fetchImpl(w.__calls.length, body, w);
      };
      if (opts.chart) { w.Chart = function (c, cfg) { if (opts.chart === 'throw') { throw new Error('x'); } w.__chart = cfg; }; }
      if (opts.clipboard === 'reject') { w.navigator.clipboard = { writeText: () => Promise.reject(new Error('no')) }; }
      else if (opts.clipboard !== 'none') { w.navigator.clipboard = { writeText: (t) => { w.__clip = t; return Promise.resolve(); } }; }
      w.addEventListener('error', (e) => errs.push(e.message));
    },
  });
  const w = dom.window; const d = w.document;
  const ask = (q) => {
    d.getElementById('inv-input').value = q;
    d.getElementById('inv-form').dispatchEvent(new w.Event('submit', { cancelable: true }));
  };
  await act({ w, d, ask });
  const send = d.getElementById('inv-send');
  const out = {
    errs, calls: w.__calls, sendDisabled: send.disabled, label: send.textContent,
    tenantDisabled: d.getElementById('inv-tenant').disabled,
    bubbles: [...d.querySelectorAll('.bubble')].map((b) => (b.classList.contains('err') ? 'ERR:' : b.classList.contains('me') ? 'ME:' : 'A:') + b.textContent),
    msgsText: d.getElementById('inv-msgs').textContent,
    scripts: d.querySelectorAll('#inv-msgs script,#inv-msgs img').length,
    details: d.querySelectorAll('details.evidence').length,
    summary: (d.querySelector('summary') || {}).textContent,
    tds: [...d.querySelectorAll('tbody td')].map((t) => t.textContent),
    chips: [...d.querySelectorAll('.chips button')].map((b) => b.textContent),
    order: [...d.getElementById('inv-msgs').children].map((c) => c.className || c.tagName),
    chartNote: [...d.querySelectorAll('.chartbox .status')].map((n) => n.textContent),
    copyLabel: (d.querySelector('.evidence .btn') || {}).textContent,
    clip: w.__clip, chartCfg: w.__chart ? w.__chart.type : null,
    canvasLabel: d.querySelector('canvas') ? d.querySelector('canvas').getAttribute('aria-label') : null,
  };
  w.close();
  return out;
}

(async () => {
  const R = {};
  const evil = '<script>alert(1)</script>"\'><img src=x onerror=1>';
  const frames = [
    fr({ type: 'status', message: 'Running query…' }),
    fr({ type: 'sql', sql: 'SELECT ' + evil, columns: ['host', 'threat_name', 'n'],
         rows: [[evil, 'Evil.Threat', 1], [null, null, null]], truncated: false, row_count: 1234, duration_ms: 1234 }),
    fr({ type: 'chart', kind: 'bar', title: 'T"<b>', x: 'host', y: 'n', labels: ['a'], values: [1] }),
    fr({ type: 'text', text: 'Answer ✓ ünï 日本語 <b>x</b>' }),
    fr({ type: 'followups', items: ['Next 1?', 'Next <i>2</i>?'] }),
    fr({ type: 'done' }),
  ];
  const bytes = enc.encode(frames.join(''));
  const mb = [...bytes].findIndex((b) => b === 0xE2);
  const cuts = [7, 40, mb + 1, mb + 2, Math.floor(bytes.length / 2), bytes.length - 3].sort((a, b) => a - b);
  const chunks = []; let p = 0;
  for (const c of cuts) { chunks.push(bytes.slice(p, c)); p = c; }
  chunks.push(bytes.slice(p));
  const split = () => ({ ok: true, status: 200, body: stream(chunks) });

  R.success = await run(split, async ({ w, d, ask }) => { ask('  hello  '); await sleep(300); }, { chart: true });
  R.success_nochart = await run(split, async ({ ask }) => { ask('q'); await sleep(300); });
  R.chart_throws = await run(split, async ({ ask }) => { ask('q'); await sleep(300); }, { chart: 'throw' });
  R.copy = await run(split, async ({ w, d, ask }) => {
    ask('q'); await sleep(300); d.querySelector('.evidence .btn').click(); await sleep(30);
  });
  R.copy_fail = await run(split, async ({ d, ask }) => {
    ask('q'); await sleep(300); d.querySelector('.evidence .btn').click(); await sleep(30);
  }, { clipboard: 'reject' });
  R.copy_none = await run(split, async ({ d, ask }) => {
    ask('q'); await sleep(300); d.querySelector('.evidence .btn').click(); await sleep(30);
  }, { clipboard: 'none' });
  R.followup_explain = await run(split, async ({ d, ask }) => {
    ask('q'); await sleep(300);
    d.querySelector('.chips button').click(); await sleep(300);
    d.querySelector('td button').click(); await sleep(300);
  });
  R.error_event = await run(() => okStream([fr({ type: 'status', message: 's' }),
    fr({ type: 'error', message: 'Model failed <b>', tokens_in: 1, tokens_out: 2 }), fr({ type: 'done' })]),
    async ({ ask }) => { ask('q'); await sleep(200); });
  for (const [st, body] of [[429, '{"error":"Rate limited"}'], [409, '{"error":"Busy"}'], [502, '<html>bad gateway</html>']]) {
    R['http_' + st] = await run(() => ({ ok: false, status: st, json: async () => JSON.parse(body), body: null }),
      async ({ ask }) => { ask('q'); await sleep(100); });
  }
  R.fetch_reject = await run(() => { throw new Error('net'); }, async ({ ask }) => { ask('q'); await sleep(100); });
  R.no_done = await run(() => okStream([fr({ type: 'text', text: 'hi' })]),
    async ({ ask }) => { ask('q'); await sleep(150); ask('q2'); await sleep(150); });
  R.empty_stream = await run(() => okStream([]),
    async ({ ask }) => { ask('q'); await sleep(100); ask('q2'); await sleep(100); });
  R.stream_error_no_answer = await run(() => okStream([fr({ type: 'status', message: 's' })], true),
    async ({ ask }) => { ask('q'); await sleep(150); ask('q2'); await sleep(150); });
  R.double_submit = await run(() => new Promise((res) => setTimeout(() => res(okStream([fr({ type: 'done' })])), 150)),
    async ({ d, ask }) => { ask('a'); ask('b'); await sleep(50); R._dbl_disabled = d.getElementById('inv-tenant').disabled; await sleep(300); });
  R.history_bound = await run(() => okStream([fr({ type: 'text', text: 'A'.repeat(6000) }), fr({ type: 'done' })]),
    async ({ ask }) => { for (let i = 0; i < 8; i++) { ask('q' + i); await sleep(80); } });
  // Tenant switch while a request is in flight (regression: old answer leaked).
  R.tenant_race = await run(async (n) => {
    if (n === 1) { await sleep(100); return okStream([fr({ type: 'text', text: 'OLDTENANT answer' }), fr({ type: 'done' })]); }
    return okStream([fr({ type: 'done' })]);
  }, async ({ w, d, ask }) => {
    ask('q'); await sleep(30);
    const s = d.getElementById('inv-tenant'); s.disabled = false; s.value = '2';
    s.dispatchEvent(new w.Event('change'));
    await sleep(250); ask('q2'); await sleep(100);
  });
  R.tenant_select_disabled_in_flight = await run(() => new Promise((res) => setTimeout(() => res(okStream([fr({ type: 'done' })])), 100)),
    async ({ d, ask }) => { ask('q'); await sleep(20); R._sel_disabled_mid = d.getElementById('inv-tenant').disabled; await sleep(250); });
  console.log(JSON.stringify(R));
})().catch((e) => { console.error('HARNESS FAIL', e); process.exit(1); });
