"""Tenant-isolation (IDOR) regression tests.

Covers the cross-tenant object-ownership gaps fixed in Task 1 of the P0
launch-remediation plan: `download_report`, the `generate` POST handler, and
`identity_user_edit` previously trusted a row's `tenant_id` (or a raw POST
`tenant_id` field) without checking that the *current* user may access that
tenant — letting a customer of tenant A enumerate `report_id`s to download
tenant B's confidential PDFs, or letting a tenant-scoped operator read/write
another tenant's identity records by guessing ids.

Routes exercised here (actual `app.py` routes — note these differ from the
illustrative paths in the original task brief):
  - GET  /reports/<report_id>/download
  - POST /generate
  - GET  /identity/users/<user_id>
"""
from __future__ import annotations


def test_customer_cannot_download_other_tenants_report(client, seed_tenants, seed_report, login_as):
    """A customer of tenant 1 must not be able to download tenant 2's report."""
    t1, t2 = seed_tenants('Acme', 'Globex')
    rid_b = seed_report(tenant_id=t2)
    login_as(role='customer', tenant_ids=[t1])

    resp = client.get(f'/reports/{rid_b}/download')

    assert resp.status_code == 404  # NOT 200, NOT the PDF bytes


def test_customer_can_download_own_report(client, seed_tenants, seed_report, login_as):
    """A customer must still be able to download their own tenant's report."""
    (t1,) = seed_tenants('Acme')
    rid = seed_report(tenant_id=t1)
    login_as(role='customer', tenant_ids=[t1])

    resp = client.get(f'/reports/{rid}/download')

    assert resp.status_code == 200


def test_scoped_operator_cannot_generate_for_foreign_tenant(client, seed_tenants, login_as, csrf_of):
    """A tenant-scoped operator must not be able to POST /generate for a
    tenant they were not granted access to, even by editing the form body."""
    t1, t2 = seed_tenants('Acme', 'Globex')
    login_as(role='user', tenant_ids=[t1])

    resp = client.post('/generate', data={
        'tenant_id': t2,
        'report_kind': 'periodic',
        'report_type': 'monthly',
        'period_start': '2026-01-01',
        'period_end': '2026-01-02',
        '_csrf': csrf_of(client),
    })

    assert resp.status_code == 404


def test_scoped_operator_cannot_open_foreign_identity_user(client, seed_tenants, seed_identity_user, login_as):
    """A tenant-scoped operator must not be able to view/edit an identity
    user belonging to a tenant they were not granted access to."""
    t1, t2 = seed_tenants('Acme', 'Globex')
    uid = seed_identity_user(tenant_id=t2)
    login_as(role='user', tenant_ids=[t1])

    resp = client.get(f'/identity/users/{uid}')

    assert resp.status_code == 404


# ── Step 8 findings: same IDOR class in report_schedules and identity_devices ──
# Discovered by grepping app.py for other object-by-id endpoints that trust a
# row's tenant_id without checking the current user may access it. All of the
# routes below took a `<int:...>` path id, ran no admin/tenant guard at all,
# and were reachable by any authenticated non-admin 'user'-role operator.


def test_scoped_operator_cannot_toggle_foreign_schedule(client, seed_tenants, seed_schedule, login_as, csrf_of):
    t1, t2 = seed_tenants('Acme', 'Globex')
    sid = seed_schedule(tenant_id=t2)
    login_as(role='user', tenant_ids=[t1])

    resp = client.post(f'/schedules/{sid}/toggle', data={'_csrf': csrf_of(client)})

    assert resp.status_code == 404


def test_scoped_operator_cannot_delete_foreign_schedule(client, seed_tenants, seed_schedule, login_as, csrf_of):
    t1, t2 = seed_tenants('Acme', 'Globex')
    sid = seed_schedule(tenant_id=t2)
    login_as(role='user', tenant_ids=[t1])

    resp = client.post(f'/schedules/{sid}/delete', data={'_csrf': csrf_of(client)})

    assert resp.status_code == 404


def test_scoped_operator_cannot_open_foreign_schedule_edit(client, seed_tenants, seed_schedule, login_as):
    t1, t2 = seed_tenants('Acme', 'Globex')
    sid = seed_schedule(tenant_id=t2)
    login_as(role='user', tenant_ids=[t1])

    resp = client.get(f'/schedules/{sid}/edit')

    assert resp.status_code == 404


def test_scoped_operator_cannot_create_schedule_for_foreign_tenant(client, seed_tenants, login_as, csrf_of):
    """The `_parse_schedule_post` helper backing both /schedules (create) and
    /schedules/<id>/edit (POST) must reject a foreign tenant_id in the body,
    the same class of bug fixed in /generate."""
    t1, t2 = seed_tenants('Acme', 'Globex')
    login_as(role='user', tenant_ids=[t1])

    resp = client.post('/schedules', data={
        'tenant_id': t2,
        'report_type': 'monthly',
        'freq': 'weekly',
        'hour': '7',
        'dow': 'mon',
        'recipient_name': 'Someone',
        'recipient_emails': 'someone@example.test',
        '_csrf': csrf_of(client),
    })

    assert resp.status_code == 404


def test_scoped_operator_cannot_delete_foreign_identity_device(client, seed_tenants, seed_identity_device, login_as, csrf_of):
    t1, t2 = seed_tenants('Acme', 'Globex')
    did = seed_identity_device(tenant_id=t2)
    login_as(role='user', tenant_ids=[t1])

    resp = client.post(f'/identity/devices/{did}/delete', data={'_csrf': csrf_of(client)})

    assert resp.status_code == 404


def test_scoped_operator_cannot_delete_foreign_identity_user(client, seed_tenants, seed_identity_user, login_as, csrf_of):
    t1, t2 = seed_tenants('Acme', 'Globex')
    uid = seed_identity_user(tenant_id=t2)
    login_as(role='user', tenant_ids=[t1])

    resp = client.post(f'/identity/users/{uid}/delete', data={'_csrf': csrf_of(client)})

    assert resp.status_code == 404
