import psycopg2
import pytest

from reports.ai import audit


@pytest.fixture
def cur(app_module):
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    conn.autocommit = True
    yield conn.cursor()
    conn.close()


def test_log_event_truncates_long_fields(cur):
    audit.log_event(cur, kind='chat', user_id=1, tenant_id=2, provider='openai', model='m',
                    question='q' * 5000, sql='s' * 9000, error='e' * 2000)
    cur.execute('SELECT length(question), length(sql), length(error) FROM ai_audit')
    assert cur.fetchone() == (2000, 4000, 500)


def test_rate_limit(cur):
    for _ in range(3):
        audit.log_event(cur, kind='chat_start', user_id=5, tenant_id=1, provider='p', model='m')
    audit.check_limits(cur, 5, per_minute=4, daily_token_budget=10**9)
    with pytest.raises(audit.LimitError):
        audit.check_limits(cur, 5, per_minute=3, daily_token_budget=10**9)
    audit.check_limits(cur, 6, per_minute=3, daily_token_budget=10**9)   # other user unaffected


def test_daily_budget(cur):
    audit.log_event(cur, kind='chat', user_id=1, tenant_id=1, provider='p', model='m',
                    tokens_in=600, tokens_out=500)
    audit.check_limits(cur, 9, per_minute=99, daily_token_budget=1101)
    with pytest.raises(audit.LimitError):
        audit.check_limits(cur, 9, per_minute=99, daily_token_budget=1100)


def test_limits_from_env():
    assert audit.limits_from_env({}) == (10, 2_000_000)
    assert audit.limits_from_env({'AI_RATE_PER_MIN': '3', 'AI_DAILY_TOKEN_BUDGET': '50'}) == (3, 50)
    assert audit.limits_from_env({'AI_RATE_PER_MIN': 'x', 'AI_DAILY_TOKEN_BUDGET': '-1'}) == (10, 2_000_000)


@pytest.mark.parametrize('tin,tout,expect', [('x', None, (0, 0)), (-5, -1, (0, 0)),
                                             (3.9, '7', (3, 7)), (None, float('nan'), (0, 0))])
def test_log_event_coerces_bad_token_counts(cur, tin, tout, expect):
    audit.log_event(cur, kind='chat', user_id=1, tenant_id=1, provider='p', model='m',
                    tokens_in=tin, tokens_out=tout)
    cur.execute('SELECT tokens_in, tokens_out FROM ai_audit')
    assert cur.fetchone() == expect


def test_log_event_truncates_kind_provider_model(cur):
    audit.log_event(cur, kind='k' * 100, user_id=1, tenant_id=1, provider='p' * 100,
                    model='m' * 300)
    cur.execute('SELECT length(kind), length(provider), length(model) FROM ai_audit')
    assert cur.fetchone() == (40, 40, 100)


@pytest.mark.parametrize('pm,db', [(0, 10), (-1, 10), (10, 0), (10, -5)])
def test_check_limits_rejects_non_positive_limits(cur, pm, db):
    with pytest.raises(ValueError):
        audit.check_limits(cur, 1, per_minute=pm, daily_token_budget=db)


def _ins(cur, kind, user_id, ts_sql, tin=0, tout=0):
    cur.execute('INSERT INTO ai_audit (kind, user_id, tenant_id, provider, model, ts, '
                f'tokens_in, tokens_out) VALUES (%s, %s, 1, \'p\', \'m\', {ts_sql}, %s, %s)',
                (kind, user_id, tin, tout))


def test_rate_old_rows_not_counted(cur):
    for _ in range(3):
        _ins(cur, 'chat_start', 5, "now() - interval '2 minutes'")
    audit.check_limits(cur, 5, per_minute=1, daily_token_budget=10**9)


def test_rate_counts_only_chat_start(cur):
    for kind in ('chat', 'tool', 'other'):
        _ins(cur, kind, 5, 'now()')
    audit.check_limits(cur, 5, per_minute=1, daily_token_budget=10**9)
    _ins(cur, 'chat_start', 5, 'now()')
    with pytest.raises(audit.LimitError):
        audit.check_limits(cur, 5, per_minute=1, daily_token_budget=10**9)


def test_rate_other_user_not_counted(cur):
    for _ in range(3):
        _ins(cur, 'chat_start', 6, 'now()')
    audit.check_limits(cur, 5, per_minute=1, daily_token_budget=10**9)


def test_budget_yesterday_not_counted_today_counted(cur):
    _ins(cur, 'chat', 1, "date_trunc('day', now()) - interval '1 hour'", 900, 900)
    audit.check_limits(cur, 9, per_minute=99, daily_token_budget=10)
    _ins(cur, 'chat', 1, 'now()', 5, 5)
    with pytest.raises(audit.LimitError, match='today'):
        audit.check_limits(cur, 9, per_minute=99, daily_token_budget=10)


def test_budget_counts_all_kinds_and_users(cur):
    _ins(cur, 'chat_start', 1, 'now()', 3, 0)
    _ins(cur, 'tool', 2, 'now()', 0, 3)
    _ins(cur, 'other', None, 'now()', 2, 2)
    audit.check_limits(cur, 9, per_minute=99, daily_token_budget=11)
    with pytest.raises(audit.LimitError):
        audit.check_limits(cur, 9, per_minute=99, daily_token_budget=10)


@pytest.mark.parametrize('uid', [None, '5', 5.0, True])
def test_check_limits_rejects_bad_user_id(cur, uid):
    with pytest.raises(ValueError):
        audit.check_limits(cur, uid, per_minute=1, daily_token_budget=1)
