import pytest

from reports.ai import net
from reports.ai.providers.base import ToolCall, ToolSpec, Usage
from reports.ai.providers.gemini import MAX_TOKENS_MSG, GeminiProvider

TOOLS = [ToolSpec('run_sql', 'Run SQL', {'type': 'object',
                                         'properties': {'sql': {'type': 'string'}},
                                         'required': ['sql']})]
MSGS = [
    {'role': 'user', 'content': 'top talkers?'},
    {'role': 'assistant', 'content': 'Checking.',
     'tool_calls': (ToolCall('run_sql-0', 'run_sql', {'sql': 'SELECT 1'}),
                    ToolCall('describe_schema-1', 'describe_schema', {}))},
    {'role': 'tool', 'tool_call_id': 'run_sql-0', 'name': 'run_sql', 'content': 'rows'},
    {'role': 'tool', 'tool_call_id': 'describe_schema-1', 'name': 'describe_schema',
     'content': 'doc'},
]
HOSTILE = [
    None, [], 'x', {'candidates': 'x'}, {'candidates': [None]},
    {'candidates': [{'content': 'x'}]}, {'candidates': [{'content': {'parts': 'x'}}]},
    {'candidates': [{'content': {'parts': [None]}}]},
    {'candidates': [{'content': {'parts': [{'text': None}]}}]},
    {'candidates': [{'content': {'parts': [{'functionCall': None}]}}]},
    {'candidates': [{'content': {'parts': [{'functionCall': {'name': 'n', 'args': 'x'}}]}}]},
    {'candidates': [{'content': {'parts': [{'text': 'x'}]}}], 'usageMetadata': 'x'},
    {'candidates': [{'content': {'parts': [{'text': 'x'}]}}],
     'usageMetadata': {'promptTokenCount': 1e999}},
]


def test_build_request_shapes():
    req = GeminiProvider().build_request('SYS', MSGS, TOOLS, 300)
    assert req['systemInstruction'] == {'parts': [{'text': 'SYS'}]}
    assert req['generationConfig'] == {'maxOutputTokens': 300}
    assert req['tools'] == [{'functionDeclarations': [
        {'name': 'run_sql', 'description': 'Run SQL', 'parameters': TOOLS[0].parameters}]}]
    roles = [c['role'] for c in req['contents']]
    assert roles == ['user', 'model', 'user']
    model_parts = req['contents'][1]['parts']
    assert model_parts[0] == {'text': 'Checking.'}
    assert model_parts[1] == {'functionCall': {'name': 'run_sql', 'args': {'sql': 'SELECT 1'}}}
    responses = req['contents'][2]['parts']
    assert responses[0] == {'functionResponse': {'name': 'run_sql',
                                                 'response': {'result': 'rows'}}}
    assert len(responses) == 2


def test_build_request_omits_empty_tools():
    req = GeminiProvider().build_request('s', [{'role': 'user', 'content': 'x'}], [], 8)
    assert 'tools' not in req


def test_build_request_omits_parameters_without_properties():
    req = GeminiProvider().build_request(
        's', [{'role': 'user', 'content': 'x'}], [ToolSpec('ping', 'Ping', {'type': 'object'})], 8)
    assert req['tools'] == [{'functionDeclarations': [{'name': 'ping', 'description': 'Ping'}]}]


def test_build_request_skips_empty_assistant():
    req = GeminiProvider().build_request('s', [
        {'role': 'user', 'content': 'x'}, {'role': 'assistant', 'content': ''},
        {'role': 'user', 'content': 'y'}], [], 8)
    assert [c['role'] for c in req['contents']] == ['user', 'user']


def test_thought_signature_round_trip():
    turn = GeminiProvider().parse_response({'candidates': [{'content': {'parts': [
        {'functionCall': {'name': 'run_sql', 'args': {'sql': 'SELECT 1'}},
         'thoughtSignature': 'SIG'}]}}]})
    call = turn.tool_calls[0]
    assert call.meta == {'thoughtSignature': 'SIG'}
    req = GeminiProvider().build_request('s', [
        {'role': 'user', 'content': 'hi'},
        {'role': 'assistant', 'content': '', 'tool_calls': (call,)},
        {'role': 'tool', 'tool_call_id': call.id, 'name': 'run_sql', 'content': 'rows'}],
        [], 8)
    part = req['contents'][1]['parts'][0]
    assert part == {'functionCall': {'name': 'run_sql', 'args': {'sql': 'SELECT 1'}},
                    'thoughtSignature': 'SIG'}


def test_build_request_no_signature_key_without_meta():
    req = GeminiProvider().build_request('s', [
        {'role': 'assistant', 'content': '', 'tool_calls': (ToolCall('n-0', 'n', {}),)}],
        [], 8)
    assert 'thoughtSignature' not in req['contents'][0]['parts'][0]


def test_parse_response():
    turn = GeminiProvider().parse_response({
        'candidates': [{'content': {'parts': [
            {'text': 'Hello'},
            {'functionCall': {'name': 'run_sql', 'args': {'sql': 'SELECT 2'}}}]}}],
        'usageMetadata': {'promptTokenCount': 9, 'candidatesTokenCount': 4}})
    assert turn.text == 'Hello'
    assert turn.tool_calls == (ToolCall('run_sql-0', 'run_sql', {'sql': 'SELECT 2'}),)
    assert (turn.usage.input_tokens, turn.usage.output_tokens) == (9, 4)


def test_parse_response_skips_thought_parts():
    turn = GeminiProvider().parse_response({'candidates': [{'content': {'parts': [
        {'text': 'secret', 'thought': True}, {'text': 'visible'}]}}]})
    assert turn.text == 'visible'


def test_parse_response_null_args_become_empty_dict():
    turn = GeminiProvider().parse_response(
        {'candidates': [{'content': {'parts': [{'functionCall': {'name': 'n'}}]}}]})
    assert turn.tool_calls == (ToolCall('n-0', 'n', {}),)


@pytest.mark.parametrize('fc', [
    {'name': 'n', 'args': 'x'}, {'name': 'n', 'args': [1]}, {'name': 'n', 'args': 5},
    {'name': 5, 'args': {}}, {'name': None, 'args': {}}, {'args': {}},
])
def test_parse_response_rejects_bad_function_call(fc):
    with pytest.raises(net.ProviderError):
        GeminiProvider().parse_response({'candidates': [{'content': {'parts': [
            {'functionCall': fc}]}}]})


@pytest.mark.parametrize('data', [{}, {'candidates': []}, {'candidates': [{}]}])
def test_parse_response_no_answer(data):
    with pytest.raises(net.ProviderError):
        GeminiProvider().parse_response(data)


def test_parse_response_max_tokens_empty_message():
    with pytest.raises(net.ProviderError, match='ran out of output tokens'):
        GeminiProvider().parse_response({'candidates': [
            {'finishReason': 'MAX_TOKENS', 'content': {}}]})


def test_parse_response_other_empty_is_generic():
    with pytest.raises(net.ProviderError) as exc:
        GeminiProvider().parse_response({'candidates': [
            {'finishReason': 'SAFETY', 'content': {}}]})
    assert 'empty answer' in str(exc.value)


def test_parse_response_huge_and_missing_usage():
    turn = GeminiProvider().parse_response({
        'candidates': [{'content': {'parts': [{'text': 'x'}]}}],
        'usageMetadata': {'promptTokenCount': 1e999, 'candidatesTokenCount': 4}})
    assert (turn.usage.input_tokens, turn.usage.output_tokens) == (0, 4)
    turn = GeminiProvider().parse_response({'candidates': [{'content': {'parts': [
        {'text': 'x'}]}}]})
    assert turn.usage == Usage()


@pytest.mark.parametrize('data', HOSTILE)
def test_parse_response_hostile_only_provider_error(data):
    try:
        GeminiProvider().parse_response(data)
    except net.ProviderError:
        pass


def test_complete_uses_header_key_and_model_in_path(monkeypatch):
    seen = {}

    def fake_post(url, headers, payload, **kw):
        seen.update(url=url, headers=headers, kw=kw)
        return {'candidates': [{'content': {'parts': [{'text': 'ok'}]}}], 'usageMetadata': {}}

    monkeypatch.setattr(net, 'post_json', fake_post)
    turn = GeminiProvider().complete(api_key='AIza-1', model='gemini-x', system='s',
                                     messages=[{'role': 'user', 'content': 'hi'}], tools=[])
    assert turn.text == 'ok'
    assert seen['url'] == ('https://generativelanguage.googleapis.com/v1beta/models/'
                           'gemini-x:generateContent')
    assert 'AIza-1' not in seen['url']
    assert seen['headers']['x-goog-api-key'] == 'AIza-1'
    assert seen['kw']['secrets'] == ['AIza-1']


def test_test_treats_max_tokens_stop_as_success(monkeypatch):
    captured = {}

    def fake_post(url, headers, payload, **kw):
        captured['payload'] = payload
        return {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {}}]}

    monkeypatch.setattr(net, 'post_json', fake_post)
    GeminiProvider().test(api_key='AIza-1', model='gemini-x')  # must not raise
    assert captured['payload']['generationConfig'] == {'maxOutputTokens': 256}
    assert MAX_TOKENS_MSG.startswith('the model ran out')


def test_test_propagates_other_provider_errors(monkeypatch):
    def fake_post(url, headers, payload, **kw):
        raise net.ProviderError('HTTP 403')

    monkeypatch.setattr(net, 'post_json', fake_post)
    with pytest.raises(net.ProviderError, match='403'):
        GeminiProvider().test(api_key='AIza-1', model='gemini-x')
