"""Spec §4.2 / §9: nothing the model can write may cross the tenant boundary."""
import psycopg2
import pytest

from reports.ai import credentials, executor
from reports.ai.sql_guard import GuardError, check_sql

ATTACKS = [
    "SELECT set_config('ss.tenant_id', '{b}', false)",
    "SELECT set_config('ss.tenant_id', '{b}', true), domain FROM ai.events",
    "WITH x AS (SELECT set_config('ss.tenant_id', '{b}', false)) SELECT * FROM ai.events",
    "SELECT current_setting('ss.tenant_id')",
    "SET ss.tenant_id = '{b}'",
    "RESET ALL",
    "SET search_path = public",
    "SELECT * FROM public.fw_events",
    "SELECT * FROM fw_events",
    "SELECT * FROM events",
    "SELECT * FROM pg_catalog.pg_roles",
    "SELECT * FROM pg_class",
    "SELECT * FROM information_schema.tables",
    "SELECT * FROM ai.events UNION SELECT * FROM public.fw_events",
    "SELECT * FROM public.lookup_identity({b}, '10.0.0.1')",
    "SELECT pg_read_file('/etc/passwd')",
    "SELECT pg_sleep(30)",
    "SELECT dblink('x', 'SELECT 1')",
    "SELECT lo_import('/etc/passwd')",
    "COPY (SELECT 1) TO PROGRAM 'id'",
    "SELECT 1; SELECT set_config('ss.tenant_id','{b}',false)",
    "EXPLAIN ANALYZE SELECT * FROM ai.events",
    "CREATE TEMP TABLE t AS SELECT 1",
    "SELECT * FROM ai.events FOR UPDATE",
    "SELECT * INTO TEMP t2 FROM ai.events",
    "SELECT * FROM ai . events /* c */ WHERE true",   # odd spacing must not bypass the rewrite
    "SELECT * FROM \"ai\".\"events\"",
]


@pytest.fixture
def two_tenants(seed_tenants, seed_fw_event):
    a, b = seed_tenants('A', 'B')
    seed_fw_event(a, domain='a.example')
    seed_fw_event(b, domain='b.example')
    return a, b


@pytest.mark.parametrize('attack', ATTACKS)
def test_attack_is_rejected_or_stays_in_tenant(attack, ai_ro_config, two_tenants):
    a, b = two_tenants
    sql = attack.format(a=a, b=b)
    try:
        guarded = check_sql(sql, a)
        result = executor.run_query(ai_ro_config, a, guarded)
    except (GuardError, executor.ExecutorError):
        return                                              # rejected: fine
    leaked = [row for row in result.rows if any('b.example' in str(v) for v in row)]
    assert leaked == [], f'cross-tenant leak via: {sql}'


# Guard-PASSING queries that really execute: tenant A's row must come back
# (positive control) and tenant B's data must never appear.
PASSING = [
    "SELECT domain FROM ai.events WHERE true OR 1 = 1",
    "SELECT domain FROM ai.events WHERE domain = 'a.example' OR tenant_id = {b}",
    "SELECT e.domain FROM ai.events e WHERE e.domain IS NOT NULL",
    "WITH events AS (SELECT domain FROM ai.events) SELECT domain FROM events",
    "SELECT x.domain FROM ai.events x JOIN ai.events y ON x.domain = y.domain",
    "SELECT domain FROM ai.events UNION SELECT domain FROM ai.events",
    "SELECT domain FROM ai.events WHERE domain IN (SELECT domain FROM ai.events)",
    "SELECT domain, count(*) OVER (PARTITION BY domain) AS n FROM ai.events",
    "SELECT row_to_json(e)::text FROM ai.events e",
    "SELECT e.row_to_json FROM ai.events e",
]


@pytest.mark.parametrize('query', PASSING)
def test_guard_passing_query_returns_own_tenant_only(query, ai_ro_config, two_tenants):
    a, b = two_tenants
    sql = query.format(a=a, b=b)
    try:
        guarded = check_sql(sql, a)
    except GuardError:
        pytest.skip(f'guard rejects this form (acceptable): {sql}')
    result = executor.run_query(ai_ro_config, a, guarded)
    flat = [str(v) for row in result.rows for v in row]
    assert any('a.example' in v for v in flat), f'positive control failed: {sql}'
    assert not any('b.example' in v for v in flat), f'cross-tenant leak via: {sql}'


def test_at_least_six_passing_queries_actually_execute():
    accepted = 0
    for q in PASSING:
        try:
            check_sql(q.format(a=1, b=2), 1)
            accepted += 1
        except GuardError:
            pass
    assert accepted >= 6


def test_every_rewritten_relation_carries_the_literal_tenant(two_tenants):
    a, b = two_tenants
    for view in ('events', 'daily_app', 'daily_web', 'daily_geo', 'hourly_bandwidth'):
        q = check_sql(f'SELECT * FROM ai.{view}', a)
        assert f'tenant_id = {a}' in q.sql and f'tenant_id = {b}' not in q.sql


def test_role_has_no_path_to_sensitive_data(ai_ro_config):
    for sql in ("SELECT * FROM public.ai_settings", "SELECT * FROM public.ai_audit",
                "SELECT * FROM public.ui_users", "SELECT * FROM public.msp_profiles",
                "SELECT * FROM public.identity_mappings", "SELECT * FROM public.sensors",
                "SELECT * FROM public.hourly_user_traffic",
                "SELECT public.lookup_identity(1, '10.0.0.1')"):
        with psycopg2.connect(**ai_ro_config) as conn:
            with conn.cursor() as cur:
                with pytest.raises(psycopg2.errors.InsufficientPrivilege):
                    cur.execute(sql)


def test_ai_audit_cannot_be_edited_by_model_role(ai_ro_config):
    with psycopg2.connect(**ai_ro_config) as conn:
        with conn.cursor() as cur:
            with pytest.raises(psycopg2.Error):
                cur.execute("DELETE FROM public.ai_audit")


# ── authorisation matrix (beyond spec §4.2): every AI endpoint ──────────────
ENDPOINTS = [
    ('GET', '/investigate'),
    ('GET', '/settings/ai'),
    ('POST', '/settings/ai'),
    ('POST', '/settings/ai/test'),
    ('POST', '/investigate/chat'),
]


def _call(client, method, path, token, tenant):
    if path == '/investigate/chat':
        return client.open(path, method=method, json={'tenant_id': tenant, 'question': 'x'},
                           headers={'X-CSRF-Token': token})
    if method == 'POST':
        return client.open(path, method=method, data={'_csrf': token, 'provider': 'openai'},
                           headers={'X-CSRF-Token': token})
    return client.open(path, method=method)


@pytest.mark.parametrize('method,path', ENDPOINTS)
def test_customer_role_is_blocked(method, path, client, login_as, csrf_of, seed_tenants):
    t, = seed_tenants('Acme')
    login_as('customer', [t])
    resp = _call(client, method, path, csrf_of(client), t)
    assert resp.status_code in (302, 404), (method, path, resp.status_code)
    if resp.status_code == 302:
        assert '/portal' in resp.headers['Location']
        assert 'ai' not in resp.headers['Location'].replace('portal', '')


@pytest.mark.parametrize('method,path', ENDPOINTS)
def test_unauthenticated_is_redirected_to_login(method, path, client):
    resp = (client.post(path, json={}) if method == 'POST' else client.get(path))
    assert resp.status_code == 302
    assert 'login' in resp.headers['Location']


# ── secrets never leave the server via /settings/ai ─────────────────────────
def test_api_key_value_never_in_any_settings_response(client, app_module, login_as, csrf_of,
                                                      seed_tenants, tmp_path, monkeypatch):
    secret = 'sk-ZZTOPSECRET-0123456789abcdef'
    key_path = str(tmp_path / 'ai.key')
    credentials.generate_key_file(key_path)
    monkeypatch.setenv('AI_KEY_FILE', key_path)
    t, = seed_tenants('Acme')
    login_as('admin')
    token = csrf_of(client)
    seen = []
    resp = client.get('/settings/ai')
    seen.append(resp)
    resp = client.post('/settings/ai', data={
        '_csrf': token, 'provider': 'openai', 'model': 'gpt-x', 'api_key': secret,
        'consent': 'on', 'tenant_ids': [str(t)]}, follow_redirects=True)
    seen.append(resp)
    seen.append(client.get('/settings/ai'))
    seen.append(client.post('/settings/ai', data={'_csrf': token, 'provider': 'openai',
                                                  'model': 'gpt-x'}, follow_redirects=True))
    for r in seen:
        blob = r.get_data(as_text=True) + str(dict(r.headers))
        assert secret not in blob
        assert 'ZZTOPSECRET' not in blob
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute('SELECT row_to_json(s)::text FROM ai_settings s')
        assert secret not in cur.fetchone()[0]          # stored encrypted only
