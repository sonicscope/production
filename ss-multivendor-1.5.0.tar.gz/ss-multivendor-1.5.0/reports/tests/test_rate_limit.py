"""Unit tests for reports/web/rate_limit.py — the pure, Flask-free sliding-
window rate limiter used to throttle brute-force / credential-stuffing
attempts against /login and /forgot-password (see
docs/superpowers/specs/2026-07-14-login-rate-limiting-design.md).

All tests inject `now` explicitly for determinism — no real sleeping, no
flakiness from wall-clock timing.
"""
from __future__ import annotations

import os
import sys

# Pure unit tests — no DB, no Flask, no app_module/client fixtures needed.
# rate_limit.py lives in reports/web/, which conftest.py only puts on
# sys.path inside the app_module fixture; add it directly here so this
# module can import RateLimiter without paying for the whole app + DB
# harness.
_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_WEB_DIR = os.path.join(os.path.dirname(_TESTS_DIR), 'web')
if _WEB_DIR not in sys.path:
    sys.path.insert(0, _WEB_DIR)

from rate_limit import RateLimiter  # noqa: E402


def test_allows_up_to_max_attempts():
    """Every attempt up to (but not including) the max-th failure must
    still be allowed — the limiter must not trip early."""
    rl = RateLimiter(max_attempts=3, window_seconds=60, block_seconds=60)
    now = 1000.0
    for i in range(3):
        assert rl.allowed('1.2.3.4', now=now) is True
        rl.record_failure('1.2.3.4', now=now)
        now += 1


def test_blocks_after_max_plus_one_failures():
    """Once max_attempts failures have landed inside the window, the next
    allowed() check must return False."""
    rl = RateLimiter(max_attempts=3, window_seconds=60, block_seconds=60)
    now = 1000.0
    for _ in range(3):
        rl.record_failure('1.2.3.4', now=now)
        now += 1
    assert rl.allowed('1.2.3.4', now=now) is False


def test_reset_clears_history():
    """reset() must fully clear a key's failure history, immediately
    un-blocking it (used on a successful login)."""
    rl = RateLimiter(max_attempts=3, window_seconds=60, block_seconds=60)
    now = 1000.0
    for _ in range(3):
        rl.record_failure('1.2.3.4', now=now)
        now += 1
    assert rl.allowed('1.2.3.4', now=now) is False
    rl.reset('1.2.3.4')
    assert rl.allowed('1.2.3.4', now=now) is True


def test_window_expiry_reallows():
    """If enough time passes that all recorded failures fall outside
    window_seconds, the key must be re-allowed even though block_seconds
    (deliberately set much longer than the window here) hasn't elapsed —
    pruning removes the stale failures before the count is compared to
    max_attempts."""
    rl = RateLimiter(max_attempts=3, window_seconds=10, block_seconds=1000)
    now = 0.0
    for _ in range(3):
        rl.record_failure('1.2.3.4', now=now)
        now += 1
    assert rl.allowed('1.2.3.4', now=now) is False
    now += 15  # last failure now well outside the 10s window
    assert rl.allowed('1.2.3.4', now=now) is True


def test_retry_after_counts_down():
    """retry_after() must report the remaining block duration, counting
    down to 0 as block_seconds elapses from the most recent failure."""
    rl = RateLimiter(max_attempts=2, window_seconds=60, block_seconds=30)
    now = 0.0
    rl.record_failure('1.2.3.4', now=now)
    now += 1
    rl.record_failure('1.2.3.4', now=now)  # 2nd failure trips the block

    first = rl.retry_after('1.2.3.4', now=now)
    assert first == 30

    now += 10
    second = rl.retry_after('1.2.3.4', now=now)
    assert second == 20
    assert second < first

    now += 30
    assert rl.retry_after('1.2.3.4', now=now) == 0
    assert rl.allowed('1.2.3.4', now=now) is True


def test_retry_after_zero_when_allowed():
    """A key that has never failed (or is under the threshold) must report
    retry_after == 0 — nothing to wait for."""
    rl = RateLimiter(max_attempts=3, window_seconds=60, block_seconds=60)
    assert rl.retry_after('1.2.3.4', now=0.0) == 0
    rl.record_failure('1.2.3.4', now=0.0)
    assert rl.retry_after('1.2.3.4', now=0.0) == 0  # 1 of 3 — still allowed


def test_eviction_cap_bounds_the_map():
    """The tracked-key map must never exceed max_tracked_keys; exceeding it
    evicts the least-recently-touched key, so a rotating-source flood of
    distinct keys cannot grow memory unboundedly."""
    rl = RateLimiter(max_attempts=1, window_seconds=1000, block_seconds=1000,
                      max_tracked_keys=3)
    for i in range(3):
        rl.record_failure(f'k{i}', now=0.0)
    assert len(rl) == 3
    assert rl.allowed('k0', now=0.0) is False  # blocked, 1 failure already

    # A 4th distinct key exceeds the cap — must evict k0 (least-recently
    # touched: it was recorded first and never touched again).
    rl.record_failure('k3', now=0.0)
    assert len(rl) == 3
    assert rl.allowed('k0', now=0.0) is True   # evicted -> treated as fresh
    assert rl.allowed('k3', now=0.0) is False  # newest entry, still blocked


def test_max_attempts_zero_disables_limiter():
    """max_attempts=0 is the documented escape hatch: allowed() must always
    return True, record_failure() must be a no-op (nothing tracked), and
    retry_after() must always be 0."""
    rl = RateLimiter(max_attempts=0, window_seconds=60, block_seconds=60)
    now = 0.0
    for _ in range(50):
        assert rl.allowed('1.2.3.4', now=now) is True
        rl.record_failure('1.2.3.4', now=now)
    assert rl.retry_after('1.2.3.4', now=now) == 0
    assert len(rl) == 0


def test_now_defaults_to_monotonic_when_omitted():
    """now is optional in production use — omitting it must not raise."""
    rl = RateLimiter(max_attempts=3, window_seconds=60, block_seconds=60)
    assert rl.allowed('1.2.3.4') is True
    rl.record_failure('1.2.3.4')
    rl.reset('1.2.3.4')
    assert rl.retry_after('1.2.3.4') == 0
