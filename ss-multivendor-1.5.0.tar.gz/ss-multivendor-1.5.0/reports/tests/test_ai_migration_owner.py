"""Migration 010 ownership as production sees it (no conftest ownership override).

Builds a scratch DB with the same files conftest applies, but WITHOUT the
test-only ALTER SCHEMA/VIEW override, and checks the ai objects end up owned
by the non-superuser role `sonicscope`.
"""
import subprocess
import time

import pytest

from reports.tests.conftest import SCHEMA_FILES, _sudo_psql

_SCRATCH = 'ss_ai_owner_check'


def _psql_out(sql: str, db: str) -> str:
    proc = subprocess.run(
        ['sudo', '-n', '-u', 'postgres', 'psql', '-At', '-v', 'ON_ERROR_STOP=1', '-d', db, '-c', sql],
        capture_output=True, text=True, timeout=60)
    if proc.returncode != 0:
        raise RuntimeError(f'psql failed: {proc.stderr}')
    return proc.stdout.strip()


def _apply_with_retry(path: str) -> None:
    for attempt in range(3):
        try:
            _sudo_psql(_SCRATCH, sql_file=path)
            return
        except RuntimeError as exc:
            if 'concurrent refresh' in str(exc) and attempt < 2:
                time.sleep(3)
                continue
            raise


def test_ai_objects_owned_by_nonsuperuser_sonicscope():
    if _psql_out("SELECT count(*) FROM pg_roles WHERE rolname='sonicscope'", 'postgres') != '1':
        pytest.skip("role 'sonicscope' does not exist on this cluster")
    _sudo_psql('postgres', sql=f'DROP DATABASE IF EXISTS "{_SCRATCH}";')
    _sudo_psql('postgres', sql=f'CREATE DATABASE "{_SCRATCH}";')
    try:
        for path in SCHEMA_FILES:
            _apply_with_retry(path)
        owners = _psql_out(
            "SELECT v.viewowner, r.rolsuper FROM pg_views v JOIN pg_roles r ON r.rolname=v.viewowner "
            "WHERE v.schemaname='ai'", _SCRATCH).splitlines()
        assert len(owners) == 9
        assert set(owners) == {'sonicscope|f'}
        assert _psql_out("SELECT nspowner::regrole FROM pg_namespace WHERE nspname='ai'",
                         _SCRATCH) == 'sonicscope'
        assert _psql_out("SELECT proowner::regrole FROM pg_proc WHERE proname='current_tenant' "
                         "AND pronamespace='ai'::regnamespace", _SCRATCH) == 'sonicscope'
        out = _psql_out("SET ROLE sonicscope; SELECT set_config('ss.tenant_id','1',true); "
                        "SELECT count(*) FROM ai.events", _SCRATCH)
        assert out.splitlines()[-1] == '0'
    finally:
        _sudo_psql('postgres', sql=f'DROP DATABASE IF EXISTS "{_SCRATCH}";')
