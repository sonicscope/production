"""Unit tests for the Live Monitor pure helpers (reports/web/live_monitor.py)."""
import os
import sys
from datetime import datetime, timezone

import pytest

# live_monitor.py lives in reports/web/, which conftest.py only puts on
# sys.path inside the app_module fixture; add it directly here so these
# pure unit tests do not pay for the Flask app + DB harness.
_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_WEB_DIR = os.path.join(os.path.dirname(_TESTS_DIR), 'web')
if _WEB_DIR not in sys.path:
    sys.path.insert(0, _WEB_DIR)

from live_monitor import feed_status, shape_feed, shape_sample, feed_label  # noqa: E402


@pytest.mark.parametrize('age,expected', [
    (0, 'live'), (30, 'live'), (31, 'idle'), (300, 'idle'),
    (301, 'silent'), (None, 'silent'),
])
def test_feed_status_thresholds(age, expected):
    assert feed_status(age) == expected


def test_shape_feed_adds_status_and_stringifies_ip():
    out = shape_feed({'source_ip': '10.0.0.1', 'feed': 'syslog', 'received': 5,
                      'ok': 4, 'skipped': 0, 'rejected': {'x': 1}, 'age_s': 12.7})
    assert out == {'source_ip': '10.0.0.1', 'feed': 'syslog', 'status': 'live',
                   'received': 5, 'ok': 4, 'skipped': 0,
                   'rejected': {'x': 1}, 'age_s': 12}


def test_shape_feed_handles_never_seen():
    out = shape_feed({'source_ip': '10.0.0.1', 'feed': 'syslog', 'received': 0,
                      'ok': 0, 'skipped': 0, 'rejected': {}, 'age_s': None})
    assert out['status'] == 'silent' and out['age_s'] is None


def test_shape_sample_iso_timestamp():
    ts = datetime(2026, 11, 9, 14, 2, 11, tzinfo=timezone.utc)
    out = shape_sample({'ts': ts, 'source_ip': '10.0.0.1', 'feed': 'syslog',
                        'outcome': 'ok', 'reason': '', 'text': 'hi'})
    assert out['ts'] == '2026-11-09T14:02:11+00:00'
    assert out['text'] == 'hi'


def test_feed_label_known_and_unknown():
    assert feed_label('ipfix') == 'NetFlow / IPFIX'
    assert feed_label('zenarmor') == 'Zenarmor'


@pytest.mark.parametrize('age,shown,status', [
    (30.9, 30, 'live'), (31.0, 31, 'idle'), (300.9, 300, 'idle'), (301.0, 301, 'silent'),
])
def test_shape_feed_status_uses_the_displayed_truncated_age(age, shown, status):
    out = shape_feed({'source_ip': '10.0.0.1', 'feed': 'syslog', 'received': 1,
                      'ok': 1, 'skipped': 0, 'rejected': {}, 'age_s': age})
    assert out['age_s'] == shown and out['status'] == status
