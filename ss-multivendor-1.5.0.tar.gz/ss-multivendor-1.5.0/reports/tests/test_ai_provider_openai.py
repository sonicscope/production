import json

import pytest

from reports.ai import net
from reports.ai.providers.base import ToolCall, ToolSpec, Usage
from reports.ai.providers.openai import OpenAIProvider

TOOLS = [ToolSpec('run_sql', 'Run SQL', {'type': 'object',
                                         'properties': {'sql': {'type': 'string'}},
                                         'required': ['sql']})]
MSGS = [
    {'role': 'user', 'content': 'top talkers?'},
    {'role': 'assistant', 'content': '',
     'tool_calls': (ToolCall('c1', 'run_sql', {'sql': 'SELECT 1'}),)},
    {'role': 'tool', 'tool_call_id': 'c1', 'name': 'run_sql', 'content': 'rows'},
]
HOSTILE = [
    None, [], 'x', {}, {'choices': None}, {'choices': [None]},
    {'choices': [{'message': 'x'}]}, {'choices': [{'message': {'content': ['x']}}]},
    {'choices': [{'message': {'tool_calls': 'x'}}]},
    {'choices': [{'message': {'tool_calls': [None]}}]},
    {'choices': [{'message': {'tool_calls': [{'id': 'a', 'function': None}]}}]},
    {'choices': [{'message': {'content': 'x'}}], 'usage': 'x'},
    {'choices': [{'message': {'content': 'x'}}], 'usage': {'prompt_tokens': []}},
    {'choices': [{'message': {'content': 'x'}}], 'usage': {'prompt_tokens': 1e999}},
]


def test_build_request_shapes():
    req = OpenAIProvider().build_request('gpt-x', 'SYS', MSGS, TOOLS, 256)
    assert req['model'] == 'gpt-x' and req['max_completion_tokens'] == 256
    assert req['messages'][0] == {'role': 'system', 'content': 'SYS'}
    assistant = req['messages'][2]
    assert assistant['content'] is None
    call = assistant['tool_calls'][0]
    assert call['id'] == 'c1' and call['type'] == 'function'
    assert json.loads(call['function']['arguments']) == {'sql': 'SELECT 1'}
    assert req['messages'][3] == {'role': 'tool', 'tool_call_id': 'c1', 'content': 'rows'}
    assert req['tools'][0] == {'type': 'function', 'function': {
        'name': 'run_sql', 'description': 'Run SQL', 'parameters': TOOLS[0].parameters}}


def test_build_request_omits_empty_tools():
    req = OpenAIProvider().build_request('m', 's', [{'role': 'user', 'content': 'x'}], [], 8)
    assert 'tools' not in req


def test_build_request_skips_empty_assistant():
    req = OpenAIProvider().build_request('m', 's', [
        {'role': 'user', 'content': 'x'}, {'role': 'assistant', 'content': ''}], [], 8)
    assert [m['role'] for m in req['messages']] == ['system', 'user']


def test_parse_response():
    turn = OpenAIProvider().parse_response({
        'choices': [{'message': {'content': 'Hi', 'tool_calls': [
            {'id': 'x1', 'type': 'function',
             'function': {'name': 'run_sql', 'arguments': '{"sql": "SELECT 3"}'}}]}}],
        'usage': {'prompt_tokens': 5, 'completion_tokens': 2}})
    assert turn.text == 'Hi'
    assert turn.tool_calls == (ToolCall('x1', 'run_sql', {'sql': 'SELECT 3'}),)
    assert (turn.usage.input_tokens, turn.usage.output_tokens) == (5, 2)


def test_parse_response_null_content_and_no_calls():
    turn = OpenAIProvider().parse_response(
        {'choices': [{'message': {'content': None}}], 'usage': {}})
    assert turn.text == '' and turn.tool_calls == ()


@pytest.mark.parametrize('data', [
    {}, {'choices': []},
    {'choices': [{'message': {'tool_calls': [
        {'id': 'x', 'function': {'name': 'run_sql', 'arguments': '{bad'}}]}}]},
])
def test_parse_response_malformed(data):
    with pytest.raises(net.ProviderError):
        OpenAIProvider().parse_response(data)


@pytest.mark.parametrize('args', ['[1]', 'null', '"x"', '5', '{bad',
                                  '[' * 100000 + ']' * 100000])
def test_parse_response_rejects_non_object_arguments(args):
    with pytest.raises(net.ProviderError):
        OpenAIProvider().parse_response({'choices': [{'message': {'tool_calls': [
            {'id': 'x', 'function': {'name': 'run_sql', 'arguments': args}}]}}]})


@pytest.mark.parametrize('call', [
    {'id': 5, 'function': {'name': 'run_sql', 'arguments': '{}'}},
    {'id': 'x', 'function': {'name': None, 'arguments': '{}'}},
])
def test_parse_response_rejects_non_str_id_or_name(call):
    with pytest.raises(net.ProviderError):
        OpenAIProvider().parse_response({'choices': [{'message': {'tool_calls': [call]}}]})


def test_parse_response_huge_and_missing_usage():
    turn = OpenAIProvider().parse_response({
        'choices': [{'message': {'content': 'x'}}],
        'usage': {'prompt_tokens': 1e999, 'completion_tokens': 3}})
    assert (turn.usage.input_tokens, turn.usage.output_tokens) == (0, 3)
    turn = OpenAIProvider().parse_response({'choices': [{'message': {'content': 'x'}}]})
    assert turn.usage == Usage()


@pytest.mark.parametrize('data', HOSTILE)
def test_parse_response_hostile_only_provider_error(data):
    try:
        OpenAIProvider().parse_response(data)
    except net.ProviderError:
        pass


def test_complete_uses_bearer_header(monkeypatch):
    seen = {}

    def fake_post(url, headers, payload, **kw):
        seen.update(url=url, headers=headers, kw=kw)
        return {'choices': [{'message': {'content': 'ok'}}], 'usage': {}}

    monkeypatch.setattr(net, 'post_json', fake_post)
    turn = OpenAIProvider().complete(api_key='sk-1', model='gpt-x', system='s',
                                     messages=[{'role': 'user', 'content': 'hi'}], tools=[])
    assert turn.text == 'ok'
    assert seen['url'] == 'https://api.openai.com/v1/chat/completions'
    assert seen['headers']['Authorization'] == 'Bearer sk-1'
    assert seen['kw']['secrets'] == ['sk-1']
