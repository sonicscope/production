"""Cover logo (white chip, no flatten), contrast-safe band text, brand charts."""
import pytest

from reports.tests.branding_util import (
    make_msp, make_tenant, render_hr, render_periodic, render_security,
)

RENDERERS = [render_periodic, render_security, render_hr]


@pytest.mark.parametrize('render', RENDERERS)
def test_logo_not_flattened(render):
    msp = make_msp(logo_path='/var/lib/ss-multivendor/logos/acme.png')
    html = render(msp, make_tenant())
    assert 'brightness(0)' not in html
    assert 'invert(1)' not in html


@pytest.mark.parametrize('render', RENDERERS)
def test_logo_sits_in_white_chip(render):
    msp = make_msp(logo_path='/var/lib/ss-multivendor/logos/acme.png')
    html = render(msp, make_tenant())
    # white chip <span> wraps the <img>
    assert 'background:#ffffff;border-radius:6px' in html
    assert '<img' in html


@pytest.mark.parametrize('render', RENDERERS)
def test_fallback_name_uses_contrast_color_on_light_band(render):
    # light primary_color -> black band text
    msp = make_msp(primary_color='#ffff00', accent_text_color='#000000', logo_path=None)
    html = render(msp, make_tenant())
    assert 'font-weight:700;color:#000000;' in html


@pytest.mark.parametrize('render', RENDERERS)
def test_fallback_name_uses_contrast_color_on_dark_band(render):
    msp = make_msp(primary_color='#001133', accent_text_color='#ffffff', logo_path=None)
    html = render(msp, make_tenant())
    assert 'font-weight:700;color:#ffffff;' in html


def test_mini_bar_uses_primary_color():
    # one data row so a mini_bar renders; distinctive colour isolates it
    from reports.tests.branding_util import _common, _env
    msp = make_msp(primary_color='#123456')
    ctx = _common(msp, make_tenant())
    ctx.update({
        'exec_summary': {}, 'bandwidth_timeline': [], 'top_apps': [],
        'top_domains': [], 'web_categories': [], 'threats': [], 'rules': [],
        'vpn': [], 'show_vpn': False, 'geo_stats': [], 'productivity': [],
        'dept_breakdown': [], 'group_breakdown': [],
        'top_users': [{'user': 'jane', 'bytes_total': 100, 'bytes_sent': 40,
                       'bytes_received': 60, 'sessions': 3}],
    })
    html = _env().get_template('periodic/report.html').render(**ctx)
    # mini_bar inner fill div is uniquely "height:100%;background:<c>;border-radius:3px"
    assert 'height:100%;background:#123456;border-radius:3px' in html
