import os
import stat

import pytest

from reports.ai import credentials as c


def test_roundtrip(tmp_path):
    p = tmp_path / 'ai.key'
    c.generate_key_file(str(p))
    key = c.load_key(str(p))
    blob = c.encrypt_secret('sk-abc123', key, b'ai_settings:1:v1')
    assert b'sk-abc123' not in blob
    assert c.decrypt_secret(blob, key, b'ai_settings:1:v1') == 'sk-abc123'


def test_nonce_is_random(tmp_path):
    p = tmp_path / 'ai.key'
    c.generate_key_file(str(p))
    key = c.load_key(str(p))
    assert c.encrypt_secret('x', key, b'a') != c.encrypt_secret('x', key, b'a')


def test_wrong_aad_fails(tmp_path):
    p = tmp_path / 'ai.key'
    c.generate_key_file(str(p))
    key = c.load_key(str(p))
    blob = c.encrypt_secret('x', key, b'a')
    with pytest.raises(c.CredentialError):
        c.decrypt_secret(blob, key, b'b')


def test_missing_key_file_fails_closed(tmp_path):
    with pytest.raises(c.CredentialError):
        c.load_key(str(tmp_path / 'nope.key'))


def test_group_readable_key_is_rejected(tmp_path):
    p = tmp_path / 'ai.key'
    c.generate_key_file(str(p))
    os.chmod(p, 0o640)
    with pytest.raises(c.CredentialError):
        c.load_key(str(p))


def test_bad_key_material_is_rejected(tmp_path):
    p = tmp_path / 'ai.key'
    p.write_text('not-base64-32-bytes')
    os.chmod(p, 0o600)
    with pytest.raises(c.CredentialError):
        c.load_key(str(p))


def test_generate_refuses_overwrite(tmp_path):
    p = tmp_path / 'ai.key'
    c.generate_key_file(str(p))
    with pytest.raises(c.CredentialError):
        c.generate_key_file(str(p))
    assert stat.S_IMODE(os.stat(p).st_mode) == 0o600


def test_versioned_key_path(tmp_path):
    base = tmp_path / 'ai.key'
    c.generate_key_file(str(base) + '.2')
    assert len(c.load_key(str(base), version=2)) == 32
