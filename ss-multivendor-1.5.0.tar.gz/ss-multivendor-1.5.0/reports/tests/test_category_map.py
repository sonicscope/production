import json
from pathlib import Path

from reports.queries import SENSITIVE_WEB_CATEGORIES

ROOT = Path(__file__).resolve().parents[1]
MAP = json.loads((ROOT / 'data' / 'ut1_category_map.json').read_text())
KNOWN = {l.strip() for l in (ROOT / 'tests' / 'fixtures' / 'known_report_categories.txt')
         .read_text().splitlines() if l.strip()} | set(SENSITIVE_WEB_CATEGORIES)


def test_every_target_is_a_known_report_category():
    unknown = {c for c in MAP['folders'].values() if c not in KNOWN}
    assert not unknown, unknown


def test_priority_covers_exactly_the_mapped_folders_without_duplicates():
    assert sorted(MAP['priority']) == sorted(MAP['folders'])
    assert len(set(MAP['priority'])) == len(MAP['priority'])


def test_security_folders_outrank_everything_else():
    pr = MAP['priority']
    for sec in ('phishing', 'malware'):
        for other in ('adult', 'gambling', 'social_networks', 'shopping'):
            assert pr.index(sec) < pr.index(other)


def test_sensitive_categories_are_reachable():
    f = MAP['folders']
    assert f['adult'] in SENSITIVE_WEB_CATEGORIES
    assert f['gambling'] in SENSITIVE_WEB_CATEGORIES
    assert f['drogue'] in SENSITIVE_WEB_CATEGORIES
    assert f['hacking'] in SENSITIVE_WEB_CATEGORIES
