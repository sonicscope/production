"""DB-backed tests for migration 009 (domain_category tables)."""
import contextlib

import psycopg2


def _fetch(app_module, sql, params=()):
    with contextlib.closing(psycopg2.connect(**app_module.DB_CONFIG)) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            return cur.fetchall()


def test_tables_exist_and_are_logged(app_module):
    rows = _fetch(app_module,
        "SELECT relname, relpersistence FROM pg_class WHERE relkind='r' AND relname IN "
        "('domain_category','domain_category_stage','category_list_state') ORDER BY relname")
    assert rows == [('category_list_state', 'p'), ('domain_category', 'p'),
                    ('domain_category_stage', 'p')]


def test_primary_key_index_names_are_the_swap_contract(app_module):
    names = {r[0] for r in _fetch(app_module,
        "SELECT indexname FROM pg_indexes WHERE tablename IN "
        "('domain_category','domain_category_stage')")}
    assert names == {'domain_category_pkey', 'domain_category_stage_pkey'}


def test_state_row_seeded_once(app_module):
    assert _fetch(app_module, "SELECT id, domains, last_error FROM category_list_state") \
        == [(1, 0, None)]


import os, sys
_COLLECTOR = os.path.join(os.path.dirname(__file__), '..', '..', 'collector')
if _COLLECTOR not in sys.path:
    sys.path.insert(0, _COLLECTOR)
from enrichment.categorizer import Categorizer


def test_categorizer_against_real_schema(app_module):
    from event import NormalizedEvent
    from datetime import datetime, timezone
    with contextlib.closing(psycopg2.connect(**app_module.DB_CONFIG)) as c, c.cursor() as cur:
        cur.execute("INSERT INTO domain_category (domain, category, list) VALUES "
                    "('bet.example','Gambling','gambling'),('example.org','Shopping','shopping')")
        c.commit()
    cat = Categorizer('unused', connect=lambda dsn: psycopg2.connect(**app_module.DB_CONFIG))
    e = NormalizedEvent(time=datetime(2026, 11, 9, tzinfo=timezone.utc), tenant_id=1,
                        sensor_id=1, vendor='opnsense', data_source='ipfix',
                        event_type='traffic', domain='www.bet.example')
    cat.apply([e])
    assert e.web_category == 'Gambling'
