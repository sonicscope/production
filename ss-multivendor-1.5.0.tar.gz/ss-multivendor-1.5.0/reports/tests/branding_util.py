"""Jinja-only render harness for report-template branding tests.

Renders the report templates to an HTML string using a jinja2 Environment
configured exactly like reports.generator._get_jinja_env(), but with
ChainableUndefined so the templates render with empty data lists without a
DB or WeasyPrint. Only the branding-relevant context (msp/tenant + real
datetimes) needs real values; all table/chart data is empty, which the
macros render as their documented "no data" states.
"""
import os
from datetime import datetime, timezone

import jinja2

_TEMPLATES_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'templates')


def _env() -> jinja2.Environment:
    return jinja2.Environment(
        loader=jinja2.FileSystemLoader(_TEMPLATES_DIR),
        autoescape=jinja2.select_autoescape(['html']),
        trim_blocks=True,
        lstrip_blocks=True,
        undefined=jinja2.ChainableUndefined,
    )


def make_msp(primary_color='#378ADD', accent_text_color='#ffffff',
             name='ACME MSP', footer_text=None, logo_path=None) -> dict:
    return {
        'id': 1, 'name': name, 'logo_path': logo_path,
        'primary_color': primary_color, 'secondary_color': '#00C9A7',
        'accent_text_color': accent_text_color,
        'contact_name': 'Ops Team', 'contact_email': 'ops@acme.example',
        'contact_phone': '+27 11 555 0000', 'website': 'acme.example',
        'footer_text': footer_text,
    }


def make_tenant(name='Client Co') -> dict:
    return {'id': 1, 'name': name, 'slug': 'client-co',
            'contact_name': 'Jane Roe', 'identity_enabled': True}


def _common(msp, tenant) -> dict:
    now = datetime(2026, 7, 1, 9, 30, tzinfo=timezone.utc)
    return {
        'msp': msp, 'tenant': tenant,
        'period_label': 'Week of 24 Jun 2026',
        'period_start': now, 'period_end': now, 'generated_at': now,
    }


def render_periodic(msp, tenant) -> str:
    ctx = _common(msp, tenant)
    ctx.update({
        'exec_summary': {}, 'bandwidth_timeline': [], 'top_users': [],
        'top_apps': [], 'top_domains': [], 'web_categories': [],
        'threats': [], 'rules': [], 'vpn': [], 'show_vpn': False,
        'geo_stats': [], 'productivity': [], 'dept_breakdown': [],
        'group_breakdown': [],
    })
    return _env().get_template('periodic/report.html').render(**ctx)


def render_security(msp, tenant) -> str:
    ctx = _common(msp, tenant)
    ctx.update({
        'exec_summary': {}, 'bandwidth': [], 'top_users': [], 'threats': [],
        'rules': [], 'geo_stats': [], 'blocked_sites': [], 'blocked_users': [],
        'top_ports': [],
    })
    return _env().get_template('security/report.html').render(**ctx)


def render_hr(msp, tenant) -> str:
    ctx = _common(msp, tenant)
    ctx.update({
        'subject': 'sample.user', 'generated_by': 'admin@acme.example',
        'user_summary': {}, 'timeline': [], 'timeline_truncated': False,
        'timeline_limit': 5000, 'top_sites': [], 'blocked': [],
        'categories': [], 'app_breakdown': [], 'clean_mode': False,
        'clean_domain': (lambda domain, web_category=None: domain),
    })
    return _env().get_template('hr/report.html').render(**ctx)
