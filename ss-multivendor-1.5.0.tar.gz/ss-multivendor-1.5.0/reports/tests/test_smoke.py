"""Smoke test for the reports-app test harness.

Proves conftest.py's fixtures actually work end-to-end: the Flask app
imports cleanly against an ephemeral Postgres test DB and answers a real
request. Tasks 1, 2 and 5 build their security regression tests on top of
this same harness.
"""


def test_login_page_returns_200(client):
    resp = client.get('/login')
    assert resp.status_code == 200
