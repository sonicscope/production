"""Flask-client tests for the /login and /forgot-password rate limiting
(P1 brute-force hardening — see
docs/superpowers/specs/2026-07-14-login-rate-limiting-design.md and
reports/web/rate_limit.py for the pure-logic unit tests).

Uses the existing reports/tests/ harness (client/csrf_of/app_module from
conftest.py). Thresholds are overridden to small values via env, set
*before* app_module reloads app.py (whose module-level login_limiter /
forgot_limiter instances read them via _e() at import time) — mirrors the
env-override-then-reload pattern in test_security_config.py.

Fixture ordering note: `small_ratelimits` must be listed before
`client`/`login_as` in each test's parameter list. pytest instantiates
same-scope fixtures with no interdependency in the order a test function
requests them, and `small_ratelimits` shares the test's single
`monkeypatch` instance with `app_module` (via `client`), so the env vars
must land before `app_module`'s reload runs.
"""
from __future__ import annotations

import importlib
import logging
import os
import secrets
import sys

import psycopg2
import pytest
from werkzeug.security import generate_password_hash


@pytest.fixture
def small_ratelimits(monkeypatch):
    """Override rate-limit thresholds to small, easy-to-exceed values.

    LOGIN_RATELIMIT_MAX=3, FORGOT_RATELIMIT_MAX=2 (deliberately lower, per
    the design spec's "separate limiter instances"). Windows/blocks are
    left at 900s (production defaults) — these tests never need real time
    to pass, only more requests than the max.
    """
    monkeypatch.setenv('LOGIN_RATELIMIT_MAX', '3')
    monkeypatch.setenv('LOGIN_RATELIMIT_WINDOW_SEC', '900')
    monkeypatch.setenv('LOGIN_RATELIMIT_BLOCK_SEC', '900')
    monkeypatch.setenv('FORGOT_RATELIMIT_MAX', '2')
    monkeypatch.setenv('FORGOT_RATELIMIT_WINDOW_SEC', '900')
    monkeypatch.setenv('FORGOT_RATELIMIT_BLOCK_SEC', '900')
    monkeypatch.setenv('RATELIMIT_MAX_TRACKED_IPS', '10000')


@pytest.fixture
def seed_login_user(app_module):
    """Factory: seed_login_user('a-real-password') -> email.

    Inserts an active `ui_users` row with a genuine password hash, so
    `/login` can be exercised with real credentials end-to-end. Unlike
    conftest's `login_as` (which writes the session cookie directly,
    bypassing the password check entirely), this is needed here because
    the rate-limit wiring lives around that password check.
    """
    def _seed(password: str, role: str = 'admin') -> str:
        email = f"ratelimit-{secrets.token_hex(4)}@example.test"
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    'INSERT INTO ui_users (email, full_name, role, is_active, password_hash) '
                    'VALUES (%s, %s, %s, true, %s)',
                    (email, 'Rate Limit Test User', role, generate_password_hash(password)),
                )
            conn.commit()
        return email
    return _seed


def _post_login(client, csrf_of, email, password):
    return client.post('/login', data={
        '_csrf': csrf_of(client), 'email': email, 'password': password,
    })


def _post_forgot(client, csrf_of, email):
    return client.post('/forgot-password', data={
        '_csrf': csrf_of(client), 'email': email,
    })


def test_login_allows_up_to_max_failed_attempts(small_ratelimits, client, csrf_of):
    """The first LOGIN_RATELIMIT_MAX (3) failed logins from one client must
    each render the ordinary login form (200) with the generic
    invalid-credentials error — not yet blocked."""
    for _ in range(3):
        resp = _post_login(client, csrf_of, 'nobody@example.test', 'wrong')
        assert resp.status_code == 200
        assert b'Invalid email or password' in resp.data


def test_login_blocks_after_max_failed_attempts(small_ratelimits, client, csrf_of):
    """The (max+1)th failed login from the same client must return 429
    with a Retry-After header and the generic, non-enumerating rate-limit
    message instead of the normal login form."""
    for _ in range(3):
        _post_login(client, csrf_of, 'nobody@example.test', 'wrong')

    resp = _post_login(client, csrf_of, 'nobody@example.test', 'wrong')

    assert resp.status_code == 429
    assert 'Retry-After' in resp.headers
    assert int(resp.headers['Retry-After']) > 0
    assert b'Too many attempts' in resp.data
    assert b'Invalid email or password' not in resp.data


def test_valid_login_before_limit_succeeds_and_resets(
    small_ratelimits, client, csrf_of, seed_login_user,
):
    """A valid login submitted before the limit is reached must succeed
    (redirect) rather than being blocked, and must reset the IP's failure
    counter — a user who mistyped their password a couple of times must
    not be punished by their own earlier mistakes once they get it right.
    """
    email = seed_login_user('correct horse battery staple')

    # Two failures — under the max of 3, so still allowed.
    for _ in range(2):
        resp = _post_login(client, csrf_of, email, 'wrong')
        assert resp.status_code == 200

    # Valid credentials succeed.
    resp = _post_login(client, csrf_of, email, 'correct horse battery staple')
    assert resp.status_code == 302

    with client.session_transaction() as sess:
        sess.clear()  # log back out; /login POST short-circuits while logged in

    # reset() must have cleared history: 3 fresh failures are required again
    # before the (now un-punished) client trips the limiter a second time.
    for _ in range(3):
        resp = _post_login(client, csrf_of, email, 'wrong')
        assert resp.status_code == 200
    resp = _post_login(client, csrf_of, email, 'wrong')
    assert resp.status_code == 429


def test_login_limit_is_per_ip_not_per_account(small_ratelimits, client, csrf_of):
    """Two different target accounts attempted from the same client (same
    remote_addr) must share one bucket — the limiter is keyed by IP, not
    by the submitted email, per the design's anti-account-lockout
    rationale."""
    for _ in range(3):
        resp = _post_login(client, csrf_of, 'account-a@example.test', 'wrong')
        assert resp.status_code == 200

    resp = _post_login(client, csrf_of, 'account-b@example.test', 'wrong')
    assert resp.status_code == 429


def test_forgot_password_blocks_after_its_lower_limit(small_ratelimits, client, csrf_of):
    """FORGOT_RATELIMIT_MAX=2 (deliberately lower than login's 3): the
    first 2 requests must render normally; the 3rd must 429."""
    for _ in range(2):
        resp = _post_forgot(client, csrf_of, 'nobody@example.test')
        assert resp.status_code == 200

    resp = _post_forgot(client, csrf_of, 'nobody@example.test')
    assert resp.status_code == 429
    assert 'Retry-After' in resp.headers
    assert int(resp.headers['Retry-After']) > 0


def test_forgot_password_does_not_reveal_account_existence_when_blocked(
    small_ratelimits, client, csrf_of, seed_login_user,
):
    """Blocked responses must be identical regardless of whether the
    (never-checked, because we're blocked) email belongs to a real
    account — no enumeration channel via the 429 path."""
    real_email = seed_login_user('whatever-password')

    for _ in range(2):
        _post_forgot(client, csrf_of, real_email)
    resp = _post_forgot(client, csrf_of, real_email)

    assert resp.status_code == 429
    assert b'Too many attempts' in resp.data
    assert real_email.encode() not in resp.data


def test_invalid_threshold_env_falls_back_to_default_and_warns(monkeypatch, caplog):
    """A fat-fingered numeric env var (e.g. LOGIN_RATELIMIT_MAX=1o) must NOT
    crash the app at import — it must fall back to the coded default and log
    a warning. Without _int_env's guard the module-level int(_e(...)) would
    raise ValueError here and brick the gunicorn worker at boot.

    Reloads app.py with a bad value set (same env-then-reload pattern the
    other tests use), then restores a clean module in teardown so no
    leftover config leaks into later tests.
    """
    tests_dir = os.path.dirname(os.path.abspath(__file__))
    web_dir = os.path.join(os.path.dirname(tests_dir), 'web')
    if web_dir not in sys.path:
        sys.path.insert(0, web_dir)

    # Preserve the ephemeral test-DB env conftest set up so the reload can
    # still connect, and blank SMTP so no real creds leak in.
    for key in ('DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD',
                'FLASK_SECRET', 'COOKIE_SECURE'):
        val = os.environ.get(key)
        if val is not None:
            monkeypatch.setenv(key, val)
    for key in ('SMTP_HOST', 'SMTP_USER', 'SMTP_PASSWORD', 'SMTP_FROM'):
        monkeypatch.setenv(key, '')

    monkeypatch.setenv('LOGIN_RATELIMIT_MAX', '1o')  # not an integer

    try:
        with caplog.at_level(logging.WARNING, logger='ss.reports.web'):
            if 'app' in sys.modules:
                mod = importlib.reload(sys.modules['app'])
            else:
                mod = importlib.import_module('app')

        # Import did NOT raise, and the limiter fell back to the coded
        # default of 10 rather than the bad env value.
        assert mod.login_limiter._max_attempts == 10
        assert any(
            'LOGIN_RATELIMIT_MAX' in rec.getMessage() and rec.levelno == logging.WARNING
            for rec in caplog.records
        )
    finally:
        if getattr(mod, '_scheduler', None) is not None:
            try:
                mod.stop_scheduler(mod._scheduler)
            except Exception:
                pass
        monkeypatch.delenv('LOGIN_RATELIMIT_MAX', raising=False)
        try:
            restored = importlib.reload(sys.modules['app'])
            if getattr(restored, '_scheduler', None) is not None:
                try:
                    restored.stop_scheduler(restored._scheduler)
                except Exception:
                    pass
        except Exception:
            pass
