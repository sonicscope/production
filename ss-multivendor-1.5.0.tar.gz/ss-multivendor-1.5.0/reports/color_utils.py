"""Shared colour helpers for MSP branding.

Pure functions (stdlib only) used by both the Reports web app login/branding
pages (reports/web/app.py) and the PDF report generator (reports/generator.py).
Kept dependency-free so the generator never has to import the Flask app.
"""
from __future__ import annotations

import re

_HEX_COLOR_RE = re.compile(r'^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$')

# Safe default when a color is missing/malformed: callers fall back to the
# pre-existing teal/blue accent, which reads well with white text, so white is
# the sane fallback for _readable_text_color() rather than guessing. In practice
# this branch is effectively unreachable from the render path — primary_color is
# pre-sanitised by _valid_hex_color() to a real hex before ever reaching
# _readable_text_color() — but the guard stays so the helper is safe to call on
# arbitrary input in isolation.
_DEFAULT_BUTTON_TEXT_COLOR = '#ffffff'
_DEFAULT_ACCENT_COLOR = '#378ADD'


def _valid_hex_color(value: str | None) -> str | None:
    """Return value if it is a syntactically valid #RGB/#RRGGBB hex color
    (case-insensitive), else None. Used before ever placing an msp_profiles
    color value into rendered CSS/HTML — cheap defense in depth against a
    malformed or hostile string breaking out of a style attribute/block."""
    if not value:
        return None
    value = value.strip()
    return value if _HEX_COLOR_RE.match(value) else None


def _hex_to_rgb(hex_color: str | None) -> tuple[int, int, int] | None:
    """Parse a valid #RGB/#RRGGBB hex color into an (r, g, b) tuple, or
    None if it is not a valid hex color."""
    color = _valid_hex_color(hex_color)
    if color is None:
        return None
    h = color.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _readable_text_color(hex_color: str | None) -> str:
    """Return '#000000' or '#ffffff' — whichever reads better as text on a
    `hex_color` background. Perceptual luminance (ITU BT.601 weighting:
    0.299 R + 0.587 G + 0.114 B) on a 0-255 scale; > 128 (roughly the
    midpoint) is light enough for black text, otherwise white text.
    Malformed/empty input returns the safe default rather than raising — an
    MSP operator can save an arbitrary string into `primary_color`, and this
    must never break a render."""
    rgb = _hex_to_rgb(hex_color)
    if rgb is None:
        return _DEFAULT_BUTTON_TEXT_COLOR
    r, g, b = rgb
    luminance = 0.299 * r + 0.587 * g + 0.114 * b
    return '#000000' if luminance > 128 else _DEFAULT_BUTTON_TEXT_COLOR
