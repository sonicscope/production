"""
SonicScope Reports — shared runtime configuration
=================================================
Loads DB / SMTP / output config from the environment (and
``/etc/ss-multivendor/collector.env``) for the **standalone scheduler
service** (``reports/scheduler_service.py``).

This is deliberately a small, self-contained loader rather than a shared
import with ``reports/web/app.py``: the reports web app rebuilds its own
config at import time and the pytest suite relies on that by
``importlib.reload``-ing ``app`` with a per-test environment. Importing the
config from a cached shared module would defeat that reload, so the web app
keeps its own copy and the scheduler process reads the same env here
independently. Both read the same ``collector.env`` keys.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

log = logging.getLogger('ss.reports.runtime_config')

_ENV_FILE = '/etc/ss-multivendor/collector.env'


def _load_env(path: str = _ENV_FILE) -> None:
    """Load key=value pairs from a .env file into os.environ (no overwrite).

    Mirrors ``app._load_env``: existing environment values win (so a
    systemd ``EnvironmentFile`` or an explicit override is never clobbered),
    a missing file is fine, and an unreadable file logs loudly rather than
    crashing the process.
    """
    try:
        for line in Path(path).read_text().splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            k, _, v = line.partition('=')
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except FileNotFoundError:
        pass
    except OSError as exc:
        log.warning("Could not read env file %s (%s) — continuing with "
                    "current environment/defaults only.", path, exc)


def _e(key: str, default: str = '') -> str:
    return os.environ.get(key, default).strip()


def _int_env(key: str, default: int) -> int:
    """Read an integer env var, falling back to `default` on a bad value."""
    raw = _e(key, str(default))
    try:
        return int(raw)
    except ValueError:
        log.warning("Invalid %s=%r — not an integer; using default %d.",
                    key, raw, default)
        return default


_load_env()

DB_CONFIG = {
    'host': _e('DB_HOST', '127.0.0.1'),
    'port': _int_env('DB_PORT', 5432),
    'dbname': _e('DB_NAME', 'sonicscope'),
    'user': _e('DB_USER', 'sonicscope'),
    'password': _e('DB_PASSWORD', ''),
}

SMTP_CONFIG = {
    'host': _e('SMTP_HOST'),
    'port': _int_env('SMTP_PORT', 587),
    'user': _e('SMTP_USER'),
    'password': _e('SMTP_PASSWORD'),
    'from_addr': _e('SMTP_FROM'),
    'use_tls': _e('SMTP_USE_TLS', 'true').lower() in ('1', 'true', 'yes'),
}

OUTPUT_DIR = _e('REPORT_OUTPUT_DIR', '/var/lib/ss-multivendor/reports')

# How often the standalone scheduler re-reads report_schedules from the DB so
# schedule changes made in the web UI are applied without cross-process
# signalling. The DB is the single source of truth; a short poll keeps the two
# processes decoupled with only a few seconds of lag before a new/edited
# schedule becomes active.
SCHEDULE_RELOAD_INTERVAL_SEC = _int_env('SCHEDULE_RELOAD_INTERVAL_SEC', 30)
