"""Per-key sliding-window rate limiter.

Pure logic, no Flask imports — deliberately framework-free so it is cheap
to unit-test in isolation (see reports/tests/test_rate_limit.py). Used by
reports/web/app.py to throttle brute-force / credential-stuffing attempts
against the unauthenticated /login and /forgot-password endpoints.

Design: docs/superpowers/specs/2026-07-14-login-rate-limiting-design.md

Keyed by an arbitrary string (the caller passes the client IP). Counters
live in-process only — no persistence, no cross-worker coordination. That
is an accepted tradeoff: the reports app's report-schedule APScheduler
singleton already pins gunicorn to `--workers 1`, so a single in-memory
instance sees every request, and counters resetting on a service restart
is acceptable for brute-force defense (see design spec "Store").

Bounded-memory tradeoff: the tracked-key map is capped at
`max_tracked_keys` (default 10000) with least-recently-touched eviction.
Under a flood of more than that many *distinct* keys, an already-blocked
key can be evicted and then treated as fresh — i.e. eviction can reset a
block. This is an accepted consequence of bounding memory, and moot in
practice, since escaping a block this way requires the attacker to already
control 10000+ distinct source IPs.
"""
from __future__ import annotations

import math
import threading
import time
from collections import OrderedDict


class RateLimiter:
    """Per-key sliding-window throttle with a bounded, LRU-evicted key map.

    Thread-safe: guarded by an internal `threading.Lock` so a single
    instance can safely be shared across gunicorn's `--threads N` worker
    threads.
    """

    def __init__(self, max_attempts: int, window_seconds: int,
                 block_seconds: int, max_tracked_keys: int = 10000) -> None:
        """Configure the limiter.

        Args:
            max_attempts: number of failures allowed per key within
                `window_seconds` before the key is blocked. `0` disables
                the limiter entirely — `allowed()` always returns True and
                `record_failure()` becomes a no-op (the documented escape
                hatch).
            window_seconds: sliding-window size, in seconds, over which
                failures are counted. Failures older than this are pruned
                before every check.
            block_seconds: how long, in seconds, a key remains blocked once
                it has accumulated `max_attempts` failures within the
                window, counted from that key's most recent failure (not
                from the window boundary).
            max_tracked_keys: upper bound on the number of distinct keys
                tracked at once. Once exceeded, the least-recently-touched
                key is evicted, bounding memory even if an attacker
                sprays failures from an unbounded/rotating set of keys
                (e.g. many source IPs).
        """
        self._max_attempts = max_attempts
        self._window_seconds = window_seconds
        self._block_seconds = block_seconds
        self._max_tracked_keys = max_tracked_keys
        self._lock = threading.Lock()
        # key -> failure timestamps within the window. OrderedDict so the
        # least-recently-touched key (moved to the end on every touch) is
        # in front for O(1) eviction.
        self._failures: "OrderedDict[str, list[float]]" = OrderedDict()

    @staticmethod
    def _resolve_now(now: float | None) -> float:
        """Return `now` if given, else the current monotonic clock value.

        Monotonic (not wall-clock) so an operator/attacker changing the
        system clock cannot shorten or extend a block.
        """
        return time.monotonic() if now is None else now

    def _prune_locked(self, key: str, now: float) -> list[float]:
        """Return `key`'s failure timestamps still inside the window,
        dropping stale ones from the stored map. Caller must hold `_lock`.
        """
        timestamps = self._failures.get(key)
        if not timestamps:
            return []
        cutoff = now - self._window_seconds
        pruned = [t for t in timestamps if t > cutoff]
        if pruned:
            self._failures[key] = pruned
        else:
            self._failures.pop(key, None)
        return pruned

    def _evict_if_needed_locked(self) -> None:
        """Drop least-recently-touched keys until within the tracked-key
        cap. Caller must hold `_lock`."""
        while len(self._failures) > self._max_tracked_keys:
            self._failures.popitem(last=False)

    def allowed(self, key: str, *, now: float | None = None) -> bool:
        """Return True if `key` may attempt now; False if currently blocked."""
        if self._max_attempts <= 0:
            return True
        now = self._resolve_now(now)
        with self._lock:
            timestamps = self._prune_locked(key, now)
            if len(timestamps) < self._max_attempts:
                return True
            most_recent = max(timestamps)
            return (now - most_recent) >= self._block_seconds

    def record_failure(self, key: str, *, now: float | None = None) -> None:
        """Register a failed attempt for `key`. No-op if the limiter is
        disabled (`max_attempts <= 0`)."""
        if self._max_attempts <= 0:
            return
        now = self._resolve_now(now)
        with self._lock:
            timestamps = self._prune_locked(key, now)
            timestamps.append(now)
            self._failures[key] = timestamps
            self._failures.move_to_end(key)
            self._evict_if_needed_locked()

    def reset(self, key: str) -> None:
        """Clear `key`'s failure history — call this on a successful
        attempt so a legitimate user isn't penalised by earlier failures."""
        with self._lock:
            self._failures.pop(key, None)

    def retry_after(self, key: str, *, now: float | None = None) -> int:
        """Return seconds until `key` is allowed again (0 if allowed now).

        Used for both user-facing messaging and the `Retry-After` header.
        Always rounds up, so callers never under-tell a client how long
        to wait.
        """
        if self._max_attempts <= 0:
            return 0
        now = self._resolve_now(now)
        with self._lock:
            timestamps = self._prune_locked(key, now)
            if len(timestamps) < self._max_attempts:
                return 0
            most_recent = max(timestamps)
            remaining = self._block_seconds - (now - most_recent)
            if remaining <= 0:
                return 0
            return math.ceil(remaining)

    def __len__(self) -> int:
        """Number of distinct keys currently tracked (test/introspection
        helper — bounded by `max_tracked_keys`)."""
        with self._lock:
            return len(self._failures)
