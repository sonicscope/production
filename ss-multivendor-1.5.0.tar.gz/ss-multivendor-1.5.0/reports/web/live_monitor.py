"""Pure helpers for the Live Monitor (no Flask, no DB) — unit-testable.
See docs/superpowers/specs/2026-11-09-live-flow-monitor-design.md."""
from __future__ import annotations

LIVE_S = 30          # data within this many seconds  -> live
SILENT_S = 300       # nothing for longer than this    -> silent

LIVE_FEED_LABELS = {'ipfix': 'NetFlow / IPFIX', 'syslog': 'Syslog'}


def feed_label(feed: str) -> str:
    """Human label for a feed key (unknown keys are title-cased)."""
    return LIVE_FEED_LABELS.get(feed, feed.replace('_', ' ').title())


def feed_status(age_s: float | None) -> str:
    """Classify feed age: live (<=30 s), idle (<=300 s), silent (older or never)."""
    if age_s is None or age_s > SILENT_S:
        return 'silent'
    return 'live' if age_s <= LIVE_S else 'idle'


def shape_feed(row: dict) -> dict:
    """Shape a live_tap_feed row for JSON; status uses the same truncated age shown."""
    raw_age = row['age_s']
    age = None if raw_age is None else int(raw_age)
    return {
        'source_ip': str(row['source_ip']),
        'feed': row['feed'],
        'status': feed_status(age),
        'received': int(row['received']),
        'ok': int(row['ok']),
        'skipped': int(row['skipped']),
        'rejected': dict(row['rejected'] or {}),
        'age_s': age,
    }


def shape_sample(row: dict) -> dict:
    """Shape a live_tap_sample row for JSON (ISO timestamp, stringified IP)."""
    return {
        'ts': row['ts'].isoformat(),
        'source_ip': str(row['source_ip']),
        'feed': row['feed'],
        'outcome': row['outcome'],
        'reason': row['reason'],
        'text': row['text'],
    }
