"""HTML/CSS/JS for the Live Monitor page (inserted into the shared _BASE
layout by app.live_page_view). Static template: the only substitution is
{{FW_OPTIONS}} (server-built, already escaped). ALL dynamic text from the
collector is written with textContent — never innerHTML."""

LIVE_PAGE = r'''
<style>
.live-wrap{--lv-bar:#0D1629;--lv-panel:#111C33;--lv-border:#1A2A4A;--lv-text:#E8EFF8;
  --lv-muted:#8BA3C0;--lv-ok:#00C9A7;--lv-warn:#FFC107;--lv-bad:#FF6B6B;--lv-fresh:#16264A;--lv-ink:#070D1A;color:var(--lv-text);}
.live-wrap .lv-mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;}
.lv-head{display:flex;flex-wrap:wrap;gap:.75rem;align-items:center;margin-bottom:1rem;}
.lv-head h4{margin:0 1rem 0 0;}
.lv-state{font-size:.8rem;color:var(--lv-muted);}
.lv-dot{display:inline-block;width:.6rem;height:.6rem;border-radius:50%;background:var(--lv-muted);margin-right:.35rem;}
.lv-dot.live{background:var(--lv-ok);} .lv-dot.idle{background:var(--lv-warn);}
.lv-dot.silent{background:transparent;border:2px solid var(--lv-muted);}
.lv-tail{background:var(--lv-bar);border:1px solid var(--lv-border);border-radius:6px;
  padding:.5rem 0;margin-bottom:1.25rem;min-height:6.2rem;}
.lv-line{display:flex;gap:.75rem;padding:.15rem .75rem .15rem 0;font-size:.8rem;
  border-left:4px solid var(--lv-muted);padding-left:.6rem;white-space:nowrap;overflow:hidden;}
.lv-line.ok{border-left-color:var(--lv-ok);} .lv-line.skipped{border-left-color:var(--lv-warn);}
.lv-line.rejected{border-left-color:var(--lv-bad);}
.lv-line .lv-txt{overflow:hidden;text-overflow:ellipsis;}
.lv-line .lv-meta{color:var(--lv-muted);flex:none;}
.lv-line.fresh{animation:lvfade .9s ease-out;}
@keyframes lvfade{from{background:var(--lv-fresh)}to{background:transparent}}
@media (prefers-reduced-motion:reduce){.lv-line.fresh{animation:none;}}
.lv-panel{background:var(--lv-panel);border:1px solid var(--lv-border);border-radius:6px;
  padding:.75rem 1rem;margin-bottom:1.25rem;}
.lv-panel h6{color:var(--lv-muted);text-transform:uppercase;letter-spacing:.5px;font-size:.72rem;margin-bottom:.5rem;}
.lv-empty{color:var(--lv-muted);font-size:.9rem;}
.lv-check{margin:.4rem 0 0;padding-left:1.2rem;color:var(--lv-muted);font-size:.85rem;}
.lv-badge{display:inline-block;padding:0 .4rem;border-radius:3px;font-size:.7rem;
  background:var(--lv-border);color:var(--lv-muted);margin-left:.4rem;}
.lv-badge.warn{background:var(--lv-warn);color:var(--lv-ink);}
.live-wrap select:focus-visible,.live-wrap button:focus-visible{outline:2px solid var(--lv-ok);outline-offset:2px;}
.live-wrap .table-responsive{max-height:22rem;}
.live-wrap .table{--bs-table-bg:transparent;--bs-table-color:var(--lv-text);}
.live-wrap .table-responsive td,.live-wrap .table-responsive th{white-space:nowrap;}
.lv-hint{display:none;color:var(--lv-muted);font-size:.7rem;text-align:right;margin-bottom:.25rem;}
.lv-noscript{color:var(--lv-warn);background:var(--lv-panel);border:1px solid var(--lv-border);
  border-radius:6px;padding:.75rem 1rem;margin-bottom:1rem;}
@media (max-width:575.98px){
  .lv-hint{display:block;}
  .lv-line{flex-wrap:wrap;gap:.1rem .6rem;white-space:normal;}
  .lv-line .lv-txt{flex:1 0 100%;white-space:nowrap;}
}
</style>

<div class="live-wrap" id="lv-root">
  <noscript><div class="lv-noscript">The Live Monitor needs JavaScript to show live data.</div></noscript>
  <div class="lv-head">
    <h4>📡 Live Monitor</h4>
    <label class="visually-hidden" for="lv-fw">Firewall</label>
    <select id="lv-fw" class="form-select form-select-sm" style="width:auto;min-width:16rem;">
      {{FW_OPTIONS}}
    </select>
    <span class="lv-state"><span class="lv-dot" id="lv-dot"></span><span id="lv-state-txt">Starting…</span></span>
    <button type="button" id="lv-pause" class="btn btn-sm btn-outline-secondary">Pause</button>
  </div>

  <div id="lv-migrate" class="alert alert-warning" hidden>
    Live monitor needs migration 007 — run <code>update.sh</code> on this server.
  </div>

  <div id="lv-shared" class="alert alert-info" hidden>
    Live feed data is hidden because another customer registered the same source IP. Ask an administrator.
  </div>

  <div id="lv-shared-note" class="small text-secondary mb-2" hidden>
    This source IP is also registered under another tenant.
  </div>

  <div class="lv-tail lv-mono" id="lv-tail" aria-live="off" aria-label="Raw feed tail">
    <div class="lv-empty px-3 py-2" id="lv-tail-empty">Waiting for data…</div>
  </div>

  <div class="lv-panel" id="lv-feeds-panel">
    <h6>Feeds</h6>
    <div class="lv-empty" id="lv-feeds-loading" hidden>Loading…</div>
    <div class="table-responsive" id="lv-feeds-wrap">
      <div class="lv-hint" aria-hidden="true">Scroll →</div>
      <table class="table table-sm mb-0">
        <thead><tr><th>Source</th><th>Feed</th><th>Status</th><th class="text-end">Rate/s</th>
          <th>Last seen</th><th>Rejected / skipped</th></tr></thead>
        <tbody id="lv-feeds"></tbody>
      </table>
    </div>
    <div id="lv-feeds-empty" class="lv-empty" hidden>
      <div>No packets from this firewall in the last 5 minutes. Check:</div>
      <ul class="lv-check">
        <li>The source IP is registered under Tenants → Register Firewall.</li>
        <li>The firewall sends NetFlow/IPFIX to UDP 2055 and syslog to UDP/TCP 514.</li>
        <li>The IP is in the collector allowlist (it updates when you register).</li>
      </ul>
    </div>
  </div>

  <div class="lv-panel" id="lv-events-panel">
    <h6>Recent stored events <span class="lv-badge">last 5 min</span></h6>
    <div class="lv-empty" id="lv-events-loading" hidden>Loading…</div>
    <div class="table-responsive" id="lv-events-wrap">
      <div class="lv-hint" aria-hidden="true">Scroll →</div>
      <table class="table table-sm mb-0 lv-mono" style="font-size:.78rem;">
        <thead><tr><th>Time</th><th>Type</th><th>Action</th><th>Source</th><th>Destination</th>
          <th>Proto</th><th>App</th><th class="text-end">Bytes</th></tr></thead>
        <tbody id="lv-events"></tbody>
      </table>
    </div>
    <div id="lv-events-empty" class="lv-empty" hidden>No stored events in the last 5 minutes.</div>
  </div>
</div>

<script>
(function () {
  'use strict';
  var POLL_MS = 2000, TAIL_LINES = 4;
  var fw = document.getElementById('lv-fw');
  var pauseBtn = document.getElementById('lv-pause');
  var dot = document.getElementById('lv-dot');
  var stateTxt = document.getElementById('lv-state-txt');
  var paused = false, timer = null, inflight = null;
  var prev = {};            // 'ip|feed' -> {received, t}
  var seenSamples = {};     // sample key -> true
  var LABELS = {ipfix: 'NetFlow / IPFIX', syslog: 'Syslog'};

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }
  function label(f) { return LABELS[f] || (f.charAt(0).toUpperCase() + f.slice(1)); }
  function hhmmss(iso) { try { return new Date(iso).toTimeString().slice(0, 8); } catch (e) { return ''; } }
  function ageTxt(s) {
    if (s === null || s === undefined) return 'never';
    if (s < 2) return 'just now';
    if (s < 120) return s + 's ago';
    return Math.round(s / 60) + 'm ago';
  }
  function setState(cls, txt) {
    dot.className = 'lv-dot ' + cls;
    stateTxt.textContent = txt;
  }

  function renderTail(samples) {
    var tail = document.getElementById('lv-tail');
    var empty = document.getElementById('lv-tail-empty');
    var lines = samples.slice(0, TAIL_LINES);
    Array.prototype.slice.call(tail.querySelectorAll('.lv-line')).forEach(function (n) { n.remove(); });
    if (!lines.length) { empty.textContent = 'Waiting for data…'; empty.hidden = false; return; }
    empty.hidden = true;
    lines.forEach(function (s) {
      var key = s.ts + '|' + s.source_ip + '|' + s.feed + '|' + s.outcome;
      var row = el('div', 'lv-line ' + s.outcome + (seenSamples[key] ? '' : ' fresh'));
      seenSamples[key] = true;
      row.appendChild(el('span', 'lv-meta', hhmmss(s.ts)));
      row.appendChild(el('span', 'lv-meta', label(s.feed)));
      row.appendChild(el('span', 'lv-meta', s.source_ip));
      row.appendChild(el('span', 'lv-meta', s.outcome + (s.reason ? ' · ' + s.reason : '')));
      row.appendChild(el('span', 'lv-txt', s.text));
      tail.appendChild(row);
    });
  }

  // Drop everything from the previously selected firewall and show a loading state.
  function clearPanels() {
    var tail = document.getElementById('lv-tail');
    Array.prototype.slice.call(tail.querySelectorAll('.lv-line')).forEach(function (n) { n.remove(); });
    var empty = document.getElementById('lv-tail-empty');
    empty.textContent = 'Loading…';
    empty.hidden = false;
    ['lv-shared', 'lv-shared-note', 'lv-migrate'].forEach(function (id) {
      document.getElementById(id).hidden = true;
    });
    document.getElementById('lv-feeds').textContent = '';
    document.getElementById('lv-events').textContent = '';
    ['lv-feeds', 'lv-events'].forEach(function (p) {
      document.getElementById(p + '-wrap').hidden = true;
      document.getElementById(p + '-empty').hidden = true;
      document.getElementById(p + '-loading').hidden = false;
    });
  }
  function hideLoading() {
    document.getElementById('lv-feeds-loading').hidden = true;
    document.getElementById('lv-events-loading').hidden = true;
  }

  function renderFeeds(feeds, now) {
    var tbody = document.getElementById('lv-feeds');
    tbody.textContent = '';
    // Checklist: no rows at all, or any feed that has gone silent.
    var anySilent = feeds.some(function (f) { return f.status === 'silent'; });
    document.getElementById('lv-feeds-empty').hidden = !(feeds.length === 0 || anySilent);
    document.getElementById('lv-feeds-wrap').hidden = feeds.length === 0;
    feeds.forEach(function (f) {
      var k = f.source_ip + '|' + f.feed, rate = '–';
      if (prev[k] && now > prev[k].t) {
        rate = Math.max(0, (f.received - prev[k].received) / ((now - prev[k].t) / 1000)).toFixed(0);
      }
      prev[k] = {received: f.received, t: now};
      var tr = el('tr');
      tr.appendChild(el('td', 'lv-mono', f.source_ip));
      tr.appendChild(el('td', '', label(f.feed)));
      var st = el('td');
      st.appendChild(el('span', 'lv-dot ' + f.status));
      st.appendChild(document.createTextNode(f.status));
      tr.appendChild(st);
      tr.appendChild(el('td', 'text-end lv-mono', rate));
      tr.appendChild(el('td', '', ageTxt(f.age_s)));
      var rej = Object.keys(f.rejected || {}).map(function (r) { return r + ' ×' + f.rejected[r]; });
      if (f.skipped) rej.push('skipped ×' + f.skipped);
      tr.appendChild(el('td', 'lv-mono', rej.length ? rej.join(', ') : '–'));
      tbody.appendChild(tr);
    });
  }

  function renderEvents(events) {
    var tbody = document.getElementById('lv-events');
    tbody.textContent = '';
    document.getElementById('lv-events-empty').hidden = events.length > 0;
    document.getElementById('lv-events-wrap').hidden = events.length === 0;
    events.forEach(function (e) {
      var tr = el('tr');
      var bytes = (e.bytes_sent || 0) + (e.bytes_received || 0);
      [hhmmss(e.time), e.event_type, e.action || '',
       (e.src_ip || '') + (e.src_port ? ':' + e.src_port : ''),
       (e.dst_ip || '') + (e.dst_port ? ':' + e.dst_port : ''),
       e.protocol || '', e.app_name || ''].forEach(function (v) { tr.appendChild(el('td', '', v)); });
      tr.appendChild(el('td', 'text-end', bytes));
      tbody.appendChild(tr);
    });
  }

  function poll() {
    if (paused || document.hidden || !fw.value) return;
    if (inflight) return;                 // previous request still running: skip this tick
    var ctl = new AbortController(), timedOut = false;
    inflight = ctl;
    var timeout = setTimeout(function () { timedOut = true; ctl.abort(); }, 5000);
    function current() { return inflight === ctl; }   // false once superseded or paused
    fetch('/live/data?fw=' + encodeURIComponent(fw.value),
          {credentials: 'same-origin', signal: ctl.signal})
      .then(function (r) {
        if (r.status === 401 || r.redirected) throw new Error('signed out');
        var ct = (r.headers.get('content-type') || '').toLowerCase();
        if (!r.ok || ct.indexOf('application/json') === -1) throw new Error('http ' + r.status);
        return r.json();
      })
      .then(function (d) {
        if (!current()) return;
        hideLoading();
        // Reset every banner first so no early return can leave a stale one showing.
        document.getElementById('lv-migrate').hidden = !d.needs_migration;
        document.getElementById('lv-shared').hidden = !d.withheld;
        document.getElementById('lv-shared-note').hidden = !(d.ip_shared && !d.withheld);
        if (d.needs_migration) { setState('silent', 'Needs migration 007'); return; }
        ['lv-tail', 'lv-feeds-panel', 'lv-events-panel'].forEach(function (id) {
          document.getElementById(id).hidden = !!d.withheld;
        });
        if (d.withheld) { setState('silent', 'Live data hidden'); return; }
        var now = Date.now();
        renderTail(d.samples || []);
        renderFeeds(d.feeds || [], now);
        document.getElementById('lv-events-panel').hidden = d.mode === 'unregistered';
        renderEvents(d.events || []);
        var live = (d.feeds || []).some(function (f) { return f.status === 'live'; });
        setState(live ? 'live' : 'idle', live ? 'Live · 2s' : 'Connected · no live feed');
      })
      .catch(function (err) {
        if (!current()) return;           // superseded (selector change) or paused: stay quiet
        if (err && err.name === 'AbortError' && !timedOut) return;
        setState('silent', 'Stale — ' + (timedOut ? 'timed out' : (err && err.message ? err.message : 'no response')));
      })
      .then(function () {
        clearTimeout(timeout);
        if (current()) inflight = null;
      });
  }

  function abortInflight() {
    if (inflight) { var c = inflight; inflight = null; c.abort(); }
  }
  function start() { stop(); poll(); timer = setInterval(poll, POLL_MS); }
  function stop() { if (timer) { clearInterval(timer); timer = null; } }

  fw.addEventListener('change', function () {
    abortInflight(); prev = {}; seenSamples = {}; clearPanels(); start();
  });
  pauseBtn.addEventListener('click', function () {
    paused = !paused;
    pauseBtn.textContent = paused ? 'Resume' : 'Pause';
    if (paused) { abortInflight(); stop(); setState('idle', 'Paused'); } else { start(); }
  });
  document.addEventListener('visibilitychange', function () { if (!document.hidden && !paused) poll(); });
  if (fw.value) start(); else setState('silent', 'No firewall selected');
})();
</script>
'''
