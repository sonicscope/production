"""UT1 category list refresh (runs in ss-scheduler; never imports collector code).

Downloads the UT1 blacklists archive, keeps only the folders named in
data/ut1_category_map.json, validates domains, loads them into
domain_category_stage and swaps stage <-> live by renaming tables and their
primary-key indexes in ONE transaction. A failed/truncated/shrunk download
keeps the previous live table. UT1 is CC BY-SA: lists are downloaded per
install and never redistributed; attribution is in the docs and UI.
"""
from __future__ import annotations

import json
import logging
import os
import re
import tarfile
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

log = logging.getLogger('ss.reports.category_lists')

DEFAULT_URL = 'https://dsi.ut-capitole.fr/blacklists/download/blacklists.tar.gz'
MAX_DOWNLOAD_BYTES = 150_000_000
MAX_MEMBER_BYTES = 300_000_000          # one 'domains' member, uncompressed
MAX_UNPACKED_BYTES = 1_500_000_000      # all members read, uncompressed
MAX_ROWS = 20_000_000
_MAX_LINE = 253                         # longest valid domain name
_READ_LIMIT = 512                       # readline() bound; longer lines are dropped
_MAP_PATH = Path(__file__).resolve().parent / 'data' / 'ut1_category_map.json'
_LABEL = re.compile(r'^[a-z0-9_-]{1,63}$')


@dataclass(frozen=True)
class Mapping:
    version: str
    folders: dict
    priority: list


def load_mapping(path: Optional[str] = None) -> Mapping:
    """Load the versioned UT1 folder -> report category mapping."""
    data = json.loads(Path(path or _MAP_PATH).read_text())
    return Mapping(data['version'], dict(data['folders']), list(data['priority']))


def valid_domain(value: str) -> Optional[str]:
    """Same rules as collector/enrichment/domain_util.normalise_domain
    (duplicated on purpose: reports must not import collector code)."""
    d = (value or '').strip().lower()
    if d.endswith('.'):
        d = d[:-1]
    if not d or len(d) > 253:
        return None
    labels = d.split('.')
    if len(labels) < 2:
        return None
    for lab in labels:
        if not _LABEL.match(lab) or lab.startswith('-') or lab.endswith('-'):
            return None
    return None if labels[-1].isdigit() else d


class _HttpsOnlyRedirect(urllib.request.HTTPRedirectHandler):
    """Refuse redirects to anything but https (no downgrade, no file://)."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not newurl.lower().startswith('https://'):
            raise ValueError('refusing redirect to non-https URL')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _default_opener(req, timeout):
    return urllib.request.build_opener(_HttpsOnlyRedirect()).open(req, timeout=timeout)


def https_fetch(url: str, dest_path: str, max_bytes: int = MAX_DOWNLOAD_BYTES,
                timeout: int = 60, opener: Callable = _default_opener) -> None:
    """Download `url` (https only) to dest_path, refusing more than max_bytes."""
    if not url.lower().startswith('https://'):
        raise ValueError('category list URL must be https')
    req = urllib.request.Request(url, headers={'User-Agent': 'sonicscope-category-refresh'})
    total = 0
    with opener(req, timeout=timeout) as resp, open(dest_path, 'wb') as out:
        while True:
            chunk = resp.read(1 << 20)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise ValueError(f'download exceeds {max_bytes} bytes')
            out.write(chunk)


def _extract_rows(archive: str, mapping: Mapping, out_tsv: str,
                  max_member_bytes: int = MAX_MEMBER_BYTES, max_rows: int = MAX_ROWS,
                  max_unpacked_bytes: int = MAX_UNPACKED_BYTES) -> dict:
    """Stream the archive; write 'domain\\tcategory\\tprio\\tfolder' rows for
    mapped folders only. Returns stats. Raises ValueError when the total row
    or unpacked-byte caps are exceeded (decompression-bomb guard); members
    larger than max_member_bytes are skipped and counted in 'rejected_members'.
    Lines are read with a bounded readline so a newline-free member cannot
    exhaust memory; over-long lines are counted invalid."""
    prio = {f: i for i, f in enumerate(mapping.priority)}
    seen, unmapped, invalid, written, rejected, read_bytes = set(), set(), 0, 0, 0, 0
    with tarfile.open(archive, 'r|gz') as tar, open(out_tsv, 'w', encoding='utf-8') as out:
        for member in tar:
            if not member.isfile():
                continue
            parts = member.name.split('/')
            if len(parts) < 2 or parts[-1] != 'domains':
                continue
            folder = parts[-2]
            if folder not in mapping.folders:
                unmapped.add(folder)
                continue
            if member.size > max_member_bytes:
                rejected += 1
                log.warning('UT1 member %s is %d bytes (> %d); skipped',
                            member.name, member.size, max_member_bytes)
                continue
            seen.add(folder)
            cat = mapping.folders[folder]
            fh = tar.extractfile(member)
            while True:
                raw = fh.readline(_READ_LIMIT)
                if not raw:
                    break
                read_bytes += len(raw)
                too_long = False
                if len(raw) == _READ_LIMIT and not raw.endswith(b'\n'):
                    too_long = True                      # consume rest of the line
                    while True:
                        rest = fh.readline(65536)
                        read_bytes += len(rest)
                        if not rest or rest.endswith(b'\n'):
                            break
                        if read_bytes > max_unpacked_bytes:
                            break
                if read_bytes > max_unpacked_bytes:
                    raise ValueError(f'archive exceeds {max_unpacked_bytes} unpacked bytes')
                d = None if too_long else valid_domain(raw.decode('utf-8', 'ignore'))
                if d is None or len(raw.rstrip(b'\r\n')) > _MAX_LINE:
                    invalid += 1
                    continue
                if written >= max_rows:
                    raise ValueError(f'archive exceeds {max_rows} rows')
                out.write(f'{d}\t{cat}\t{prio[folder]}\t{folder}\n')
                written += 1
    return {'folders_seen': sorted(seen), 'unmapped_folders': sorted(unmapped),
            'invalid': invalid, 'written': written, 'rejected_members': rejected}


_LOCK_TIMEOUT_SQL = "SET LOCAL lock_timeout = '2s'"
_SWAP_SQL = (
    "ALTER TABLE domain_category RENAME TO domain_category_old",
    "ALTER INDEX domain_category_pkey RENAME TO domain_category_old_pkey",
    "ALTER TABLE domain_category_stage RENAME TO domain_category",
    "ALTER INDEX domain_category_stage_pkey RENAME TO domain_category_pkey",
    "ALTER TABLE domain_category_old RENAME TO domain_category_stage",
    "ALTER INDEX domain_category_old_pkey RENAME TO domain_category_stage_pkey",
)


def refresh_categories(connect: Callable, mapping: Mapping, fetch: Callable,
                       shrink_floor: float = 0.5, max_member_bytes: int = MAX_MEMBER_BYTES,
                       max_rows: int = MAX_ROWS,
                       max_unpacked_bytes: int = MAX_UNPACKED_BYTES) -> dict:
    """Run one refresh. `connect()` returns a psycopg2 connection; `fetch(dest)`
    downloads the archive to `dest`. Never raises: failures keep the previous
    table and are recorded in category_list_state.last_error."""
    result = {'status': 'kept', 'domains': 0, 'invalid': 0, 'folders_seen': [],
              'unmapped_folders': [], 'error': None}
    conn = None
    tmpdir = tempfile.mkdtemp(prefix='ut1-')
    try:
        archive = os.path.join(tmpdir, 'lists.tar.gz')
        tsv = os.path.join(tmpdir, 'rows.tsv')
        conn = connect()
        with conn.cursor() as cur:
            cur.execute("INSERT INTO category_list_state (id) VALUES (1) "
                        "ON CONFLICT (id) DO NOTHING")
        _state(conn, "last_attempt_at = now()")
        conn.commit()

        fetch(archive)
        stats = _extract_rows(archive, mapping, tsv, max_member_bytes, max_rows,
                              max_unpacked_bytes)
        result.update({k: stats[k] for k in ('invalid', 'folders_seen', 'unmapped_folders')})
        if stats['unmapped_folders']:
            log.info('UT1 folders without a mapping (skipped): %s', stats['unmapped_folders'])

        with conn.cursor() as cur:
            cur.execute("SELECT domains FROM category_list_state WHERE id = 1")
            row = cur.fetchone()
            previous = (row[0] if row else 0) or 0
            cur.execute("CREATE TEMP TABLE ut1_load (domain text, category text, "
                        "prio int, folder text) ON COMMIT DROP")
            with open(tsv, 'r', encoding='utf-8') as fh:
                cur.copy_expert("COPY ut1_load FROM STDIN", fh)
            cur.execute("TRUNCATE domain_category_stage")
            cur.execute(
                "INSERT INTO domain_category_stage (domain, category, list) "
                "SELECT DISTINCT ON (domain) domain, category, folder FROM ut1_load "
                "ORDER BY domain, prio")
            cur.execute("SELECT count(*) FROM domain_category_stage")
            total = cur.fetchone()[0]
            if total == 0:
                raise ValueError('refresh produced no domains')
            if previous and total < previous * shrink_floor:
                raise ValueError(f'list shrank from {previous} to {total} domains')
            cur.execute(_LOCK_TIMEOUT_SQL)           # blocked rename fails, keeps old list
            for stmt in _SWAP_SQL:
                cur.execute(stmt)
            cur.execute("TRUNCATE domain_category_stage")   # old list: not on disk twice
            cur.execute(
                "UPDATE category_list_state SET list_version = %s, domains = %s, "
                "refreshed_at = now(), last_error = NULL WHERE id = 1",
                (mapping.version, total))
        conn.commit()
        result.update(status='ok', domains=total)
        log.info('UT1 categories refreshed: %d domains', total)
    except Exception as exc:                 # keep the previous table, record why
        result['error'] = str(exc)
        log.warning('UT1 category refresh failed; keeping previous list: %s', exc)
        try:
            if conn is not None:
                conn.rollback()
                _state(conn, "last_error = %s", (str(exc)[:500],))
                conn.commit()
        except Exception:
            log.exception('could not record category refresh error')
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
        for name in os.listdir(tmpdir):
            try:
                os.remove(os.path.join(tmpdir, name))
            except OSError:
                pass
        try:
            os.rmdir(tmpdir)
        except OSError:
            pass
    return result


def _state(conn, assignment: str, params: tuple = ()) -> None:
    with conn.cursor() as cur:
        cur.execute(f"UPDATE category_list_state SET {assignment} WHERE id = 1", params)
