-- Migration 010: AI Investigate foundation (spec 2026-11-17-ai-investigate-design.md)
-- Idempotent. The role is created WITHOUT a password; scripts/ai-bootstrap.sh
-- sets it from AI_DB_PASSWORD in collector.env.

-- ── Restricted read-only role ────────────────────────────────────────────────
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ss_ai_ro') THEN
        CREATE ROLE ss_ai_ro LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
    END IF;
END $$;

ALTER ROLE ss_ai_ro SET default_transaction_read_only = on;
ALTER ROLE ss_ai_ro SET statement_timeout = '10s';
ALTER ROLE ss_ai_ro SET lock_timeout = '2s';
ALTER ROLE ss_ai_ro SET idle_in_transaction_session_timeout = '30s';
ALTER ROLE ss_ai_ro SET work_mem = '16MB';
-- pg_catalog first so built-ins can't be shadowed; public only for TimescaleDB
-- (time_bucket). `ai` is deliberately NOT on the path: the SQL guard requires
-- ai.<view> qualification, so an unqualified name must never resolve to a view.
ALTER ROLE ss_ai_ro SET search_path = pg_catalog, public;
ALTER ROLE ss_ai_ro CONNECTION LIMIT 16;

-- Removes only DIRECT grants to ss_ai_ro; privileges inherited via PUBLIC
-- (e.g. _timescaledb_* catalogs) remain and are blocked at the SQL-guard layer.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM ss_ai_ro;

-- Functions default to EXECUTE for PUBLIC; lookup_identity returns user
-- identity, so it must not be callable by ss_ai_ro.
DO $$
BEGIN
    IF to_regprocedure('public.lookup_identity(integer, inet)') IS NOT NULL THEN
        REVOKE EXECUTE ON FUNCTION public.lookup_identity(integer, inet) FROM PUBLIC;
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sonicscope') THEN
            GRANT EXECUTE ON FUNCTION public.lookup_identity(integer, inet) TO sonicscope;
        END IF;
    END IF;
END $$;

-- ── Per-tenant switch (default OFF) ──────────────────────────────────────────
ALTER TABLE tenants ADD COLUMN IF NOT EXISTS ai_enabled boolean NOT NULL DEFAULT false;

-- ── Install-wide settings (single row) ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS ai_settings (
    id               smallint PRIMARY KEY CHECK (id = 1),
    provider         text NOT NULL CHECK (provider IN ('anthropic', 'openai', 'gemini')),
    model            text NOT NULL,
    api_key_enc      bytea NOT NULL,
    api_key_last4    text NOT NULL,
    key_version      integer NOT NULL DEFAULT 1,
    consent_user_id  integer,
    consent_at       timestamptz,
    consent_provider text,
    updated_at       timestamptz NOT NULL DEFAULT now()
);

-- ── Audit log (immutable; rows older than 365 days may be deleted) ───────────
CREATE TABLE IF NOT EXISTS ai_audit (
    id          bigserial PRIMARY KEY,
    ts          timestamptz NOT NULL DEFAULT now(),
    kind        text NOT NULL,                 -- 'chat_start' | 'chat' | 'query' | 'settings' | 'test'
    user_id     integer,
    tenant_id   integer,
    provider    text,
    model       text,
    question    text,
    sql         text,
    row_count   integer,
    duration_ms integer,
    error       text,
    tokens_in   integer NOT NULL DEFAULT 0,
    tokens_out  integer NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ai_audit_ts_idx ON ai_audit (ts DESC);
CREATE INDEX IF NOT EXISTS ai_audit_user_kind_idx ON ai_audit (user_id, kind, ts DESC);

CREATE OR REPLACE FUNCTION ai_audit_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        RAISE EXCEPTION 'ai_audit rows are immutable';
    END IF;
    IF TG_OP = 'DELETE' AND OLD.ts > now() - interval '365 days' THEN
        RAISE EXCEPTION 'ai_audit rows newer than 365 days cannot be deleted';
    END IF;
    RETURN OLD;
END $$;

DROP TRIGGER IF EXISTS ai_audit_immutable_trg ON ai_audit;
CREATE TRIGGER ai_audit_immutable_trg BEFORE UPDATE OR DELETE ON ai_audit
    FOR EACH ROW EXECUTE FUNCTION ai_audit_immutable();

-- ── ai schema: tenant helper + curated views (explicit columns, never *) ─────
CREATE SCHEMA IF NOT EXISTS ai;

CREATE OR REPLACE FUNCTION ai.current_tenant() RETURNS integer
LANGUAGE sql STABLE AS
$$ SELECT NULLIF(current_setting('ss.tenant_id', true), '')::integer $$;

CREATE OR REPLACE VIEW ai.events WITH (security_barrier = true) AS
SELECT time, tenant_id, sensor_id, vendor, event_type, action,
       src_ip, dst_ip, src_port, dst_port, protocol,
       bytes_sent, bytes_received, packets_sent, packets_received, duration_ms,
       zone_src, zone_dst, rule_name, app_name, app_category, app_risk,
       domain, regexp_replace(url, '[?#].*$', '') AS url_path, web_category,
       threat_name, threat_category, threat_severity, threat_id,
       geo_src_country_code, geo_dst_country, geo_dst_country_code, vpn_policy_name
FROM public.fw_events
WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.hourly_bandwidth WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, bytes_sent, bytes_received, bytes_total, event_count
FROM public.hourly_bandwidth_timeline WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.hourly_threat WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, threat_category, threat_severity, event_count
FROM public.hourly_threat_stats WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.daily_threat WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, threat_category, threat_severity, event_count
FROM public.daily_threat_stats WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.daily_app WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, app_name, app_category, app_risk,
       bytes_total, session_count
FROM public.daily_app_stats WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.daily_web WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, web_category, action, request_count, bytes_total
FROM public.daily_web_stats WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.daily_domain WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, domain, web_category, action,
       request_count, bytes_total
FROM public.daily_domain_stats WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.daily_geo WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, geo_dst_country, geo_dst_country_code, action,
       connection_count, bytes_total
FROM public.daily_geo_stats WHERE tenant_id = ai.current_tenant();

CREATE OR REPLACE VIEW ai.daily_rule WITH (security_barrier = true) AS
SELECT bucket, tenant_id, sensor_id, vendor, rule_name, rule_id, action, hit_count, bytes_total
FROM public.daily_rule_stats WHERE tenant_id = ai.current_tenant();

-- ── Grants: explicit, per view. Nothing else is visible to ss_ai_ro. ─────────
GRANT USAGE ON SCHEMA ai TO ss_ai_ro;
GRANT EXECUTE ON FUNCTION ai.current_tenant() TO ss_ai_ro;
GRANT SELECT ON ai.events, ai.hourly_bandwidth, ai.hourly_threat, ai.daily_threat,
                ai.daily_app, ai.daily_web, ai.daily_domain, ai.daily_geo, ai.daily_rule
    TO ss_ai_ro;

-- ── Schema/function/views owned by a NON-superuser (spec requirement) ────────
-- Owner = the app role `sonicscope` if it exists, else the fw_events table
-- owner (fallback for clusters without that role, e.g. CI). Because the base
-- tables may be owned by a superuser (postgres), a non-superuser owner is
-- explicitly granted SELECT on every relation the views read.
DO $$
DECLARE
    v_owner text;
    v_name  text;
    v_rel   text;
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sonicscope') THEN
        v_owner := 'sonicscope';
    ELSE
        SELECT tableowner INTO v_owner FROM pg_tables
         WHERE schemaname = 'public' AND tablename = 'fw_events';
    END IF;
    IF v_owner IS NULL THEN
        RAISE WARNING 'ai views: no owner found (role sonicscope missing and fw_events absent); ownership not changed. Role sonicscope should exist.';
        RETURN;
    END IF;
    IF (SELECT rolsuper FROM pg_roles WHERE rolname = v_owner) THEN
        RAISE WARNING 'ai views will be owned by superuser %; role sonicscope should exist so they are not superuser-owned', v_owner;
    END IF;
    IF NOT (SELECT rolsuper FROM pg_roles WHERE rolname = v_owner) THEN
        FOREACH v_rel IN ARRAY ARRAY['fw_events', 'hourly_bandwidth_timeline',
                'hourly_threat_stats', 'daily_threat_stats', 'daily_app_stats',
                'daily_web_stats', 'daily_domain_stats', 'daily_geo_stats',
                'daily_rule_stats'] LOOP
            EXECUTE format('GRANT SELECT ON public.%I TO %I', v_rel, v_owner);
        END LOOP;
    END IF;
    EXECUTE format('ALTER SCHEMA ai OWNER TO %I', v_owner);
    EXECUTE format('ALTER FUNCTION ai.current_tenant() OWNER TO %I', v_owner);
    FOR v_name IN SELECT viewname FROM pg_views WHERE schemaname = 'ai' LOOP
        EXECUTE format('ALTER VIEW ai.%I OWNER TO %I', v_name, v_owner);
    END LOOP;
END $$;
