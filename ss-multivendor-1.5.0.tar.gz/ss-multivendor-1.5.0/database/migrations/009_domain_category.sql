-- Migration 009: UT1-derived domain categories.
--
-- domain_category is the live lookup table used by the collector's
-- categoriser; domain_category_stage is the permanent twin the daily refresh
-- job loads and then swaps (table + primary-key index renames in one
-- transaction, so readers never see a half-loaded list). category_list_state
-- is a single status row (what the admin/log view shows). All of it is
-- re-downloadable and excluded from backup.sh data.
-- See docs/superpowers/specs/2026-11-09-web-categories-b2-b3-design.md.
--
-- Run once on existing installs (update.sh's numbered loop does this):
--   sudo -u postgres psql sonicscope -f database/migrations/009_domain_category.sql

CREATE TABLE IF NOT EXISTS domain_category (
    domain      text        PRIMARY KEY,
    category    text        NOT NULL,
    list        text        NOT NULL,
    updated_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS domain_category_stage (LIKE domain_category INCLUDING ALL);

CREATE TABLE IF NOT EXISTS category_list_state (
    id               integer     PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    list_version     text,
    domains          bigint      NOT NULL DEFAULT 0,
    refreshed_at     timestamptz,
    last_attempt_at  timestamptz,
    last_error       text
);

INSERT INTO category_list_state (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- The refresh job runs as the application role and swaps the two tables by
-- renaming them, which needs ownership (migrations run as postgres, so the
-- tables would otherwise belong to postgres). Idempotent; skipped when the
-- role does not exist (e.g. ephemeral test databases).
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sonicscope') THEN
        ALTER TABLE domain_category       OWNER TO sonicscope;
        ALTER TABLE domain_category_stage OWNER TO sonicscope;
        ALTER TABLE category_list_state   OWNER TO sonicscope;
    END IF;
END $$;
