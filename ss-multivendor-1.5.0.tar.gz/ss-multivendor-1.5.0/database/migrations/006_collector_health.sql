-- Migration 006: collector_health heartbeat table (P1 launch-readiness: /healthz).
--
-- Single-row table (one collector per install). The collector's db_writer
-- UPSERTs into it every HEALTH_HEARTBEAT_SEC (default 15s); the reports
-- app's GET /healthz reads it to report collector liveness plus the
-- dropped/poison/error counters (added in the P0-2 silent-loss fix) that
-- were previously invisible in production. See
-- docs/superpowers/specs/2026-07-14-healthz-metrics-design.md.
--
-- Run once on existing installs:
--   cp database/migrations/006_collector_health.sql /tmp/ && \
--   sudo -u postgres psql sonicscope -f /tmp/006_collector_health.sql

CREATE TABLE IF NOT EXISTS collector_health (
    id               integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    last_seen        timestamptz NOT NULL,   -- when the heartbeat was last written
    last_insert_at   timestamptz,            -- when the writer last inserted rows (ingest liveness)
    events_inserted  bigint NOT NULL DEFAULT 0,
    events_dropped   bigint NOT NULL DEFAULT 0,
    events_poison    bigint NOT NULL DEFAULT 0,
    events_errors    bigint NOT NULL DEFAULT 0,
    queue_depth      integer NOT NULL DEFAULT 0,
    queue_max        integer NOT NULL DEFAULT 0
);
