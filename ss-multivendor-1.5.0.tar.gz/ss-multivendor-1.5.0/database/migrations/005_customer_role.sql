-- Migration 005: Allow 'customer' as a legal ui_users.role value.
--
-- app.py has referenced a 'customer' role (MSP self-service portal accounts)
-- since Phase 5 (commit d6f4730, "MSP customer self-service portal"): the
-- admin-users create/edit screens let an admin pick role=customer, and
-- is_customer()/customer_tenant_id()/the portal-confinement check in
-- _enforce_login() all key off ui_users.role == 'customer'. But migration
-- 002_auth.sql's CHECK constraint only ever allowed ('admin', 'user') — so
-- every attempt to create a customer account has always failed at the DB
-- with a CheckViolation, in production as well as in this repo's schema.
-- This widens the constraint to match the role model the app already
-- implements. Discovered while building tenant-isolation tests for the
-- customer portal's cross-tenant IDOR fix (Task 1, P0 launch remediation).
--
-- Run once on existing installs:
--   cp database/migrations/005_customer_role.sql /tmp/ && \
--   sudo -u postgres psql sonicscope -f /tmp/005_customer_role.sql

ALTER TABLE ui_users DROP CONSTRAINT IF EXISTS ui_users_role_check;
ALTER TABLE ui_users ADD CONSTRAINT ui_users_role_check
    CHECK (role IN ('admin', 'user', 'customer'));
