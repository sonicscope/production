-- Migration 000: schema_migrations ledger
-- Records which SQL files have been applied so install.sh / update.sh can
-- skip already-applied migrations and never re-run (or half-run) a schema.
-- Applied FIRST, before any other schema file. Must be idempotent.
--
-- Run once on existing installs (harmless if already present):
--   cp database/migrations/000_schema_migrations.sql /tmp/ && \
--   sudo -u postgres psql sonicscope -f /tmp/000_schema_migrations.sql

CREATE TABLE IF NOT EXISTS schema_migrations (
    filename    text PRIMARY KEY,
    applied_at  timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON schema_migrations TO sonicscope;
