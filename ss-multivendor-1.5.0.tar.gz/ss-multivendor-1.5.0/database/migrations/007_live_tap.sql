-- Migration 007: live-tap tables (Live Flow Monitor).
--
-- Transient, UNLOGGED (no WAL; truncated after a Postgres crash — that is
-- fine, they are a live view only and refill in seconds). The collector's
-- TapFlusher writes them ONLY while the Reports "Live Monitor" page is being
-- polled (live_tap_watch.last_poll within 30 s). See
-- docs/superpowers/specs/2026-11-09-live-flow-monitor-design.md.
--
-- Run once on existing installs (update.sh's numbered-migration loop does this):
--   sudo -u postgres psql sonicscope -f database/migrations/007_live_tap.sql

CREATE UNLOGGED TABLE IF NOT EXISTS live_tap_feed (
    source_ip   inet        NOT NULL,
    feed        text        NOT NULL,                 -- 'ipfix' | 'syslog' | later 'zenarmor'
    received    bigint      NOT NULL DEFAULT 0,       -- cumulative since collector start
    ok          bigint      NOT NULL DEFAULT 0,
    skipped     bigint      NOT NULL DEFAULT 0,
    rejected    jsonb       NOT NULL DEFAULT '{}'::jsonb,  -- {reason: count}
    last_seen   timestamptz,
    updated_at  timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (source_ip, feed)
);

CREATE UNLOGGED TABLE IF NOT EXISTS live_tap_sample (
    id          bigserial   PRIMARY KEY,
    source_ip   inet        NOT NULL,
    feed        text        NOT NULL,
    ts          timestamptz NOT NULL,
    outcome     text        NOT NULL,                 -- 'ok' | 'skipped' | 'rejected'
    reason      text        NOT NULL DEFAULT '',
    text        text        NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS live_tap_sample_src_idx
    ON live_tap_sample (source_ip, feed, ts DESC);

CREATE UNLOGGED TABLE IF NOT EXISTS live_tap_watch (
    id          integer     PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    last_poll   timestamptz NOT NULL
);
