-- Migration 008: persisted NetFlow/IPFIX templates.
--
-- The collector keeps learned templates in memory; after a restart every
-- exporter's flows were dropped (live-tap reason "no_template") until the
-- exporter re-sent its template. The collector now upserts templates here
-- (when new, changed, or hourly) and preloads rows <= 7 days old at start.
-- Tiny table (exporters x templates). See
-- docs/superpowers/specs/2026-11-09-opnsense-b1-firewall-truth-design.md.
--
-- Run once on existing installs (update.sh's numbered loop does this):
--   sudo -u postgres psql sonicscope -f database/migrations/008_ipfix_templates.sql

CREATE TABLE IF NOT EXISTS ipfix_templates (
    source_ip    inet        NOT NULL,
    domain_id    bigint      NOT NULL,
    template_id  integer     NOT NULL,
    fields       jsonb       NOT NULL,        -- [[field_id, length, enterprise_id|null], ...]
    updated_at   timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (source_ip, domain_id, template_id)
);
