#!/usr/bin/env bash
# AI Investigate bootstrap — idempotent. Called by install-reports.sh and update.sh
# AFTER migration 010 has created the (password-less) ss_ai_ro role.
#   1. create the data-key file (mode 0600, owned by the reports user) if absent
#      — NEVER overwritten
#   2. add AI_DB_PASSWORD to collector.env if absent/empty — NEVER regenerated
#   3. (re)apply the ss_ai_ro role password from it (heals a reset role)
# The password is never printed and never placed on a command line.
set -euo pipefail

CONFIG_FILE="${CONFIG_FILE:-/etc/ss-multivendor/collector.env}"
KEY_FILE="${AI_KEY_FILE:-/etc/ss-multivendor/ai.key}"
PG_DB="${PG_DB:-sonicscope}"
REPORTS_USER="${REPORTS_USER:-$(systemctl show -p User --value ss-reports 2>/dev/null || true)}"
[ -n "$REPORTS_USER" ] || REPORTS_USER=root

info() { echo "[ai-bootstrap] $*"; }
warn() { echo "[ai-bootstrap] WARNING: $*" >&2; }
die()  { echo "[ai-bootstrap] ERROR: $*" >&2; exit 1; }

[ -f "$CONFIG_FILE" ] || die "$CONFIG_FILE not found — run the installer first (this script never creates it)"
id "$REPORTS_USER" >/dev/null 2>&1 || die "reports user '$REPORTS_USER' does not exist"

# Parent directory must be traversable by the reports user (not changed here).
if [ "$REPORTS_USER" != "root" ]; then
    kdir="$(dirname "$KEY_FILE")"
    dmode="$(stat -c %a "$kdir")"; downer="$(stat -c %U "$kdir")"; dgroup="$(stat -c %G "$kdir")"
    ok_dir=0
    if [ "$downer" = "$REPORTS_USER" ] && (( (8#$dmode & 8#100) != 0 )); then ok_dir=1
    elif (( (8#$dmode & 8#001) != 0 )); then ok_dir=1
    elif (( (8#$dmode & 8#010) != 0 )) && id -nG "$REPORTS_USER" | tr ' ' '\n' | grep -qx "$dgroup"; then ok_dir=1
    fi
    [ "$ok_dir" = "1" ] || warn "$kdir (mode $dmode, $downer:$dgroup) is not traversable by $REPORTS_USER — ss-reports will not be able to read $KEY_FILE; fix the directory permissions (not changed by this script)"
fi

# 1 — data key
[ ! -L "$KEY_FILE" ] || die "$KEY_FILE is a symlink — refusing to write through it; remove it and re-run"
[ ! -d "$KEY_FILE" ] || die "$KEY_FILE is a directory — remove it and re-run"
if [ -e "$KEY_FILE" ]; then
    [ -s "$KEY_FILE" ] || die "key file $KEY_FILE exists but is empty — delete it and re-run"
else
    # Generate into a private temp file in the same directory, validate, then
    # move into place without overwriting (no empty/partial key is ever left).
    ktmp="$(umask 077; mktemp "$(dirname "$KEY_FILE")/.ai.key.XXXXXX")" || die "cannot create temp key file next to $KEY_FILE"
    trap 'rm -f "$ktmp"' EXIT
    if ! python3 -c 'import base64, os; print(base64.urlsafe_b64encode(os.urandom(32)).decode())' > "$ktmp"; then
        die "key generation failed (python3) — no key file created"
    fi
    [ "$(tr -d '\n' < "$ktmp" | wc -c)" = "44" ] || die "generated key has unexpected length — no key file created"
    chmod 600 "$ktmp"
    mv -n "$ktmp" "$KEY_FILE" || true
    if [ -e "$ktmp" ]; then rm -f "$ktmp"; fi     # lost a race: keep the existing key
    info "created $KEY_FILE (back this file up separately — it is NOT in config backups)"
fi
chmod 600 "$KEY_FILE"
if ! chown "$REPORTS_USER" "$KEY_FILE" 2>/dev/null; then
    [ "$(stat -c %U "$KEY_FILE")" = "$REPORTS_USER" ] \
        || die "cannot make $KEY_FILE owned by $REPORTS_USER (run as root)"
fi

# 2 — role password in collector.env (python: password never on argv/stdout).
# A present-but-empty "AI_DB_PASSWORD=" line counts as missing and is replaced.
CONFIG_FILE="$CONFIG_FILE" python3 - <<'PY'
import os, secrets
path = os.environ["CONFIG_FILE"]
with open(path) as fh:
    lines = fh.read().splitlines(keepends=True)
key = "AI_DB_PASSWORD="
have = [ln for ln in lines if ln.startswith(key) and ln[len(key):].strip()]
if not have:
    pw = key + secrets.token_hex(32) + "\n"
    out, placed = [], False
    for ln in lines:
        if ln.startswith(key):          # empty line(s): replace first, drop rest
            if not placed:
                out.append(pw); placed = True
            continue
        out.append(ln)
    if not placed:
        if out and not out[-1].endswith("\n"):
            out[-1] += "\n"
        out.append(pw)
    with open(path, "r+") as fh:        # in place: keeps inode, owner, mode
        fh.writelines(out)
        fh.truncate()
    print("[ai-bootstrap] generated AI_DB_PASSWORD")
PY
PW="$(grep '^AI_DB_PASSWORD=' "$CONFIG_FILE" | head -n1 | cut -d= -f2-)"
[[ "$PW" =~ ^[A-Za-z0-9]{32,128}$ ]] \
    || die "AI_DB_PASSWORD in $CONFIG_FILE has an unexpected format — delete the line and re-run to regenerate"

# 3 — apply to the role every run (password goes via stdin, never argv)
if [ "${SKIP_DB:-0}" != "1" ]; then
    if ! err="$(printf "ALTER ROLE ss_ai_ro PASSWORD '%s';\n" "$PW" \
            | sudo -u postgres psql -v ON_ERROR_STOP=1 -q -d "$PG_DB" 2>&1 >/dev/null)"; then
        err="${err//$PW/***}"
        echo "$err" >&2
        die "could not set the ss_ai_ro password (role missing?) — run the database migrations first (migration 010 creates ss_ai_ro), then re-run"
    fi
    info "ss_ai_ro password set"
fi
