# SonicScope V2 — Operations Handover

**Version:** 1.3 | **Date:** May 2026  
**Platform:** ss-multivendor on Ubuntu 24.04 (sonicscopedev — 192.168.8.16)

This document covers day-to-day operations, adding customers, managing users, and handling common situations. For architecture detail see `DESIGN.md`. For deployment see `docs/install-guide.html`.

---

## Services Quick Reference

| Service | Purpose | Port |
|---|---|---|
| `ss-collector` | IPFIX + syslog receiver, enrichment, DB writer | UDP 2055, 514, TCP 514, 6514 |
| `ss-reports` | Flask management UI + PDF scheduler | 8080 |
| `grafana-server` | Live dashboards | 3000 |
| `postgresql` | TimescaleDB — all flow data | 5432 (local only) |

```bash
# Status of all services
sudo systemctl status ss-collector ss-reports grafana-server postgresql

# Live collector log (watch flows coming in)
sudo journalctl -u ss-collector -f

# Reports UI log
sudo journalctl -u ss-reports -f

# Restart all SonicScope services
sudo systemctl restart ss-collector ss-reports
```

---

## Daily Checks

```bash
# Confirm data is flowing
sudo -u postgres psql sonicscope \
  -c "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '1 hour';"

# Check licence expiry
sudo journalctl -u ss-collector --since today | grep -i "licence\|expired\|warning"

# Check for DB write errors
sudo journalctl -u ss-collector --since today | grep -i "error\|failed\|dropped"

# Disk usage (TimescaleDB compresses chunks > 7 days automatically)
df -h /
sudo -u postgres psql sonicscope -c "\l+"
```

---

## Adding a New Tenant (Customer Site)

**1. Create the tenant in the Reports UI**

Open `http://192.168.8.16:8080` → log in with email OTP → **Tenants** → **+ New Tenant**

Fill in:
- Company Name, Slug (URL-safe), MSP Profile, Timezone, Contact

**2. Register their firewall(s)**

On the tenant edit page → **Registered Firewalls** panel → **Register Firewall**

- Enter the firewall's name, vendor, and the **source IP** it sends IPFIX/syslog from
- This is the IP that appears as the source of UDP packets on port 2055
- Saving automatically updates `IPFIX_ALLOWED_SOURCES` and `SYSLOG_ALLOWED_SOURCES` in `collector.env` and restarts the collector — no manual steps needed
- The TenantResolver also refreshes within 5 minutes

**3. Grafana tenant dropdown**

The dropdown updates automatically when you save a tenant. No manual action needed. If the dropdown ever looks stale, you can force a refresh:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

**4. Configure the firewall**

Point the customer's firewall IPFIX to this server's IP on UDP 2055:
- SonicWall: `Log → NetFlow` → set collector IP
- Syslog (optional, for denied traffic + user identity): UDP/TCP 514 or TLS 6514

**5. Add optional fallback subnets**

If the firewall IP cannot be registered (e.g. shared NAT), go to the tenant edit page → **IP Subnets** → add the customer's internal IP range as `192.168.x.0/24`.

---

## First Login (Fresh Install)

After running `install-reports.sh`, the default admin credentials are printed to the console:

- **Email:** `admin@sonicscope.local`
- **Password:** same as the Grafana admin password (stored in `/etc/ss-multivendor/grafana-admin-password`)

Log in at `http://<server-ip>:8080`, then click the 🔑 icon in the top-right navbar to change the password immediately.

---

## Adding a New UI User

Open the Reports UI → **👥 Users** (admin only) → **+ New User**

- Enter full name, email, and an initial password (min 8 characters)
- Select role: **Admin** (full access) or **User** (restricted to assigned tenants)
- For **User** role: tick which tenants they can access
- Save — they can log in immediately at `/login` with their email and the password you set

**Users log in with email + password.** To reset a forgotten password, use the "Forgot password?" link on the login page — a 6-digit reset code is emailed. SMTP must be configured for this to work.

**Admin can reset any user's password:** Users → Edit → Reset Password panel.

**Deactivate a user:** Users → Edit → Deactivate (they can no longer log in)

---

## Generating a PDF Report On-Demand

`http://192.168.8.16:8080` → **⚡ Generate Now**

1. Select tenant
2. Select report kind:
   - **Periodic** — full network activity overview (bandwidth, top users, top sites, threats, rules, VPN, geo, productivity)
   - **IT & Network Security** — security-focused (threats, blocked traffic, firewall rules, top ports, geographic destinations)
   - **HR Investigation** — per-user activity deep-dive (confidential, with optional clean mode to redact sensitive domains)
3. Set date range
4. Click Generate — PDF appears in the dashboard marked **Ready** when complete
5. Download or email directly from the dashboard

**Note:** There is a 30-second cooldown between generations to protect server resources.

---

## Setting Up Automatic Report Delivery

`http://192.168.8.16:8080` → **🗓 Schedules** → **+ New Schedule**

The schedule form uses friendly dropdowns — no cron knowledge needed:

| Field | Options |
|---|---|
| Frequency | Daily / Weekly / Monthly |
| Delivery Time | 00:00 – 23:00 |
| Day of Week | Mon–Sun (shown for Weekly only) |
| Day of Month | 1st–28th (shown for Monthly only) |
| Report Type | Daily / Weekly / Monthly (for date range label in PDF) |
| Recipients | Customer contact email(s), comma separated |

**Editing a schedule:** click **Edit** on any row in the schedule list — same form, pre-populated.

**Pausing a schedule:** click **Pause** — it stays saved but won't fire until reactivated.

The scheduler runs as part of `ss-reports`. Reports are generated and emailed automatically. On-demand reports show **Ready** in the dashboard; scheduled reports show **Sent** on successful email delivery or **Failed** if SMTP errors.

---

## Renewing a Customer Licence

Open `http://192.168.8.16:8888` (Licence Manager) → log in → **Customers** → select customer → **+ New Licence**

Enter the new expiry date, confirm MAC and sensor count, check **Send licence email**. The customer receives a new `.env` block by email. They update `collector.env` and restart:

```bash
sudo systemctl restart ss-collector
```

---

## Adding GeoIP Databases

Required for country/city enrichment in dashboards and reports.

```bash
sudo bash scripts/download-geoip.sh <MaxMind_Licence_Key>
sudo systemctl restart ss-collector
```

Get a free MaxMind key at maxmind.com → Account → Manage Licence Keys.

---

## Upgrading Grafana Dashboards

After any dashboard JSON changes in the repo:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

This is idempotent — safe to run at any time. Also run after adding/renaming tenants.

---

## FortiGate Parser (Pending)

When sample syslog arrives from the design partner, add the parser as follows:

1. Create `collector/parsers/fortinet_parser.py`
2. Implement `normalize_syslog(raw, source_ip, tenant_id, sensor_id) → Optional[NormalizedEvent]`
3. In `main.py`, update `on_syslog_message()` to detect and call the FortiGate parser
4. Deploy: `sudo rsync -a collector/ /opt/ss-multivendor/ --exclude __pycache__`
5. `sudo systemctl restart ss-collector`

The database, aggregates, enrichment pipeline, Grafana dashboards, and report engine require **zero changes** — the unified schema absorbs the new vendor automatically.

**What to request from the design partner** — see `docs/` or ask the development team.

---

## Updating an Existing Installation (Preserves Data)

Use this for all routine version updates on live customer systems. The database, all collected flow data, `collector.env`, GeoIP databases, and generated PDF reports are untouched.

```bash
# On the customer server — copy the new tarball across first, then:
tar -xzf ss-multivendor-<version>.tar.gz
cd ss-multivendor-<version>
sudo bash scripts/update.sh
```

The script will:
1. Show the current → new version and ask for confirmation
2. Stop `ss-collector` and `ss-reports`
3. Rsync the new collector and reports code into `/opt/ss-multivendor/` (skipping `venv/` and `geoip/`)
4. Install any new Python packages from both `collector/requirements.txt` and `reports/requirements.txt`
5. Re-apply all DB migrations (all are idempotent — safe to run on an existing database)
6. Start both services and confirm they are running

If anything fails mid-update a `trap` ensures services are always restarted before the script exits.

**After the update:**
- Log in to the Reports UI and confirm the version in the footer
- Check `sudo journalctl -u ss-reports --since "2 minutes ago" | grep "Loaded"` to confirm schedules reloaded
- If Grafana dashboards need refreshing: `sudo bash scripts/install-grafana-dashboards.sh`

**When to use full reinstall instead:** Only if migrating to a new server, recovering from a corrupt install, or if the release notes explicitly say a clean install is required.

---

## Fresh Install / Redeploy

```bash
# Wipe everything (interactive confirmation required)
sudo bash scripts/uninstall.sh

# Reinstall in order
sudo bash scripts/install.sh
sudo bash scripts/download-geoip.sh <MaxMind_key>

# Edit collector.env — paste the licence block from the customer's .env file
sudo nano /etc/ss-multivendor/collector.env

sudo systemctl start ss-collector
sudo journalctl -u ss-collector -f   # confirm: Licence valid, no warnings

sudo bash scripts/install-grafana-dashboards.sh
sudo bash scripts/install-reports.sh
# ↑ prints default admin credentials at the end — save them
```

After reinstall: log in to Reports UI at `:8080` as `admin@sonicscope.local`, change the password, add MSP profile, add tenants, register firewalls (allowlist updates automatically), configure SMTP in `/etc/ss-multivendor/collector.env`, set up report schedules.

**Confirm data is flowing (no INFO logs for individual inserts — check DB directly):**
```bash
sudo -u postgres psql -d sonicscope -c \
  "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';"
```
A non-zero count confirms the collector is writing. The journal will also show a heartbeat every 10,000 events: `DB writer: N events inserted total`.

---

## Key File Locations

| Path | Contents |
|---|---|
| `/etc/ss-multivendor/collector.env` | All config — DB credentials, SMTP, licence, feature toggles. Mode 660 (root:ss-collector) — writable by the Flask app |
| `/opt/ss-multivendor/` | Installed application (collector + reports) |
| `/opt/ss-multivendor/geoip/` | MaxMind .mmdb files |
| `/var/lib/ss-multivendor/reports/` | Generated PDF archive |
| `/var/lib/ss-multivendor/logos/` | Uploaded MSP logos |
| `/var/log/ss-multivendor/` | Collector and report logs |
| `/var/log/sonicscope/licence.log` | Licence validation events |
| `/etc/grafana/provisioning/` | Grafana datasource + dashboard config |
| `/var/lib/grafana/dashboards/sonicscope/` | Deployed dashboard JSON files (mode 775, writable by ss-collector group) |
| `/etc/ss-multivendor/grafana-admin-password` | Grafana + Reports UI default admin password (generated at install) |
| `/etc/sudoers.d/ss-collector` | Allows ss-reports to restart ss-collector without password (allowlist updates) |

---

## Troubleshooting

### Collector not receiving flows
```bash
# Check the service is running
sudo systemctl status ss-collector

# Check IPFIX port is listening
ss -ulnp | grep 2055

# Confirm firewall is sending to the right IP
sudo tcpdump -i any udp port 2055 -c 10
```

### "Licence invalid" on startup
```bash
# Check the licence log for the specific error
cat /var/log/sonicscope/licence.log | tail -20

# Common causes:
# - Missing SONICSCOPE_LICENSE/CUSTOMER_ID/EXPIRY in collector.env
# - Server MAC changed (VM migration) — requires new key from licence manager
# - Licence expired — renew via http://192.168.8.16:8888
```

### Reports UI showing no data
```bash
# Check ss-reports is running
sudo systemctl status ss-reports

# Check the DB connection
sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events;"

# Check the tenant_id is correct in the UI dropdown
```

### Grafana tenant dropdown empty / shows wrong names
```bash
# Re-run the dashboard installer — it reads tenants from the DB live
sudo bash scripts/install-grafana-dashboards.sh
```

### Email not sending
```bash
# Verify SMTP settings in collector.env
sudo grep "^SMTP_" /etc/ss-multivendor/collector.env | grep -v PASSWORD

# Test SMTP manually
python3 -c "
import smtplib, ssl
with smtplib.SMTP_SSL('smtp.sonicscope.co.za', 465) as s:
    s.login('mailer@sonicscope.co.za', 'PASSWORD')
    print('SMTP OK')
"
```

### TenantResolver showing 0 firewalls after registering one
The resolver refreshes every 5 minutes automatically. Check it loaded:
```bash
sudo journalctl -u ss-collector --since "10 minutes ago" | grep TenantResolver
```
If it hasn't refreshed, restart the collector.

### Collector appears running but no flows visible in journal
IPFIX inserts log at DEBUG level — they are invisible in `journalctl` at INFO. The collector IS working if the DB has rows:
```bash
sudo -u postgres psql -d sonicscope -c \
  "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';"
```
A non-zero count means data is flowing. The journal will also show `DB writer: N events inserted total` every 10,000 events.

### Flows arriving (tcpdump shows packets) but collector silently drops them
`IPFIX_ALLOWED_SOURCES` is filtering them. Verify the registered sensor IPs match what the firewall actually sends from:
```bash
sudo tcpdump -i any udp port 2055 -c 5   # check source IP in output
sudo grep IPFIX_ALLOWED_SOURCES /etc/ss-multivendor/collector.env
```
Registering a firewall via the Reports UI automatically updates the allowlist and restarts the collector. If you edited collector.env manually, restart the collector to apply.

### "password authentication failed for user sonicscope" on collector start
The password in `collector.env` doesn't match what PostgreSQL has — usually caused by saving an old collector.env over a fresh install. Fix:
```bash
DB_PASS=$(sudo grep '^DB_PASSWORD=' /etc/ss-multivendor/collector.env | cut -d'=' -f2-)
sudo -u postgres psql -c "ALTER USER sonicscope WITH PASSWORD '$DB_PASS';"
sudo systemctl restart ss-collector
```

### Grafana tenant dropdown shows wrong or missing tenants
The dropdown is updated automatically when tenants are saved in the Reports UI. If it's stale, force a refresh:
```bash
sudo bash scripts/install-grafana-dashboards.sh
```

---

## Contacts

| Role | Contact |
|---|---|
| Platform owner | wynand@vannispen.co.za |
| SonicScope sales | sales@sonicscope.co.za |
| Licence issues | sales@sonicscope.co.za |
| Website | sonicscope.co.za |
