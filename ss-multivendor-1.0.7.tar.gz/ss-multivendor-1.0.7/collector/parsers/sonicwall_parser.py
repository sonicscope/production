"""
SonicWall Parser — normalizes both IPFIX flows and Enhanced Syslog events
into NormalizedEvent objects for the unified fw_events table.
"""

from __future__ import annotations
import re
import logging
from datetime import datetime, timezone
from typing import Optional

from event import NormalizedEvent

logger = logging.getLogger('ss.parser.sonicwall')

# ─────────────────────────────────────────────────────────────────────────────
# SonicWall Enhanced Syslog — key=value parser
# (same logic as ss-syslog/fw_parser.py, kept here to avoid cross-repo import)
# ─────────────────────────────────────────────────────────────────────────────

_KV_RE = re.compile(r'(\w+)=(?:"((?:[^"\\]|\\.)*)"|(\S+))')


def _parse_kv(text: str) -> dict:
    result = {}
    for m in _KV_RE.finditer(text):
        result[m.group(1)] = m.group(2) if m.group(2) is not None else m.group(3)
    return result


def _parse_endpoint(value: str) -> dict:
    """Parse SonicWall src/dst field: IP:PORT:IFACE[:NAME]"""
    if not value:
        return {}
    parts = value.split(':')
    out = {}
    if len(parts) >= 1 and parts[0]:
        out['ip'] = parts[0]
    if len(parts) >= 2 and parts[1]:
        try:
            out['port'] = int(parts[1])
        except ValueError:
            pass
    if len(parts) >= 3 and parts[2]:
        out['iface'] = parts[2]
    if len(parts) >= 4 and parts[3]:
        out['name'] = parts[3]
    return out


def _safe_int(val, default=0) -> int:
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


# Message-ID → event_type mapping (from ss-syslog fw_parser.py)
_MSG_ID_TYPES = {
    98: 'traffic', 537: 'traffic', 41: 'traffic',
    26: 'denied',  36: 'denied',  37: 'denied',  38: 'denied',
    39: 'denied',  538: 'denied', 882: 'denied', 884: 'denied',
    22: 'threat',  23: 'threat',  27: 'threat',  28: 'threat',
    82: 'threat',  83: 'threat',  175: 'threat', 260: 'threat',
    261: 'threat', 501: 'threat', 502: 'threat', 503: 'threat',
    505: 'threat', 608: 'threat', 1154: 'threat', 1369: 'threat',
    401: 'vpn',    402: 'vpn',    403: 'vpn',    404: 'vpn',
    406: 'vpn',    411: 'vpn',    413: 'vpn',    428: 'vpn',
    440: 'vpn',    441: 'vpn',    546: 'vpn',    547: 'vpn',
    24: 'auth',    25: 'auth',    31: 'auth',    32: 'auth',
    33: 'auth',    34: 'auth',
    29: 'admin',   30: 'admin',   506: 'admin',  520: 'admin',
    521: 'admin',  522: 'admin',  548: 'admin',  860: 'admin',
    14: 'web',     16: 'web',     97: 'web',
    461: 'system', 598: 'system',
}

_FW_ACTION_MAP = {
    'forward': 'allow',
    'allow':   'allow',
    'drop':    'deny',
    'deny':    'deny',
    'blocked': 'deny',
    'block':   'deny',
    'reject':  'reset',
    'tunnel':  'tunnel',
}

_THREAT_SEVERITY_MAP = {
    0: 'critical', 1: 'critical',
    2: 'high',     3: 'high',
    4: 'medium',   5: 'medium',
    6: 'low',      7: 'low',
}

# SonicWall IPFIX app category IDs → names
_APP_CATEGORY_MAP = {
    0: 'Unknown',        1: 'Business',       2: 'Communication',
    3: 'Email',          4: 'File Transfer',  5: 'Games',
    6: 'General Internet', 7: 'Malicious',    8: 'Media',
    9: 'Network Management', 10: 'P2P',       11: 'Productivity',
    12: 'Proxy',         13: 'Remote Access', 14: 'Security',
    15: 'Social Networking', 16: 'Storage/Backup', 17: 'Streaming',
    18: 'Update',        19: 'VoIP',          20: 'Web',
}

_PROTOCOL_NAMES = {
    1: 'icmp', 6: 'tcp', 17: 'udp', 47: 'gre',
    50: 'esp', 51: 'ah', 58: 'icmpv6', 89: 'ospf',
}


def _is_binary_hex(val) -> bool:
    """Return True if val is a binary fallback hex dump (e.g. SonicWall zone/app object IDs)."""
    if not val or not isinstance(val, str):
        return False
    return bool(re.match(r'^[0-9a-f]{6,16}$', val.lower()))


def _classify_event(kv: dict, msg_id: Optional[int]) -> str:
    if msg_id and msg_id in _MSG_ID_TYPES:
        return _MSG_ID_TYPES[msg_id]
    action = kv.get('fw_action', '').lower()
    if action in ('drop', 'deny', 'blocked', 'block'):
        return 'denied'
    if kv.get('sid') or kv.get('ipscat'):
        return 'threat'
    if kv.get('id', '').lower() == 'sslvpn' or 'vpn' in kv.get('msg', '').lower():
        return 'vpn'
    if kv.get('Category') or kv.get('dstname'):
        return 'web'
    msg = kv.get('msg', '').lower()
    if any(w in msg for w in ('drop', 'denied', 'blocked', 'reject')):
        return 'denied'
    if any(w in msg for w in ('attack', 'scan', 'flood', 'intrusion')):
        return 'threat'
    if any(w in msg for w in ('login', 'logout', 'auth')):
        return 'auth'
    if any(w in msg for w in ('admin', 'config', 'rule added', 'rule deleted')):
        return 'admin'
    if kv.get('sent') or kv.get('rcvd') or kv.get('proto'):
        return 'traffic'
    return 'system'


# ─────────────────────────────────────────────────────────────────────────────
# Public API — Syslog
# ─────────────────────────────────────────────────────────────────────────────

def is_sonicwall_syslog(raw: str) -> bool:
    return bool(re.search(r'\bid=(?:firewall|sslvpn)\b', raw))


def normalize_syslog(raw_message: str, source_ip: str,
                     tenant_id: int, sensor_id: int) -> Optional[NormalizedEvent]:
    """
    Parse a raw SonicWall Enhanced Syslog message and return a NormalizedEvent.
    Returns None if the message is not a SonicWall Enhanced Syslog entry.
    """
    msg = raw_message if isinstance(raw_message, str) else raw_message.decode('utf-8', errors='replace')
    msg = re.sub(r'^<\d{1,3}>', '', msg).strip()

    if 'id=' not in msg:
        return None

    kv = _parse_kv(msg)
    if not kv.get('id'):
        return None

    msg_id = _safe_int(kv.get('m')) or None
    src = _parse_endpoint(kv.get('src', ''))
    dst = _parse_endpoint(kv.get('dst', ''))

    # Protocol: "tcp/https" → protocol='tcp', app hint in protocol_app
    protocol = None
    proto_app = None
    proto_raw = kv.get('proto', '')
    if '/' in proto_raw:
        parts = proto_raw.split('/', 1)
        protocol = parts[0].lower()
        proto_app = parts[1]
    elif proto_raw:
        protocol = proto_raw.lower()

    # Action
    fw_action = (kv.get('fw_action') or '').lower()
    action = _FW_ACTION_MAP.get(fw_action)
    if action is None:
        # Infer from event type
        event_type = _classify_event(kv, msg_id)
        action = 'deny' if event_type == 'denied' else 'allow'
    else:
        event_type = _classify_event(kv, msg_id)

    # Timestamp from 'time' field — SonicWall format: "2026-03-13 12:00:00"
    time = datetime.now(timezone.utc)
    time_raw = kv.get('time', '')
    if time_raw:
        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S'):
            try:
                time = datetime.strptime(time_raw, fmt).replace(tzinfo=timezone.utc)
                break
            except ValueError:
                pass

    # Threat severity from priority (pri field)
    threat_severity = None
    pri = _safe_int(kv.get('pri')) if kv.get('pri') else None
    if pri is not None:
        threat_severity = _THREAT_SEVERITY_MAP.get(pri)

    # VPN
    vpn_policy = None
    vpn_client_ip = None
    if event_type == 'vpn':
        vpn_policy = kv.get('vpnpolicyname') or kv.get('portal')

    # App name: prefer explicit app field, fall back to protocol_app hint
    app_name = None
    if kv.get('app') and kv['app'].isdigit():
        pass  # IPFIX app ID in syslog — skip, no name available
    elif proto_app and proto_app not in ('', 'unknown'):
        app_name = proto_app.upper()

    # URL / domain
    domain = kv.get('dstname') or dst.get('name')
    url = kv.get('arg')  # URL path argument field
    web_category = kv.get('Category')

    return NormalizedEvent(
        time            = time,
        tenant_id       = tenant_id,
        sensor_id       = sensor_id,
        vendor          = 'sonicwall',
        data_source     = 'syslog',
        event_type      = event_type,
        action          = action,
        src_ip          = src.get('ip'),
        dst_ip          = dst.get('ip') or kv.get('dstip'),
        src_port        = src.get('port'),
        dst_port        = dst.get('port'),
        protocol        = protocol,
        bytes_sent      = _safe_int(kv.get('sent')),
        bytes_received  = _safe_int(kv.get('rcvd')),
        packets_sent    = _safe_int(kv.get('spkt')),
        packets_received = _safe_int(kv.get('rpkt')),
        zone_src        = kv.get('srcZone'),
        zone_dst        = kv.get('dstZone'),
        interface_src   = src.get('iface'),
        interface_dst   = dst.get('iface'),
        rule_name       = kv.get('rule'),
        app_name        = app_name,
        app_category    = kv.get('appcat'),
        domain          = domain,
        url             = url,
        web_category    = web_category,
        threat_name     = kv.get('ipscat') or kv.get('sid'),
        threat_category = kv.get('ipscat'),
        threat_severity = threat_severity,
        threat_id       = _safe_int(kv.get('sid')) or None,
        vpn_policy_name = vpn_policy,
        vpn_client_ip   = vpn_client_ip,
        user_name       = kv.get('user') or kv.get('usr') or kv.get('susr'),
        message_id      = msg_id,
        message         = kv.get('msg'),
        raw_message     = raw_message[:2000] if len(raw_message) > 2000 else raw_message,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Public API — IPFIX
# ─────────────────────────────────────────────────────────────────────────────

def normalize_ipfix(flow: dict, export_time: datetime,
                    tenant_id: int, sensor_id: int) -> Optional[NormalizedEvent]:
    """
    Convert a parsed IPFIX flow dict (as produced by ipfix_input.py) into
    a NormalizedEvent.

    The flow dict uses field names from sonicwall_templates.py.
    Critical SonicWall IPFIX notes (from packet analysis, January 2026):
      - Field 5 (internal_src_ip) = pre-NAT internal client IP — USE THIS as src_ip
      - Field 6 (dst_ip) = destination IP
      - Field 11 (src_port) = source port
      - Field 12 (dst_port) = destination port
      - Field 14 (init_bytes) = bytes sent by initiator (src→dst)
      - Field 16 (resp_bytes) = bytes sent by responder (dst→src)
    """
    # ── Source IP: prefer pre-NAT internal IP ──────────────────────────────
    src_ip = flow.get('internal_src_ip') or flow.get('sourceIPv4Address')
    if src_ip == '0.0.0.0':
        src_ip = flow.get('sourceIPv4Address')

    dst_ip = flow.get('dst_ip') or flow.get('destinationIPv4Address')

    # ── Ports ──────────────────────────────────────────────────────────────
    src_port = flow.get('src_port') or flow.get('sourceTransportPort')
    dst_port = flow.get('dst_port') or flow.get('destinationTransportPort')

    # ── Protocol ───────────────────────────────────────────────────────────
    proto_num = flow.get('protocolIdentifier')
    protocol = _PROTOCOL_NAMES.get(proto_num, f'proto_{proto_num}') if proto_num else None
    # SonicWall IPFIX often omits protocolIdentifier — infer from dst_port
    if protocol is None:
        _tcp_ports = {21,22,23,25,80,110,143,443,465,587,993,995,1433,1521,3306,3389,5432,5900,8080,8443}
        _udp_ports = {53,67,68,69,123,161,162,500,514,4500,1194}
        _dst = flow.get('dst_port') or flow.get('destinationTransportPort')
        if _dst in _tcp_ports:
            proto_num, protocol = 6, 'tcp'
        elif _dst in _udp_ports:
            proto_num, protocol = 17, 'udp'

    # ── Timestamps ─────────────────────────────────────────────────────────
    time = export_time

    # Prefer millisecond precision
    start_ms = flow.get('flowStartMilliseconds') or flow.get('session_start_time')
    end_ms = flow.get('flowEndMilliseconds') or flow.get('session_end_time')

    if start_ms and start_ms > 1_000_000_000_000:  # looks like ms
        try:
            time = datetime.fromtimestamp(start_ms / 1000, tz=timezone.utc)
        except (ValueError, OSError):
            pass
    elif flow.get('flowStartSeconds'):
        try:
            time = datetime.fromtimestamp(flow['flowStartSeconds'], tz=timezone.utc)
        except (ValueError, OSError):
            pass

    duration_ms = None
    if start_ms and end_ms and end_ms >= start_ms:
        duration_ms = int(end_ms - start_ms)
    elif flow.get('flowDurationMilliseconds'):
        duration_ms = int(flow['flowDurationMilliseconds'])

    # ── Traffic metrics ────────────────────────────────────────────────────
    bytes_sent     = int(flow.get('init_bytes') or flow.get('octetDeltaCount') or 0)
    bytes_received = int(flow.get('resp_bytes') or 0)
    packets_sent   = int(flow.get('init_packets') or flow.get('packetDeltaCount') or 0)
    packets_received = int(flow.get('resp_packets') or 0)

    # Fallback: total_bytes split evenly
    if bytes_sent == 0 and bytes_received == 0:
        total = int(flow.get('total_bytes') or 0)
        if total:
            bytes_sent = total // 2
            bytes_received = total - bytes_sent

    # ── Application ────────────────────────────────────────────────────────
    app_name_raw = flow.get('app_name', '')
    # SonicWall sends 4-char ASCII codes like 'isl3', 'http', 'dns '
    # Clean these up to readable names
    _app_code_map = {
        'isl3': 'SSL/TLS', 'http': 'HTTP', 'dns ': 'DNS', 'dns': 'DNS',
        'smtp': 'SMTP', 'imap': 'IMAP', 'ssh ': 'SSH', 'ssh': 'SSH',
        'rdp ': 'RDP', 'rdp': 'RDP', 'ntp ': 'NTP', 'ntp': 'NTP',
        'quic': 'QUIC', 'h2  ': 'HTTP/2', 'ftp ': 'FTP', 'ftp': 'FTP',
    }
    app_name = None if _is_binary_hex(app_name_raw) else _app_code_map.get(app_name_raw.lower().strip(), app_name_raw.strip() or None)

    cat_id = flow.get('app_category_id')
    app_category = _APP_CATEGORY_MAP.get(cat_id) if cat_id is not None else None

    app_risk_raw = flow.get('app_risk')
    # Cap at SMALLINT max — SonicWall IPFIX field 22 is uint32 but schema column is SMALLINT
    app_risk = min(int(app_risk_raw), 32767) if app_risk_raw is not None else None

    # ── Zones ──────────────────────────────────────────────────────────────
    zone_src_raw = flow.get('zone_id_src') or flow.get('zone_src')
    zone_dst_raw = flow.get('zone_id_dst') or flow.get('zone_dst')
    zone_src = None if _is_binary_hex(zone_src_raw) else zone_src_raw
    zone_dst = None if _is_binary_hex(zone_dst_raw) else zone_dst_raw

    # ── Rule ───────────────────────────────────────────────────────────────
    rule_id = None
    rule_info = flow.get('rule_info')
    if isinstance(rule_info, int) and rule_info > 0:
        rule_id = rule_info & 0xFF  # lower byte = rule ID

    # ── URL/domain from IPFIX template 262 ─────────────────────────────────
    domain = flow.get('url_host') or None

    # ── Event type: all IPFIX flows are 'traffic' unless app category is Malicious
    event_type = 'traffic'
    if cat_id == 7:  # Malicious
        event_type = 'threat'

    return NormalizedEvent(
        time            = time,
        tenant_id       = tenant_id,
        sensor_id       = sensor_id,
        vendor          = 'sonicwall',
        data_source     = 'ipfix',
        event_type      = event_type,
        action          = 'allow',   # IPFIX only exports completed flows
        src_ip          = src_ip,
        dst_ip          = dst_ip,
        src_port        = int(src_port) if src_port else None,
        dst_port        = int(dst_port) if dst_port else None,
        protocol        = protocol,
        protocol_num    = int(proto_num) if proto_num else None,
        bytes_sent      = bytes_sent,
        bytes_received  = bytes_received,
        packets_sent    = packets_sent,
        packets_received = packets_received,
        duration_ms     = duration_ms,
        zone_src        = zone_src,
        zone_dst        = zone_dst,
        rule_id         = rule_id,
        app_name        = app_name,
        app_category    = app_category,
        app_risk        = app_risk,
        domain          = domain,
        threat_name     = 'Malicious Traffic' if event_type == 'threat' else None,
        threat_category = app_category if event_type == 'threat' else None,
        extra           = {
            'flow_id_high': flow.get('flow_id_high'),
            'flow_id_low':  flow.get('flow_id_low'),
            'user_object_id': flow.get('user_object_id'),
        } if flow.get('flow_id_high') or flow.get('user_object_id') else None,
    )
