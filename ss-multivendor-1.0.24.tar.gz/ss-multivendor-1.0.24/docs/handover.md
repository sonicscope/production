# SonicScope V2 — Operations Handover

**Version:** 1.20 | **Date:** May 2026  
**Platform:** ss-multivendor on Ubuntu 24.04 (sonicscopedev — 192.168.8.16)

This document covers day-to-day operations, adding customers, managing users, and handling common situations. For architecture detail see `DESIGN.md`. For deployment see `docs/install-guide.html`.

---

## Services Quick Reference

| Service | Purpose | Port |
|---|---|---|
| `ss-collector` | IPFIX + syslog receiver, enrichment, DB writer | UDP 2055, 514, TCP 514, 6514 |
| `ss-reports` | Flask management UI + PDF scheduler | 8080 |
| `grafana-server` | Live dashboards | 3000 |
| `postgresql` | TimescaleDB — all flow data | 5432 (local only) |

```bash
# Status of all services
sudo systemctl status ss-collector ss-reports grafana-server postgresql

# Live collector log (watch flows coming in)
sudo journalctl -u ss-collector -f

# Reports UI log
sudo journalctl -u ss-reports -f

# Restart all SonicScope services
sudo systemctl restart ss-collector ss-reports
```

---

## Daily Checks

```bash
# Confirm data is flowing
sudo -u postgres psql sonicscope \
  -c "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '1 hour';"

# Check licence expiry
sudo journalctl -u ss-collector --since today | grep -i "licence\|expired\|warning"

# Check for DB write errors
sudo journalctl -u ss-collector --since today | grep -i "error\|failed\|dropped"

# Disk usage (TimescaleDB compresses chunks > 7 days automatically)
df -h /
sudo -u postgres psql sonicscope -c "\l+"
```

---

## Adding a New Tenant (Customer Site)

**1. Create the tenant in the Reports UI**

Open `http://192.168.8.16:8080` → log in with email OTP → **Tenants** → **+ New Tenant**

Fill in:
- Company Name, Slug (URL-safe), MSP Profile, Timezone, Contact

**2. Register their firewall(s)**

On the tenant edit page → **Registered Firewalls** panel → **Register Firewall**

- Enter the firewall's name, vendor, and the **source IP** it sends IPFIX/syslog from
- This is the IP that appears as the source of UDP packets on port 2055
- Saving automatically updates `IPFIX_ALLOWED_SOURCES` and `SYSLOG_ALLOWED_SOURCES` in `collector.env` and restarts the collector — no manual steps needed
- The TenantResolver also refreshes within 5 minutes

**3. Grafana tenant dropdown**

The dropdown updates automatically when you save a tenant. No manual action needed. If the dropdown ever looks stale, you can force a refresh:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

**4. Configure the firewall**

Point the customer's firewall IPFIX to this server's IP on UDP 2055:
- SonicWall: `Log → NetFlow` → set collector IP
- Syslog (optional, for denied traffic + user identity): UDP/TCP 514 or TLS 6514

**5. Add optional fallback subnets**

If the firewall IP cannot be registered (e.g. shared NAT), go to the tenant edit page → **IP Subnets** → add the customer's internal IP range as `192.168.x.0/24`.

**6. Identity mapping (optional)**

On the tenant edit page, the **Identity mapping enabled** toggle controls whether reports resolve IPs to user names:

- **On (default):** reports use the two-tier identity system — collection-time SSO/DHCP names first, then a report-time fallback lookup against the identity database for any remaining raw IPs. Mappings added after deployment apply retroactively to future reports.
- **Off:** all user columns show raw IPs only. Use this for privacy or compliance deployments that must not attribute network activity to named individuals.

See `DESIGN.md §5.4` for the full two-tier resolution design.

---

## First Login (Fresh Install)

After running `install-reports.sh`, the default admin credentials are printed to the console:

- **Email:** `admin@sonicscope.local`
- **Password:** same as the Grafana admin password (stored in `/etc/ss-multivendor/grafana-admin-password`)

Log in at `http://<server-ip>:8080`, then click the 🔑 icon in the top-right navbar to change the password immediately.

---

## Adding a New UI User

Open the Reports UI → **👥 Users** (admin only) → **+ New User**

- Enter full name, email, and an initial password (min 8 characters)
- Select role: **Admin** (full access) or **User** (restricted to assigned tenants)
- For **User** role: tick which tenants they can access
- Save — they can log in immediately at `/login` with their email and the password you set

**Users log in with email + password.** To reset a forgotten password, use the "Forgot password?" link on the login page — a 6-digit reset code is emailed. SMTP must be configured for this to work.

**Admin can reset any user's password:** Users → Edit → Reset Password panel.

**Deactivate a user:** Users → Edit → Deactivate (they can no longer log in)

---

## Generating a PDF Report On-Demand

`http://192.168.8.16:8080` → **⚡ Generate Now**

1. Select tenant
2. Select report kind:
   - **Periodic** — full network activity overview (bandwidth, top users, top sites, threats, rules, VPN, geo, productivity)
   - **IT & Network Security** — security-focused (threats, blocked traffic, firewall rules, top ports, geographic destinations)
   - **HR Investigation** — per-user activity deep-dive (confidential, with optional clean mode to redact sensitive domains)
3. Set date range
4. Click Generate — PDF appears in the dashboard marked **Ready** when complete
5. Download or email directly from the dashboard

**Note:** There is a 30-second cooldown between generations to protect server resources.

---

## Setting Up Automatic Report Delivery

`http://192.168.8.16:8080` → **🗓 Schedules** → **+ New Schedule**

The schedule form uses friendly dropdowns — no cron knowledge needed:

| Field | Options |
|---|---|
| Frequency | Daily / Weekly / Monthly |
| Delivery Time | 00:00 – 23:00 |
| Day of Week | Mon–Sun (shown for Weekly only) |
| Day of Month | 1st–28th (shown for Monthly only) |
| Report Type | Daily / Weekly / Monthly (for date range label in PDF) |
| Recipients | Customer contact email(s), comma separated |

**Editing a schedule:** click **Edit** on any row in the schedule list — same form, pre-populated.

**Pausing a schedule:** click **Pause** — it stays saved but won't fire until reactivated.

The scheduler runs as part of `ss-reports`. Reports are generated and emailed automatically. On-demand reports show **Ready** in the dashboard; scheduled reports show **Sent** on successful email delivery or **Failed** if SMTP errors.

---

## Issuing a New Licence (After Online Payment)

When a customer completes payment on sonicscope.co.za, an email arrives at `license@sonicscope.co.za` with all the details needed. The email includes:
- Customer name, email, company, phone, country
- Tier (Solo/Micro/Small/Professional/Business/Enterprise/Unlimited)
- Number of firewalls (max sensors)
- Term (years) and calculated expiry date
- **Server MAC address** (collected during checkout — the licence will be bound to this)
- Payment reference and amount

**To issue the licence:**

1. Open `http://192.168.8.16:8888` (Licence Manager) → log in
2. **Customers** → **+ New Customer** — enter name and email from the notification email
3. On the customer page → **+ New Licence**
4. Set expiry date (from email), sensor count (from email), confirm MAC address (from email)
5. Tick **Send licence email** → Save
6. The customer receives their `licence.env` block and can deploy immediately using `deploy.sh`

---

## Renewing a Customer Licence

Open `http://192.168.8.16:8888` (Licence Manager) → log in → **Customers** → select customer → **+ New Licence**

Enter the new expiry date, confirm MAC and sensor count, check **Send licence email**. The customer receives a new `.env` block by email. They update `collector.env` and restart:

```bash
sudo systemctl restart ss-collector
```

---

## Adding GeoIP Databases

Required for country/city enrichment in dashboards and reports. Without GeoIP the world map and country columns are blank.

```bash
sudo bash scripts/download-geoip.sh <MaxMind_Licence_Key>
sudo systemctl restart ss-collector
```

Get a free MaxMind key at maxmind.com → Account → Manage Licence Keys.

**snwlrep2 status:** GeoIP installed 2026-05-07 (GeoLite2-City 63 MB + GeoLite2-ASN 12 MB). Country enrichment confirmed working.

---

## Upgrading Grafana Dashboards

After any dashboard JSON changes in the repo:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

This is idempotent — safe to run at any time. Also run after adding/renaming tenants.

---

## FortiGate Syslog (Live — v1.0.11)

FortiGate 7.x syslog is fully supported as of v1.0.11. No additional steps required once a FortiGate is registered and sending syslog.

**FortiGate syslog configuration (FortiOS CLI):**
```
config log syslogd setting
    set status enable
    set server <snwlrep2-ip>
    set port 514
    set mode udp
    set facility local7
    set format default
end
config log syslogd filter
    set severity information
    set forward-traffic enable
    set local-traffic enable
    set anomaly enable
end
```

**Note:** FortiGate VM eval licences do not support NetFlow/IPFIX (error -61). Syslog is the correct data source for FortiGate — it provides richer data anyway (app names, user identity, web categories).

**To add a FortiGate to an existing installation:**
1. Reports UI → Tenants → Edit → Register Firewall — enter the FortiGate's source IP
2. This auto-updates `SYSLOG_ALLOWED_SOURCES` in `collector.env` and restarts the collector
3. Configure syslog on the FortiGate pointing to the server IP on UDP 514
4. Verify: `sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events WHERE vendor='fortinet' AND time > NOW() - INTERVAL '5 minutes';"`

**Fields populated from FortiGate syslog:** src/dst IP and port, protocol, action, event type, interface names, zone roles (lan/wan/dmz), rule ID, app name (FortiGuard), app category, web category, threat name/severity (IPS/AV), user identity, bytes sent/received, duration.

---

## Palo Alto PAN-OS Syslog (Parser Ready — v1.0.22)

Palo Alto PAN-OS 9.x–12.x syslog is supported as of v1.0.22. The parser handles IETF/RFC 5424 format with CSV payload. Supported log types: TRAFFIC, THREAT, AUTH, GLOBALPROTECT.

**Licence requirement:** PAN-OS VM-Series with no licence (`vm-license: none`) does not forward syslog. A capacity licence or 90-day eval is required:
1. Register at `support.paloaltonetworks.com`
2. Use device UUID to request an eval serial number
3. Apply in PAN-OS: **Device → Licenses → Activate feature using authorization code**

**Lab PA-VM details:**
- IP: `192.168.8.195` | PAN-OS: `12.1.6` | UUID: `564DCBBF-B1D3-C502-6F8D-DC10D2AFF8C3`
- Status: licence pending — syslog not yet flowing

**PAN-OS syslog configuration (web UI):**
1. **Device → Server Profiles → Syslog** — create profile, Server: `<snwlrep2-ip>`, Port: `514`, Transport: `UDP`, Format: `IETF`
2. **Device → Log Settings** — for each log type (Traffic, Threat, System), add a Syslog entry pointing to the profile
3. **Policies → Security** — edit each policy rule → Actions tab → attach a Log Forwarding profile (for traffic logs)
4. **Commit**

**To add a Palo Alto to an existing installation:**
1. Reports UI → Tenants → Edit → Register Firewall — enter the PAN-OS management IP (source of syslog packets)
2. Configure syslog on the PAN-OS device as above, pointing to the server IP on UDP 514
3. Verify: `sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events WHERE vendor='paloalto' AND time > NOW() - INTERVAL '5 minutes';"`

**Fields populated from PAN-OS syslog:** src/dst IP and port, protocol, action, event type, zone names, interface names, rule name, application name, bytes sent/received, session duration, threat name/severity/category (THREAT logs), user identity, URL and web category (URL filter), VPN client IP and portal name (GlobalProtect).

**Note:** SSH access on PAN-OS requires explicit enablement — **Device → Setup → Management → Management Interface Settings** → tick SSH → Commit.

---

## Updating an Existing Installation (Preserves Data)

Use this for all routine version updates on live customer systems. The database, all collected flow data, `collector.env`, GeoIP databases, and generated PDF reports are untouched.

```bash
# On the customer server — copy the new tarball across first, then:
tar -xzf ss-multivendor-<version>.tar.gz
cd ss-multivendor-<version>
sudo bash scripts/update.sh
```

The script will:
1. Show the current → new version and ask for confirmation
2. Stop `ss-collector` and `ss-reports`
3. Rsync the new collector and reports code into `/opt/ss-multivendor/` (skipping `venv/` and `geoip/`)
4. Install any new Python packages from both `collector/requirements.txt` and `reports/requirements.txt`
5. Re-apply all DB migrations (all are idempotent — safe to run on an existing database)
6. Start both services and confirm they are running

If anything fails mid-update a `trap` ensures services are always restarted before the script exits.

**After the update:**
- Log in to the Reports UI and confirm the version in the footer
- Check `sudo journalctl -u ss-reports --since "2 minutes ago" | grep "Loaded"` to confirm schedules reloaded
- If Grafana dashboards need refreshing: `sudo bash scripts/install-grafana-dashboards.sh`

**When to use full reinstall instead:** Only if migrating to a new server, recovering from a corrupt install, or if the release notes explicitly say a clean install is required.

**Note:** `update.sh` is idempotent — safe to re-run the same version. All migrations are applied again (they are all idempotent) and services are restarted. If you check status mid-run the services will briefly be down; wait for the script to finish before concluding something went wrong.

---

## Fresh Install / Redeploy

```bash
# Wipe everything (interactive confirmation required)
sudo bash scripts/uninstall.sh

# Reinstall in order
sudo bash scripts/install.sh
sudo bash scripts/download-geoip.sh <MaxMind_key>

# Edit collector.env — paste the licence block from the customer's .env file
sudo nano /etc/ss-multivendor/collector.env

sudo systemctl start ss-collector
sudo journalctl -u ss-collector -f   # confirm: Licence valid, no warnings

sudo bash scripts/install-grafana-dashboards.sh
sudo bash scripts/install-reports.sh
# ↑ prints default admin credentials at the end — save them
```

After reinstall: log in to Reports UI at `:8080` as `admin@sonicscope.local`, change the password, add MSP profile, add tenants, register firewalls (allowlist updates automatically), configure SMTP in `/etc/ss-multivendor/collector.env`, set up report schedules.

**Confirm data is flowing (no INFO logs for individual inserts — check DB directly):**
```bash
sudo -u postgres psql -d sonicscope -c \
  "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';"
```
A non-zero count confirms the collector is writing. The journal will also show a heartbeat every 10,000 events: `DB writer: N events inserted total`.

---

## Key collector.env Settings

| Setting | Default | Notes |
|---|---|---|
| `IPFIX_TIMESTAMP_OFFSET_HOURS` | `0` | Set to `-2` for SonicWall firewalls in SAST (UTC+2). SonicWall sends IPFIX timestamps in local time despite the `universal` flag in SonicOS. Without this, all data appears 2 hours in the future. |
| `IPFIX_ALLOWED_SOURCES` | *(blank)* | Comma-separated firewall IPs. Updated automatically when firewalls registered via Reports UI. |
| `ENABLE_GEOIP` | `true` | Requires MaxMind .mmdb files — run `download-geoip.sh` first. |
| `SMTP_HOST` / `SMTP_PORT` | *(blank)* | Required for scheduled report delivery and forgot-password OTP. |

---

## Key File Locations

| Path | Contents |
|---|---|
| `/etc/ss-multivendor/collector.env` | All config — DB credentials, SMTP, licence, feature toggles. Mode 660 (root:ss-collector) — writable by the Flask app |
| `/opt/ss-multivendor/` | Installed application (collector + reports) |
| `/opt/ss-multivendor/geoip/` | MaxMind .mmdb files |
| `/var/lib/ss-multivendor/reports/` | Generated PDF archive |
| `/var/lib/ss-multivendor/logos/` | Uploaded MSP logos |
| `/var/log/ss-multivendor/` | Collector and report logs |
| `/var/log/sonicscope/licence.log` | Licence validation events |
| `/etc/grafana/provisioning/` | Grafana datasource + dashboard config |
| `/var/lib/grafana/dashboards/sonicscope/` | Deployed dashboard JSON files (mode 775, writable by ss-collector group) |
| `/etc/ss-multivendor/grafana-admin-password` | Grafana + Reports UI default admin password (generated at install) |
| `/etc/sudoers.d/ss-collector` | Allows ss-reports to restart ss-collector without password (allowlist updates) |

---

## Known Collector Limitations

**Generic syslog devices (routers, switches) are silently dropped — current behaviour.**
The collector listens on a single port 514 for all vendors. Packets are accepted if the source IP is in `SYSLOG_ALLOWED_SOURCES`, but then routed to a parser based on the *content* of the message — not the source IP. Messages that don't match any known vendor fingerprint (SonicWall, FortiGate, Palo Alto) hit `else: return` and are discarded silently. This means:

- Cisco IOS/NX-OS, Juniper Junos, Ubiquiti, HP/Aruba switches → **dropped**
- Any RFC 3164/5424 syslog not from a supported firewall → **dropped**
- No error is logged — the packet simply doesn't appear in `fw_events`

**Standard IPFIX from non-SonicWall routers is not decoded — current behaviour.**
The IPFIX listener only understands SonicWall's proprietary templates (PEN 8741). A Cisco router or Ubiquiti device sending standard IANA IPFIX on port 2055 will have its packets received but not decoded.

**Phase 4a+4b fix — registration-based routing + generic IPFIX (live v1.0.24):**
Both limitations are resolved. The collector routes by source IP → `sensors.vendor`; no content fingerprinting for registered devices. Content detection is retained as fallback for unregistered devices only.

Generic IPFIX (Cisco, Ubiquiti, MikroTik, any standard IPFIX device) is handled by `parsers/generic_ipfix_parser.py` (v1.0.24). Register the device in the Reports UI with the correct vendor type — flows appear in `fw_events` immediately. Standard IPFIX is unidirectional so `bytes_received=0`; both directions appear as separate rows. No app names, threats, or user identity (standard IPFIX doesn't carry these).

**To add a Ubiquiti UniFi device:**
1. Reports UI → Tenants → Register Firewall → vendor: `Ubiquiti`, IP: `<UniFi device IP>`
2. UniFi Settings → Teleport & VPN → NetFlow → enable, set collector IP + port `2055`
3. Verify: `sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events WHERE vendor='ubiquiti' AND time > NOW() - INTERVAL '5 minutes';"`

See `DESIGN.md §5.2a` (routing) and `§6b` (IPFIX design) for full detail.

**Verify what's actually being received:**
```bash
# See exactly which source IPs are hitting port 514
sudo tcpdump -i any -nn 'udp port 514' -q | awk '{print $3}' | cut -d. -f1-4 | sort | uniq -c | sort -rn

# Confirm events are landing in the DB from expected sources
sudo -u postgres psql sonicscope -c \
  "SELECT vendor, COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes' GROUP BY vendor;"
```

---

## Data Accuracy Notes

IPFIX data from SonicWall firewalls is accurate for most traffic but has a few inherent behaviours to be aware of:

- **Large single-connection downloads** (one long-lived TCP session) may be under-reported or appear with a timestamp at the flow *start*, not when the download completed. The IPFIX record is only exported when the connection closes, which can lag the actual transfer by up to 60 seconds.
- **Validated accuracy (2026-05-07):** A 396 MB file download was recorded as 412 MB (~96% accurate). The 4% overhead is TCP/TLS handshake bytes included in the flow record.
- **FlowDeltaTracker** (v1.0.8+): SonicWall exports cumulative byte totals for active flows every ~60 seconds. The collector converts these to per-export deltas before storing. Without this, a single long-lived VPN or streaming session inflates totals dramatically. On collector restart, the first export of each active flow uses its full cumulative bytes (unavoidable without persisted state) — this self-corrects after the first IPFIX cycle (~60 seconds).
- **Syslog data** does not have the cumulative bytes issue — syslog records one entry per flow termination.

---

## Troubleshooting

### Collector not receiving flows
```bash
# Check the service is running
sudo systemctl status ss-collector

# Check IPFIX port is listening
ss -ulnp | grep 2055

# Confirm firewall is sending to the right IP
sudo tcpdump -i any udp port 2055 -c 10
```

### "Licence invalid" on startup
```bash
# Check the licence log for the specific error
cat /var/log/sonicscope/licence.log | tail -20

# Common causes:
# - Missing SONICSCOPE_LICENSE/CUSTOMER_ID/EXPIRY in collector.env
# - Server MAC changed (VM migration) — requires new key from licence manager
# - Licence expired — renew via http://192.168.8.16:8888
```

### Reports UI showing no data
```bash
# Check ss-reports is running
sudo systemctl status ss-reports

# Check the DB connection
sudo -u postgres psql sonicscope -c "SELECT COUNT(*) FROM fw_events;"

# Check the tenant_id is correct in the UI dropdown
```

### Grafana tenant dropdown empty / shows wrong names
```bash
# Re-run the dashboard installer — it reads tenants from the DB live
sudo bash scripts/install-grafana-dashboards.sh
```

### Email not sending
```bash
# Verify SMTP settings in collector.env
sudo grep "^SMTP_" /etc/ss-multivendor/collector.env | grep -v PASSWORD

# Test SMTP manually
python3 -c "
import smtplib, ssl
with smtplib.SMTP_SSL('smtp.sonicscope.co.za', 465) as s:
    s.login('mailer@sonicscope.co.za', 'PASSWORD')
    print('SMTP OK')
"
```

### Reports showing `failed` — "Sender Verify Failed" in logs

The SMTP relay (smtp.sonicscope.co.za) verifies that `SMTP_FROM` is a real deliverable mailbox before accepting the message. If `deploy.sh` set `SMTP_FROM` from the customer's contact email in `licence.env` (e.g. `cust002@sonicscope.co.za`), and that address isn't a real mailbox, every report email will bounce with `SMTPRecipientsRefused: Sender Verify Failed`. The PDF is generated and saved to disk — only delivery fails.

```bash
# Check for this specific error
sudo journalctl -u ss-reports | grep "SMTPRecipients"

# Fix: SMTP_FROM must be the relay's actual sending account
sudo sed -i 's/^SMTP_FROM=.*/SMTP_FROM=mailer@sonicscope.co.za/' /etc/ss-multivendor/collector.env
sudo systemctl restart ss-reports
```

**Note:** failed reports are not automatically retried. The next scheduled fire will generate a fresh report. Existing PDFs can be downloaded from the Reports UI dashboard at any time regardless of delivery status.

### Weekly or monthly report has no data (first few weeks)

This is expected behaviour — not a bug.

| Report type | When first data appears |
|---|---|
| Daily | Day 2 (covers yesterday) |
| Weekly | Week 3 (first full Mon–Sun week after install) |
| Monthly | Month 2 (covers the previous full calendar month) |

If a customer reports empty weekly/monthly reports in the first 1–4 weeks, reassure them the daily report will have data from day 2 and the weekly/monthly will populate naturally over time.

### Firewall registered but collector still not accepting its traffic

The Reports UI will show a yellow warning banner if the `collector.env` allowlist update fails (e.g. filesystem error, permission issue). If you see this:

```bash
# Manually verify the IP is in the allowlist
sudo grep 'SYSLOG_ALLOWED_SOURCES\|IPFIX_ALLOWED_SOURCES' /etc/ss-multivendor/collector.env

# If missing, re-register via the UI (it will retry) or add manually:
sudo sed -i 's/^SYSLOG_ALLOWED_SOURCES=.*/&,<new-ip>/' /etc/ss-multivendor/collector.env
sudo systemctl restart ss-collector
```

**If allowlist update always fails (permission denied):** Two root causes have been seen:

1. **`collector.env` permissions wrong** — `sed -i` in `deploy.sh` (pre-v1.0.20) reset ownership from `root:ss-collector 660` to `root:root 644`. Fix:
```bash
sudo chown root:ss-collector /etc/ss-multivendor/collector.env
sudo chmod 660 /etc/ss-multivendor/collector.env
```

2. **`ProtectSystem=full` blocking writes** — the `ss-reports` systemd service has `ProtectSystem=full` which makes `/etc/` read-only for the process regardless of file permissions. Fixed in v1.0.21 by adding `ReadWritePaths=/etc/ss-multivendor` to the service definition. If running a pre-v1.0.21 install, patch manually:
```bash
sudo sed -i '/^ProtectSystem=full/a ReadWritePaths=/etc/ss-multivendor /var/lib/ss-multivendor /var/log/ss-multivendor /var/lib/grafana/dashboards' /etc/systemd/system/ss-reports.service
sudo systemctl daemon-reload && sudo systemctl restart ss-reports
```

Both fixes are applied automatically on all fresh installs from v1.0.21 onward.

### Grafana tenant dropdown missing a tenant after adding one

The Reports UI will show a yellow warning banner if the Grafana dashboard patch fails. Fix:

```bash
sudo bash scripts/install-grafana-dashboards.sh
```

This re-reads all tenants from the DB and patches all 10 dashboard JSONs. Safe to run at any time.

### TenantResolver showing 0 firewalls after registering one
The resolver refreshes every 5 minutes automatically. Check it loaded:
```bash
sudo journalctl -u ss-collector --since "10 minutes ago" | grep TenantResolver
```
If it hasn't refreshed, restart the collector.

### Collector appears running but no flows visible in journal
IPFIX inserts log at DEBUG level — they are invisible in `journalctl` at INFO. The collector IS working if the DB has rows:
```bash
sudo -u postgres psql -d sonicscope -c \
  "SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';"
```
A non-zero count means data is flowing. The journal will also show `DB writer: N events inserted total` every 10,000 events.

### Flows arriving (tcpdump shows packets) but collector silently drops them
`IPFIX_ALLOWED_SOURCES` is filtering them. Verify the registered sensor IPs match what the firewall actually sends from:
```bash
sudo tcpdump -i any udp port 2055 -c 5   # check source IP in output
sudo grep IPFIX_ALLOWED_SOURCES /etc/ss-multivendor/collector.env
```
Registering a firewall via the Reports UI automatically updates the allowlist and restarts the collector. If you edited collector.env manually, restart the collector to apply.

### "password authentication failed for user sonicscope" on collector start
The password in `collector.env` doesn't match what PostgreSQL has — usually caused by saving an old collector.env over a fresh install. Fix:
```bash
DB_PASS=$(sudo grep '^DB_PASSWORD=' /etc/ss-multivendor/collector.env | cut -d'=' -f2-)
sudo -u postgres psql -c "ALTER USER sonicscope WITH PASSWORD '$DB_PASS';"
sudo systemctl restart ss-collector
```

### Grafana tenant dropdown shows wrong or missing tenants
The dropdown is updated automatically when tenants are saved in the Reports UI. If it's stale, force a refresh:
```bash
sudo bash scripts/install-grafana-dashboards.sh
```

### Reports show raw IPs instead of user names

**Check 1 — Identity mapping toggle.** Open Reports UI → Tenants → Edit → confirm **Identity mapping enabled** is checked. If it was accidentally turned off, tick it and save.

**Check 2 — No mappings defined.** If identity mapping is on but no devices are registered, there is nothing to resolve. Go to **👤 User Identity** → **💻 Devices** and add IP-to-user mappings, or import via DHCP CSV.

**Check 3 — Aggregate limitation.** The periodic report's Top Users section reads from the `daily_user_traffic` aggregate. Mappings added *after* data was collected will not retroactively rename users in the aggregate — only new data collected after the mapping is added will show names there. HR reports, blocked-user lists, and VPN activity (which query raw `fw_events`) resolve names retroactively from the day the mapping is added.

### Grafana shows data that is consistently 2 hours behind real time
The SonicWall's IPFIX export timestamps are in local time (SAST, UTC+2) instead of UTC. All flow records arrive with timestamps 2 hours ahead of the collector server's clock, so `NOW()`-relative queries in Grafana appear to show data from 2 hours ago.

**Fix on the SonicWall:**
1. Go to **System → Time** on the SonicWall management interface
2. Confirm **Time Zone** is set to `(GMT+02:00) Africa/Johannesburg`
3. Confirm **NTP Server** is configured and synchronised
4. After correcting, restart the collector: `sudo systemctl restart ss-collector`

The collector's flow delta tracker resets on restart — the first ~60 seconds of data after restart will carry the full cumulative bytes for any active long-lived flows (unavoidable without persisted state). This self-corrects after the first IPFIX export cycle.

### Bandwidth figures look inflated (Grafana shows GB/min on a home network)
The SonicWall exports active flow records every ~60 seconds with **cumulative** total bytes since session start, not bytes since the last export. Without delta correction, a single long-lived connection (e.g. a VPN tunnel or a large download) adds its full cumulative byte count on every export interval.

The collector (v1.0.8+) includes a `FlowDeltaTracker` that corrects this automatically. If you see inflation on an older install, update to v1.0.8:
```bash
sudo bash scripts/update.sh
sudo systemctl restart ss-collector
```

---

## Customer Self-Service Deployment

Customers deploy SonicScope using a single script downloaded from GitHub. No manual server access or configuration files required from you — the `deploy.sh` script handles everything.

**What the customer needs:**
1. A Ubuntu 22.04, 24.04, or 26.04 LTS server (VM or bare metal)
2. Their `licence.env` file (emailed automatically after licence issuance)
3. Internet access from the server

**Deployment command:**
```bash
curl -fsSL https://raw.githubusercontent.com/sonicscope/production/main/deploy.sh | sudo bash
```

The script must be run from the directory containing `licence.env`. It auto-detects the Ubuntu version and installs the correct PostgreSQL + TimescaleDB versions.

The script downloads `ss-multivendor-latest.tar.gz` from github.com/sonicscope/production, runs the full installer, applies the licence, optionally downloads GeoIP (if `MAXMIND_KEY` is in `licence.env`), installs Grafana dashboards and the Reports UI, and prints the default admin credentials on completion.

**Optional keys the customer can add to `licence.env`** before running deploy.sh:
```
MAXMIND_KEY=<free MaxMind key>     # enables GeoIP enrichment automatically
SMTP_HOST=smtp.their-domain.com    # pre-configures scheduled report email delivery
SMTP_PORT=465
SMTP_USER=reports@their-domain.com
SMTP_PASSWORD=<password>
SMTP_FROM=reports@their-domain.com
SMTP_USE_TLS=true
```

**To release a new version** (update github.com/sonicscope/production):
```bash
cd /home/devadmin/production
cp /home/devadmin/ss-multivendor/dist/ss-multivendor-X.X.X.tar.gz .
cp ss-multivendor-X.X.X.tar.gz ss-multivendor-latest.tar.gz
git add ss-multivendor-X.X.X.tar.gz ss-multivendor-latest.tar.gz
git commit -m "release: vX.X.X — <summary>"
git push
```
All existing customers using `deploy.sh` or `update.sh` will automatically receive the new version on their next deployment/update.

---

## Pricing (SS-MULTIVENDOR)

| Tier | Firewalls | ZAR / year | USD / year |
|---|---|---|---|
| Solo | 1 | R1,490 | $89 |
| Micro | 3 | R3,490 | $199 |
| Small | 5 | R4,990 | $279 |
| Professional | 10 | R8,490 | $469 |
| Business | 25 | R16,990 | $949 |
| Enterprise | 50 | R27,990 | $1,549 |
| Unlimited | ∞ | R39,990 | $2,199 |

Multi-year discounts: 2 years = 10% off (×1.80 total), 3 years = 15% off (×2.55 total).

Payments are processed at sonicscope.co.za via PayFast (ZAR, South African customers) and Paystack (USD, international). Both gateways are **LIVE** as of May 2026. On payment, `license@sonicscope.co.za` receives a notification with all details to issue the licence manually via the Licence Manager at `http://192.168.8.16:8888`.

**Payment gateway credentials** are in `/home/devadmin/web/config.php` — never commit this file. Webhook URL for both gateways: `https://sonicscope.co.za/payment_notify.php`.

**Website files** live in `/home/devadmin/web/` and are hosted on Xneelo (shared hosting). Upload via FTP/cPanel. SEO complete: GA4 (`G-1ZE2CXLJZC`), structured data, `sitemap.xml`, `robots.txt`.

---

## Resetting a VM for a Clean Redeploy

If a deployment fails partway through (e.g. PostgreSQL version conflict, package error), use `reset-vm.sh` to wipe everything and start fresh — no OS reinstall required.

```bash
curl -fsSL https://raw.githubusercontent.com/sonicscope/production/main/reset-vm.sh | sudo bash
```

Type `YES` to confirm. The script removes all PostgreSQL versions and data, TimescaleDB, Grafana, all SonicScope services and files, and the APT sources added by the installer. Takes ~30 seconds. After it completes, re-run `deploy.sh`.

**Use this when:** a deploy hung mid-way, an older PostgreSQL version is blocking the new install, or you want a guaranteed clean state before a customer deployment test.

---

## Development Workflow

Source code lives on the dev machine (sonicscopedev — 192.168.8.16).

| Location | Purpose |
|---|---|
| `/home/devadmin/ss-multivendor/` | Working source directory |
| `/home/devadmin/sonicscope-software/` | Full git clone of `github.com/sonicscope/software` |
| `/home/devadmin/production/` | Release tarballs + git clone of `github.com/sonicscope/production` |

**Running parser tests:**
```bash
# On snwlrep2 (live test server)
ssh devadmin@192.168.8.17 "sudo /opt/ss-multivendor/venv/bin/python3 -m pytest /opt/ss-multivendor/tests/ -v"

# On dev machine
cd /home/devadmin/sonicscope-software/ss-multivendor/collector
python3 -m pytest tests/ -v
```

96 tests covering Palo Alto (TRAFFIC, THREAT, AUTH, GLOBALPROTECT) and FortiGate (TRAFFIC, UTM, EVENT) parsers. Tests use synthetic logs — no live firewall needed. Run after every parser change and after live-validation reveals a field mapping discrepancy. See `DESIGN.md §6a` for full coverage detail.

**Committing source changes to GitHub:**
```bash
cd /home/devadmin/ss-multivendor
bash git_commit.sh "feat: description of change"
```
This rsyncs the working directory into the `ss-multivendor/` subdirectory of the software repo clone, commits, and pushes. Excludes `dist/`, build artefacts, and other product directories.

**Building and releasing a new version:**
```bash
# 1. Bump version in collector/main.py and DESIGN.md
# 2. Build (salt is read from ~/ss-license/operator.env)
cd /home/devadmin/ss-multivendor
bash scripts/build-release.sh --version X.X.X --salt '<salt>'

# 3. Publish to production repo
cp dist/ss-multivendor-X.X.X.tar.gz /home/devadmin/production/
cp /home/devadmin/production/ss-multivendor-X.X.X.tar.gz /home/devadmin/production/ss-multivendor-latest.tar.gz
cd /home/devadmin/production
git add ss-multivendor-X.X.X.tar.gz ss-multivendor-latest.tar.gz
git commit -m "release: vX.X.X — summary"
git push

# 4. Update snwlrep2
rsync -av production/ss-multivendor-X.X.X.tar.gz devadmin@192.168.8.17:/tmp/
ssh devadmin@192.168.8.17 "cd /tmp && tar -xzf ss-multivendor-X.X.X.tar.gz && cd ss-multivendor-X.X.X && echo y | sudo bash scripts/update.sh"

# 5. Commit source changes
bash git_commit.sh "release: vX.X.X — summary"
```

**SSH access:** `devadmin@192.168.8.17` is set up with key auth and NOPASSWD sudo from sonicscopedev.

**Quick collector deploy to snwlrep2 (without a full release build):**
```bash
cd /home/devadmin/ss-multivendor
bash deploy_dev.sh
```
This rsyncs collector source to `/opt/ss-multivendor/` on snwlrep2 and restarts the collector. It intentionally excludes `license_validator.py` — the production copy has the licence salt baked in and must never be overwritten by rsync.

---

## Contacts

| Role | Contact |
|---|---|
| Platform owner | wynand@vannispen.co.za |
| SonicScope sales | sales@sonicscope.co.za |
| Licence notifications | license@sonicscope.co.za |
| Website | sonicscope.co.za |
