"""
TenantResolver — maps incoming flows to (tenant_id, sensor_id) and vendor type.

Resolution priority (first match wins):
  1. source_ip (firewall sending IPFIX/syslog) matched against sensors.ip_address
  2. internal src_ip matched against tenant_subnets
  3. Fall back to (default_tenant_id, default_sensor_id) from config

get_device_type(source_ip) returns the sensors.vendor for a registered source IP
('sonicwall', 'fortinet', 'paloalto', 'cisco', 'ubiquiti', 'generic', etc.) or an
empty string for unregistered devices. Used by main.py to dispatch to the correct
parser without content fingerprinting (registration-based routing — Phase 4a).

Both tables are cached in memory and refreshed every 5 minutes so changes
made in the web UI take effect without a collector restart.
"""
from __future__ import annotations

import ipaddress
import logging
import threading
import time
from typing import Optional

log = logging.getLogger('ss.enrichment.tenant_resolver')

_Subnet = ipaddress.IPv4Network | ipaddress.IPv6Network


class TenantResolver:

    def __init__(self, pool, default_tenant_id: int, default_sensor_id: int,
                 refresh_interval: int = 300):
        self._pool = pool
        self._default_tenant = default_tenant_id
        self._default_sensor = default_sensor_id
        self._refresh_interval = refresh_interval
        self._lock = threading.RLock()
        # source_ip string → (tenant_id, sensor_id)
        self._sensor_map: dict[str, tuple[int, int]] = {}
        # source_ip string → vendor (e.g. 'sonicwall', 'fortinet', 'cisco')
        self._vendor_map: dict[str, str] = {}
        # (network, tenant_id) sorted most-specific first
        self._subnets: list[tuple[_Subnet, int]] = []
        self._load()
        self._start_refresh_thread()

    # ── Public ────────────────────────────────────────────────────────────

    def get_device_type(self, source_ip: str) -> str:
        """Return the registered vendor/device type for a source IP.

        Returns the sensors.vendor value ('sonicwall', 'fortinet', 'paloalto',
        'cisco', 'ubiquiti', 'generic', etc.) or an empty string if the source
        IP is not registered. Empty string triggers content-detection fallback
        in the syslog/IPFIX dispatch.
        """
        with self._lock:
            return self._vendor_map.get(source_ip, '')

    def resolve(self, ip_str: Optional[str] = None,
                source_ip: Optional[str] = None) -> tuple[int, int]:
        """Return (tenant_id, sensor_id) for a flow.

        Checks firewall source IP first (most reliable), then internal
        subnet match, then falls back to configured defaults.
        """
        with self._lock:
            # 1. Firewall source IP → registered sensor
            if source_ip and source_ip in self._sensor_map:
                return self._sensor_map[source_ip]

            # 2. Internal src_ip → configured subnet
            if ip_str:
                try:
                    ip = ipaddress.ip_address(ip_str)
                    for net, tenant_id in self._subnets:
                        if ip in net:
                            return (tenant_id, self._default_sensor)
                except ValueError:
                    pass

        return (self._default_tenant, self._default_sensor)

    # ── Internal ──────────────────────────────────────────────────────────

    def _load(self) -> None:
        try:
            conn = self._pool.getconn()
            try:
                with conn.cursor() as cur:
                    # Load registered sensors — host() strips the /32 prefix
                    # so lookups match bare IPs from incoming IPFIX/syslog packets
                    cur.execute(
                        "SELECT id, host(ip_address), tenant_id, "
                        "COALESCE(vendor, 'sonicwall') "
                        "FROM sensors "
                        "WHERE ip_address IS NOT NULL"
                    )
                    sensor_rows = cur.fetchall()

                    # Load tenant subnets (internal IP ranges)
                    cur.execute(
                        "SELECT subnet::text, tenant_id "
                        "FROM tenant_subnets "
                        "ORDER BY masklen(subnet) DESC"
                    )
                    subnet_rows = cur.fetchall()
            finally:
                self._pool.putconn(conn)

            sensor_map: dict[str, tuple[int, int]] = {}
            vendor_map: dict[str, str] = {}
            for sensor_id, ip_str, tenant_id, vendor in sensor_rows:
                if ip_str:
                    sensor_map[ip_str] = (tenant_id, sensor_id)
                    vendor_map[ip_str] = vendor

            subnets: list[tuple[_Subnet, int]] = []
            for subnet_str, tenant_id in subnet_rows:
                try:
                    subnets.append((ipaddress.ip_network(subnet_str, strict=False), tenant_id))
                except ValueError:
                    log.warning("Ignoring invalid subnet in DB: %s", subnet_str)

            with self._lock:
                self._sensor_map = sensor_map
                self._vendor_map = vendor_map
                self._subnets = subnets

            log.info(
                "TenantResolver: %d registered firewall(s), %d subnet(s)",
                len(sensor_map), len(subnets)
            )

        except Exception as exc:
            log.warning("TenantResolver load failed (will retry): %s", exc)

    def _start_refresh_thread(self) -> None:
        def _loop():
            while True:
                time.sleep(self._refresh_interval)
                self._load()
        t = threading.Thread(target=_loop, daemon=True,
                             name='tenant-resolver-refresh')
        t.start()
