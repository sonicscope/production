"""
Synthetic log tests for parsers/paloalto_parser.py

Tests use PAN-OS 12.x IETF/RFC 5424 + CSV format, constructed from Palo Alto
field documentation. Run with: pytest tests/test_paloalto_parser.py -v

Field positions (0-indexed from the CSV message body):
  [3]  log type   [6]  generated time  [7]  src ip    [8]  dst ip
  [11] rule name  [12] src user        [14] app        [16] src zone
  [17] dst zone   [18] inbound intf    [19] outbound   [24] src port
  [25] dst port   [29] protocol        [30] action (TRAFFIC/THREAT)
  TRAFFIC: [32] bytes_sent [33] bytes_recv [36] elapsed_s [44] pkts_sent [45] pkts_recv
  THREAT:  [31] url/misc   [32] threat_name [33] category  [34] severity
"""

import pytest
from datetime import timezone
from parsers.paloalto_parser import is_paloalto_syslog, normalize_syslog

TENANT_ID = 1
SENSOR_ID = 1
SOURCE_IP = '192.168.8.195'


# ── Helpers ───────────────────────────────────────────────────────────────────

def _rfc5424(csv_body: str) -> str:
    """Wrap CSV body in a minimal RFC 5424 header."""
    return f'<14>1 2026-05-19T10:00:00.000Z PA-VM - - - - {csv_body}'


def _traffic_csv(
    subtype='end', src='192.168.1.10', dst='8.8.8.8',
    rule='Allow-Internet', user='jdoe', app='web-browsing',
    zone_src='Trust', zone_dst='Untrust',
    intf_src='ethernet1/1', intf_dst='ethernet1/2',
    src_port='54321', dst_port='443', proto='tcp',
    action='allow',
    bytes_sent='1024', bytes_recv='512',
    elapsed='5', pkts_sent='8', pkts_recv='4',
) -> str:
    """Build a minimal PAN-OS TRAFFIC CSV body (all 53 positional fields)."""
    fields = [
        '1',                        # [0]  domain
        '2026/05/19 10:00:00',      # [1]  receive time
        'unknown',                  # [2]  serial
        'TRAFFIC',                  # [3]  type
        subtype,                    # [4]  subtype
        '0',                        # [5]  future use
        '2026/05/19 10:00:00',      # [6]  generated time
        src,                        # [7]  src ip
        dst,                        # [8]  dst ip
        '0.0.0.0',                  # [9]  nat src ip
        '0.0.0.0',                  # [10] nat dst ip
        rule,                       # [11] rule name
        user,                       # [12] src user
        '',                         # [13] dst user
        app,                        # [14] application
        'vsys1',                    # [15] vsys
        zone_src,                   # [16] src zone
        zone_dst,                   # [17] dst zone
        intf_src,                   # [18] inbound interface
        intf_dst,                   # [19] outbound interface
        '',                         # [20] log profile
        '',                         # [21] future use
        '12345',                    # [22] session id
        '1',                        # [23] repeat count
        src_port,                   # [24] src port
        dst_port,                   # [25] dst port
        '0',                        # [26] nat src port
        '0',                        # [27] nat dst port
        '0x400000',                 # [28] flags
        proto,                      # [29] protocol
        action,                     # [30] action
        str(int(bytes_sent) + int(bytes_recv)),  # [31] bytes total
        bytes_sent,                 # [32] bytes sent
        bytes_recv,                 # [33] bytes received
        '12',                       # [34] packets total
        '2026/05/19 09:59:55',      # [35] start time
        elapsed,                    # [36] elapsed seconds
        'any',                      # [37] url category
        '0',                        # [38] future use
        '9876543210',               # [39] sequence number
        '0x0',                      # [40] action flags
        'Private',                  # [41] src location
        'United States',            # [42] dst location
        '0',                        # [43] future use
        pkts_sent,                  # [44] packets sent
        pkts_recv,                  # [45] packets received
        'tcp-fin',                  # [46] session end reason
        '0', '0', '0', '0',         # [47-50] device group hierarchy
        'vsys1',                    # [51] vsys name
        'PA-VM',                    # [52] device name
    ]
    return ','.join(fields)


def _threat_csv(
    subtype='vulnerability', src='192.168.1.10', dst='203.0.113.50',
    rule='Block-Threats', user='jdoe', app='web-browsing',
    zone_src='Trust', zone_dst='Untrust',
    intf_src='ethernet1/1', intf_dst='ethernet1/2',
    src_port='54321', dst_port='80', proto='tcp',
    action='reset-both',
    url='http://malicious.example.com/exploit',
    threat_name='Apache.Log4j.Remote.Code.Execution',
    threat_cat='exploit',
    severity='critical',
) -> str:
    """Build a minimal PAN-OS THREAT CSV body."""
    fields = [
        '1',                        # [0]  domain
        '2026/05/19 10:00:00',      # [1]  receive time
        'unknown',                  # [2]  serial
        'THREAT',                   # [3]  type
        subtype,                    # [4]  subtype
        '0',                        # [5]  future use
        '2026/05/19 10:00:00',      # [6]  generated time
        src,                        # [7]  src ip
        dst,                        # [8]  dst ip
        '0.0.0.0',                  # [9]  nat src ip
        '0.0.0.0',                  # [10] nat dst ip
        rule,                       # [11] rule name
        user,                       # [12] src user
        '',                         # [13] dst user
        app,                        # [14] application
        'vsys1',                    # [15] vsys
        zone_src,                   # [16] src zone
        zone_dst,                   # [17] dst zone
        intf_src,                   # [18] inbound interface
        intf_dst,                   # [19] outbound interface
        '',                         # [20] log profile
        '',                         # [21] future use
        '12345',                    # [22] session id
        '1',                        # [23] repeat count
        src_port,                   # [24] src port
        dst_port,                   # [25] dst port
        '0',                        # [26] nat src port
        '0',                        # [27] nat dst port
        '0x0',                      # [28] flags
        proto,                      # [29] protocol
        action,                     # [30] action
        url,                        # [31] url / misc
        threat_name,                # [32] threat name
        threat_cat,                 # [33] category
        severity,                   # [34] severity
        'client-to-server',         # [35] direction
        '9876543210',               # [36] sequence number
        '0x0',                      # [37] action flags
        'United States',            # [38] src location
        'Private',                  # [39] dst location
    ]
    return ','.join(fields)


def _auth_csv(
    subtype='AUTH_LOGON', src='192.168.1.20', src_port='0',
    zone_src='Trust', intf_src='ethernet1/1',
    user='jdoe', auth_event='Authentication Successful',
) -> str:
    """Build a minimal PAN-OS AUTH CSV body (field layout differs from TRAFFIC)."""
    fields = [
        '1',                        # [0]  domain
        '2026/05/19 10:00:00',      # [1]  receive time
        'unknown',                  # [2]  serial
        'AUTH',                     # [3]  type
        subtype,                    # [4]  subtype
        '0',                        # [5]  future use
        '2026/05/19 10:00:00',      # [6]  generated time
        src,                        # [7]  src ip
        src_port,                   # [8]  src port
        'vsys1',                    # [9]  vsys
        zone_src,                   # [10] src zone
        intf_src,                   # [11] inbound interface
        '',                         # [12] dst zone
        '',                         # [13] outbound interface
        '',                         # [14] future use
        '0',                        # [15] session id
        '', '',                     # [16-17] future use
        user,                       # [18] src user
        user,                       # [19] normalized user
        'GP-Gateway',               # [20] object (auth target)
        'AuthPolicy-1',             # [21] auth policy
        '1',                        # [22] repeat count
        '0',                        # [23] auth id
        'Kerberos',                 # [24] vendor
        '',                         # [25] log action
        '',                         # [26] server profile
        '',                         # [27] description
        'GlobalProtect',            # [28] client type
        auth_event,                 # [29] event
    ]
    return ','.join(fields)


def _gp_csv(
    subtype='gateway-connected', user='jdoe',
    public_ip='102.132.1.55', private_ip='10.0.0.101',
    portal='GP-Portal',
) -> str:
    """Build a minimal PAN-OS GLOBALPROTECT CSV body."""
    fields = [
        '1',                        # [0]  domain
        '2026/05/19 10:00:00',      # [1]  receive time
        'unknown',                  # [2]  serial
        'GLOBALPROTECT',            # [3]  type
        subtype,                    # [4]  subtype
        '0',                        # [5]  future use
        '2026/05/19 10:00:00',      # [6]  generated time
        'vsys1',                    # [7]  vsys
        'gateway-connected',        # [8]  event id
        'login',                    # [9]  stage
        'SAML',                     # [10] auth method
        'IPSec',                    # [11] tunnel type
        user,                       # [12] src user
        'ZA',                       # [13] src region
        'LAPTOP-001',               # [14] machine name
        public_ip,                  # [15] public ip
        '',                         # [16] public ipv6
        private_ip,                 # [17] private ip
        '',                         # [18] private ipv6
        'host-id-abc123',           # [19] host id
        'unknown',                  # [20] serial number
        '6.0.0',                    # [21] client version
        'Windows',                  # [22] client os
        '10.0',                     # [23] client os version
        '1',                        # [24] repeat count
        '',                         # [25] reason
        '',                         # [26] error
        'Connected',                # [27] description
        'success',                  # [28] status
        'ZA',                       # [29] location
        '3600',                     # [30] login duration
        'pre-logon',                # [31] connect method
        '0',                        # [32] error code
        portal,                     # [33] portal
    ]
    return ','.join(fields)


# ── Detection tests ───────────────────────────────────────────────────────────

class TestDetection:
    def test_detects_traffic_log(self):
        assert is_paloalto_syslog(_rfc5424(_traffic_csv()))

    def test_detects_threat_log(self):
        assert is_paloalto_syslog(_rfc5424(_threat_csv()))

    def test_detects_auth_log(self):
        assert is_paloalto_syslog(_rfc5424(_auth_csv()))

    def test_detects_globalprotect_log(self):
        assert is_paloalto_syslog(_rfc5424(_gp_csv()))

    def test_rejects_sonicwall_syslog(self):
        sw = '<134>  id=firewall sn=18C2419BE3E4 time="2026-05-19 10:00:00" fw=1.2.3.4 pri=6 c=262144 m=98 msg="Connection Opened" src=192.168.1.1:1234:X0 dst=8.8.8.8:443:X1 proto=tcp/https sent=60'
        assert not is_paloalto_syslog(sw)

    def test_rejects_fortinet_syslog(self):
        fg = '<189>date=2026-05-19 time=10:00:00 devname="FGVM" devid="FGVM01" logid="0000000013" type="traffic" action="accept" srcip=1.2.3.4 dstip=8.8.8.8'
        assert not is_paloalto_syslog(fg)

    def test_rejects_plain_syslog(self):
        assert not is_paloalto_syslog('<14>May 19 10:00:00 host sshd[1234]: Accepted password for admin')


# ── TRAFFIC log tests ─────────────────────────────────────────────────────────

class TestTrafficLog:
    def test_allowed_flow_basic_fields(self):
        raw = _rfc5424(_traffic_csv())
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.vendor == 'paloalto'
        assert ev.data_source == 'syslog'
        assert ev.event_type == 'traffic'
        assert ev.action == 'allow'
        assert ev.src_ip == '192.168.1.10'
        assert ev.dst_ip == '8.8.8.8'
        assert ev.src_port == 54321
        assert ev.dst_port == 443
        assert ev.protocol == 'tcp'

    def test_allowed_flow_network_metadata(self):
        raw = _rfc5424(_traffic_csv())
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.zone_src == 'Trust'
        assert ev.zone_dst == 'Untrust'
        assert ev.interface_src == 'ethernet1/1'
        assert ev.interface_dst == 'ethernet1/2'
        assert ev.rule_name == 'Allow-Internet'
        assert ev.app_name == 'web-browsing'
        assert ev.user_name == 'jdoe'

    def test_allowed_flow_traffic_metrics(self):
        raw = _rfc5424(_traffic_csv(bytes_sent='2048', bytes_recv='512', elapsed='10', pkts_sent='16', pkts_recv='4'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.bytes_sent == 2048
        assert ev.bytes_received == 512
        assert ev.packets_sent == 16
        assert ev.packets_received == 4
        assert ev.duration_ms == 10000

    def test_timestamp_parsed(self):
        raw = _rfc5424(_traffic_csv())
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.time.year == 2026
        assert ev.time.month == 5
        assert ev.time.day == 19
        assert ev.time.tzinfo == timezone.utc

    def test_denied_subtype_maps_to_denied(self):
        raw = _rfc5424(_traffic_csv(subtype='deny', action='deny'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'denied'
        assert ev.action == 'deny'

    def test_drop_subtype_maps_to_denied(self):
        raw = _rfc5424(_traffic_csv(subtype='drop', action='drop'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'denied'
        assert ev.action == 'deny'

    def test_allow_action_overrides_end_subtype(self):
        raw = _rfc5424(_traffic_csv(subtype='end', action='allow'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'traffic'
        assert ev.action == 'allow'

    def test_reset_both_action(self):
        raw = _rfc5424(_traffic_csv(action='reset-both'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'reset'
        assert ev.event_type == 'denied'

    def test_udp_protocol(self):
        raw = _rfc5424(_traffic_csv(proto='udp', dst_port='53'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'udp'
        assert ev.dst_port == 53

    def test_icmp_protocol(self):
        raw = _rfc5424(_traffic_csv(proto='icmp', src_port='0', dst_port='0'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'icmp'

    def test_anonymous_user_stripped(self):
        for anon in ('', 'N/A', 'unknown', 'Unknown'):
            raw = _rfc5424(_traffic_csv(user=anon))
            ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
            assert ev.user_name is None, f"Expected None for user={anon!r}"

    def test_generic_app_stripped(self):
        for generic in ('not-applicable', 'unknown', 'insufficient-data'):
            raw = _rfc5424(_traffic_csv(app=generic))
            ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
            assert ev.app_name is None, f"Expected None for app={generic!r}"

    def test_zero_elapsed_gives_none_duration(self):
        raw = _rfc5424(_traffic_csv(elapsed='0'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.duration_ms is None

    def test_tenant_sensor_passthrough(self):
        raw = _rfc5424(_traffic_csv())
        ev = normalize_syslog(raw, SOURCE_IP, 42, 7)
        assert ev.tenant_id == 42
        assert ev.sensor_id == 7

    def test_raw_message_stored(self):
        raw = _rfc5424(_traffic_csv())
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.raw_message == raw

    def test_raw_message_truncated_at_2000_chars(self):
        long_rule = 'R' * 2500
        raw = _rfc5424(_traffic_csv(rule=long_rule))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert len(ev.raw_message) == 2000


# ── THREAT log tests ──────────────────────────────────────────────────────────

class TestThreatLog:
    def test_vulnerability_basic_fields(self):
        raw = _rfc5424(_threat_csv(subtype='vulnerability'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.event_type == 'threat'
        assert ev.action == 'reset'
        assert ev.vendor == 'paloalto'
        assert ev.src_ip == '192.168.1.10'
        assert ev.dst_ip == '203.0.113.50'

    def test_threat_name_and_severity(self):
        raw = _rfc5424(_threat_csv(
            threat_name='Apache.Log4j.Remote.Code.Execution',
            severity='critical',
        ))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.threat_name == 'Apache.Log4j.Remote.Code.Execution'
        assert ev.threat_severity == 'critical'

    def test_severity_mapping(self):
        cases = {
            'critical':      'critical',
            'high':          'high',
            'medium':        'medium',
            'low':           'low',
            'informational': 'low',
        }
        for pan_sev, expected in cases.items():
            raw = _rfc5424(_threat_csv(severity=pan_sev))
            ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
            assert ev.threat_severity == expected, f"severity={pan_sev}"

    def test_url_filter_maps_to_web_event_type(self):
        raw = _rfc5424(_threat_csv(
            subtype='url',
            url='https://example.com/page',
            threat_name='adult-content',
            threat_cat='Adult Content',
            severity='medium',
            action='block-url',
        ))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'web'
        assert ev.web_category == 'Adult Content'
        assert ev.threat_category is None
        assert ev.url == 'https://example.com/page'

    def test_domain_extracted_from_url(self):
        raw = _rfc5424(_threat_csv(url='http://malicious.example.com/exploit/payload'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.domain == 'malicious.example.com'

    def test_domain_extracted_from_https_url(self):
        raw = _rfc5424(_threat_csv(url='https://badsite.co.za/path?q=1'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.domain == 'badsite.co.za'

    def test_virus_subtype_is_threat(self):
        raw = _rfc5424(_threat_csv(subtype='virus', threat_name='Eicar-Test-File', severity='high'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'threat'

    def test_spyware_subtype_is_threat(self):
        raw = _rfc5424(_threat_csv(subtype='spyware', severity='high'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'threat'

    def test_wildfire_subtype_is_threat(self):
        raw = _rfc5424(_threat_csv(subtype='wildfire', severity='critical'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'threat'

    def test_block_url_action_maps_to_deny(self):
        raw = _rfc5424(_threat_csv(action='block-url', subtype='url'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'deny'

    def test_alert_action_maps_to_allow(self):
        raw = _rfc5424(_threat_csv(action='alert', subtype='vulnerability'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'allow'

    def test_network_fields_populated(self):
        raw = _rfc5424(_threat_csv(src_port='12345', dst_port='80', proto='tcp'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.src_port == 12345
        assert ev.dst_port == 80
        assert ev.protocol == 'tcp'
        assert ev.zone_src == 'Trust'
        assert ev.zone_dst == 'Untrust'
        assert ev.rule_name == 'Block-Threats'


# ── AUTH log tests ────────────────────────────────────────────────────────────

class TestAuthLog:
    def test_successful_auth(self):
        raw = _rfc5424(_auth_csv(auth_event='Authentication Successful'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.event_type == 'auth'
        assert ev.action == 'allow'
        assert ev.user_name == 'jdoe'
        assert ev.src_ip == '192.168.1.20'

    def test_failed_auth(self):
        raw = _rfc5424(_auth_csv(auth_event='Authentication Failed'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'auth'
        assert ev.action == 'deny'

    def test_auth_zone_and_interface(self):
        raw = _rfc5424(_auth_csv(zone_src='Trust', intf_src='ethernet1/1'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.zone_src == 'Trust'
        assert ev.interface_src == 'ethernet1/1'
        assert ev.zone_dst is None
        assert ev.dst_ip is None


# ── GLOBALPROTECT log tests ───────────────────────────────────────────────────

class TestGlobalProtectLog:
    def test_connected_event(self):
        raw = _rfc5424(_gp_csv(subtype='gateway-connected', public_ip='102.132.1.55'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.event_type == 'vpn'
        assert ev.action == 'allow'
        assert ev.user_name == 'jdoe'
        assert ev.vpn_client_ip == '102.132.1.55'
        assert ev.src_ip == '102.132.1.55'

    def test_portal_name_stored(self):
        raw = _rfc5424(_gp_csv(portal='MyPortal'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.vpn_policy_name == 'MyPortal'

    def test_failed_subtype_maps_to_deny(self):
        raw = _rfc5424(_gp_csv(subtype='gateway-auth-failure'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'deny'

    def test_private_ip_fallback_when_no_public(self):
        raw = _rfc5424(_gp_csv(public_ip='', private_ip='10.0.0.200'))
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.src_ip == '10.0.0.200'


# ── Skipped log type tests ────────────────────────────────────────────────────

class TestSkippedLogTypes:
    def _make(self, log_type: str) -> str:
        fields = ['1', '2026/05/19 10:00:00', 'unknown', log_type, 'info',
                  '0', '2026/05/19 10:00:00', 'vsys1', 'EVT001', 'object',
                  '', '', 'general', 'informational', 'System event occurred',
                  '123', '0x0']
        return _rfc5424(','.join(fields))

    def test_system_log_returns_none(self):
        assert normalize_syslog(self._make('SYSTEM'), SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_config_log_returns_none(self):
        assert normalize_syslog(self._make('CONFIG'), SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_hipmatch_log_returns_none(self):
        assert normalize_syslog(self._make('HIPMATCH'), SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_unknown_type_returns_none(self):
        raw = _rfc5424('1,2026/05/19 10:00:00,unknown,BOGUSTYPE,end,0,2026/05/19 10:00:00')
        assert normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_empty_message_returns_none(self):
        assert normalize_syslog('', SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_non_panos_syslog_returns_none(self):
        raw = 'May 19 10:00:00 host kernel: some kernel message'
        assert normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID) is None


# ── RFC 5424 header stripping tests ──────────────────────────────────────────

class TestHeaderStripping:
    def test_rfc5424_header_stripped(self):
        raw = _rfc5424(_traffic_csv())
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.src_ip == '192.168.1.10'

    def test_no_header_still_parses(self):
        raw = _traffic_csv()
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.src_ip == '192.168.1.10'

    def test_rfc3164_priority_stripped(self):
        raw = '<14>' + _traffic_csv()
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.src_ip == '192.168.1.10'
