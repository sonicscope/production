"""Add the collector directory to sys.path so parsers can import event.py."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
