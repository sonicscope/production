"""
Synthetic log tests for parsers/fortinet_parser.py

Tests use FortiGate 7.x Enhanced Syslog format (key=value pairs).
Confirmed field behaviour from live FortiGate VM (2026-05-08).
Run with: pytest tests/test_fortinet_parser.py -v

Key facts validated against live data:
  - eventtime = nanoseconds since Unix epoch (FortiGate 7.x)
  - sentbyte/rcvdbyte = per-session totals on flow close
  - srcintfrole/dstintfrole carry lan/wan/dmz (mapped to zone_src/zone_dst)
  - proto = IP protocol number (6=TCP, 17=UDP, 1=ICMP)
"""

import pytest
from datetime import timezone
from parsers.fortinet_parser import is_fortinet_syslog, normalize_syslog

TENANT_ID = 1
SENSOR_ID = 1
SOURCE_IP = '192.168.8.39'

# Nanosecond eventtime for 2026-05-19 10:00:00 UTC
_EVENTTIME_NS = '1779184800000000000'


# ── Helpers ───────────────────────────────────────────────────────────────────

def _pri(msg: str) -> str:
    """Wrap message in RFC 3164 priority prefix."""
    return f'<189>{msg}'


def _traffic(
    action='accept', subtype='forward',
    srcip='192.168.1.10', srcport='54321',
    dstip='8.8.8.8', dstport='443',
    proto=6,
    srcintf='port1', srcintfrole='lan',
    dstintf='port2', dstintfrole='wan',
    policyid=1, policyname='Allow-Internet',
    app='HTTPS', appcat='Web.Client',
    sentbyte=1024, rcvdbyte=512,
    sentpkt=8, rcvdpkt=4,
    duration=10,
    user='jdoe',
    devname='FGVM',
) -> str:
    return _pri(
        f'date=2026-05-19 time=10:00:00 devname="{devname}" devid="FGVMEVIIKCKMUI76" '
        f'eventtime={_EVENTTIME_NS} tz="+0200" logid="0000000013" type="traffic" '
        f'subtype="{subtype}" level="notice" vd="root" '
        f'srcip={srcip} srcport={srcport} srcintf="{srcintf}" srcintfrole="{srcintfrole}" '
        f'dstip={dstip} dstport={dstport} dstintf="{dstintf}" dstintfrole="{dstintfrole}" '
        f'proto={proto} action="{action}" '
        f'policyid={policyid} policyname="{policyname}" '
        f'app="{app}" appcat="{appcat}" '
        f'sentbyte={sentbyte} rcvdbyte={rcvdbyte} '
        f'sentpkt={sentpkt} rcvdpkt={rcvdpkt} '
        f'duration={duration} user="{user}"'
    )


def _utm(
    subtype='ips', action='block',
    srcip='192.168.1.10', srcport='54321',
    dstip='203.0.113.50', dstport='80',
    proto=6,
    srcintf='port1', srcintfrole='lan',
    dstintf='port2', dstintfrole='wan',
    attack='Apache.Log4j.Remote.Code.Execution',
    attackid=99002,
    severity='critical',
    user='jdoe',
    hostname='',
    url='',
    catdesc='',
    devname='FGVM',
) -> str:
    extra = ''
    if hostname:
        extra += f' hostname="{hostname}"'
    if url:
        extra += f' url="{url}"'
    if catdesc:
        extra += f' catdesc="{catdesc}"'
    return _pri(
        f'date=2026-05-19 time=10:00:00 devname="{devname}" devid="FGVMEVIIKCKMUI76" '
        f'eventtime={_EVENTTIME_NS} tz="+0200" logid="0419016384" type="utm" '
        f'subtype="{subtype}" level="alert" vd="root" '
        f'srcip={srcip} srcport={srcport} srcintf="{srcintf}" srcintfrole="{srcintfrole}" '
        f'dstip={dstip} dstport={dstport} dstintf="{dstintf}" dstintfrole="{dstintfrole}" '
        f'proto={proto} action="{action}" '
        f'attack="{attack}" attackid={attackid} severity="{severity}" '
        f'user="{user}"{extra}'
    )


def _event(
    subtype='vpn', action='tunnel-up',
    srcip='102.132.1.55', dstip='',
    user='jdoe',
    msg='SSL VPN tunnel established',
    devname='FGVM',
) -> str:
    dst = f' dstip={dstip}' if dstip else ''
    return _pri(
        f'date=2026-05-19 time=10:00:00 devname="{devname}" devid="FGVMEVIIKCKMUI76" '
        f'eventtime={_EVENTTIME_NS} tz="+0200" logid="0101039948" type="event" '
        f'subtype="{subtype}" level="notice" vd="root" '
        f'srcip={srcip}{dst} user="{user}" action="{action}" msg="{msg}"'
    )


# ── Detection tests ───────────────────────────────────────────────────────────

class TestDetection:
    def test_detects_fortinet_traffic(self):
        assert is_fortinet_syslog(_traffic())

    def test_detects_fortinet_utm(self):
        assert is_fortinet_syslog(_utm())

    def test_detects_fortinet_event(self):
        assert is_fortinet_syslog(_event())

    def test_rejects_sonicwall_syslog(self):
        sw = '<134>  id=firewall sn=18C2419BE3E4 time="2026-05-19 10:00:00" fw=1.2.3.4 pri=6 m=98 msg="Connection Opened" src=192.168.1.1:1234:X0 dst=8.8.8.8:443:X1'
        assert not is_fortinet_syslog(sw)

    def test_rejects_paloalto_syslog(self):
        pa = '<14>1 2026-05-19T10:00:00Z PA-VM - - - - 1,2026/05/19 10:00:00,unknown,TRAFFIC,end,0,2026/05/19 10:00:00,192.168.1.1,8.8.8.8'
        assert not is_fortinet_syslog(pa)

    def test_rejects_plain_syslog(self):
        assert not is_fortinet_syslog('<14>May 19 10:00:00 host sshd[123]: Accepted password')


# ── TRAFFIC log tests ─────────────────────────────────────────────────────────

class TestTrafficLog:
    def test_allowed_flow_basic_fields(self):
        ev = normalize_syslog(_traffic(), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.vendor == 'fortinet'
        assert ev.data_source == 'syslog'
        assert ev.event_type == 'traffic'
        assert ev.action == 'allow'
        assert ev.src_ip == '192.168.1.10'
        assert ev.dst_ip == '8.8.8.8'
        assert ev.src_port == 54321
        assert ev.dst_port == 443
        assert ev.protocol == 'tcp'

    def test_allowed_flow_metadata(self):
        ev = normalize_syslog(_traffic(), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.zone_src == 'lan'
        assert ev.zone_dst == 'wan'
        assert ev.interface_src == 'port1'
        assert ev.interface_dst == 'port2'
        assert ev.rule_id == 1
        assert ev.rule_name == 'Allow-Internet'
        assert ev.app_name == 'HTTPS'
        assert ev.app_category == 'Web.Client'
        assert ev.user_name == 'jdoe'

    def test_traffic_metrics(self):
        ev = normalize_syslog(
            _traffic(sentbyte=4096, rcvdbyte=1024, sentpkt=32, rcvdpkt=8, duration=30),
            SOURCE_IP, TENANT_ID, SENSOR_ID
        )
        assert ev.bytes_sent == 4096
        assert ev.bytes_received == 1024
        assert ev.packets_sent == 32
        assert ev.packets_received == 8
        assert ev.duration_ms == 30000

    def test_deny_action_maps_to_denied_event_type(self):
        ev = normalize_syslog(_traffic(action='deny'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'denied'
        assert ev.action == 'deny'

    def test_block_action_maps_to_denied(self):
        ev = normalize_syslog(_traffic(action='block'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'denied'
        assert ev.action == 'deny'

    def test_close_action_maps_to_allow(self):
        ev = normalize_syslog(_traffic(action='close'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'traffic'
        assert ev.action == 'allow'

    def test_timeout_action_maps_to_allow(self):
        ev = normalize_syslog(_traffic(action='timeout'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'allow'

    def test_udp_protocol_number(self):
        ev = normalize_syslog(_traffic(proto=17, dstport='53'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'udp'
        assert ev.dst_port == 53

    def test_icmp_protocol_number(self):
        ev = normalize_syslog(_traffic(proto=1, srcport='0', dstport='0'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'icmp'

    def test_timestamp_from_eventtime_nanoseconds(self):
        ev = normalize_syslog(_traffic(), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.time.year == 2026
        assert ev.time.month == 5
        assert ev.time.day == 19
        assert ev.time.tzinfo == timezone.utc

    def test_undefined_intfrole_stored_as_none_zone(self):
        ev = normalize_syslog(
            _traffic(srcintfrole='undefined', dstintfrole='undefined'),
            SOURCE_IP, TENANT_ID, SENSOR_ID
        )
        assert ev.zone_src is None
        assert ev.zone_dst is None

    def test_dmz_intfrole(self):
        ev = normalize_syslog(
            _traffic(srcintfrole='lan', dstintfrole='dmz'),
            SOURCE_IP, TENANT_ID, SENSOR_ID
        )
        assert ev.zone_src == 'lan'
        assert ev.zone_dst == 'dmz'

    def test_na_user_stripped(self):
        for anon in ('N/A', 'n/a', ''):
            ev = normalize_syslog(_traffic(user=anon), SOURCE_IP, TENANT_ID, SENSOR_ID)
            assert ev.user_name is None, f"Expected None for user={anon!r}"

    def test_generic_app_stripped(self):
        ev = normalize_syslog(_traffic(app='udp/53'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.app_name is None

    def test_named_service_used_as_fallback_app(self):
        raw = _pri(
            f'date=2026-05-19 time=10:00:00 devname="FGVM" devid="FG01" '
            f'eventtime={_EVENTTIME_NS} logid="0000000013" type="traffic" subtype="forward" '
            f'level="notice" vd="root" srcip=1.2.3.4 srcport=1234 srcintf="port1" srcintfrole="lan" '
            f'dstip=8.8.8.8 dstport=443 dstintf="port2" dstintfrole="wan" '
            f'proto=6 action="accept" policyid=1 app="N/A" service="HTTPS" '
            f'sentbyte=100 rcvdbyte=50 duration=1'
        )
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.app_name == 'HTTPS'

    def test_tenant_and_sensor_passthrough(self):
        ev = normalize_syslog(_traffic(), SOURCE_IP, 99, 3)
        assert ev.tenant_id == 99
        assert ev.sensor_id == 3

    def test_raw_message_stored(self):
        raw = _traffic()
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.raw_message == raw


# ── UTM (threat) log tests ────────────────────────────────────────────────────

class TestUTMLog:
    def test_ips_maps_to_threat(self):
        ev = normalize_syslog(_utm(subtype='ips'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.event_type == 'threat'
        assert ev.vendor == 'fortinet'

    def test_threat_fields_populated(self):
        ev = normalize_syslog(
            _utm(
                subtype='ips',
                attack='Apache.Log4j.Remote.Code.Execution',
                severity='critical',
                action='block',
            ),
            SOURCE_IP, TENANT_ID, SENSOR_ID
        )
        assert ev.threat_name == 'Apache.Log4j.Remote.Code.Execution'
        assert ev.threat_severity == 'critical'
        assert ev.action == 'deny'

    def test_severity_mapping(self):
        cases = {
            'critical':    'critical',
            'alert':       'critical',
            'emergency':   'critical',
            'high':        'high',
            'error':       'high',
            'medium':      'medium',
            'warning':     'medium',
            'low':         'low',
            'notice':      'low',
            'info':        'low',
            'information': 'low',
        }
        for fg_sev, expected in cases.items():
            ev = normalize_syslog(_utm(severity=fg_sev), SOURCE_IP, TENANT_ID, SENSOR_ID)
            assert ev.threat_severity == expected, f"severity={fg_sev}"

    def test_virus_subtype_maps_to_threat(self):
        ev = normalize_syslog(_utm(subtype='virus', attack='Eicar-Test-File', severity='high'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'threat'

    def test_webfilter_maps_to_web(self):
        ev = normalize_syslog(
            _utm(
                subtype='webfilter',
                action='blocked',
                hostname='adult-site.example.com',
                url='/page',
                catdesc='Adult Content',
                severity='medium',
                attack='',
                attackid=0,
            ),
            SOURCE_IP, TENANT_ID, SENSOR_ID
        )
        assert ev.event_type == 'web'
        assert ev.domain == 'adult-site.example.com'
        assert ev.url == '/page'
        assert ev.web_category == 'Adult Content'

    def test_network_fields_in_utm(self):
        ev = normalize_syslog(
            _utm(srcip='192.168.2.5', srcport='11111', dstip='1.1.1.1', dstport='80', proto=6),
            SOURCE_IP, TENANT_ID, SENSOR_ID
        )
        assert ev.src_ip == '192.168.2.5'
        assert ev.src_port == 11111
        assert ev.dst_ip == '1.1.1.1'
        assert ev.dst_port == 80
        assert ev.protocol == 'tcp'

    def test_block_action_maps_to_deny(self):
        ev = normalize_syslog(_utm(action='block'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'deny'

    def test_passthrough_action_maps_to_allow(self):
        ev = normalize_syslog(_utm(action='passthrough'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.action == 'allow'


# ── EVENT log tests ───────────────────────────────────────────────────────────

class TestEventLog:
    def test_vpn_subtype_maps_to_vpn(self):
        ev = normalize_syslog(_event(subtype='vpn'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.event_type == 'vpn'

    def test_ipsec_subtype_maps_to_vpn(self):
        ev = normalize_syslog(_event(subtype='ipsec'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'vpn'

    def test_sslvpn_subtype_maps_to_vpn(self):
        ev = normalize_syslog(_event(subtype='sslvpn'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'vpn'

    def test_user_subtype_maps_to_auth(self):
        ev = normalize_syslog(_event(subtype='user', msg='User logged in'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'auth'

    def test_authentication_subtype_maps_to_auth(self):
        ev = normalize_syslog(_event(subtype='authentication', msg='Auth event'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'auth'

    def test_other_event_subtype_maps_to_system(self):
        ev = normalize_syslog(_event(subtype='system', msg='Config changed'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'system'

    def test_user_identity_in_vpn_event(self):
        ev = normalize_syslog(_event(subtype='vpn', user='wynand'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.user_name == 'wynand'

    def test_src_ip_in_event(self):
        ev = normalize_syslog(_event(subtype='vpn', srcip='102.132.5.20'), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.src_ip == '102.132.5.20'


# ── Skipped log types ─────────────────────────────────────────────────────────

class TestSkippedLogTypes:
    def test_anomaly_type_skipped(self):
        raw = _pri(
            f'date=2026-05-19 time=10:00:00 devname="FGVM" devid="FG01" '
            f'eventtime={_EVENTTIME_NS} logid="0720018433" type="anomaly" '
            f'level="alert" vd="root" srcip=1.2.3.4 msg="SYN flood detected"'
        )
        # anomaly is in the allowed list — should parse, not None
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None

    def test_non_fortinet_message_returns_none(self):
        raw = 'May 19 10:00:00 host kernel: some kernel message with no devname'
        assert normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_unknown_log_type_returns_none(self):
        raw = _pri(
            f'date=2026-05-19 time=10:00:00 devname="FGVM" devid="FG01" '
            f'eventtime={_EVENTTIME_NS} logid="9999999999" type="unknown_bogus" '
            f'level="notice" vd="root" srcip=1.2.3.4'
        )
        assert normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID) is None

    def test_empty_message_returns_none(self):
        assert normalize_syslog('', SOURCE_IP, TENANT_ID, SENSOR_ID) is None


# ── Eventtime nanosecond parsing ──────────────────────────────────────────────

class TestEventtimeParsing:
    def _raw_with_eventtime(self, ns: int) -> str:
        raw = _traffic()
        return raw.replace(f'eventtime={_EVENTTIME_NS}', f'eventtime={ns}')

    def test_nanosecond_precision(self):
        # 2026-05-19 10:00:00 UTC in nanoseconds
        ev = normalize_syslog(self._raw_with_eventtime(int(_EVENTTIME_NS)), SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev.time.year == 2026
        assert ev.time.month == 5
        assert ev.time.day == 19
        assert ev.time.hour == 10

    def test_fallback_to_date_time_fields(self):
        raw = _pri(
            'date=2026-05-19 time=09:30:00 devname="FGVM" devid="FG01" '
            'logid="0000000013" type="traffic" subtype="forward" '
            'level="notice" vd="root" srcip=1.2.3.4 srcport=1234 '
            'srcintf="port1" srcintfrole="lan" dstip=8.8.8.8 dstport=443 '
            'dstintf="port2" dstintfrole="wan" proto=6 action="accept" '
            'policyid=1 sentbyte=100 rcvdbyte=50 duration=1'
        )
        ev = normalize_syslog(raw, SOURCE_IP, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.time.hour == 9
        assert ev.time.minute == 30
