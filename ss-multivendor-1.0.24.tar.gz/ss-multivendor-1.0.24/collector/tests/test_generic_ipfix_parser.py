"""
Synthetic tests for parsers/generic_ipfix_parser.py

Tests use decoded IANA IPFIX flow dicts as produced by
IPFIXInput._decode_record() + sonicwall_templates.IANA_FIELDS for
standard (non-SonicWall) devices (Cisco, Ubiquiti, MikroTik, etc.).

Run with: pytest tests/test_generic_ipfix_parser.py -v

Key behaviours validated:
  - Standard IPFIX is unidirectional — bytes_received is always 0
  - FlowDeltaTracker is NOT used — bytes_sent is the raw IPFIX value
  - Timestamp priority: flowStartMilliseconds > flowStartSeconds >
    export_time - duration > export_time
  - Interface: interfaceName preferred over numeric ingressInterface index
  - vendor field set to the registered sensors.vendor value (passed in)
  - No action/threat/app/user fields — all NULL for generic IPFIX
"""

import pytest
from datetime import datetime, timezone, timedelta
from parsers.generic_ipfix_parser import normalize_ipfix

TENANT_ID = 1
SENSOR_ID = 1
SOURCE_IP = '192.168.10.1'

_EXPORT_TIME = datetime(2026, 5, 19, 10, 0, 0, tzinfo=timezone.utc)

# Epoch milliseconds for 2026-05-19 09:59:55 UTC (flow started 5s before export)
_FLOW_START_MS = int(datetime(2026, 5, 19, 9, 59, 55, tzinfo=timezone.utc).timestamp() * 1000)
_FLOW_START_S  = int(datetime(2026, 5, 19, 9, 59, 55, tzinfo=timezone.utc).timestamp())


def _flow(**overrides) -> dict:
    """Build a minimal decoded IANA IPFIX flow dict."""
    base = {
        'sourceIPv4Address':       '192.168.1.10',
        'destinationIPv4Address':  '8.8.8.8',
        'sourceTransportPort':     54321,
        'destinationTransportPort': 443,
        'protocolIdentifier':      6,
        'octetDeltaCount':         2048,
        'packetDeltaCount':        16,
        'flowDurationMilliseconds': 5000,
        'flowStartMilliseconds':   _FLOW_START_MS,
        'ingressInterface':        1,
        'flowDirection':           0,
    }
    base.update(overrides)
    return base


# ── Basic field mapping ───────────────────────────────────────────────────────

class TestBasicFields:
    def test_returns_normalized_event(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev is not None

    def test_vendor_set(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID, vendor='ubiquiti')
        assert ev.vendor == 'ubiquiti'

    def test_vendor_defaults_to_generic(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.vendor == 'generic'

    def test_data_source_is_ipfix(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.data_source == 'ipfix'

    def test_event_type_is_traffic(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.event_type == 'traffic'

    def test_action_is_allow(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.action == 'allow'

    def test_src_ip(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.src_ip == '192.168.1.10'

    def test_dst_ip(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.dst_ip == '8.8.8.8'

    def test_src_port(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.src_port == 54321

    def test_dst_port(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.dst_port == 443

    def test_protocol_tcp(self):
        ev = normalize_ipfix(_flow(protocolIdentifier=6), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'tcp'
        assert ev.protocol_num == 6

    def test_protocol_udp(self):
        ev = normalize_ipfix(_flow(protocolIdentifier=17), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'udp'
        assert ev.protocol_num == 17

    def test_protocol_icmp(self):
        ev = normalize_ipfix(_flow(protocolIdentifier=1, sourceTransportPort=0, destinationTransportPort=0),
                             _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'icmp'

    def test_unknown_protocol_formatted(self):
        ev = normalize_ipfix(_flow(protocolIdentifier=89), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.protocol == 'ospf'

    def test_tenant_sensor_passthrough(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, 42, 7)
        assert ev.tenant_id == 42
        assert ev.sensor_id == 7


# ── Traffic metrics ───────────────────────────────────────────────────────────

class TestTrafficMetrics:
    def test_bytes_sent_from_octet_delta(self):
        ev = normalize_ipfix(_flow(octetDeltaCount=4096), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.bytes_sent == 4096

    def test_bytes_received_always_zero(self):
        """Standard IPFIX is unidirectional — bytes_received is always 0."""
        ev = normalize_ipfix(_flow(octetDeltaCount=9999), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.bytes_received == 0

    def test_packets_sent_from_packet_delta(self):
        ev = normalize_ipfix(_flow(packetDeltaCount=32), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.packets_sent == 32

    def test_packets_received_always_zero(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.packets_received == 0

    def test_duration_from_flow_duration_ms(self):
        ev = normalize_ipfix(_flow(flowDurationMilliseconds=10000), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.duration_ms == 10000

    def test_duration_computed_from_start_end_ms(self):
        start = _FLOW_START_MS
        end   = start + 7500
        f = _flow(flowDurationMilliseconds=None,
                  flowStartMilliseconds=start,
                  flowEndMilliseconds=end)
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.duration_ms == 7500

    def test_duration_none_when_zero(self):
        ev = normalize_ipfix(_flow(flowDurationMilliseconds=0), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.duration_ms is None

    def test_bytes_fallback_to_octet_total(self):
        f = _flow()
        del f['octetDeltaCount']
        f['octetTotalCount'] = 512
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.bytes_sent == 512

    def test_packets_fallback_to_packet_total(self):
        f = _flow()
        del f['packetDeltaCount']
        f['packetTotalCount'] = 4
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.packets_sent == 4


# ── Timestamp parsing ─────────────────────────────────────────────────────────

class TestTimestampParsing:
    def test_flow_start_milliseconds_preferred(self):
        ev = normalize_ipfix(_flow(flowStartMilliseconds=_FLOW_START_MS),
                             _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.time.year == 2026
        assert ev.time.month == 5
        assert ev.time.day == 19
        assert ev.time.hour == 9
        assert ev.time.minute == 59
        assert ev.time.second == 55
        assert ev.time.tzinfo == timezone.utc

    def test_flow_start_seconds_fallback(self):
        f = _flow()
        del f['flowStartMilliseconds']
        f['flowStartSeconds'] = _FLOW_START_S
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.time.hour == 9
        assert ev.time.minute == 59
        assert ev.time.second == 55

    def test_export_time_minus_duration_fallback(self):
        f = _flow(flowDurationMilliseconds=5000)
        del f['flowStartMilliseconds']
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        expected = _EXPORT_TIME - timedelta(milliseconds=5000)
        assert ev.time == expected

    def test_export_time_last_resort(self):
        f = {'sourceIPv4Address': '1.2.3.4', 'destinationIPv4Address': '5.6.7.8',
             'octetDeltaCount': 100, 'packetDeltaCount': 1}
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.time == _EXPORT_TIME

    def test_none_export_time_falls_back_to_now(self):
        f = {'sourceIPv4Address': '1.2.3.4', 'destinationIPv4Address': '5.6.7.8',
             'octetDeltaCount': 100, 'packetDeltaCount': 1}
        ev = normalize_ipfix(f, None, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.time is not None


# ── Interface handling ────────────────────────────────────────────────────────

class TestInterfaceHandling:
    def test_interface_name_preferred(self):
        ev = normalize_ipfix(_flow(interfaceName='GigabitEthernet0/0'),
                             _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.interface_src == 'GigabitEthernet0/0'

    def test_numeric_interface_formatted(self):
        ev = normalize_ipfix(_flow(ingressInterface=3), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.interface_src == 'if3'

    def test_no_interface_gives_none(self):
        f = _flow()
        del f['ingressInterface']
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.interface_src is None


# ── IPv6 support ──────────────────────────────────────────────────────────────

class TestIPv6:
    def test_ipv6_src(self):
        ev = normalize_ipfix(
            _flow(sourceIPv6Address='2001:db8::1', sourceIPv4Address=None),
            _EXPORT_TIME, TENANT_ID, SENSOR_ID
        )
        assert ev.src_ip == '2001:db8::1'

    def test_ipv6_dst(self):
        ev = normalize_ipfix(
            _flow(destinationIPv6Address='2001:4860:4860::8888', destinationIPv4Address=None),
            _EXPORT_TIME, TENANT_ID, SENSOR_ID
        )
        assert ev.dst_ip == '2001:4860:4860::8888'


# ── Null / edge cases ────────────────────────────────────────────────────────

class TestEdgeCases:
    def test_no_ip_returns_none(self):
        f = {'octetDeltaCount': 100, 'packetDeltaCount': 1}
        assert normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID) is None

    def test_only_src_ip_accepted(self):
        f = {'sourceIPv4Address': '1.2.3.4', 'octetDeltaCount': 100, 'packetDeltaCount': 1}
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev is not None
        assert ev.src_ip == '1.2.3.4'
        assert ev.dst_ip is None

    def test_no_security_fields_populated(self):
        """Generic IPFIX carries no threat/app/user data."""
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.threat_name is None
        assert ev.threat_severity is None
        assert ev.app_name is None
        assert ev.user_name is None
        assert ev.rule_name is None
        assert ev.web_category is None

    def test_raw_message_stored(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert ev.raw_message is not None
        assert len(ev.raw_message) > 0

    def test_raw_message_truncated_at_2000(self):
        f = _flow(interfaceName='x' * 3000)
        ev = normalize_ipfix(f, _EXPORT_TIME, TENANT_ID, SENSOR_ID)
        assert len(ev.raw_message) == 2000

    def test_vendor_cisco(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID, vendor='cisco')
        assert ev.vendor == 'cisco'

    def test_vendor_mikrotik(self):
        ev = normalize_ipfix(_flow(), _EXPORT_TIME, TENANT_ID, SENSOR_ID, vendor='mikrotik')
        assert ev.vendor == 'mikrotik'
