"""
Palo Alto PAN-OS Parser — normalizes PAN-OS 9.x–12.x syslog events
(IETF RFC 5424 format, CSV payload) into NormalizedEvent objects.

PAN-OS IETF syslog structure:
  <PRI>1 TIMESTAMP HOSTNAME - - - - CSV_DATA

CSV field positions are 0-indexed and match PAN-OS 9.x/10.x/11.x/12.x
documentation. All field accesses use _csv_get() to handle short log
lines or minor version differences gracefully.

Supported log types:
  TRAFFIC   — allow/deny flow records (primary data source)
  THREAT    — IPS, AV, URL filter, DNS, WildFire events
  AUTH      — authentication success/failure (field layout differs from TRAFFIC)
  GLOBALPROTECT — VPN connect/disconnect events

SYSTEM, CONFIG, HIPMATCH, DECRYPTION and other types are silently skipped.

Validated against PAN-OS 12.1.6 field documentation (PA-VM).
Live syslog validation pending licence activation on the test VM.
"""

from __future__ import annotations
import csv
import io
import re
import logging
from datetime import datetime, timezone
from typing import List, Optional

from event import NormalizedEvent

logger = logging.getLogger('ss.parser.paloalto')

# ── Log-type sets ─────────────────────────────────────────────────────────────
_SKIP_TYPES = frozenset({
    'SYSTEM', 'CONFIG', 'HIPMATCH', 'DECRYPTION', 'IPTAG', 'CORR',
})
_ALL_KNOWN = frozenset({
    'TRAFFIC', 'THREAT', 'AUTH', 'GLOBALPROTECT',
}) | _SKIP_TYPES

# Detection: PAN-OS CSV body always contains the log-type token at field [3]
_PANOS_TYPE_RE = re.compile(
    r',(?:TRAFFIC|THREAT|SYSTEM|CONFIG|HIPMATCH|GLOBALPROTECT|AUTH|DECRYPTION|IPTAG|CORR),'
)

# RFC 5424: <PRI>1 TIMESTAMP HOSTNAME APPNAME PROCID MSGID SD MSG
_RFC5424_RE = re.compile(
    r'^<\d+>1 \S+ \S+ \S+ \S+ \S+ (?:-|\[[^\]]*\]) (.*)',
    re.DOTALL,
)
_PRI_RE = re.compile(r'^<\d{1,3}>')


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_body(raw: str) -> str:
    """Strip RFC 5424 (or RFC 3164) header; return the CSV message body."""
    m = _RFC5424_RE.match(raw)
    if m:
        return m.group(1).strip()
    # RFC 3164 fallback — strip priority prefix only
    return _PRI_RE.sub('', raw).strip()


def _parse_csv_line(msg: str) -> List[str]:
    try:
        return next(csv.reader(io.StringIO(msg)))
    except Exception:
        return msg.split(',')


def _csv_get(fields: List[str], idx: int, default: str = '') -> str:
    try:
        return fields[idx].strip()
    except IndexError:
        return default


def _safe_int(val: str, default: int = 0) -> int:
    try:
        return int(val)
    except (ValueError, TypeError):
        return default


def _parse_timestamp(s: str) -> datetime:
    """Parse PAN-OS generated time ('2026/05/19 02:20:00') or ISO 8601."""
    for fmt in ('%Y/%m/%d %H:%M:%S', '%Y-%m-%dT%H:%M:%S.%f%z', '%Y-%m-%dT%H:%M:%S%z'):
        try:
            dt = datetime.strptime(s, fmt)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt
        except ValueError:
            continue
    return datetime.now(timezone.utc)


_PROTO_MAP = {
    'tcp': 'tcp', 'udp': 'udp', 'icmp': 'icmp', 'icmpv6': 'icmpv6',
    'esp': 'esp', 'ah': 'ah', 'gre': 'gre', 'sctp': 'sctp',
}

_ACTION_MAP = {
    'allow':          'allow',
    'allowed':        'allow',
    'alert':          'allow',
    'continue':       'allow',
    'override':       'allow',
    'deny':           'deny',
    'denied':         'deny',
    'drop':           'deny',
    'dropped':        'deny',
    'block':          'deny',
    'block-url':      'deny',
    'block-ip':       'deny',
    'block-continue': 'deny',
    'reset-client':   'reset',
    'reset-server':   'reset',
    'reset-both':     'reset',
}

_SEVERITY_MAP = {
    'critical':      'critical',
    'high':          'high',
    'medium':        'medium',
    'low':           'low',
    'informational': 'low',
}

# THREAT subtype → event_type
_THREAT_EVENT_MAP = {
    'vulnerability':  'threat',
    'virus':          'threat',
    'wildfire':       'threat',
    'wildfire-virus': 'threat',
    'spyware':        'threat',
    'dns':            'threat',
    'exploit':        'threat',
    'file':           'threat',
    'data':           'threat',
    'flood':          'threat',
    'scan':           'threat',
    'packet':         'threat',
    'url':            'web',
}

# App names that carry no useful classification
_GENERIC_APPS = frozenset({
    '', 'not-applicable', 'unknown', 'insufficient-data', 'n/a',
})

# Users that should be treated as anonymous
_ANON_USERS = frozenset({'', 'n/a', 'unknown', 'Unknown'})


# ── Field index constants (0-indexed, shared by TRAFFIC + THREAT) ────────────
_F_GENERATED_TIME = 6
_F_SRC_IP         = 7
_F_DST_IP         = 8
_F_RULE_NAME      = 11
_F_SRC_USER       = 12
_F_APP_NAME       = 14
_F_VSYS           = 15
_F_ZONE_SRC       = 16
_F_ZONE_DST       = 17
_F_INTF_SRC       = 18
_F_INTF_DST       = 19
_F_SRC_PORT       = 24
_F_DST_PORT       = 25
_F_PROTOCOL       = 29
_F_ACTION         = 30

# TRAFFIC-only fields beyond [30]
_F_BYTES_SENT     = 32
_F_BYTES_RECV     = 33
_F_ELAPSED_S      = 36
_F_PKTS_SENT      = 44
_F_PKTS_RECV      = 45

# THREAT-only fields beyond [30]
_F_THREAT_MISC    = 31   # URL or filename
_F_THREAT_NAME    = 32
_F_THREAT_CAT     = 33
_F_THREAT_SEV     = 34

# Device name (same index for both)
_F_DEVICE_NAME    = 52

# AUTH-specific (layout diverges from [7] onwards)
_F_AUTH_SRC_IP    = 7
_F_AUTH_SRC_PORT  = 8
_F_AUTH_ZONE_SRC  = 10
_F_AUTH_INTF_SRC  = 11
_F_AUTH_USER      = 18
_F_AUTH_EVENT     = 29

# GlobalProtect-specific
_F_GP_USER        = 12
_F_GP_PUBLIC_IP   = 15
_F_GP_PRIVATE_IP  = 17
_F_GP_PORTAL      = 33


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def is_paloalto_syslog(raw: str) -> bool:
    """Detect PAN-OS syslog by the known log-type token in the CSV body."""
    return bool(_PANOS_TYPE_RE.search(raw))


def normalize_syslog(raw_message: str, source_ip: str,
                     tenant_id: int, sensor_id: int) -> Optional[NormalizedEvent]:
    """
    Parse a raw PAN-OS syslog message and return a NormalizedEvent.
    Returns None for log types that carry no network event data.
    """
    msg    = raw_message if isinstance(raw_message, str) \
             else raw_message.decode('utf-8', errors='replace')
    body   = _extract_body(msg)
    fields = _parse_csv_line(body)

    log_type = _csv_get(fields, 3).upper()
    if log_type not in _ALL_KNOWN:
        return None
    if log_type in _SKIP_TYPES:
        return None

    subtype = _csv_get(fields, 4).lower()
    time    = _parse_timestamp(_csv_get(fields, _F_GENERATED_TIME))

    # ── Common fields (TRAFFIC + THREAT share positions [7]–[29]) ────────────
    src_ip        = _csv_get(fields, _F_SRC_IP)   or None
    dst_ip        = _csv_get(fields, _F_DST_IP)   or None
    rule_name     = _csv_get(fields, _F_RULE_NAME) or None
    user_name     = _csv_get(fields, _F_SRC_USER)
    if user_name.lower() in _ANON_USERS:
        user_name = None
    app_name      = _csv_get(fields, _F_APP_NAME)
    if app_name.lower() in _GENERIC_APPS:
        app_name = None
    zone_src      = _csv_get(fields, _F_ZONE_SRC)  or None
    zone_dst      = _csv_get(fields, _F_ZONE_DST)  or None
    interface_src = _csv_get(fields, _F_INTF_SRC)  or None
    interface_dst = _csv_get(fields, _F_INTF_DST)  or None
    src_port      = _safe_int(_csv_get(fields, _F_SRC_PORT)) or None
    dst_port      = _safe_int(_csv_get(fields, _F_DST_PORT)) or None
    proto_raw     = _csv_get(fields, _F_PROTOCOL).lower()
    protocol      = _PROTO_MAP.get(proto_raw, proto_raw) or None

    # Per-type defaults
    action           = 'allow'
    event_type       = 'traffic'
    bytes_sent       = 0
    bytes_received   = 0
    packets_sent     = 0
    packets_received = 0
    duration_ms      = None
    threat_name      = None
    threat_severity  = None
    threat_category  = None
    url              = None
    domain           = None
    web_category     = None
    vpn_policy_name  = None
    vpn_client_ip    = None

    if log_type == 'TRAFFIC':
        raw_action       = _csv_get(fields, _F_ACTION).lower()
        action           = _ACTION_MAP.get(raw_action, 'allow')
        bytes_sent       = _safe_int(_csv_get(fields, _F_BYTES_SENT))
        bytes_received   = _safe_int(_csv_get(fields, _F_BYTES_RECV))
        elapsed_s        = _safe_int(_csv_get(fields, _F_ELAPSED_S))
        duration_ms      = elapsed_s * 1000 if elapsed_s else None
        packets_sent     = _safe_int(_csv_get(fields, _F_PKTS_SENT))
        packets_received = _safe_int(_csv_get(fields, _F_PKTS_RECV))
        if subtype in ('drop', 'deny') or action in ('deny', 'drop', 'reset'):
            event_type = 'denied'

    elif log_type == 'THREAT':
        raw_action      = _csv_get(fields, _F_ACTION).lower()
        action          = _ACTION_MAP.get(raw_action, 'allow')
        url             = _csv_get(fields, _F_THREAT_MISC) or None
        threat_name     = _csv_get(fields, _F_THREAT_NAME) or None
        threat_category = _csv_get(fields, _F_THREAT_CAT)  or None
        threat_severity = _SEVERITY_MAP.get(_csv_get(fields, _F_THREAT_SEV).lower())
        event_type      = _THREAT_EVENT_MAP.get(subtype, 'threat')
        if event_type == 'web':
            web_category    = threat_category
            threat_category = None
        if url:
            m = re.match(r'(?:https?://)?([^/?#\s]+)', url)
            if m:
                domain = m.group(1)

    elif log_type == 'AUTH':
        # AUTH log field layout diverges from TRAFFIC at position [7]
        src_ip        = _csv_get(fields, _F_AUTH_SRC_IP)   or None
        src_port      = _safe_int(_csv_get(fields, _F_AUTH_SRC_PORT)) or None
        zone_src      = _csv_get(fields, _F_AUTH_ZONE_SRC) or None
        interface_src = _csv_get(fields, _F_AUTH_INTF_SRC) or None
        zone_dst      = None
        interface_dst = None
        dst_ip        = None
        dst_port      = None
        user_name     = _csv_get(fields, _F_AUTH_USER) or None
        if user_name and user_name.lower() in _ANON_USERS:
            user_name = None
        auth_event    = _csv_get(fields, _F_AUTH_EVENT).lower()
        action        = 'allow' if 'success' in auth_event else 'deny'
        event_type    = 'auth'

    elif log_type == 'GLOBALPROTECT':
        # GP log field layout is unique — no conventional src/dst fields
        user_name       = _csv_get(fields, _F_GP_USER)       or None
        vpn_client_ip   = _csv_get(fields, _F_GP_PUBLIC_IP)  or None
        private_ip      = _csv_get(fields, _F_GP_PRIVATE_IP) or None
        src_ip          = vpn_client_ip or private_ip
        vpn_policy_name = _csv_get(fields, _F_GP_PORTAL)     or None
        dst_ip          = None
        src_port        = None
        dst_port        = None
        zone_src        = None
        zone_dst        = None
        event_type      = 'vpn'
        action          = 'deny' if ('fail' in subtype or 'error' in subtype) else 'allow'

    device_name = _csv_get(fields, _F_DEVICE_NAME) or source_ip

    return NormalizedEvent(
        time             = time,
        tenant_id        = tenant_id,
        sensor_id        = sensor_id,
        vendor           = 'paloalto',
        data_source      = 'syslog',
        event_type       = event_type,
        action           = action,
        src_ip           = src_ip,
        dst_ip           = dst_ip,
        src_port         = src_port,
        dst_port         = dst_port,
        protocol         = protocol,
        bytes_sent       = bytes_sent,
        bytes_received   = bytes_received,
        packets_sent     = packets_sent,
        packets_received = packets_received,
        duration_ms      = duration_ms,
        user_name        = user_name,
        interface_src    = interface_src,
        interface_dst    = interface_dst,
        zone_src         = zone_src,
        zone_dst         = zone_dst,
        rule_name        = rule_name,
        app_name         = app_name,
        domain           = domain,
        url              = url,
        web_category     = web_category,
        threat_name      = threat_name,
        threat_category  = threat_category,
        threat_severity  = threat_severity,
        vpn_policy_name  = vpn_policy_name,
        vpn_client_ip    = vpn_client_ip,
        message          = f"[{log_type}/{subtype}] {device_name}",
        raw_message      = raw_message[:2000] if len(raw_message) > 2000 else raw_message,
    )
