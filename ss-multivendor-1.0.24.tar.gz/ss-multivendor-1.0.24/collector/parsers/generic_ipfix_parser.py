"""
Generic IPFIX Parser — normalizes standard IANA IPFIX/NetFlow v9 flows
from any vendor (Cisco, Ubiquiti, MikroTik, generic routers/switches)
into NormalizedEvent objects.

The shared IPFIXInput._decode_record() already decodes IANA field IDs
using sonicwall_templates.IANA_FIELDS for all non-SonicWall devices.
This parser maps those decoded field names to the NormalizedEvent schema.

Standard IPFIX is UNIDIRECTIONAL — each record covers one flow direction.
A TCP session A→B typically generates two records (A→B and B→A). For this
reason bytes_received is always 0; both directions appear as separate events
with bytes_sent populated. Reports show correct totals by summing all rows.

Standard IPFIX does NOT provide: application names, threat data, user
identity, URL categories, firewall rule names, or allow/deny action.
(Dropped flows are not exported — all records represent allowed traffic.)
These NormalizedEvent fields remain NULL.

Live validation target: Ubiquiti UniFi Dream Machine (IPFIX via UniFi
Settings → Teleport & VPN → NetFlow → collector IP + port 2055).
Field names confirmed from IANA IPFIX registry and sonicwall_templates.py.
"""

from __future__ import annotations
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from event import NormalizedEvent

logger = logging.getLogger('ss.parser.generic_ipfix')

_PROTO_MAP = {
    1: 'icmp', 6: 'tcp', 17: 'udp', 47: 'gre',
    50: 'esp', 51: 'ah', 58: 'icmpv6', 89: 'ospf',
}


def _safe_int(val, default: int = 0) -> int:
    try:
        return int(val) if val is not None else default
    except (TypeError, ValueError):
        return default


def _parse_time(flow: dict, export_time: Optional[datetime]) -> datetime:
    """
    Extract flow start time from IANA fields, in priority order:
    1. flowStartMilliseconds — epoch milliseconds, most precise
    2. flowStartSeconds — epoch seconds
    3. export_time - flowDurationMilliseconds — computed from export + duration
    4. export_time fallback
    """
    ms = flow.get('flowStartMilliseconds')
    if ms:
        try:
            return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(milliseconds=int(ms))
        except (OverflowError, OSError, ValueError):
            pass

    s = flow.get('flowStartSeconds')
    if s:
        try:
            return datetime.fromtimestamp(int(s), tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            pass

    dur_ms = flow.get('flowDurationMilliseconds')
    if dur_ms and export_time:
        try:
            return export_time - timedelta(milliseconds=int(dur_ms))
        except (OverflowError, ValueError):
            pass

    return export_time if export_time else datetime.now(timezone.utc)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def normalize_ipfix(flow: dict, export_time: Optional[datetime],
                    tenant_id: int, sensor_id: int,
                    source_ip: str = '',
                    vendor: str = 'generic') -> Optional[NormalizedEvent]:
    """
    Normalize a decoded IANA IPFIX flow dict into a NormalizedEvent.
    Returns None if the flow carries no usable source or destination IP.

    Args:
        flow:        Decoded field dict from IPFIXInput._decode_record()
        export_time: Packet export timestamp (used as fallback for flow time)
        tenant_id:   Default tenant — overwritten by TenantResolver in enrich_and_write
        sensor_id:   Default sensor — overwritten by TenantResolver in enrich_and_write
        source_ip:   IP of the device that sent the IPFIX packet (for logging)
        vendor:      sensors.vendor value ('cisco', 'ubiquiti', 'generic', etc.)
    """
    src_ip = (flow.get('sourceIPv4Address')
              or flow.get('sourceIPv6Address')
              or None)
    dst_ip = (flow.get('destinationIPv4Address')
              or flow.get('destinationIPv6Address')
              or None)

    if not src_ip and not dst_ip:
        return None

    src_port = _safe_int(flow.get('sourceTransportPort')) or None
    dst_port = _safe_int(flow.get('destinationTransportPort')) or None

    proto_num = _safe_int(flow.get('protocolIdentifier')) or None
    protocol  = _PROTO_MAP.get(proto_num, f'proto_{proto_num}') if proto_num else None

    # Bytes and packets — prefer delta counts, fall back to total counts
    bytes_sent   = _safe_int(flow.get('octetDeltaCount') or flow.get('octetTotalCount'))
    packets_sent = _safe_int(flow.get('packetDeltaCount') or flow.get('packetTotalCount'))

    # Duration — direct field, or computed from start/end milliseconds
    duration_ms = _safe_int(flow.get('flowDurationMilliseconds')) or None
    if not duration_ms:
        start_ms = flow.get('flowStartMilliseconds')
        end_ms   = flow.get('flowEndMilliseconds')
        if start_ms and end_ms:
            diff = _safe_int(end_ms) - _safe_int(start_ms)
            duration_ms = diff if diff > 0 else None

    # Interface — prefer name, fall back to numeric index
    intf_src = flow.get('interfaceName') or None
    if not intf_src:
        idx = flow.get('ingressInterface')
        if idx is not None:
            intf_src = f'if{int(idx)}'

    time = _parse_time(flow, export_time)

    return NormalizedEvent(
        time             = time,
        tenant_id        = tenant_id,
        sensor_id        = sensor_id,
        vendor           = vendor,
        data_source      = 'ipfix',
        event_type       = 'traffic',
        action           = 'allow',    # IPFIX only exports allowed flows
        src_ip           = src_ip,
        dst_ip           = dst_ip,
        src_port         = src_port,
        dst_port         = dst_port,
        protocol         = protocol,
        protocol_num     = proto_num,
        bytes_sent       = bytes_sent,
        bytes_received   = 0,          # standard IPFIX is unidirectional
        packets_sent     = packets_sent,
        packets_received = 0,
        duration_ms      = duration_ms,
        interface_src    = intf_src,
        raw_message      = str(flow)[:2000],
    )
