"""List the models a provider offers, using the saved API key (settings dropdown).

Names change often, so nothing is hardcoded: each vendor's own model list is fetched on
demand. The result only fills a suggestion list; the model field stays free text.
"""
from __future__ import annotations

import re

from reports.ai import net
from reports.ai.providers.base import _MODEL_RE, _MODEL_SLASH_RE

MAX_MODELS = 300
_URLS = {
    'anthropic': 'https://api.anthropic.com/v1/models?limit=100',
    'openai': 'https://api.openai.com/v1/models',
    'gemini': 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200',
    'openrouter': 'https://openrouter.ai/api/v1/models',
}
# OpenAI's list mixes in embeddings, speech, image and moderation models.
_OPENAI_SKIP = re.compile(r'embed|whisper|tts|dall-e|image|audio|realtime|transcribe|'
                          r'moderation|search|instruct|davinci|babbage|codex', re.I)


def _headers(provider: str, key: str) -> dict:
    if provider == 'anthropic':
        return {'x-api-key': key, 'anthropic-version': '2023-06-01'}
    if provider == 'gemini':
        return {'x-goog-api-key': key}
    return {'Authorization': f'Bearer {key}'}


def _rows(data: dict, field: str) -> list[dict]:
    rows = data.get(field)
    if not isinstance(rows, list):
        raise net.ProviderError('provider returned an unexpected response')
    return [r for r in rows if isinstance(r, dict)]


def parse_models(provider: str, data: dict) -> list[str]:
    """Pure: turn one provider's list response into sorted, valid, de-duplicated ids."""
    ids: list[str] = []
    if provider == 'gemini':
        for r in _rows(data, 'models'):
            if 'generateContent' in (r.get('supportedGenerationMethods') or []):
                ids.append(str(r.get('name', '')).removeprefix('models/'))
    elif provider == 'openrouter':
        for r in _rows(data, 'data'):
            if 'tools' in (r.get('supported_parameters') or []):
                ids.append(str(r.get('id', '')))
    else:
        for r in _rows(data, 'data'):
            ids.append(str(r.get('id', '')))
        if provider == 'openai':
            ids = [i for i in ids if not _OPENAI_SKIP.search(i)]
    rx = _MODEL_SLASH_RE if provider == 'openrouter' else _MODEL_RE
    return sorted({i for i in ids if rx.fullmatch(i)})[:MAX_MODELS]


def list_models(provider: str, api_key: str) -> list[str]:
    if provider not in _URLS:
        raise net.ProviderError('choose a supported provider')
    data = net.get_json(_URLS[provider], _headers(provider, api_key), secrets=[api_key])
    return parse_models(provider, data)
