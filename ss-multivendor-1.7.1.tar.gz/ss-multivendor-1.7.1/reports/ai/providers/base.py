"""Provider-neutral types shared by all adapters and the agent loop."""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Protocol

from reports.ai.net import ProviderError

_MODEL_RE = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,99}')
_MAX_SANE_INT = 10 ** 12


@dataclass(frozen=True)
class ToolSpec:
    name: str
    description: str
    parameters: dict


@dataclass(frozen=True)
class ToolCall:
    id: str
    name: str
    arguments: dict
    meta: dict | None = None


@dataclass(frozen=True)
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0


@dataclass(frozen=True)
class Turn:
    text: str
    tool_calls: tuple[ToolCall, ...]
    usage: Usage


class Provider(Protocol):
    name: str

    def complete(self, *, api_key: str, model: str, system: str, messages: list[dict],
                 tools: list[ToolSpec], max_tokens: int = 2048) -> Turn: ...

    def test(self, *, api_key: str, model: str) -> None: ...


_MODEL_SLASH_RE = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,59}/[A-Za-z0-9][A-Za-z0-9._:-]{0,59}')


def validate_model(model: str, allow_slash: bool = False) -> str:
    """``allow_slash`` is for OpenRouter, whose ids are always ``vendor/model``."""
    if allow_slash:
        if not isinstance(model, str) or not _MODEL_SLASH_RE.fullmatch(model):
            raise ProviderError("OpenRouter model ids look like 'vendor/model', "
                                "for example openai/gpt-4o")
        return model
    if not isinstance(model, str) or not _MODEL_RE.fullmatch(model):
        raise ProviderError('invalid model name')
    return model


def unexpected() -> ProviderError:
    return ProviderError('provider returned an unexpected response')


def as_int(value: object) -> int:
    """Return a usage counter as int, or 0 for anything that is not a sane number."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return 0
    if isinstance(value, float) and not math.isfinite(value):
        return 0
    if not 0 <= value <= _MAX_SANE_INT:
        return 0
    return int(value)


def make_tool_call(id: object, name: object, arguments: object,
                   meta: dict | None = None) -> ToolCall:
    """Build a ToolCall from provider data, rejecting malformed fields."""
    if not isinstance(id, str) or not id:
        raise unexpected()
    if not isinstance(name, str) or not name:
        raise unexpected()
    if not isinstance(arguments, dict):
        raise unexpected()
    return ToolCall(id=id, name=name, arguments=arguments, meta=meta)
