"""AI provider adapters (Anthropic, OpenAI, Gemini, OpenRouter)."""
from __future__ import annotations

import importlib

from reports.ai.providers.base import Provider

PROVIDER_NAMES = ('anthropic', 'openai', 'gemini', 'openrouter')
_CLASSES = {
    'anthropic': ('reports.ai.providers.anthropic', 'AnthropicProvider'),
    'openai': ('reports.ai.providers.openai', 'OpenAIProvider'),
    'gemini': ('reports.ai.providers.gemini', 'GeminiProvider'),
    'openrouter': ('reports.ai.providers.openrouter', 'OpenRouterProvider'),
}


def get_provider(name: str) -> Provider:
    if name not in _CLASSES:
        raise ValueError(f'unknown provider: {name}')
    module, cls = _CLASSES[name]
    return getattr(importlib.import_module(module), cls)()
