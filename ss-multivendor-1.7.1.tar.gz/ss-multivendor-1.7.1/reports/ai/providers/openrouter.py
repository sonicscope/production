"""OpenRouter adapter: the OpenAI Chat Completions wire format at a different endpoint.

Model ids are ``vendor/model`` (e.g. ``anthropic/claude-x``), so a slash is allowed here.
No Referer/X-Title headers are sent: nothing about the install is disclosed.
"""
from __future__ import annotations

from reports.ai import net
from reports.ai.providers.base import ToolSpec, Turn, validate_model
from reports.ai.providers.openai import OpenAIProvider

URL = 'https://openrouter.ai/api/v1/chat/completions'


class OpenRouterProvider(OpenAIProvider):
    name = 'openrouter'

    def build_request(self, model: str, system: str, messages: list[dict],
                      tools: list[ToolSpec], max_tokens: int) -> dict:
        body = super().build_request(model, system, messages, tools, max_tokens)
        # OpenRouter documents max_tokens; it is accepted by every routed model.
        body['max_tokens'] = body.pop('max_completion_tokens')
        return body

    def complete(self, *, api_key: str, model: str, system: str, messages: list[dict],
                 tools: list[ToolSpec], max_tokens: int = 2048) -> Turn:
        validate_model(model, allow_slash=True)
        body = self.build_request(model, system, messages, tools, max_tokens)
        data = net.post_json(URL, {'Authorization': f'Bearer {api_key}'}, body,
                             secrets=[api_key])
        return self.parse_response(data)
