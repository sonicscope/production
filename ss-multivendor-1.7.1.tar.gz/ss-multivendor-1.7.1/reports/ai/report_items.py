"""Pure shaping of frozen finding evidence into PDF exhibits (Stage 3 spec §3).

No DB, no Flask, no WeasyPrint. Output strings are NOT escaped here: the Jinja template
autoescapes every value. Nothing here executes a query.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

ROW_LIMITS = (10, 25, 100)
DEFAULT_ROW_LIMIT = 25
MAX_ITEMS = 25
MAX_COLS = 12
CELL_MAX = 200
QUESTION_MAX = 300
# Total print budget for one report (checked before rendering; WeasyPrint time grows fast with
# table size and a gunicorn worker keeps rendering after the proxy gives up).
MAX_REPORT_ROWS = 500
MAX_REPORT_CELLS = 5000
MAX_REPORT_CHARS = 250000


def exhibit_letter(i: int) -> str:
    """0 -> A ... 25 -> Z, 26 -> AA, 27 -> AB ... (bijective base-26)."""
    n, out = i + 1, ''
    while n > 0:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


def _clip(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[:limit - 1] + '…'


_ISO_TS = re.compile(r'^(\d{4}-\d\d-\d\d)T(\d\d:\d\d:\d\d)(?:\.\d+)?(\+00:00|Z)?$')


def _cell(v) -> str:
    if v is None:
        return ''
    text = str(v)
    m = _ISO_TS.match(text)
    if m:                                    # compact, readable timestamps (UTC kept explicit)
        return f"{m.group(1)} {m.group(2)}" + (' UTC' if m.group(3) else '')
    return _clip(text, CELL_MAX)


def _when(raw) -> str:
    if not isinstance(raw, str) or not raw:
        return ''
    try:
        dt = datetime.fromisoformat(raw)
    except ValueError:
        return raw[:40]
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc)
    return dt.strftime('%Y-%m-%d %H:%M UTC')


def _int(v, default: int = 0) -> int:
    return v if type(v) is int and v >= 0 else default


def build_exhibits(items: list[dict]) -> list[dict]:
    out: list[dict] = []
    for idx, item in enumerate(items):
        f = item['finding']
        ev = f.get('evidence') if isinstance(f.get('evidence'), dict) else {}
        lim = item.get('row_limit')
        limit = lim if type(lim) is int and lim in ROW_LIMITS else DEFAULT_ROW_LIMIT
        cols_raw = ev.get('columns') if isinstance(ev.get('columns'), list) else []
        rows_raw = ev.get('rows') if isinstance(ev.get('rows'), list) else []
        ncols = min(len(cols_raw), MAX_COLS)
        columns = [_cell(c) for c in cols_raw[:ncols]]
        rows = [[_cell(v) for v in (r[:ncols] if isinstance(r, (list, tuple)) else [])]
                for r in rows_raw[:limit]]
        total = max(_int(ev.get('row_count'), 0), len(rows_raw))
        notes: list[str] = []
        if total > len(rows):
            notes.append(f'Showing {len(rows)} of {total} rows')
        if ev.get('truncated'):
            notes.append('The saved snapshot was limited to 500 rows.')
        if len(cols_raw) > ncols:
            notes.append(f'{len(cols_raw) - ncols} more columns omitted')
        kind = f.get('evidence_kind')
        q = item.get('question')
        out.append({
            'letter': exhibit_letter(idx), 'finding_id': f.get('id'),
            'title': f.get('title') or '', 'note': f.get('note') or '',
            # Only a stored query has an originating turn; timelines never carry a question.
            'question': _clip(q, QUESTION_MAX) if kind == 'query' and isinstance(q, str) and q
            else None,
            'kind': kind,
            'frozen_at': _when(ev.get('snapshot_at') if kind == 'query' else ev.get('generated_at')),
            'subject': str(ev.get('subject')) if kind == 'timeline' and ev.get('subject') else None,
            'window': str(ev.get('window')) if kind == 'timeline' and ev.get('window') else None,
            'columns': columns, 'rows': rows, 'shown': len(rows), 'total': total, 'notes': notes,
        })
    return out


def print_totals(exhibits: list[dict]) -> tuple[int, int, int]:
    """(rows, cells, characters) that these shaped exhibits will actually print.

    Uses the output of build_exhibits, so row limits and CELL_MAX/MAX_COLS clipping are
    already applied. Characters count column headings and cell text.
    """
    rows = cells = chars = 0
    for ex in exhibits:
        cols = ex.get('columns') or []
        body = ex.get('rows') or []
        rows += len(body)
        cells += len(body) * len(cols)
        chars += sum(len(c) for c in cols)
        chars += sum(len(v) for r in body for v in r)
    return rows, cells, chars


def budget_error(exhibits: list[dict]) -> str | None:
    """A user-actionable message when the report would print too much, else None."""
    rows, cells, chars = print_totals(exhibits)
    for used, limit, what in ((rows, MAX_REPORT_ROWS, 'rows'), (cells, MAX_REPORT_CELLS, 'cells'),
                              (chars, MAX_REPORT_CHARS, 'characters')):
        if used > limit:
            return (f'This report would print too much evidence (limit {limit} {what}). '
                    'Select fewer findings or lower the rows per finding.')
    return None
