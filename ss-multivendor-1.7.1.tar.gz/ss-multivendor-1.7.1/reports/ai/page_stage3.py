"""Stage 3 UI fragments for the Investigate page: findings selection + "Generate report" dialog.

JS shares the page IIFE scope (see page_stage2.STAGE2_JS) and follows its timeline-dialog pattern.
"""
from __future__ import annotations

TRAY_FOOTER_HTML = (
    '<div class="tray-foot"><button type="button" id="report-open" class="btn btn-sm btn-ss" disabled '
    'aria-describedby="report-hint">Generate report</button>'
    '<div id="report-hint" class="meta">Select at least one finding.</div></div>')

STAGE3_CSS = """
#inv .f-pickrow{display:flex;gap:.75rem;align-items:center;flex-wrap:wrap;}
#inv .f-pick{display:inline-flex;gap:.35rem;align-items:center;margin:0;}
#inv .f-limit{max-width:110px;}
#inv .tray-foot{display:flex;flex-direction:column;gap:.35rem;margin-top:.75rem;}
#inv .tray-foot .meta{font-size:.75rem;color:#8BA3C0;}
#inv .f-pick input:focus-visible,#inv .f-limit:focus-visible,#inv .tray-foot .btn:focus-visible{outline:2px solid #378ADD;outline-offset:2px;}
#inv .rp-overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:1050;display:flex;align-items:center;justify-content:center;padding:1rem;}
#inv .rp-panel{background:var(--bs-body-bg,#0f1b2d);border:1px solid rgba(139,163,192,.4);border-radius:8px;padding:1rem;width:min(720px,100%);max-height:90vh;overflow-y:auto;display:flex;flex-direction:column;gap:.5rem;}
#inv .rp-panel .meta{font-size:.75rem;color:#8BA3C0;}
#inv .rp-form{display:flex;flex-direction:column;gap:.5rem;}
#inv .rp-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:.5rem;}
#inv .rp-item{border:1px solid rgba(139,163,192,.25);border-radius:6px;padding:.5rem;display:flex;gap:.5rem;align-items:center;justify-content:space-between;flex-wrap:wrap;}
#inv .rp-item .rp-text{overflow-wrap:anywhere;}
#inv .rp-item .rp-limit{width:auto;}
#inv .rp-item .rp-acts,#inv .rp-foot,#inv .rp-result{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;}
#inv .rp-pick-body{display:flex;flex-direction:column;gap:.5rem;margin-top:.5rem;}
#inv .rp-inv-toggle{text-align:left;overflow-wrap:anywhere;}
#inv .rp-inv-findings{display:flex;flex-direction:column;gap:.25rem;padding-left:.75rem;}
#inv .rp-add{display:flex;gap:.5rem;align-items:center;margin:0;overflow-wrap:anywhere;}
#inv .rp-panel .btn:focus-visible,#inv .rp-panel select:focus-visible,#inv .rp-panel input:focus-visible,#inv .rp-panel textarea:focus-visible,#inv .rp-panel h2:focus-visible,#inv .rp-panel summary:focus-visible,#inv .rp-panel a:focus-visible{outline:2px solid #378ADD;outline-offset:2px;}
@media (max-width:575.98px){#inv .rp-overlay{padding:0;align-items:stretch;}#inv .rp-panel{max-height:100vh;border-radius:0;}#inv .rp-panel .btn,#inv .rp-panel select,#inv .rp-panel input[type="text"],#inv .rp-panel summary,#inv .f-limit,#inv .tray-foot .btn{min-height:44px;}}
@media (prefers-reduced-motion:reduce){#inv .rp-overlay,#inv .rp-panel{transition:none;}}
"""

STAGE3_JS = r"""
  // ---- Stage 3: findings selection + "Generate report" dialog ----
  var reportOpenBtn = document.getElementById('report-open');
  var reportHint = document.getElementById('report-hint');
  var RP_MAX_ITEMS = 25, RP_MAX_INVS = 50, RP_MAX_ROWS = 500, RP_LIMITS = [10, 25, 100];
  var rpSel = new Map();        // finding id -> {checked, limit, inv, title, rows}; Map order = report order
  var rpSelInv = null;          // investigation the tray selection belongs to
  var rpOpen = null;            // {overlay, opener, seq}

  // Bijective base-26, identical to the server: 0 -> A ... 25 -> Z, 26 -> AA.
  function exhibitLetter(i) {
    var n = i + 1, s = '';
    while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); }
    return s;
  }
  function rpSelected() {
    var out = [];
    rpSel.forEach(function (e, fid) { if (e.checked) { out.push({ fid: fid, e: e }); } });
    return out;
  }
  // Rows a finding can print (the server prints min(limit, stored rows)); read-only hint only.
  function rpAvail(f) {
    var ev = f.evidence || {};
    return Array.isArray(ev.rows) ? ev.rows.length : (Number(ev.row_count) || 0);
  }
  function rpFinding(fid) {
    var r = current ? current.findings.filter(function (x) { return x.id === fid; }) : [];
    return r.length ? r[0] : null;
  }
  function rpFoot() {
    var n = rpSelected().length;
    reportOpenBtn.disabled = n === 0;
    reportHint.textContent = n ? n + ' selected' : 'Select at least one finding.';
  }
  // Add the checkbox + row-limit selector to every card that lacks one, and re-apply saved state.
  function decorateCards() {
    Array.prototype.forEach.call(trayList.querySelectorAll('.finding'), function (card) {
      var fid = Number(card.getAttribute('data-fid'));
      if (!card.querySelector('.f-pick')) {
        var row = el('div', 'f-pickrow');
        var lab = el('label', 'f-pick'); var cb = el('input'); cb.type = 'checkbox';
        lab.appendChild(cb); lab.appendChild(document.createTextNode(' Include in report'));
        var lim = el('select', 'form-select form-select-sm f-limit');
        RP_LIMITS.forEach(function (n) { var o = el('option', '', n + ' rows'); o.value = String(n); lim.appendChild(o); });
        lim.value = '25';
        cb.addEventListener('change', function () {
          var f = rpFinding(fid), old = rpSel.get(fid);
          if (cb.checked && !f) { cb.checked = false; }
          if (cb.checked && f) {
            rpSel.delete(fid);
            rpSel.set(fid, { checked: true, limit: Number(lim.value), inv: current.id, title: f.title, rows: Number((f.evidence || {}).row_count) || 0, avail: rpAvail(f) });
          } else if (old) { old.checked = false; }
          lim.disabled = !cb.checked; rpFoot();
        });
        lim.addEventListener('change', function () { var e = rpSel.get(fid); if (e) { e.limit = Number(lim.value); } });
        row.appendChild(lab); row.appendChild(lim);
        var before = card.querySelector('.f-actions') || card.lastElementChild;
        card.insertBefore(row, before);
      }
      var st = rpSel.get(fid), on = !!(st && st.checked);
      var ft = rpFinding(fid), ttl = ft ? ft.title : '';
      card.querySelector('.f-pick input').setAttribute('aria-label', 'Include in report: ' + ttl);
      card.querySelector('.f-limit').setAttribute('aria-label', 'Rows to print: ' + ttl);
      card.querySelector('.f-pick input').checked = on;
      var sl = card.querySelector('.f-limit'); sl.value = String(st ? st.limit : 25); sl.disabled = !on;
    });
  }
  var origSync = syncTray;
  syncTray = function (replaceId) {
    origSync(replaceId);
    var inv = current ? current.id : null;
    if (inv !== rpSelInv) { rpSel.clear(); rpSelInv = inv; }
    else if (current) {                                   // forget findings deleted since they were ticked
      var gone = [];
      rpSel.forEach(function (e, fid) { if (e.inv === current.id && !rpFinding(fid)) { gone.push(fid); } });
      gone.forEach(function (fid) { rpSel.delete(fid); });
    }
    decorateCards(); rpFoot();
  };
  syncTray();

  function closeReport() {
    if (!rpOpen) { return; }
    var t = rpOpen; rpOpen = null; t.seq = -1;
    t.overlay.remove();
    if (t.opener && t.opener.isConnected && !t.opener.disabled) { t.opener.focus(); }
    else if (!reportOpenBtn.disabled) { reportOpenBtn.focus(); }
    else { trayHeading.focus(); }
  }
  function openReport(opener) {
    closeReport();
    if (!current || !rpSelected().length) { return; }
    var tenant = Number(tenantSel.value);
    var overlay = el('div', 'rp-overlay');
    var dg = el('div', 'rp-panel');
    dg.setAttribute('role', 'dialog'); dg.setAttribute('aria-modal', 'true'); dg.setAttribute('aria-labelledby', 'rp-heading');
    var h = el('h2', 'h6', 'Generate report'); h.id = 'rp-heading'; h.tabIndex = -1;
    var msg = el('div', 'meta'); msg.setAttribute('role', 'status'); msg.setAttribute('aria-live', 'polite');
    var form = el('div', 'rp-form'), result = el('div', 'rp-result');
    var t = { overlay: overlay, opener: opener, seq: 0 }; rpOpen = t;

    var tLab = el('label', 'form-label small mb-0', 'Report title'); tLab.htmlFor = 'rp-title';
    var titleIn = el('input', 'form-control form-control-sm'); titleIn.id = 'rp-title'; titleIn.type = 'text';
    titleIn.maxLength = 200; titleIn.value = current.title;
    var sLab = el('label', 'form-label small mb-0', 'Executive summary (optional)'); sLab.htmlFor = 'rp-summary';
    var sumIn = el('textarea', 'form-control form-control-sm'); sumIn.id = 'rp-summary'; sumIn.rows = 5; sumIn.maxLength = 2000;
    var counter = el('div', 'meta', '0 / 2000');
    sumIn.addEventListener('input', function () { counter.textContent = sumIn.value.length + ' / 2000'; });
    var listHead = el('h3', 'h6 mb-0', 'Findings in this report');
    var ol = el('ol', 'rp-list');

    var pk = el('details', 'rp-pick'); pk.appendChild(el('summary', '', 'Add findings from other investigations'));
    var pkBody = el('div', 'rp-pick-body'); pk.appendChild(pkBody);
    var pkCache = {}, pkBoxes = {}, pkStarted = false;
    var curId = current.id;                      // captured at open: `current` may be swapped meanwhile

    var budget = el('div', 'meta rp-budget');
    var genBtn = btn('Generate report', 'btn-ss'), cancelBtn = btn('Cancel');
    var emptyHint = el('span', 'meta rp-empty');
    var foot = el('div', 'rp-foot'); foot.appendChild(genBtn); foot.appendChild(cancelBtn); foot.appendChild(emptyHint);
    cancelBtn.addEventListener('click', closeReport);

    function renderBudget() {      // read-only hint; the server enforces the real limits
      var n = 0;
      rpSelected().forEach(function (x) { n += Math.min(x.e.limit, x.e.avail === undefined ? x.e.rows : x.e.avail); });
      budget.textContent = n + ' of ' + RP_MAX_ROWS + ' rows' + (n > RP_MAX_ROWS ? ' \u2014 over the limit; select fewer findings or fewer rows' : '');
    }
    function renderList() {
      clearNode(ol);
      var items = rpSelected();
      renderBudget();
      genBtn.disabled = !items.length;
      emptyHint.textContent = items.length ? '' : 'Select at least one finding.';
      if (!items.length) { ol.appendChild(el('li', 'meta', 'No findings selected.')); return; }
      items.forEach(function (it, i) {
        var e = it.e, f = (current && e.inv === current.id) ? rpFinding(it.fid) : null;
        if (f) { e.title = f.title; e.rows = Number((f.evidence || {}).row_count) || 0; e.avail = rpAvail(f); }
        var li = el('li', 'rp-item');
        li.appendChild(el('span', 'rp-text', 'Exhibit ' + exhibitLetter(i) + ' · ' + e.title + ' · ' + e.rows + (e.rows === 1 ? ' row' : ' rows')));
        var acts = el('span', 'rp-acts');
        var sel = el('select', 'form-select form-select-sm rp-limit');
        sel.setAttribute('aria-label', 'Rows to print: ' + e.title);
        RP_LIMITS.forEach(function (n) { var o = el('option', '', n + ' rows'); o.value = String(n); sel.appendChild(o); });
        sel.value = String(e.limit);
        sel.addEventListener('change', function () { e.limit = Number(sel.value); decorateCards(); renderBudget(); });
        acts.appendChild(sel);
        var up = btn('Move up'), dn = btn('Move down'), rm = btn('Remove');
        up.className += ' rp-up'; dn.className += ' rp-down'; rm.className += ' rp-rm';
        up.setAttribute('aria-label', 'Move up: ' + e.title); dn.setAttribute('aria-label', 'Move down: ' + e.title);
        rm.setAttribute('aria-label', 'Remove: ' + e.title);
        up.disabled = i === 0; dn.disabled = i === items.length - 1;
        up.addEventListener('click', function () { move(it.fid, -1, 'up'); });
        dn.addEventListener('click', function () { move(it.fid, 1, 'down'); });
        rm.addEventListener('click', function () { removeItem(it.fid, i); });
        acts.appendChild(up); acts.appendChild(dn); acts.appendChild(rm); li.appendChild(acts); ol.appendChild(li);
      });
    }
    function move(fid, dir, which) {
      var arr = rpSelected(), i = -1;
      arr.forEach(function (x, k) { if (x.fid === fid) { i = k; } });
      var j = i + dir;
      if (i < 0 || j < 0 || j >= arr.length) { return; }
      var tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
      var rest = [];
      rpSel.forEach(function (e, k) { if (!e.checked) { rest.push({ fid: k, e: e }); } });
      rpSel.clear();
      arr.concat(rest).forEach(function (x) { rpSel.set(x.fid, x.e); });
      renderList();
      var li = ol.children[j];
      var target = li.querySelector(which === 'up' ? '.rp-up' : '.rp-down');
      if (target.disabled) { target = li.querySelector(which === 'up' ? '.rp-down' : '.rp-up'); }
      target.focus();
    }
    function removeItem(fid, idx) {
      var e = rpSel.get(fid);
      if (e && current && e.inv === current.id) { e.checked = false; } else { rpSel.delete(fid); }
      decorateCards(); rpFoot(); renderList(); renderPicks();
      var rms = ol.querySelectorAll('.rp-rm');
      if (rms.length) { rms[Math.min(idx, rms.length - 1)].focus(); } else { titleIn.focus(); }
      msg.textContent = 'Removed from the report.';
    }

    // "Add findings from other investigations": same tenant only, loaded lazily on expand.
    function renderPick(id) {
      var box = pkBoxes[id]; if (!box || !pkCache[id]) { return; }
      clearNode(box);
      var fs = pkCache[id].filter(function (f) { var s = rpSel.get(f.id); return !(s && s.checked); });
      if (!fs.length) { box.appendChild(el('div', 'meta', 'No more findings to add.')); return; }
      fs.forEach(function (f) {
        var lab = el('label', 'rp-add'); var cb = el('input'); cb.type = 'checkbox';
        var rows = Number((f.evidence || {}).row_count) || 0;
        lab.appendChild(cb); lab.appendChild(document.createTextNode(f.title + ' · ' + rows + (rows === 1 ? ' row' : ' rows')));
        cb.addEventListener('change', function () {
          if (!cb.checked) { return; }
          if (rpSelected().length >= RP_MAX_ITEMS) { cb.checked = false; msg.textContent = 'Select at most 25 findings.'; return; }
          rpSel.delete(f.id);
          rpSel.set(f.id, { checked: true, limit: 25, inv: id, title: f.title, rows: rows, avail: rpAvail(f) });
          rpFoot(); renderList(); renderPicks();
          msg.textContent = 'Added to the report as Exhibit ' + exhibitLetter(rpSelected().length - 1) + '.';
          var nb = box.querySelector('input'); if (nb) { nb.focus(); } else { pkBoxes[id].previousSibling.focus(); }
        });
        box.appendChild(lab);
      });
    }
    function renderPicks() { Object.keys(pkBoxes).forEach(function (id) { renderPick(id); }); }
    function loadInv(id, box) {
      box.textContent = 'Loading…';
      api('GET', '/investigate/' + id).then(function (d) {
        if (rpOpen !== t) { return; }
        if (!d.investigation || Number(d.investigation.tenant_id) !== tenant) { box.textContent = 'Not available.'; return; }
        pkCache[id] = d.findings || []; renderPick(id);
      }).catch(function (e) {
        if (rpOpen !== t) { return; }
        box.textContent = 'Could not load findings.'; msg.textContent = e.message;
      });
    }
    function loadPicker() {
      pkBody.textContent = 'Loading…';
      var railAll = document.getElementById('rail-all');
      var tabs = ['mine', 'shared'];
      if (railAll && !railAll.classList.contains('d-none')) { tabs.push('all'); }   // admins can open every investigation
      Promise.all(tabs.map(function (tab) {
        return api('GET', '/investigate/list?tab=' + tab).then(function (j) { return j.items || []; });
      })).then(function (lists) {
        if (rpOpen !== t) { return; }
        var seen = {}, items = [];
        lists.forEach(function (l) {
          l.forEach(function (i) {
            if (seen[i.id] || Number(i.tenant_id) !== tenant || i.id === curId || !i.finding_count) { return; }
            seen[i.id] = true; items.push(i);
          });
        });
        clearNode(pkBody);
        if (!items.length) { pkBody.appendChild(el('div', 'meta', 'No other investigations with findings for this customer.')); return; }
        items.slice(0, RP_MAX_INVS).forEach(function (i) {
          var tb = btn(i.title + ' · ' + i.finding_count + ' finding(s)'); tb.className += ' rp-inv-toggle';
          tb.setAttribute('aria-expanded', 'false');
          var box = el('div', 'rp-inv-findings'); box.hidden = true; pkBoxes[i.id] = box;
          tb.addEventListener('click', function () {
            var open = box.hidden; box.hidden = !open; tb.setAttribute('aria-expanded', open ? 'true' : 'false');
            if (open && !pkCache[i.id]) { loadInv(i.id, box); }
          });
          pkBody.appendChild(tb); pkBody.appendChild(box);
        });
      }).catch(function (e) {
        if (rpOpen !== t) { return; }
        pkStarted = false; clearNode(pkBody); msg.textContent = e.message;      // retry on next expand
      });
    }
    pk.addEventListener('toggle', function () { if (pk.open && !pkStarted) { pkStarted = true; loadPicker(); } });

    function setBusy(b) { genBtn.disabled = b || !rpSelected().length; cancelBtn.disabled = b; }
    function submit() {
      var title = titleIn.value.trim(), items = rpSelected();
      if (!title) { msg.textContent = 'Enter a report title.'; titleIn.focus(); return; }
      if (!items.length) { msg.textContent = 'Select at least one finding.'; return; }
      if (items.length > RP_MAX_ITEMS) { msg.textContent = 'Select at most 25 findings.'; return; }
      var seq = ++t.seq; setBusy(true); msg.textContent = 'Generating…';
      api('POST', '/investigate/report', { title: title, summary: sumIn.value,
        items: items.map(function (x) { return { finding_id: x.fid, row_limit: x.e.limit }; }) }).then(function (j) {
        if (rpOpen !== t || t.seq !== seq) { return; }
        var url = j && j.download_url;
        if (typeof url !== 'string' || url.indexOf('/reports/') !== 0) {
          msg.textContent = 'The server returned an unexpected download link.'; setBusy(false); return;
        }
        form.remove();
        msg.textContent = 'Report generated';
        var a = el('a', 'btn btn-sm btn-ss', 'Download report'); a.href = url;
        var done = btn('Close'); done.addEventListener('click', closeReport);
        result.appendChild(a); result.appendChild(done);
        rpSel.clear(); decorateCards(); rpFoot();
        a.focus(); loadFindings();
      }).catch(function (e) {
        if (rpOpen !== t || t.seq !== seq) { return; }
        msg.textContent = e.message; setBusy(false);
      });
    }
    genBtn.addEventListener('click', submit);

    [tLab, titleIn, sLab, sumIn, counter, listHead, ol, budget, pk, foot].forEach(function (n) { form.appendChild(n); });
    dg.appendChild(h); dg.appendChild(msg); dg.appendChild(form); dg.appendChild(result);
    overlay.appendChild(dg); root.appendChild(overlay);
    renderList();
    function usable(x) {
      if (x.disabled) { return false; }
      for (var p = x.parentElement; p && p !== dg; p = p.parentElement) {
        if (p.hidden) { return false; }
        if (p.tagName === 'DETAILS' && !p.open && !(x.tagName === 'SUMMARY' && x.parentElement === p)) { return false; }
      }
      return true;
    }
    dg.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { e.stopPropagation(); closeReport(); return; }
      if (e.key !== 'Tab') { return; }
      var f = Array.prototype.filter.call(dg.querySelectorAll('select, input, textarea, button, a[href], summary'), usable);
      if (!f.length) { return; }
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === h)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
    overlay.addEventListener('click', function (e) { if (e.target === overlay) { closeReport(); } });
    h.focus();
  }
  reportOpenBtn.addEventListener('click', function () { openReport(reportOpenBtn); });
"""
