"""Deterministic evidence-timeline SQL for one IP (spec §5). Not model-written.

The IP is validated with ipaddress and inlined as a quoted inet literal (the Stage 1
executor runs without bind parameters); the window comes from a fixed map.
"""
from __future__ import annotations

import ipaddress
import re

WINDOWS = {'1h': '1 hour', '24h': '24 hours', '7d': '7 days', '31d': '31 days'}
DENIED_ACTIONS = ('deny', 'drop', 'block', 'reset')
ROWS_MAX = 500                  # rows returned / pinned
LIMIT = ROWS_MAX + 1            # one extra row so truncation can be detected
_IP_CHARS = re.compile(r'[0-9A-Fa-f:.]+')
_BAD_IP = 'Enter a valid IP address.'
COLUMNS = ('time', 'kind', 'action', 'src_ip', 'dst_ip', 'dst_port', 'protocol', 'rule_name',
           'threat_or_app', 'country')


def normalize_ip(ip: str) -> str:
    """Return the canonical plain IP text (IPv4-mapped IPv6 -> IPv4); ValueError otherwise.

    The text is inlined into SQL, so it is restricted to [0-9A-Fa-f:.] before parsing (this
    rejects IPv6 scope ids such as ``%eth0``, quotes, whitespace, NUL and non-ASCII digits)
    and re-checked after normalising. Only plain ASCII spaces are stripped.
    """
    if not isinstance(ip, str):
        raise ValueError(_BAD_IP)
    s = ip.strip(' ')
    if not _IP_CHARS.fullmatch(s):
        raise ValueError(_BAD_IP)
    try:
        addr = ipaddress.ip_address(s)
    except ValueError:
        raise ValueError(_BAD_IP) from None
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped is not None:
        addr = addr.ipv4_mapped
    out = str(addr)
    if not _IP_CHARS.fullmatch(out):
        raise ValueError(_BAD_IP)
    return out


def trim(rows: list) -> tuple[list, bool]:
    """Cap rows at ROWS_MAX; the second value is True when more were available."""
    return rows[:ROWS_MAX], len(rows) > ROWS_MAX


def build_sql(ip: str, window: str, include_allowed: bool = False) -> str:
    """Return the timeline SELECT for ``ip``; ValueError for a bad IP or window."""
    addr = normalize_ip(ip)
    if window not in WINDOWS:
        raise ValueError('Unknown time window.')
    denied = ', '.join(f"'{a}'" for a in DENIED_ACTIONS)
    kind = (f"CASE WHEN threat_name IS NOT NULL THEN 'threat' "
            f"WHEN vpn_policy_name IS NOT NULL THEN 'vpn' "
            f"WHEN lower(action) IN ({denied}) THEN 'denied' ELSE 'allowed' END")
    keep = '' if include_allowed else (
        f" AND (threat_name IS NOT NULL OR vpn_policy_name IS NOT NULL "
        f"OR lower(action) IN ({denied}))")
    return (
        f"SELECT time, {kind} AS kind, action, src_ip, dst_ip, dst_port, protocol, rule_name, "
        f"COALESCE(threat_name, app_name) AS threat_or_app, "
        f"COALESCE(geo_dst_country_code, geo_src_country_code) AS country "
        f"FROM ai.events WHERE time >= now() - interval '{WINDOWS[window]}' "
        f"AND (src_ip = '{addr}'::inet OR dst_ip = '{addr}'::inet){keep} "
        f"ORDER BY time DESC LIMIT {LIMIT}")
