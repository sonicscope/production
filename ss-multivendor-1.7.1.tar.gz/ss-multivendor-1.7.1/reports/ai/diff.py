"""Order-insensitive diff of a stored query snapshot against a fresh run (spec §4)."""
from __future__ import annotations

import json
from collections import Counter

SAMPLE = 20


def _h(row) -> str:
    return json.dumps(row, sort_keys=True, default=str, ensure_ascii=False)


def diff_results(old_columns, old_rows, new_columns, new_rows, old_count: int,
                 new_count: int) -> dict:
    cols_changed = list(old_columns) != list(new_columns)
    out = {'columns_changed': cols_changed, 'row_count_old': old_count,
           'row_count_new': new_count, 'delta': new_count - old_count}
    old_keys = [_h(r[0]) if r else '' for r in old_rows]
    new_keys = [_h(r[0]) if r else '' for r in new_rows]
    keyed = (len(set(old_keys)) == len(old_keys) and len(set(new_keys)) == len(new_keys)
             and not cols_changed and bool(old_columns))
    if keyed:
        om = dict(zip(old_keys, old_rows))
        nm = dict(zip(new_keys, new_rows))
        added = [nm[k] for k in nm if k not in om]
        removed = [om[k] for k in om if k not in nm]
        changed = sum(1 for k in nm if k in om and _h(nm[k]) != _h(om[k]))
        out.update(mode='keyed', added=len(added), removed=len(removed), changed=changed,
                   added_rows=added[:SAMPLE], removed_rows=removed[:SAMPLE])
    else:
        oc, nc = Counter(_h(r) for r in old_rows), Counter(_h(r) for r in new_rows)
        added_h, removed_h = nc - oc, oc - nc
        by_h_new = {_h(r): r for r in new_rows}
        by_h_old = {_h(r): r for r in old_rows}
        added = [by_h_new[k] for k in added_h for _ in range(added_h[k])]
        removed = [by_h_old[k] for k in removed_h for _ in range(removed_h[k])]
        out.update(mode='multiset', added=len(added), removed=len(removed), changed=0,
                   added_rows=added[:SAMPLE], removed_rows=removed[:SAMPLE])
    out['identical'] = (not cols_changed and out['added'] == 0 and out['removed'] == 0
                        and out['changed'] == 0 and old_count == new_count)
    return out
