"""CSV serialisation with spreadsheet-formula protection (spec §4)."""
from __future__ import annotations

import csv
import io
import json

EXPORT_HARD_CAP = 50_000
_FORMULA = ('=', '+', '-', '@', '\t', '\r')


def effective_cap(setting: int) -> int:
    """Rows allowed in one export: the stored setting, never above the hard ceiling."""
    return max(1, min(int(setting), EXPORT_HARD_CAP))


def escape_cell(value) -> str:
    if value is None:
        return ''
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, (int, float)):
        return str(value)                      # numbers cannot carry a formula payload
    text = json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else str(value)
    return "'" + text if text.startswith(_FORMULA) else text


def to_csv(columns, rows, *, truncated_at: int | None) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator='\r\n')
    w.writerow([escape_cell(str(c)) for c in columns])
    for r in rows:
        w.writerow([escape_cell(v) for v in r])
    if truncated_at is not None:
        w.writerow([f'Showing the first {truncated_at} rows only'])
    return '﻿' + buf.getvalue()
