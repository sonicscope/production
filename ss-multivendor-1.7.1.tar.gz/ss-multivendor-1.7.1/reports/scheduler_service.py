"""
SonicScope Report Scheduler — standalone service
================================================
Runs the report-schedule APScheduler in its **own process**
(systemd unit ``ss-scheduler.service``), decoupled from the gunicorn web
workers.

Why it is separate: the scheduler used to start once per gunicorn worker at
import time, which forced ``ss-reports`` to run with ``--workers 1`` — a
second worker would fire every scheduled report a second time. With the
scheduler in its own single process, the web tier can scale to multiple
workers freely and there is exactly one scheduler.

How schedule edits propagate: there is **no cross-process signalling**. The
web UI writes schedule changes to ``report_schedules``; this service
re-reads that table every ``SCHEDULE_RELOAD_INTERVAL_SEC`` (default 30s) and
rebuilds its jobs. The database is the single source of truth. A new or
edited schedule therefore becomes active within one poll interval.

Run (production):  ${INSTALL_DIR}/venv/bin/python reports/scheduler_service.py
Run (local/dev):   python3 reports/scheduler_service.py
"""
from __future__ import annotations

import logging
import signal
import sys
import threading
from pathlib import Path

# Resolve imports relative to the ss-multivendor project root (…/reports/..).
_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from reports.runtime_config import (  # noqa: E402
    DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR, SCHEDULE_RELOAD_INTERVAL_SEC,
)
from reports.scheduler import (  # noqa: E402
    start_scheduler, reload_schedules, stop_scheduler,
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
)
log = logging.getLogger('ss.reports.scheduler_service')

# Job id for the periodic DB-poll reload. Deliberately NOT prefixed
# 'schedule_' so reload_schedules() (which removes every 'schedule_*' job)
# never removes its own trigger.
_RELOAD_JOB_ID = '__schedule_reload__'


def install_reload_job(scheduler, interval_sec: int = SCHEDULE_RELOAD_INTERVAL_SEC):
    """Add the periodic DB-poll reload job to `scheduler` and return it.

    Kept separate from main() so it can be unit-tested. The job id is
    deliberately not 'schedule_'-prefixed so reload_schedules() (which removes
    every 'schedule_*' job) never removes this trigger.
    """
    return scheduler.add_job(
        reload_schedules,
        trigger='interval',
        seconds=interval_sec,
        args=[scheduler, DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR],
        id=_RELOAD_JOB_ID,
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )


_CATEGORY_JOB_ID = '__category_refresh__'


def _category_job(connect, mapping, fetch, interval_hours: float, shrink_floor: float):
    """Scheduled UT1 refresh. Skips (returns None) when the list was refreshed
    less than `interval_hours` ago, so a service restart does not trigger a
    full download every time."""
    from reports.category_lists import refresh_categories
    try:
        conn = connect()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT refreshed_at > now() - make_interval(secs => %s) "
                            "FROM category_list_state WHERE id = 1",
                            (float(interval_hours) * 3600,))
                row = cur.fetchone()
            conn.commit()
        finally:
            conn.close()
        if row and row[0]:
            log.info('UT1 category list is fresh (< %s h old); skipping this run', interval_hours)
            return None
    except Exception:
        log.warning('could not check category list freshness; refreshing', exc_info=True)
    return refresh_categories(connect, mapping, fetch, shrink_floor=shrink_floor)


def install_category_job(scheduler, connect, mapping, fetch, interval_hours: float = 24,
                         enabled: bool = True, shrink_floor: float = 0.5):
    """Schedule the UT1 refresh (first run ~60 s after start, skipped if the
    list is still fresh, then every `interval_hours`). Returns the job, or
    None when disabled. `shrink_floor` 0 disables the shrink guard."""
    if not enabled:
        return None
    from datetime import datetime, timedelta
    return scheduler.add_job(
        _category_job,
        trigger='interval',
        hours=interval_hours,
        next_run_time=datetime.now() + timedelta(seconds=60),
        args=[connect, mapping, fetch, interval_hours, shrink_floor],
        id=_CATEGORY_JOB_ID,
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )


def _install_category_from_env(scheduler) -> None:
    """Wire the UT1 refresh job from collector.env (UT1_ENABLED, UT1_REFRESH_HOURS,
    UT1_LIST_URL, UT1_SHRINK_FLOOR). A bad value logs and falls back to defaults; never crashes."""
    import os
    import psycopg2
    from functools import partial
    from reports import category_lists as cl
    enabled = os.environ.get('UT1_ENABLED', 'true').strip().lower() not in ('0', 'false', 'no')
    try:
        hours = max(1.0, float(os.environ.get('UT1_REFRESH_HOURS', '24')))
    except ValueError:
        log.warning('Bad UT1_REFRESH_HOURS; using 24')
        hours = 24.0
    try:
        floor = float(os.environ.get('UT1_SHRINK_FLOOR', '0.5'))
        if not 0.0 <= floor <= 1.0:
            raise ValueError(floor)
    except ValueError:
        log.warning('Bad UT1_SHRINK_FLOOR; using 0.5')
        floor = 0.5
    url = os.environ.get('UT1_LIST_URL', cl.DEFAULT_URL)
    try:
        mapping = cl.load_mapping()
    except Exception:
        log.exception('Cannot load UT1 category mapping; category refresh disabled')
        return
    install_category_job(
        scheduler, connect=lambda: psycopg2.connect(**DB_CONFIG), mapping=mapping,
        fetch=partial(_fetch_url, url), interval_hours=hours, enabled=enabled,
        shrink_floor=floor)


_AI_PURGE_JOB_ID = 'ai-investigations-retention'


def _ai_purge_job(connect) -> None:
    """Daily purge of expired saved investigations (retention_days from ai_settings)."""
    from reports.ai import audit, investigations
    conn = connect()
    try:
        with conn.cursor() as cur:
            cur.execute('SELECT retention_days FROM ai_settings WHERE id = 1')
            row = cur.fetchone()
            days = row[0] if row else 90
            n = investigations.purge_expired(cur, days)
            if n:
                audit.log_event(cur, kind='purge', user_id=None, tenant_id=None, provider=None,
                                model=None, row_count=n)
        conn.commit()
        if n:
            log.info('AI retention: purged %d investigation(s) older than %d days', n, days)
    except Exception:
        conn.rollback()
        log.exception('AI retention purge failed')
    finally:
        conn.close()


def install_ai_retention_job(scheduler, connect):
    from datetime import datetime, timedelta
    return scheduler.add_job(
        _ai_purge_job, trigger='interval', hours=24,
        next_run_time=datetime.now() + timedelta(minutes=5), args=[connect],
        id=_AI_PURGE_JOB_ID, replace_existing=True, max_instances=1, coalesce=True)


def _install_ai_retention_from_env(scheduler) -> None:
    """Wire the AI retention job; failure logs and never blocks scheduler start."""
    import psycopg2
    try:
        install_ai_retention_job(scheduler, lambda: psycopg2.connect(**DB_CONFIG))
    except Exception:
        log.exception('Cannot install AI retention job; saved investigations will not be purged')


def _fetch_url(url: str, dest: str) -> None:
    from reports import category_lists as cl
    cl.https_fetch(url, dest)


def main() -> int:
    stop_event = threading.Event()

    def _handle_signal(signum, _frame):
        log.info('Received signal %s — shutting down scheduler service', signum)
        stop_event.set()

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    try:
        scheduler = start_scheduler(DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)
    except Exception:
        log.exception(
            'Scheduler failed to start — is the database reachable? '
            'The service will exit non-zero so systemd restarts it.'
        )
        return 1

    # Poll the DB for schedule changes so the web UI never has to signal us.
    install_reload_job(scheduler)
    _install_category_from_env(scheduler)
    _install_ai_retention_from_env(scheduler)
    log.info(
        'Scheduler service running — re-reading schedules every %ds',
        SCHEDULE_RELOAD_INTERVAL_SEC,
    )

    stop_event.wait()  # block the main thread until SIGTERM/SIGINT

    try:
        stop_scheduler(scheduler)
    except Exception:
        log.exception('Error during scheduler shutdown')
    return 0


if __name__ == '__main__':
    sys.exit(main())
