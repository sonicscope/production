"""
Unit tests for the standalone report scheduler service
(reports/scheduler_service.py) and its shared config (reports/runtime_config.py).

These are pure/unit tests — no database and no started scheduler. They guard
the two things most likely to break the extraction:

  1. The periodic DB-poll reload job must NOT remove itself. reload_schedules()
     deletes every 'schedule_*' job, so the poll job's id must not collide with
     that prefix, and it must survive a reload cycle.
  2. runtime_config must read DB/SMTP/interval settings from the environment.
"""
import importlib
import sys
from pathlib import Path

import pytest
from apscheduler.schedulers.background import BackgroundScheduler

# Make the project root importable (…/reports/tests -> …/).
_ROOT = str(Path(__file__).resolve().parent.parent.parent)
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from reports import scheduler_service
from reports import scheduler as sched_mod


@pytest.fixture
def scheduler():
    """A BackgroundScheduler that is never started (no jobs fire)."""
    s = BackgroundScheduler()
    yield s
    # It was never started, so nothing to shut down.


def test_reload_job_id_is_not_schedule_prefixed():
    # reload_schedules() removes every job whose id startswith 'schedule_'.
    # The poll job must be immune to that, or it would delete its own trigger.
    assert not scheduler_service._RELOAD_JOB_ID.startswith('schedule_')


def test_install_reload_job_adds_interval_trigger(scheduler):
    job = scheduler_service.install_reload_job(scheduler, interval_sec=42)
    assert job.id == scheduler_service._RELOAD_JOB_ID
    # IntervalTrigger stringifies as e.g. "interval[0:00:42]".
    assert 'interval' in str(job.trigger)
    assert '0:00:42' in str(job.trigger)
    # It is registered on the scheduler.
    assert scheduler.get_job(scheduler_service._RELOAD_JOB_ID) is not None


def test_reload_job_survives_reload_schedules(scheduler, monkeypatch):
    """A reload cycle must drop stale schedule_* jobs but keep the poll job."""
    # Install the self-poll job + a stale schedule job.
    scheduler_service.install_reload_job(scheduler)
    scheduler.add_job(lambda: None, trigger='interval', seconds=60, id='schedule_99')
    ids = {j.id for j in scheduler.get_jobs()}
    assert 'schedule_99' in ids and scheduler_service._RELOAD_JOB_ID in ids

    # Make reload_schedules load ZERO schedules from the "DB" without a real DB:
    # force the connection to fail — reload_schedules catches this and proceeds
    # to rebuild with an empty set, exercising the removal path.
    def _boom(_cfg):
        raise RuntimeError('no DB in this unit test')
    monkeypatch.setattr(sched_mod, '_db_connect', _boom)

    sched_mod.reload_schedules(scheduler, {}, {}, '/tmp')

    ids_after = {j.id for j in scheduler.get_jobs()}
    assert 'schedule_99' not in ids_after, 'stale schedule job should be removed'
    assert scheduler_service._RELOAD_JOB_ID in ids_after, 'poll job must survive reload'


def test_runtime_config_reads_env(monkeypatch):
    monkeypatch.setenv('DB_HOST', 'db.example.test')
    monkeypatch.setenv('DB_PORT', '6543')
    monkeypatch.setenv('DB_NAME', 'ss_test')
    monkeypatch.setenv('DB_USER', 'ss_user')
    monkeypatch.setenv('DB_PASSWORD', 'secret')
    monkeypatch.setenv('SMTP_PORT', '465')
    monkeypatch.setenv('SCHEDULE_RELOAD_INTERVAL_SEC', '15')

    import reports.runtime_config as rc
    rc = importlib.reload(rc)

    assert rc.DB_CONFIG['host'] == 'db.example.test'
    assert rc.DB_CONFIG['port'] == 6543
    assert rc.DB_CONFIG['dbname'] == 'ss_test'
    assert rc.SMTP_CONFIG['port'] == 465
    assert rc.SCHEDULE_RELOAD_INTERVAL_SEC == 15


def test_runtime_config_bad_int_falls_back(monkeypatch):
    monkeypatch.setenv('DB_PORT', 'not-a-number')
    monkeypatch.setenv('SCHEDULE_RELOAD_INTERVAL_SEC', 'xyz')
    import reports.runtime_config as rc
    rc = importlib.reload(rc)
    assert rc.DB_CONFIG['port'] == 5432          # default
    assert rc.SCHEDULE_RELOAD_INTERVAL_SEC == 30  # default


def test_category_job_id_is_not_schedule_prefixed():
    assert not scheduler_service._CATEGORY_JOB_ID.startswith('schedule_')


def test_install_category_job_registers_interval_job(scheduler):
    job = scheduler_service.install_category_job(
        scheduler, connect=lambda: None, mapping=object(),
        fetch=lambda dest: None, interval_hours=24)
    assert job.id == scheduler_service._CATEGORY_JOB_ID
    assert 'interval' in str(job.trigger) and '1 day' in str(job.trigger)
    assert job.max_instances == 1 and job.coalesce is True
    assert scheduler.get_job(scheduler_service._CATEGORY_JOB_ID) is not None


def test_install_category_job_disabled_adds_nothing(scheduler):
    assert scheduler_service.install_category_job(
        scheduler, connect=lambda: None, mapping=object(),
        fetch=lambda dest: None, interval_hours=24, enabled=False) is None
    assert scheduler.get_job(scheduler_service._CATEGORY_JOB_ID) is None


def test_category_job_survives_a_schedule_reload_cycle(scheduler):
    scheduler_service.install_category_job(
        scheduler, connect=lambda: None, mapping=object(),
        fetch=lambda dest: None, interval_hours=24)
    for job in scheduler.get_jobs():                  # what reload_schedules() removes
        if job.id.startswith('schedule_'):
            job.remove()
    assert scheduler.get_job(scheduler_service._CATEGORY_JOB_ID) is not None


def test_ut1_shrink_floor_env(monkeypatch, scheduler):
    captured = {}
    monkeypatch.setattr(scheduler_service, 'install_category_job',
                        lambda sched, **kw: captured.update(kw))
    monkeypatch.setenv('UT1_SHRINK_FLOOR', '0')
    scheduler_service._install_category_from_env(scheduler)
    assert captured['shrink_floor'] == 0.0
    monkeypatch.setenv('UT1_SHRINK_FLOOR', 'junk')
    scheduler_service._install_category_from_env(scheduler)
    assert captured['shrink_floor'] == 0.5
    monkeypatch.delenv('UT1_SHRINK_FLOOR')
    scheduler_service._install_category_from_env(scheduler)
    assert captured['shrink_floor'] == 0.5


def test_install_ai_retention_from_env_registers_job_and_never_raises(monkeypatch):
    from reports import scheduler_service as ss

    class FakeScheduler:
        def __init__(self):
            self.jobs = []

        def add_job(self, func, *args, **kwargs):
            self.jobs.append(kwargs.get('id'))

    sched = FakeScheduler()
    ss._install_ai_retention_from_env(sched)
    assert ss._AI_PURGE_JOB_ID in sched.jobs

    class Broken:
        def add_job(self, *a, **k):
            raise RuntimeError('scheduler down')

    ss._install_ai_retention_from_env(Broken())          # logged, never raised

    def no_db(**kw):
        raise OSError('db unavailable')

    import psycopg2
    monkeypatch.setattr(psycopg2, 'connect', no_db)
    ss._install_ai_retention_from_env(FakeScheduler())   # connection is lazy; must not raise
