"""Behavioural tests for the Investigate page script, run in jsdom via Node.

Skipped when `node` is not on PATH or jsdom cannot be resolved. To run locally:

    cd /tmp && npm install jsdom
    JSDOM_NODE_MODULES=/tmp/node_modules venv/bin/pytest reports/tests/test_ai_page_js.py

(jsdom is looked up in $JSDOM_NODE_MODULES, falling back to ./node_modules.)
"""
import json
import os
import shutil
import subprocess

import pytest

from reports.ai import page as ai_page

HARNESS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'js', 'investigate_harness.js')


def _jsdom_dir():
    cand = os.environ.get('JSDOM_NODE_MODULES') or os.path.join(os.getcwd(), 'node_modules')
    return cand if os.path.isdir(os.path.join(cand, 'jsdom')) else None


@pytest.fixture(scope='module')
def R():
    if shutil.which('node') is None:
        pytest.skip('node is not on PATH — set JSDOM_NODE_MODULES — required at release gate')
    nm = _jsdom_dir()
    if nm is None:
        pytest.skip('set JSDOM_NODE_MODULES — required at release gate (node_modules dir containing jsdom)')
    html = ai_page.investigate_html(configured=True, is_admin=True,
                                    tenants=[(1, 'Acme'), (2, 'Beta')], has_tenants=True,
                                    csrf='CSRF', nonce='N')
    # Drop the external Chart.js script (jsdom must not fetch it); tests stub window.Chart.
    html = html.replace(f'<script src="{ai_page.CHART_JS}"></script>', '')
    page = '<!doctype html><html><body>' + html + '</body></html>'
    proc = subprocess.run(['node', HARNESS], input=page, capture_output=True, text=True,
                          timeout=120, env={**os.environ, 'JSDOM_NODE_MODULES': nm})
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout)


def test_success_stream_split_chunks_and_text_nodes(R):
    r = R['success']
    assert r['errs'] == []
    assert r['bubbles'][0] == 'ME:hello'
    assert 'A:Answer ✓ ünï 日本語 <b>x</b>' in r['bubbles']
    assert r['scripts'] == 0 and r['details'] == 1
    assert r['summary'] == 'QUERY · 1234 rows · 1.2 s'  # row_count, not rows.length
    assert '<script>alert(1)</script>"\'><img src=x onerror=1>' in r['tds']
    o = r['order']
    assert o.index('bubble ') < o.index('chartbox') < o.index('evidence') < o.index('chips')
    assert r['chartCfg'] == 'bar' and r['canvasLabel'] == 'T"<b>'
    assert r['chips'] == ['Next 1?', 'Next <i>2</i>?']
    assert r['calls'][0]['question'] == 'hello' and r['calls'][0]['tenant_id'] == 1
    assert not r['sendDisabled'] and r['label'] == 'Ask'


def test_chart_unavailable_note(R):
    assert R['success_nochart']['chartNote'] == ['Chart unavailable']
    assert R['chart_throws']['chartNote'] == ['Chart unavailable']


def test_copy_sql(R):
    assert R['copy']['clip'].startswith('SELECT <script>')
    assert R['copy']['copyLabel'] == 'Copied'
    assert R['copy_fail']['copyLabel'] == 'Copy failed'
    assert R['copy_none']['copyLabel'] == 'Copy failed'


def test_error_event_and_http_errors(R):
    assert R['error_event']['bubbles'][-1] == 'ERR:Model failed <b>'
    assert R['http_429']['bubbles'][-1] == 'ERR:Rate limited Try again in a minute.'
    assert R['http_409']['bubbles'][-1] == 'ERR:Busy'
    assert R['http_502']['bubbles'][-1] == 'ERR:Request failed (502).'
    for k in ('error_event', 'http_429', 'http_409', 'http_502', 'fetch_reject'):
        assert not R[k]['sendDisabled'] and R[k]['label'] == 'Ask', k


def test_fetch_rejection(R):
    assert R['fetch_reject']['bubbles'][-1] == \
        'ERR:Could not reach the server. Check your connection and try again.'


def test_history_only_for_completed_answers(R):
    assert R['no_done']['calls'][1]['history'] == [
        {'role': 'user', 'content': 'q'}, {'role': 'assistant', 'content': 'hi'}]
    assert R['empty_stream']['calls'][1]['history'] == []
    assert R['stream_error_no_answer']['calls'][1]['history'] == []


def test_double_submit_while_busy(R):
    assert len(R['double_submit']['calls']) == 1


def test_history_bounded_and_capped(R):
    h = R['history_bound']['calls'][7]['history']
    assert len(h) == 10
    assert max(len(x['content']) for x in h) == 4000


def test_followup_and_explain_requests(R):
    calls = R['followup_explain']['calls']
    assert calls[1]['question'] == 'Next 1?'
    assert calls[2]['explain_threat'] == 'Evil.Threat'
    users = [h['content'] for h in calls[2]['history'] if h['role'] == 'user']
    assert users == ['q', 'Next 1?']
    last = R['followup_explain']['bubbles']
    assert 'ME:Explain: Evil.Threat' in last


def test_tenant_switch_during_request_does_not_leak(R):
    r = R['tenant_race']
    assert 'OLDTENANT' not in r['msgsText']
    assert r['calls'][1]['tenant_id'] == 2
    assert r['calls'][1]['history'] == []
    assert not r['sendDisabled'] and r['label'] == 'Ask'


def test_tenant_select_disabled_while_in_flight(R):
    assert R['_sel_disabled_mid'] is True
    assert R['tenant_select_disabled_in_flight']['tenantDisabled'] is False


# ── Stage 2: investigations rail ────────────────────────────────────────────
def test_rail_lists_items_as_text(R):
    r = R['rail_list']
    assert r['errs'] == [] and len(r['rail']) == 2
    assert r['rail'][0].startswith('<img src=x onerror=1> Q')       # literal text, not markup
    assert 'Beta' in r['rail'][0] and 'shared' in r['rail'][0] and '2 finding(s)' in r['rail'][0]
    assert r['railImgs'] == 0
    assert 'GET /investigate/list?tab=mine' in r['reqs']


def test_rail_open_rebuilds_conversation_and_follow_ups_append(R):
    r = R['rail_open']
    assert r['errs'] == [] and 'GET /investigate/7' in r['reqs']
    assert r['bubbles'][:2] == ['ME:old q <b>', 'A:old a']
    assert r['details'] == 1 and r['railImgs'] == 0 and r['scripts'] == 0
    assert r['tenantValue'] == '2'
    assert r['calls'][0]['investigation_id'] == 7
    assert [h['content'] for h in r['calls'][0]['history']] == ['old q <b>', 'old a']
    assert r['railCurrent'] == 1


def test_rail_saved_event_sets_current_and_refreshes_list(R):
    r = R['rail_saved']
    assert r['errs'] == []
    assert 'investigation_id' not in r['calls'][0] or r['calls'][0]['investigation_id'] is None
    assert r['calls'][1]['investigation_id'] == 8
    assert r['reqs'].count('GET /investigate/list?tab=mine') >= 2


def test_rail_new_clears_conversation_and_drops_investigation_id(R):
    r = R['rail_new']
    assert r['errs'] == [] and R['_new_bubbles'] == 0
    assert r['calls'][0].get('investigation_id') is None and r['calls'][0]['history'] == []


def test_rail_tab_switch_changes_query(R):
    assert 'GET /investigate/list?tab=shared' in R['rail_tab']['reqs']


def test_rail_search_filters_client_side(R):
    rail = R['rail_search']['rail']
    assert len(rail) == 1 and rail[0].startswith('Second')


def test_rail_survives_api_failure(R):
    r = R['rail_api_fail']
    assert r['errs'] == [] and r['rail'] == ['No investigations yet.']


def test_admin_all_tab_only_for_admins(R):
    assert R['rail_list']['allTabHidden'] is False
    import re

    def all_tab(is_admin):
        html = ai_page.investigate_html(configured=True, is_admin=is_admin, tenants=[(1, 'A')],
                                        has_tenants=True, csrf='c', nonce='n')
        return re.search(r'<button[^>]*id="rail-all"[^>]*>', html).group(0)

    assert 'd-none' in all_tab(False) and 'd-none' not in all_tab(True)


# ── Stage 2 follow-ups ──────────────────────────────────────────────────────
def test_shared_read_only_disables_composer_until_new_or_tenant_change(R):
    r = R['readonly']
    assert r['errs'] == []
    note = 'Shared with you — read only. Start a new conversation to ask questions.'
    assert R['_ro_before'] == {'inp': False, 'btn': False, 'note': ''}
    assert R['_ro_open'] == {'inp': True, 'btn': True, 'note': note}
    assert R['_ro_new'] == {'inp': False, 'btn': False, 'note': ''}
    assert R['_ro_open2']['inp'] is True
    assert R['_ro_tenant'] == {'inp': False, 'btn': False, 'note': ''}


def test_stale_open_response_is_ignored(R):
    r = R['stale_open']
    assert r['errs'] == []
    assert r['bubbles'] == ['ME:pq', 'A:pa']                  # the later request (9) wins
    assert r['tenantValue'] == '1'
    r = R['stale_open_then_new']
    assert r['bubbles'] == [] and r['railCurrent'] == 0       # New cancels a pending open


def test_drawer_closes_on_escape_and_backdrop(R):
    assert R['_dr_open'] == {'open': True, 'exp': 'true', 'bd': True}
    assert R['_dr_esc'] == {'open': False, 'exp': 'false', 'bd': False}
    assert R['_dr_focus'] is True
    assert R['_dr_bd'] == {'open': False, 'exp': 'false', 'bd': False}
    assert R['_dr_noop']['open'] is False


def test_tabs_arrow_keys_roving_tabindex(R):
    assert R['_tab_init'] == {'sel': ['true', 'false', 'false'], 'ti': [0, -1, -1], 'focus': -1}
    assert R['_tab_right'] == {'sel': ['false', 'true', 'false'], 'ti': [-1, 0, -1], 'focus': 1}
    assert R['_tab_left']['sel'] == ['true', 'false', 'false'] and R['_tab_left']['focus'] == 0
    assert R['_tab_wrap']['sel'] == ['false', 'false', 'true'] and R['_tab_wrap']['focus'] == 2
    assert 'GET /investigate/list?tab=shared' in R['tabs_keys']['reqs']


# ── Task 3: toolbar (Re-run, diff badge, Ask AI to refresh) ─────────────────
def test_toolbar_rerun_posts_result_id_and_shows_changed_badge(R):
    r = R['tb_owner']
    assert r['errs'] == []
    assert R['_tb_before'] == ['Re-run', 'CSV', 'Pin', 'Ask AI to refresh']
    assert 'POST /investigate/7/rerun' in r['reqs']
    assert '/investigate/7/rerun {"result_id":1}' in r['apiBodies']
    assert r['badge'] == ['Changed: rows 120 → 134 · +15 / −1 / 3 changed|diff-badge diff']
    assert r['tds'] == ['<img src=x onerror=1>', '3']          # fresh rows as literal text
    assert r['scripts'] == 0
    assert any(m.startswith('Re-run ') and 'snapshot' in m for m in r['toolbarMeta'])


def test_toolbar_rerun_identical_badge(R):
    assert R['tb_same']['badge'] == ['No change since the snapshot.|diff-badge same']


def test_toolbar_rerun_error_is_shown_as_text_and_button_reenabled(R):
    r = R['tb_err']
    assert r['badge'] == ['Query rejected <b>|diff-badge'] and R['_tb_err_enabled'] is True
    assert r['scripts'] == 0


def test_shared_read_only_view_has_rerun_but_no_refresh(R):
    r = R['tb_shared']
    assert r['toolbarBtns'] == ['Re-run', 'CSV']
    assert '/investigate/9/rerun {"result_id":5}' in r['apiBodies']


def test_ask_ai_refresh_posts_message_seq_and_keeps_history_clean(R):
    r = R['tb_refresh']
    assert r['errs'] == []
    assert 'POST /investigate/7/refresh' in r['reqs']
    assert r['calls'][0] == {'message_seq': 1}                  # no client-supplied evidence/question
    assert 'ME:Refresh: old q <b>' in r['bubbles'] and 'A:fresh answer' in r['bubbles']
    nxt = r['calls'][1]
    assert nxt['investigation_id'] == 7 and nxt['question'] == 'next'
    assert [h['content'] for h in nxt['history']][-2:] == ['old q <b>', 'fresh answer']


# ── Task 4: CSV button, sampled diff badge ──────────────────────────────────
def test_csv_button_posts_result_id_and_downloads_blob(R):
    r = R['csv_ok']
    assert r['errs'] == [] and R['_csv_enabled'] is True
    assert r['apiBodies'].count('/investigate/7/export {"result_id":1}') == 1
    assert r['reqs'].count('POST /investigate/7/export') == 1
    assert R['_csv_aria'] == 'Download CSV'
    assert r['dl'] == ['T-1.csv|blob:x/1'] and r['revoked'] == ['blob:x/1']
    assert r['badge'] == ['CSV downloaded.|diff-badge']


def test_csv_button_error_shown_as_text_and_reenabled(R):
    r = R['csv_err']
    assert r['dl'] == [] and R['_csv_enabled'] is True and r['scripts'] == 0
    assert r['badge'] == ['Query rejected <b>|diff-badge']


def test_diff_badge_notes_sampling_when_truncated_or_over_500_rows(R):
    suffix = ' (sampled — first 500 rows compared)'
    assert R['sampled']['badge'] == ['Changed: rows 120 → 134 · +15 / −1 / 3 changed' + suffix + '|diff-badge diff']
    assert R['sampled_big']['badge'][0].split('|')[0].endswith(suffix)
    assert not R['tb_owner']['badge'][0].split('|')[0].endswith(suffix)


# ── Task 5: header controls, Pin, findings tray ─────────────────────────────
EVIL = '<img src=x onerror=1>'


def test_tray_renders_cards_as_text_with_frozen_preview(R):
    t = R['_t5_tray']
    assert R['t5_owner']['errs'] == []
    assert t['cards'] == 1 and t['inject'] == 0
    assert t['titles'] == ['<script>alert(1)</script>"\'><img src=x onerror=1>']
    assert t['notes'] == [EVIL]
    assert t['tds'] == 5 * 2                                  # first 5 rows only, 2 columns
    assert t['explain'] == 0                                  # frozen preview has no Explain buttons
    assert 'As of' in t['text'] and 'first 5 of 7' in t['text']
    assert t['btns'] == ['Save', 'Remove'] and t['toggle'] == 'Findings (1)'


def test_header_controls_for_owner_and_pin_button_in_toolbar(R):
    h = R['_t5_header']
    assert h['btns'] == ['Rename', 'Unshare', 'Delete']
    assert h['title'] == R['_t5_title']
    assert R['_t5_toolbar'] == ['Re-run', 'CSV', 'Pin', 'Ask AI to refresh']


def test_pin_flow_posts_exact_body_and_reloads_tray(R):
    r = R['t5_pin']
    assert r['errs'] == []
    assert R['_t5_pinform']['title'] == '<img src=x onerror=1> Q' and R['_t5_pinform']['hasNote']
    assert '/investigate/7/pin {"kind":"query","result_id":1,"title":"My <i>pin</i>","note":"why <b>"}' in r['apiBodies']
    assert r['reqs'].count('GET /investigate/7') >= 2          # tray reloaded from the server
    assert R['_t5_after']['cards'] == 2 and 'My <i>pin</i>' in R['_t5_after']['titles']
    assert R['_t5_after']['inject'] == 0 and R['_t5_formGone'] is True
    assert R['_t5_status'] == ['Pinned.']


def test_pin_error_is_text_and_keeps_form(R):
    assert R['_t5_pinerr'] == ['Enter a title <b>'] and R['_t5_pinform_kept'] is True
    assert R['t5_pin_err']['scripts'] == 0


def test_tray_edit_patches_title_and_note(R):
    r = R['t5_edit']
    assert '/investigate/7/findings/3 {"title":"Edited","note":"new note"}' in r['apiBodies']
    assert 'PATCH /investigate/7/findings/3' in r['reqs']
    assert R['_t5_edited']['titles'] == ['Edited'] and R['_t5_edited']['notes'] == ['new note']


def test_tray_remove_deletes_and_empties(R):
    assert R['_t5_rm_first']['btns'] == ['Yes', 'No']          # first click only asks
    assert 'DELETE /investigate/7/findings/3' in R['t5_remove']['reqs']
    t = R['_t5_removed']
    assert t['cards'] == 0 and 'No findings' in t['text'] and t['toggle'] == 'Findings (0)'


def test_read_only_viewer_sees_no_edit_or_pin_controls(R):
    ro = R['_t5_ro']
    assert ro['header']['btns'] == [] and 'read-only' in ro['header']['text']
    assert ro['toolbar'] == ['Re-run', 'CSV']
    assert ro['tray']['cards'] == 1 and ro['tray']['btns'] == [] and ro['tray']['titles'] == []
    assert 'Peer finding' in ro['tray']['text']


def test_rename_posts_and_renders_title_as_text(R):
    assert R['_t5_renameVal'] == '<img src=x onerror=1> Q'
    assert '/investigate/7/rename {"title":"Renamed <b>"}' in R['t5_rename']['apiBodies']
    assert R['_t5_renamed'] == {'title': 'Renamed <b>', 'inject': 0}


def test_share_toggle_posts_flipped_flag(R):
    assert '/investigate/7/share {"shared":false}' in R['t5_share']['apiBodies']
    assert R['_t5_shared_after'] == ['Rename', 'Share', 'Delete']


def test_delete_is_two_step_and_clears_conversation(R):
    assert R['_t5_confirm'] == ['Yes', 'No'] and R['_t5_cancel'] == ['Rename', 'Unshare', 'Delete']
    assert 'POST /investigate/7/delete' in R['t5_delete']['reqs']
    d = R['_t5_deleted']
    assert d['header'] == '' and d['bubbles'] == 0 and d['tray']['cards'] == 0


def test_header_hidden_for_an_unsaved_conversation(R):
    f = R['_t5_fresh']
    assert f['header'] == '' and f['btns'] == [] and f['tray']['cards'] == 0
    assert 'Save an investigation' in f['tray']['text']


# ── Task 5 review fixes ──────────────────────────────────────────────────────
def test_focus_after_header_actions(R):
    assert R['t5_focus_header']['errs'] == []
    assert R['_f_cancel'] == 'Rename'          # Cancel -> Rename button
    assert R['_f_rensave'] == 'Rename'         # Save -> Rename button
    assert R['_f_delno'] == 'Delete'           # No -> Delete button
    assert R['_f_share'] == 'Share'            # toggled share button keeps focus
    assert R['_f_delyes'] == 'inv-input'       # deleted -> composer


def test_status_live_regions_are_persistent(R):
    a = R['_s_attrs']
    assert a['h'] == ['status', 'polite'] and a['t'] == ['status', 'polite']
    assert a['hEmpty'] and a['tEmpty']                         # exist (empty) before any message
    assert R['_s_hdr'] == {'same': True, 'text': 'Title rejected <b>', 'count': 1}
    assert R['_s_hdr_after_render'] is True


def test_finding_save_keeps_focus_and_other_drafts(R):
    f = R['_fs']
    assert f['active'] == 'Save' and f['aTitle'] == 'A saved'
    assert f['bSame'] is True and f['bTitle'] == 'B draft title' and f['bNote'] == 'B draft note'
    assert f['cards'] == 2


def test_failed_reload_shows_message_and_keeps_cards_and_drafts(R):
    r = R['_rf']
    assert r['status'] == 'Could not refresh findings.'
    assert r['cards'] == 2 and r['bNote'] == 'B draft'
    assert r['active'] == 'Save'


def test_finding_remove_is_two_step_with_focus(R):
    f = R['_fr']
    assert f['confirm'] == ['Yes', 'No'] and f['noDelete'] is True and f['activeNo'] == 'No'
    assert f['restored'] == ['Save', 'Remove'] and f['activeRm'] == 'Remove'
    assert f['deleted'] == ['DELETE /investigate/7/findings/3']
    assert f['afterFirst']['cards'] == 1 and f['afterFirst']['val'] == 'Second'   # next card's title
    assert f['afterLast'] == {'cards': 0, 'active': 'tray-heading'}


def test_pin_form_close_returns_focus_to_pin_button(R):
    assert R['_pf_open'] == 'INPUT'
    assert R['_pf'] == {'active': 'Pin as finding', 'formGone': True}


def test_live_evidence_gets_toolbar_from_saved_ids_and_pins_that_id(R):
    r = R['t5_live_pin']
    assert r['errs'] == []
    assert R['_lp_bar'] == ['Re-run', 'CSV', 'Pin', 'Ask AI to refresh']
    assert any(b.startswith('/investigate/7/pin {"kind":"query","result_id":55,') for b in r['apiBodies'])
    assert R['_lp_active'] == 'Pin as finding'


def test_live_evidence_not_upgraded_on_count_mismatch_or_missing_saved(R):
    assert R['_lm'] == {'bar': [], 'details': 1}
    assert R['_ln'] == {'bar': [], 'details': 1}


# ── Task 6: timeline ────────────────────────────────────────────────────────
def test_timeline_button_only_for_ip_columns_and_valid_values(R):
    assert R['_tb'] == ['Timeline for 10.9.9.9', 'Timeline for 2001:db8::1']   # null cells get none
    assert R['_tbn'] == 0 and R['_tbb'] == 0


def test_timeline_panel_is_an_accessible_dialog_and_refetches(R):
    t = R['_tp']
    assert t['label'] == 'Timeline for 10.9.9.9' and t['modal'] == 'true' and t['focusIn']
    assert t['first'].startswith('/investigate/timeline ') and '"ip":"10.9.9.9"' in t['first']
    assert '"window":"24h"' in t['first'] and '"include_allowed":false' in t['first']
    assert '"tenant_id":1' in t['first']
    assert t['rows'] == 150 and t['xss'] == 0 and t['note'] and t['live'] == 'polite'
    assert t['winVal'] == '24h' and t['winOpts'] == ['1h:1 hour', '24h:24 hours', '7d:7 days', '31d:31 days']
    assert t['chips'][:4] == ['denied|chip chip-denied', 'threat|chip chip-threat',
                              'vpn|chip chip-vpn', 'allowed|chip chip-allowed']
    assert '"window":"7d"' in t['win'] and '"include_allowed":true' in t['inc'] and t['n'] == 3
    assert t['pinDisabled'] is True
    assert t['closed'] and t['restored']


def test_timeline_error_is_text_in_the_live_region(R):
    assert R['_te'] == {'status': 'Too many <b>', 'rows': 0}


def test_timeline_pin_posts_kind_timeline_and_returns_focus(R):
    p = R['_tpin']
    assert p['disabled'] is False and p['formGone'] and p['active'] == 'Pin as finding'
    assert p['formFocus'] == 'INPUT' and p['status'] == 'Pinned.'
    assert p['body'].startswith('/investigate/7/pin ')
    body = json.loads(p['body'].split(' ', 1)[1])
    assert body == {'kind': 'timeline', 'ip': '10.9.9.9', 'window': '24h', 'include_allowed': False,
                    'title': 'Timeline for 10.9.9.9', 'note': 'note x'}


def test_timeline_summarise_question_is_bounded_and_closes_panel(R):
    s = R['_ts']
    assert s['n'] == 2 and s['closed']
    assert s['q'].startswith('Summarise this timeline for 10.9.9.9')
    assert len(s['q']) <= 1900 and 0 < s['q'].count('["2026-') <= 100     # 150 rows in, bounded out
    assert 'untrusted data' in s['q']
    assert s['bubble'] == 'Summarise timeline for 10.9.9.9'


def test_timeline_truncated_banner_only_when_server_says_truncated(R):
    assert R['_tt'] == {'banner': True, 'rows': 3}
    assert R['_tnt'] is False


def test_timeline_summarise_while_busy_keeps_dialog_and_explains(R):
    b = R['_tbusy']
    assert b['open'] is True and b['status'] == 'Wait for the current answer to finish.'
    assert b['calls'] == 2                                # first + second only, no third


def test_timeline_pin_enables_when_conversation_saved_while_open(R):
    assert R['_tpl'] == {'before': True, 'after': False}


# ── Final review fixes ──────────────────────────────────────────────────────
def test_update_snapshot_button_flow_for_owner_after_changed_rerun(R):
    assert R['us_owner']['errs'] == []
    a = R['_us_after_rerun']
    assert a['btns'] == ['Re-run', 'Update snapshot', 'CSV', 'Pin', 'Ask AI to refresh']
    assert '/investigate/7/rerun {"result_id":1,"update_snapshot":true}' in R['us_owner']['apiBodies']
    u = R['_us_after_update']
    assert 'Update snapshot' not in u['btns']
    assert u['stamp'] == 'Snapshot ' + R['_us_expected']                 # server timestamp, not the client clock
    assert u['badge'] == ['Snapshot updated.|diff-badge same']
    assert u['focus'] == 'Re-run'
    assert 'Update snapshot' in R['_us_rerun_again']['btns']             # a further changed re-run offers it again


def test_update_snapshot_hidden_when_identical_or_read_only(R):
    assert 'Update snapshot' not in R['_us_same']['btns']
    assert 'Update snapshot' not in R['_us_shared']['btns']
    assert R['_us_shared']['badge'][0].startswith('Changed:')


def test_timeline_finding_card_shows_frozen_preview(R):
    t = R['_tl_card']
    assert R['tl_card']['errs'] == []
    assert t['cards'] == 1 and t['inject'] == 0
    assert t['tds'] == 5 * 2                                              # first 5 rows, 2 columns
    assert 'As of ' + t['expectedDate'] in t['text']
    assert '10.9.9.9' in t['text'] and '24h' in t['text'] and 'first 5 of 7' in t['text']


def test_rail_list_is_not_a_live_region_and_tabs_control_a_tabpanel(R):
    s = R['_a11y_static']
    assert s['liveOnList'] is False and s['hasPanel'] is True
    assert s['controls'] == [True, True, True] and s['labelledby'] is True
    assert R['_a11y_tabswitch'] is True


def test_overlay_drawer_and_tray_move_and_return_focus(R):
    assert R['a11y']['errs'] == []
    assert R['_a11y_rail_open'] is True
    assert R['_a11y_rail_bd'] is True and R['_a11y_rail_esc'] is True
    assert R['_a11y_tray_open'] is True and R['_a11y_tray_close'] is True


# ---- Stage 3: tray selection + report dialog ----

def test_tray_selection_enables_limit_and_generate_button(R):
    assert R['s3_select']['errs'] == []
    assert R['_s3_opts'] == ['10', '25', '100']
    a = R['_s3_a']
    assert a['boxes'] == 2 and a['limits'] == ['off:25', 'off:25']
    assert a['btn'] is True and a['hint'] == 'Select at least one finding.'
    b = R['_s3_b']
    assert b['checked'][0] is True and b['limits'] == ['on:25', 'off:25']
    assert b['btn'] is False and b['hint'] == '1 selected'
    c = R['_s3_c']
    assert c['limits'] == ['off:25', 'off:25'] and c['btn'] is True and c['hint'] == 'Select at least one finding.'
    d = R['_s3_d']                                          # survives a card rebuild after Save
    assert d['checked'][0] is True and d['limits'][0] == 'on:100' and d['hint'] == '1 selected'


def test_report_dialog_is_an_accessible_modal(R):
    assert R['s3_dialog']['errs'] == []
    g = R['_s3_dlg']
    assert g['modal'] == 'true' and g['heading'] == 'Generate report' and g['focusH'] is True
    assert int(g['z']) >= 1050 and g['live'] == 'polite' and g['inRoot'] is True
    assert g['titleVal'] == 'Current inv' and g['labelFor'] is True and g['counter'] is True
    assert g['wrapFwd'] is True and g['wrapBack'] is True
    assert g['closed'] is True and g['restored'] is True


def test_report_submit_posts_exact_body_and_renders_download_link(R):
    assert R['s3_submit']['errs'] == []
    assert R['_s3_busy'] == {'gen': True, 'cancel': True, 'msg': 'Generating…'}
    s = R['_s3_sub']
    assert s['posts'] == ['/investigate/report ' + json.dumps({
        'title': 'My <b>report</b>', 'summary': 'Sum',
        'items': [{'finding_id': 3, 'row_limit': 25}, {'finding_id': 21, 'row_limit': 100}]},
        separators=(',', ':'))]
    assert s['msg'] == 'Report generated' and s['href'] == '/reports/9/download'
    assert s['linkText'] == 'Download report' and s['focusLink'] is True and s['closeBtn'] is True
    assert s['foot']['btn'] is True and s['foot']['checked'] == [False, False]   # ticks cleared
    assert s['refetch'] >= 2                                                      # findings refreshed


@pytest.mark.parametrize('k', ['js', 'ext', 'proto'])
def test_report_rejects_non_report_download_urls(R, k):
    assert R['s3_bad_' + k]['errs'] == []
    b = R['_s3_bad_' + k]
    assert b['links'] == 0 and b['msg'] != 'Report generated' and b['gen'] is False


def test_report_validation_blocks_the_request(R):
    z = R['_s3_zero']
    assert z['dlg'] is False and z['disabled'] is True
    v = R['_s3_val']
    assert v['msg'] == 'Enter a report title.' and v['posts'] == 0 and v['open'] and v['focusTitle']
    m = R['_s3_many']
    assert m['msg'] == 'Select at most 25 findings.' and m['posts'] == 0 and m['hint'] == '26 selected'


def test_report_reorder_rederives_exhibit_letters_and_post_order(R):
    assert R['s3_reorder']['errs'] == []
    assert R['_s3_re0'] == ['Exhibit A · Alpha · 7 rows|Move up(x),Move down,Remove',
                            'Exhibit B · Host 10.9.9.9 · 1 row|Move up,Move down(x),Remove']
    assert R['_s3_re1'] == ['Exhibit A · Host 10.9.9.9 · 1 row|Move up(x),Move down,Remove',
                            'Exhibit B · Alpha · 7 rows|Move up,Move down(x),Remove']
    assert R['_s3_reFocus'] == 'Move up: Alpha'          # same item; its Move down is now disabled
    body = json.loads(R['_s3_rePost'][0].split(' ', 1)[1])
    assert [i['finding_id'] for i in body['items']] == [21, 3]


def test_report_error_shows_message_and_late_response_is_ignored(R):
    e = R['_s3_err']
    assert e == {'msg': 'Slow down <b>', 'gen': False, 'cancel': False, 'open': True}
    assert R['s3_late']['errs'] == []
    late = R['_s3_late']
    assert late['dlg'] is False and late['overlays'] == 0 and late['links'] == 0 and late['restored'] is True


def test_report_dialog_renders_hostile_titles_as_text(R):
    h = R['_s3_host']
    assert h['imgs'] == 0 and '<img src=x onerror=1>' in h['text']


def test_read_only_viewer_can_generate_but_not_edit(R):
    ro = R['_s3_ro']
    assert R['s3_readonly']['errs'] == []
    assert ro['boxes'] == 2 and ro['edit'] == 0
    assert ro['posts'] == 1 and ro['msg'] == 'Report generated'


def test_report_picker_is_lazy_tenant_scoped_and_adds_exhibits(R):
    assert R['s3_picker']['errs'] == []
    assert R['_s3_pk0']['reqsBefore'] == 0
    p1 = R['_s3_pk1']
    assert p1['lists'].count('GET /investigate/list?tab=shared') == 1      # picker loads both tabs
    assert p1['lists'].count('GET /investigate/list?tab=mine') == 2        # rail + picker
    assert len(p1['toggles']) == 1 and p1['toggles'][0].startswith('Other Beta <i>x</i>')   # other tenant + current excluded
    assert p1['imgs'] == 0 and p1['fetched'] == 0
    p2 = R['_s3_pk2']
    assert p2['fetched'] == 1 and p2['boxes'] == 1 and p2['expanded'] == 'true'
    p3 = R['_s3_pk3']
    assert p3['items'][-1] == 'Exhibit C · Gamma · 4 rows' and p3['boxes'] == 0
    assert 'Exhibit C' in p3['msg']
    assert R['_s3_pkFocus'] == 'Move down: Alpha'          # focus stays on the moved item's same button
    body = json.loads(R['_s3_pkPost'][0].split(' ', 1)[1])
    assert [i['finding_id'] for i in body['items']] == [21, 3, 31]


def test_report_picker_includes_all_tab_for_admins_deduped(R):
    assert R['s3_admin_picker']['errs'] == []
    a = R['_s3_adm']
    assert a['lists'].count('GET /investigate/list?tab=all') == 1
    assert sorted(a['toggles']) == sorted(['Admin only · 1 finding(s)', 'Other Beta <i>x</i> · 1 finding(s)'])


def test_report_dialog_has_per_item_row_limit_synced_with_tray(R):
    assert R['s3_dialog_limit']['errs'] == []
    d0 = R['_s3_dl0']
    assert d0['n'] == 2 and d0['vals'] == ['25', '25'] and d0['opts'] == ['10', '25', '100']
    assert d0['labels'] == ['Rows to print: Alpha', 'Rows to print: Host 10.9.9.9']
    assert d0['budget'] == '8 of 500 rows'                 # 7 + 1 rows available, both under 25
    d1 = R['_s3_dl1']
    assert d1['tray'] == ['on:10', 'on:100'] and d1['budget'] == '8 of 500 rows'
    body = json.loads(R['_s3_dlPost'][0].split(' ', 1)[1])
    assert [(i['finding_id'], i['row_limit']) for i in body['items']] == [(3, 10), (21, 100)]


def test_report_budget_hint_and_server_message(R):
    assert R['s3_budget_over']['errs'] == []
    b = R['_s3_bo']
    assert b['budget'] == '150 of 500 rows'                # 6 findings x 25 rows
    assert b['after'].startswith('600 of 500 rows') and 'over the limit' in b['after']
    assert b['msg'].startswith('This report would print too much evidence (limit 500 rows)')
    assert b['gen'] is False


def test_report_dialog_small_ui_fixes(R):
    assert R['s3_b6']['errs'] == []
    assert R['_s3_lab']['cb'] == ['Include in report: Alpha', 'Include in report: Host 10.9.9.9']
    assert R['_s3_lab']['sel'] == ['Rows to print: Alpha', 'Rows to print: Host 10.9.9.9']
    assert R['_s3_gen0'] == {'dis': False, 'hint': ''}
    assert R['_s3_gen1'] == {'dis': True, 'hint': 'Select at least one finding.'}
    g = R['_s3_ghost']
    assert g['has'] is True and g['checked'] is False and g['btn'] is True


def test_report_picker_can_be_retried_after_a_list_failure(R):
    assert R['s3_picker_retry']['errs'] == []
    assert R['_s3_rt0']['calls'] == 3 and R['_s3_rt0']['toggles'] == 0 and 'List failed' in R['_s3_rt0']['msg']
    assert R['_s3_rt1']['toggles'] == 1
