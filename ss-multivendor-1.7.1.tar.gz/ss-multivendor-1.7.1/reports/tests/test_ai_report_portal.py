"""Investigation reports are MSP-internal: hidden from the customer portal, not downloadable by
customers, labelled in the MSP list, and released from findings when purged."""
from datetime import datetime, timedelta, timezone

import psycopg2
import pytest

from reports.ai import investigations

AI = 'ai_investigation'


def sql(app_module, query, params=()):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute(query, params)
        return cur.fetchall() if cur.description else None


@pytest.fixture
def env(app_module, seed_tenants, seed_msp_profile, seed_report):
    """One tenant linked to an MSP with a periodic and an investigation report."""
    msp = seed_msp_profile('Portal MSP')
    tid, = seed_tenants('Portal Corp')
    sql(app_module, 'UPDATE tenants SET msp_profile_id = %s WHERE id = %s', (msp, tid))
    return {'tid': tid, 'periodic': seed_report(tid, 'periodic'), 'ai': seed_report(tid, AI)}


def link(app_module, tid, report_id, title='f'):
    """Create an investigation with one finding linked to report_id; return the finding id."""
    uid = sql(app_module, "INSERT INTO ui_users (email, full_name, role, is_active) VALUES "
              "(%s, 'o', 'user', true) RETURNING id", (f'o{report_id}@t.test',))[0][0]
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        inv = investigations.create(cur, tenant_id=tid, owner_user_id=uid, title='t')
        cur.execute("INSERT INTO ai_findings (investigation_id, tenant_id, title, evidence_kind, "
                    "evidence, report_id) VALUES (%s, %s, %s, 'query', '{}', %s) RETURNING id",
                    (inv, tid, title, report_id))
        fid = cur.fetchone()[0]
        conn.commit()
    return fid


def dl(report_id):
    return f'/reports/{report_id}/download'


@pytest.mark.parametrize('path', ['/portal', '/portal/reports'])
def test_customer_lists_hide_investigation_reports(client, login_as, env, path):
    login_as('customer', tenant_ids=[env['tid']])
    body = client.get(path).get_data(as_text=True)
    assert dl(env['periodic']) in body
    assert dl(env['ai']) not in body


def test_customer_download_guard(client, login_as, env):
    login_as('customer', tenant_ids=[env['tid']])
    assert client.get(dl(env['ai'])).status_code == 404
    assert client.get(dl(env['periodic'])).status_code == 200


def test_customer_of_other_tenant_status_unchanged(client, login_as, env, seed_tenants):
    other, = seed_tenants('Other Corp')
    login_as('customer', tenant_ids=[other])
    assert client.get(dl(env['ai'])).status_code == client.get(dl(env['periodic'])).status_code


@pytest.mark.parametrize('role', ['admin', 'user'])
def test_staff_can_download_investigation_report(client, login_as, env, role):
    login_as(role, tenant_ids=[env['tid']])
    resp = client.get(dl(env['ai']))
    assert resp.status_code == 200 and resp.data.startswith(b'%PDF-')


def test_msp_list_labels_investigation(client, login_as, env):
    login_as('admin')
    body = client.get('/').get_data(as_text=True)
    assert 'Investigation</span>' in body
    assert f'>{AI}<' not in body
    assert '>periodic<' in body


def purge(client, csrf_of, days=1):
    return client.post('/reports/purge', data={'_csrf': csrf_of(client), 'days': days})


def age(app_module, *ids):
    old = datetime.now(timezone.utc) - timedelta(days=30)
    sql(app_module, 'UPDATE generated_reports SET generated_at = %s WHERE id = ANY(%s)',
        (old, list(ids)))


def test_purge_deletes_report_and_unlinks_findings(client, app_module, login_as, csrf_of, env):
    keep = link(app_module, env['tid'], env['periodic'], 'keep')
    gone = link(app_module, env['tid'], env['ai'], 'gone')
    age(app_module, env['ai'])
    login_as('admin')
    assert purge(client, csrf_of).status_code == 302
    assert sql(app_module, 'SELECT id FROM generated_reports WHERE id = %s', (env['ai'],)) == []
    assert sql(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s', (gone,)) == [(None,)]
    assert sql(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s',
               (keep,)) == [(env['periodic'],)]


def test_purge_failure_leaves_findings_linked(client, app_module, login_as, csrf_of, env,
                                              monkeypatch):
    fid = link(app_module, env['tid'], env['ai'])
    age(app_module, env['ai'])
    login_as('admin')

    def boom(cur, ids):
        cur.execute('SELECT 1/0')

    monkeypatch.setattr(app_module.investigations, 'unlink_reports', boom)
    with pytest.raises(Exception):
        purge(client, csrf_of)
    assert sql(app_module, 'SELECT id FROM generated_reports WHERE id = %s',
               (env['ai'],)) == [(env['ai'],)]
    assert sql(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s',
               (fid,)) == [(env['ai'],)]


def test_tenant_delete_cascades_findings_without_error(app_module, env):
    fid = link(app_module, env['tid'], env['ai'])
    sql(app_module, 'DELETE FROM generated_reports WHERE tenant_id = %s', (env['tid'],))
    sql(app_module, 'DELETE FROM tenants WHERE id = %s', (env['tid'],))
    assert sql(app_module, 'SELECT id FROM ai_findings WHERE id = %s', (fid,)) == []
