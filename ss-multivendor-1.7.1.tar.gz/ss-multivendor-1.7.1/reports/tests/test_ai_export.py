import csv
import io

from reports.ai import export


def test_formula_cells_escaped():
    for bad in ('=1+1', '+cmd', '-2+3', '@SUM(A1)', '\tx', '\rx'):
        assert export.escape_cell(bad) == "'" + bad


def test_numbers_are_not_prefixed_but_numeric_strings_with_sign_are():
    assert export.escape_cell(-5) == '-5' and export.escape_cell(1.5) == '1.5'
    assert export.escape_cell('-5') == "'-5"


def test_none_bool_and_nested():
    assert export.escape_cell(None) == ''
    assert export.escape_cell(True) == 'true'
    assert export.escape_cell([1, 'a']) == '[1, "a"]'


def test_csv_roundtrip_quotes_commas_newlines():
    text = export.to_csv(['a', 'b'], [['x,y', 'l1\nl2'], ['"q"', None]], truncated_at=None)
    assert text.startswith('﻿')
    rows = list(csv.reader(io.StringIO(text.lstrip('﻿'))))
    assert rows == [['a', 'b'], ['x,y', 'l1\nl2'], ['"q"', '']]
    assert '\r\n' in text


def test_header_cells_are_escaped_too():
    assert export.to_csv(['=evil'], [], truncated_at=None).splitlines()[0].lstrip('﻿') == "'=evil"


def test_truncation_note_row():
    text = export.to_csv(['a'], [[1]], truncated_at=5000)
    assert text.strip().splitlines()[-1] == 'Showing the first 5000 rows only'


def test_effective_cap_is_bounded_by_hard_cap():
    assert export.effective_cap(5000) == 5000
    assert export.effective_cap(10**9) == export.EXPORT_HARD_CAP
    assert export.effective_cap(0) == 1


def test_unicode_text_roundtrips_through_to_csv():
    text = export.to_csv(['名前', 'n'], [['Zoë 日本語', 'ünï ✓'], ['=Zoë', None]], truncated_at=None)
    assert text.startswith('﻿')
    rows = list(csv.reader(io.StringIO(text.lstrip('﻿'))))
    assert rows == [['名前', 'n'], ['Zoë 日本語', 'ünï ✓'], ["'=Zoë", '']]
    assert text.encode('utf-8').decode('utf-8-sig').startswith('名前')


def test_decimal_derived_strings_are_prefixed_but_real_numbers_are_not():
    # Postgres numeric values reach the CSV as strings (JSON-safe), so a negative one looks like a formula.
    assert export.escape_cell('-1234567.123456789012') == "'-1234567.123456789012"
    assert export.escape_cell('+1.5') == "'+1.5"
    assert export.escape_cell('1234567.123456789012') == '1234567.123456789012'
    assert export.escape_cell(-1234567) == '-1234567'
    assert export.escape_cell(-1234567.5) == '-1234567.5'
    text = export.to_csv(['amt'], [['-1234567.123456789012'], [-12], [-1.5]], truncated_at=None)
    assert list(csv.reader(io.StringIO(text.lstrip('﻿')))) == [['amt'], ["'-1234567.123456789012"],
                                                               ['-12'], ['-1.5']]
