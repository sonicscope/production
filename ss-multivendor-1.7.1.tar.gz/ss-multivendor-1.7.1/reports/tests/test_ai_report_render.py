"""Investigation report: real WeasyPrint + real test DB."""
from __future__ import annotations

import os
from datetime import datetime, timezone

import psycopg2
import pytest
import weasyprint

from reports import generator
from reports.generator import _get_jinja_env, generate_investigation_report

XSS = '<script>alert(1)</script>'


def _exhibits() -> list[dict]:
    base = {'note': '', 'question': '', 'frozen_at': '2026-11-18 10:00 UTC',
            'subject': '', 'window': '', 'notes': [], 'finding_id': 1}
    big = dict(base, letter='A', title='Big table', question='Top talkers?', kind='query',
               columns=[f'c{i}' for i in range(15)],
               rows=[[f'r{r}v{c}' for c in range(15)] for r in range(100)],
               shown=100, total=100)
    evil = dict(base, letter='B', title=XSS, note=XSS + ' &lt;b&gt;', kind='query',
                columns=['x'], rows=[[XSS], ['&lt;b&gt;']], shown=2, total=2)
    tl = dict(base, letter='C', title='Host timeline', kind='timeline',
              subject='10.0.0.5', window='24h', columns=['time', 'event'],
              rows=[['10:00', 'deny']], shown=1, total=1)
    return [big, evil, tl]


@pytest.fixture
def ctx(app_module, seed_tenants, seed_msp_profile, tmp_path):
    (tid,) = seed_tenants('Acme Corp')
    msp = seed_msp_profile('Test MSP', primary_color='#2255aa')
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    yield conn, tid, msp, str(tmp_path)
    conn.close()


def _rows(conn, rid):
    with conn.cursor() as cur:
        cur.execute("SELECT report_type, delivery_status, tenant_id, subject_user "
                    "FROM generated_reports WHERE id = %s", (rid,))
        return cur.fetchall()


def test_real_render_and_row(ctx):
    conn, tid, msp, out = ctx
    path, rid = generate_investigation_report(conn, tid, msp, 'Case 1', 'Sum', _exhibits(), out)
    assert os.path.isfile(path)
    with open(path, 'rb') as f:
        assert f.read(5) == b'%PDF-'
    assert _rows(conn, rid) == [('ai_investigation', 'ready', tid, None)]


def _html(summary='Findings text'):
    msp = {'name': 'Test MSP', 'primary_color': '#2255aa', 'accent_text_color': '#fff',
           'logo_path': None}
    return _get_jinja_env().get_template('investigation/report.html').render(
        msp=msp, tenant={'name': 'Acme Corp'}, title='Case 1', summary=summary,
        exhibits=_exhibits(), generated_at=datetime.now(timezone.utc))


def test_html_escaping_and_names():
    html = _html()
    assert '&lt;script&gt;alert(1)&lt;/script&gt;' in html
    assert XSS not in html
    for s in ('Exhibit A', 'Exhibit B', 'Exhibit C', 'Prepared with SonicScope Investigate',
              '<meta name="author" content="Test MSP">'):
        assert s in html
    # Only the MSP name, tenant name and fixed wording are printed (no author/tool identity).
    assert html.count('<meta name="author"') == 1
    assert 'content: "Acme Corp \u2014 Prepared with SonicScope Investigate";' in html


@pytest.mark.skipif(not os.environ.get('FORBIDDEN_NAME_TERMS'),
                    reason='set FORBIDDEN_NAME_TERMS (comma-separated) to scan for private names')
def test_no_forbidden_name_terms():
    terms = [t.strip().lower() for t in os.environ['FORBIDDEN_NAME_TERMS'].split(',') if t.strip()]
    low = _html().lower()
    for bad in terms:
        assert bad not in low


def _css_html(tenant_name, footer, summary=''):
    msp = {'name': 'Test MSP', 'footer_text': footer, 'primary_color': '#2255aa',
           'accent_text_color': '#fff', 'logo_path': None}
    return _get_jinja_env().get_template('investigation/report.html').render(
        msp=msp, tenant={'name': tenant_name}, title='Case 1', summary=summary,
        exhibits=_exhibits(), generated_at=datetime.now(timezone.utc))


EVIL_TENANT = 'Smith & Sons "Ltd" \'x\' \\ </style><b>'


def test_css_string_escaping_in_footers():
    html = _css_html(EVIL_TENANT, 'Test MSP & Co')
    contents = [ln for ln in html.splitlines() if ln.strip().startswith('content: "')]
    assert contents and not any('&amp;' in ln or '&#' in ln or '&lt;' in ln for ln in contents)
    assert 'content: "Smith & Sons \\22 Ltd\\22  \'x\' \\5c  \\3c /style><b>' in html
    assert '</style><b>' not in html.split('<body')[0].split('</title>')[-1]   # not in <style>
    assert 'content: "Test MSP & Co";' in html


def test_css_string_filter_unit():
    f = generator._css_string
    assert str(f('a\nb\r\x0c\x00')) == 'a\\a b\\d \\c \\0 '
    assert str(f('</style>')) == '\\3c /style>'
    assert len(str(f('x' * 500))) == generator.CSS_STRING_MAX
    assert str(f(None)) == ''


@pytest.mark.skipif(not __import__('shutil').which('pdftotext'), reason='pdftotext not installed')
def test_pdf_footer_text_has_no_entities(ctx):
    import subprocess
    conn, tid, msp, out = ctx
    with conn.cursor() as cur:
        cur.execute('UPDATE tenants SET name = %s WHERE id = %s', ('Smith & Sons', tid))
        cur.execute('UPDATE msp_profiles SET footer_text = %s WHERE id = %s',
                    ('Test MSP & Co', msp))
    conn.commit()
    path, _rid = generate_investigation_report(conn, tid, msp, 'Case 1', '', _exhibits()[2:], out)
    text = subprocess.run(['pdftotext', path, '-'], capture_output=True, text=True,
                          check=True).stdout
    assert 'Smith & Sons' in text and 'Test MSP & Co' in text
    assert '&amp;' not in text


def test_summary_optional():
    assert '<h2>Summary</h2>' not in _html(summary='')
    assert '<h2>Summary</h2>' in _html(summary='text')


def test_no_queries_beyond_fetch_and_insert(ctx):
    conn, tid, msp, out = ctx
    seen: list[str] = []

    class Spy:
        def __init__(self, real): self._r = real
        def __enter__(self): self._r.__enter__(); return self
        def __exit__(self, *a): return self._r.__exit__(*a)
        def __getattr__(self, n): return getattr(self._r, n)
        def execute(self, sql, *a):
            seen.append(str(sql))
            return self._r.execute(sql, *a)

    class Wrap:
        def __init__(self, c): self._c = c
        def cursor(self, *a, **k): return Spy(self._c.cursor(*a, **k))
        def __getattr__(self, n): return getattr(self._c, n)

    generate_investigation_report(Wrap(conn), tid, msp, 'T', '', _exhibits(), out)
    assert len(seen) == 4
    for sql in seen:
        assert 'fw_events' not in sql and 'ai_query_results' not in sql
        assert sql.lstrip().split()[0].upper() in ('SELECT', 'INSERT', 'UPDATE')


def test_failure_path_leaves_no_row(ctx, monkeypatch):
    conn, tid, msp, out = ctx

    def boom(*a, **k):
        raise RuntimeError('render failed')

    monkeypatch.setattr(generator.weasyprint, 'HTML', boom)
    with pytest.raises(RuntimeError):
        generate_investigation_report(conn, tid, msp, 'T', '', _exhibits(), out)
    with conn.cursor() as cur:
        cur.execute("SELECT count(*) FROM generated_reports WHERE report_type='ai_investigation'")
        assert cur.fetchone()[0] == 0


def test_commit_false_leaves_transaction_to_caller(ctx):
    conn, tid, msp, out = ctx
    _path, rid = generate_investigation_report(conn, tid, msp, 'T', '', _exhibits()[2:], out,
                                               commit=False)
    conn.rollback()
    assert _rows(conn, rid) == []
