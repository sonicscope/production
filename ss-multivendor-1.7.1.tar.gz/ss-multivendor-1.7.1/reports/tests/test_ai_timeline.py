"""Deterministic evidence timeline: SQL builder + /investigate/timeline (spec §5)."""
import re

import psycopg2
import pytest

from reports.ai import executor, timeline
from reports.ai.sql_guard import check_sql
from reports.tests.test_ai_routes import ai_ready, audit_rows  # noqa: F401


def test_rejects_non_ip_and_bad_window():
    for bad in ("1.2.3.4'; DROP TABLE x;--", '1.2.3', '', 'abc', '1.2.3.4/24', '1.2.3.4 OR 1=1'):
        with pytest.raises(ValueError):
            timeline.build_sql(bad, '24h')
    with pytest.raises(ValueError):
        timeline.build_sql('10.0.0.1', '99d')


def test_ip_is_normalised_and_inlined_only_as_inet_literal():
    sql = timeline.build_sql('10.0.0.1', '24h')
    assert "'10.0.0.1'::inet" in sql and '%s' not in sql
    assert "'::1'::inet" in timeline.build_sql('::1', '1h')


def test_generated_sql_passes_the_stage1_guard_for_every_window_and_family():
    for window in timeline.WINDOWS:
        for ip in ('10.0.0.1', '2001:db8::1'):
            for inc in (False, True):
                assert check_sql(timeline.build_sql(ip, window, inc), 1).sql


def test_denied_and_classification_literals():
    sql = timeline.build_sql('10.0.0.1', '7d')
    for a in timeline.DENIED_ACTIONS:
        assert f"'{a}'" in sql
    assert 'threat_name IS NOT NULL' in sql and 'vpn_policy_name IS NOT NULL' in sql


MALICIOUS = [
    "fe80::1%x' OR '1'='1", 'fe80::1%eth0', 'fe80::1%1', "fe80::1%'", "1.2.3.4'; DROP TABLE x;--",
    "1.2.3.4'", "'1.2.3.4'", '1.2.3.4\n', '\n1.2.3.4', '1.2.3.4\t', '1.2.3.4\x00', '1.2.3.\x004',
    '1.2.3.4\r\n', '\u00a01.2.3.4', '１２７.０.０.１', '١٢٧.٠.٠.١', '1.2.3.4 ', 'x 1.2.3.4',
    '1.2.3.4 OR 1=1', '::1%lo', '::g', '1.2.3.4;', '1.2.3.4--', '1.2.3.4/32', '1.2.3.4"',
    '1.2.3.4\\']
TEMPLATE = timeline.build_sql('10.0.0.1', '24h').replace('10.0.0.1', '@@IP@@')


@pytest.mark.parametrize('bad', MALICIOUS)
def test_malicious_ip_text_never_reaches_sql(bad):
    if bad == '1.2.3.4 ':           # plain ASCII spaces are stripped by policy
        assert timeline.build_sql(bad, '24h') == timeline.build_sql('1.2.3.4', '24h')
        return
    with pytest.raises(ValueError, match='Enter a valid IP address.'):
        timeline.build_sql(bad, '24h')


@pytest.mark.parametrize('ip', ['10.0.0.1', '  10.0.0.1  ', '::1', '2001:DB8::1', 'fe80::1',
                                '::ffff:1.2.3.4', '255.255.255.255'])
@pytest.mark.parametrize('window', list(timeline.WINDOWS))
@pytest.mark.parametrize('inc', [False, True])
def test_only_template_quotes_for_every_valid_ip(ip, window, inc):
    sql = timeline.build_sql(ip, window, inc)
    tmpl = timeline.build_sql('10.0.0.1', window, inc).replace('10.0.0.1', '@@IP@@')
    addr = sql.split("src_ip = '", 1)[1].split("'", 1)[0]
    assert re.fullmatch(r'[0-9A-Fa-f:.]+', addr)
    assert sql == tmpl.replace('@@IP@@', addr)
    assert sql.count("'") == tmpl.count("'")


def test_ipv4_mapped_ipv6_is_normalised_to_ipv4():
    sql = timeline.build_sql('::ffff:1.2.3.4', '24h')
    assert "'1.2.3.4'::inet" in sql and 'ffff' not in sql
    assert timeline.normalize_ip('::FFFF:1.2.3.4') == '1.2.3.4'


def test_limit_selects_one_extra_row_for_the_truncation_signal():
    assert f'LIMIT {timeline.ROWS_MAX + 1}' in timeline.build_sql('10.0.0.1', '24h')
    assert timeline.ROWS_MAX == 500


# ── route ──────────────────────────────────────────────────────────────────
IP = '10.9.9.9'


def post(client, csrf_of, tenant=None, **body):
    if tenant is not None:
        body['tenant_id'] = tenant
    return client.post('/investigate/timeline', json=body,
                       headers={'X-CSRF-Token': csrf_of(client)})


@pytest.fixture
def spy(monkeypatch):
    calls = []
    real = executor.run_query

    def wrapper(config, tenant_id, guarded, **kw):
        calls.append((tenant_id, guarded))
        return real(config, tenant_id, guarded, **kw)

    monkeypatch.setattr(executor, 'run_query', wrapper)
    return calls


def seed_mixed(seed_fw_event, tenant):
    from datetime import datetime, timedelta, timezone
    now = datetime.now(timezone.utc)
    seed_fw_event(tenant, time=now - timedelta(minutes=50), src_ip=IP, dst_ip='1.1.1.1',
                  action='deny', rule_name='r-deny')
    seed_fw_event(tenant, time=now - timedelta(minutes=40), src_ip='8.8.8.8', dst_ip=IP,
                  action='allow', threat_name='Evil.Bot')
    seed_fw_event(tenant, time=now - timedelta(minutes=30), src_ip=IP, dst_ip='1.1.1.1',
                  action='allow', vpn_policy_name='site2site')
    seed_fw_event(tenant, time=now - timedelta(minutes=20), src_ip=IP, dst_ip='1.1.1.1',
                  action='allow', app_name='HTTPS')
    seed_fw_event(tenant, time=now - timedelta(days=40), src_ip=IP, dst_ip='1.1.1.1',
                  action='deny')
    seed_fw_event(tenant, time=now - timedelta(minutes=10), src_ip='7.7.7.7', dst_ip='1.1.1.1',
                  action='deny')


def test_timeline_classifies_orders_and_excludes_allowed(client, app_module, login_as, csrf_of,
                                                         ai_ready, seed_fw_event, spy):
    seed_mixed(seed_fw_event, ai_ready)
    login_as('user', [ai_ready])
    resp = post(client, csrf_of, ai_ready, ip=f' {IP} ', window='31d')
    assert resp.status_code == 200
    j = resp.get_json()
    assert j['columns'] == list(timeline.COLUMNS) and j['ip'] == IP and j['window'] == '31d'
    kinds = [r[1] for r in j['rows']]
    assert kinds == ['vpn', 'threat', 'denied']            # newest first, allowed excluded,
    assert j['row_count'] == 3 and j['truncated'] is False   # 40-day-old event absent
    assert 'token' not in j
    assert [c[0] for c in spy] == [ai_ready]               # via executor.run_query, guarded
    row = audit_rows(app_module, 'timeline')
    assert len(row) == 1 and row[0][6].startswith('SELECT time, CASE')


def test_include_allowed_adds_allowed_rows(client, login_as, csrf_of, ai_ready, seed_fw_event):
    seed_mixed(seed_fw_event, ai_ready)
    login_as('user', [ai_ready])
    j = post(client, csrf_of, ai_ready, ip=IP, window='24h', include_allowed=True).get_json()
    assert [r[1] for r in j['rows']] == ['allowed', 'vpn', 'threat', 'denied']


def test_cross_tenant_rows_never_appear(client, login_as, csrf_of, ai_ready, seed_fw_event,
                                        seed_tenants):
    other, = seed_tenants('Other')
    seed_fw_event(other, src_ip=IP, dst_ip='2.2.2.2', action='deny', rule_name='other-rule')
    seed_fw_event(ai_ready, src_ip=IP, dst_ip='1.1.1.1', action='deny', rule_name='mine')
    login_as('user', [ai_ready])
    j = post(client, csrf_of, ai_ready, ip=IP).get_json()
    assert [r[7] for r in j['rows']] == ['mine']


def test_rows_capped_at_500_with_truncated(client, login_as, csrf_of, ai_ready, seed_fw_event):
    for _ in range(503):
        seed_fw_event(ai_ready, src_ip=IP, dst_ip='1.1.1.1', action='deny')
    login_as('user', [ai_ready])
    j = post(client, csrf_of, ai_ready, ip=IP).get_json()
    assert len(j['rows']) == 500 and j['row_count'] == 500 and j['truncated'] is True


def test_exactly_500_rows_is_not_truncated(client, login_as, csrf_of, ai_ready, seed_fw_event):
    for _ in range(500):
        seed_fw_event(ai_ready, src_ip=IP, dst_ip='1.1.1.1', action='deny')
    login_as('user', [ai_ready])
    j = post(client, csrf_of, ai_ready, ip=IP).get_json()
    assert len(j['rows']) == 500 and j['truncated'] is False


@pytest.mark.parametrize('bad', ["fe80::1%x' OR '1'='1", 'fe80::1%eth0', '1.2.3.4\n'])
def test_scoped_or_quoted_ip_is_400_without_executor_or_audit(
        client, app_module, login_as, csrf_of, ai_ready, spy, bad):
    login_as('user', [ai_ready])
    resp = post(client, csrf_of, ai_ready, ip=bad)
    assert resp.status_code == 400 and resp.get_json()['error'] == 'Enter a valid IP address.'
    assert spy == [] and audit_rows(app_module, 'timeline') == []


def test_mapped_ipv4_returns_plain_subject(client, login_as, csrf_of, ai_ready, seed_fw_event):
    seed_fw_event(ai_ready, src_ip='1.2.3.4', dst_ip='1.1.1.1', action='deny')
    login_as('user', [ai_ready])
    j = post(client, csrf_of, ai_ready, ip='::ffff:1.2.3.4').get_json()
    assert j['ip'] == '1.2.3.4' and len(j['rows']) == 1


@pytest.mark.parametrize('body', [
    {'ip': "1.2.3.4'; DROP TABLE x;--"}, {'ip': ''}, {'ip': '1.2.3.4/24'}, {'ip': 5},
    {'ip': IP, 'window': '99d'}, {'ip': IP, 'window': 7},
    {'ip': IP, 'include_allowed': 'yes'}])
def test_invalid_input_is_400(client, login_as, csrf_of, ai_ready, spy, body):
    login_as('user', [ai_ready])
    assert post(client, csrf_of, ai_ready, **body).status_code == 400
    assert spy == []


@pytest.mark.parametrize('tenant', [None, 'x', True, 0, 2**40])
def test_invalid_tenant_is_400(client, login_as, csrf_of, ai_ready, tenant):
    login_as('user', [ai_ready])
    resp = client.post('/investigate/timeline', json={'tenant_id': tenant, 'ip': IP},
                       headers={'X-CSRF-Token': csrf_of(client)})
    assert resp.status_code == 400


def test_access_flag_csrf_and_roles(client, app_module, login_as, csrf_of, ai_ready, seed_tenants,
                                    spy):
    other, = seed_tenants('Other')
    login_as('user', [ai_ready])
    assert post(client, csrf_of, other, ip=IP).status_code == 404          # no access
    assert client.post('/investigate/timeline', json={'tenant_id': ai_ready, 'ip': IP}
                       ).status_code == 400                               # no CSRF
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute('UPDATE tenants SET ai_enabled = false WHERE id = %s', (ai_ready,))
    assert post(client, csrf_of, ai_ready, ip=IP).status_code == 403
    assert spy == []
    login_as('customer', [ai_ready])
    assert post(client, csrf_of, ai_ready, ip=IP).status_code in (302, 404)
    assert spy == []


def test_needs_no_provider_key_but_needs_executor_role(client, app_module, login_as, csrf_of,
                                                       ai_ready, monkeypatch):
    login_as('user', [ai_ready])
    monkeypatch.setattr(routes_mod(), 'get_provider',
                        lambda n: (_ for _ in ()).throw(AssertionError('no provider')))
    assert post(client, csrf_of, ai_ready, ip=IP).status_code == 200
    monkeypatch.delenv('AI_DB_PASSWORD')
    assert post(client, csrf_of, ai_ready, ip=IP).status_code == 409


def routes_mod():
    from reports.ai import routes
    return routes


def test_rate_limit_counts_timeline_and_gate_released(client, app_module, login_as, csrf_of,
                                                      ai_ready, spy):
    uid = login_as('user', [ai_ready])
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        for _ in range(20):
            cur.execute("INSERT INTO ai_audit (kind, user_id, tenant_id) VALUES ('timeline', %s, %s)",
                        (uid, ai_ready))
    resp = post(client, csrf_of, ai_ready, ip=IP)
    assert resp.status_code == 429 and spy == []


def test_unexpected_error_is_generic_and_gate_released(client, login_as, csrf_of, ai_ready,
                                                       monkeypatch):
    login_as('user', [ai_ready])

    def boom(*a, **k):
        raise RuntimeError('secret-internal-detail')

    monkeypatch.setattr(executor, 'run_query', boom)
    for _ in range(routes_mod().MAX_CONCURRENT + 1):
        resp = post(client, csrf_of, ai_ready, ip=IP)
        assert resp.status_code == 500 and 'secret' not in resp.get_data(as_text=True)


def test_denied_actions_match_reports_queries():
    assert set(timeline.DENIED_ACTIONS) == {'deny', 'drop', 'block', 'reset'}
    assert "'drop'" in timeline.build_sql('10.0.0.1', '7d')
