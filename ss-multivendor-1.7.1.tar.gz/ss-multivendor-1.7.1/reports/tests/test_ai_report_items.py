"""Pure exhibit shaping for the Investigation Report (Stage 3 spec §3)."""
import pytest

from reports.ai import report_items as ri


def finding(kind='query', cols=('a', 'b'), rows=(('1', '2'),), row_count=None, truncated=False,
            title='T', note='N', **extra):
    ev = {'columns': list(cols), 'rows': [list(r) for r in rows],
          'row_count': len(rows) if row_count is None else row_count, 'truncated': truncated}
    if kind == 'query':
        ev.update({'sql': 'SELECT 1', 'snapshot_at': '2026-11-19T08:30:00+00:00'})
    else:
        ev.update({'subject': '10.0.0.5', 'window': '24h',
                   'generated_at': '2026-11-19T08:30:00+00:00'})
    ev.update(extra)
    return {'id': 7, 'title': title, 'note': note, 'evidence_kind': kind, 'evidence': ev}


def one(f, limit=25, q='What happened?'):
    return ri.build_exhibits([{'finding': f, 'row_limit': limit, 'question': q}])[0]


@pytest.mark.parametrize('i,s', [(0, 'A'), (1, 'B'), (25, 'Z'), (26, 'AA'), (27, 'AB'),
                                 (51, 'AZ'), (52, 'BA')])
def test_exhibit_letter(i, s):
    assert ri.exhibit_letter(i) == s


def test_basic_query_exhibit():
    e = one(finding())
    assert e['letter'] == 'A' and e['finding_id'] == 7 and e['kind'] == 'query'
    assert e['title'] == 'T' and e['note'] == 'N' and e['question'] == 'What happened?'
    assert e['columns'] == ['a', 'b'] and e['rows'] == [['1', '2']]
    assert e['shown'] == 1 and e['total'] == 1 and e['notes'] == []
    assert e['frozen_at'] == '2026-11-19 08:30 UTC'


def test_row_limit_and_note():
    rows = [(str(i), 'x') for i in range(40)]
    e = one(finding(rows=rows), limit=10)
    assert len(e['rows']) == 10 and e['shown'] == 10 and e['total'] == 40
    assert 'Showing 10 of 40 rows' in e['notes']


def test_total_comes_from_row_count_and_snapshot_truncation_noted():
    e = one(finding(rows=[('1', '2')] * 5, row_count=1234, truncated=True), limit=100)
    assert e['shown'] == 5 and e['total'] == 1234
    assert 'Showing 5 of 1234 rows' in e['notes']
    assert 'The saved snapshot was limited to 500 rows.' in e['notes']


@pytest.mark.parametrize('bad', [7, 10.0, True, '10', None])
def test_bad_row_limit_falls_back_to_25(bad):
    rows = [(str(i), 'x') for i in range(40)]
    assert len(one(finding(rows=rows), limit=bad)['rows']) == 25


def test_columns_capped_at_12_with_note():
    cols = [f'c{i}' for i in range(15)]
    e = one(finding(cols=cols, rows=[[str(i) for i in range(15)]]))
    assert len(e['columns']) == 12 and len(e['rows'][0]) == 12
    assert '3 more columns omitted' in e['notes']


def test_cells_clipped_and_none_blank_and_non_strings():
    e = one(finding(rows=[('x' * 500, None), (12, 3.5)]))
    assert e['rows'][0][0] == 'x' * 199 + '…' and e['rows'][0][1] == ''
    assert e['rows'][1] == ['12', '3.5']


def test_hostile_text_is_passed_through_unmodified_for_autoescape():
    h = '<script>alert(1)</script>'
    e = one(finding(title=h, note=h, rows=[(h, h)]), q=h)
    assert e['title'] == h and e['rows'][0][0] == h      # escaping is the template's job
    assert e['question'] == h


def test_question_trimmed_and_optional():
    assert one(finding(), q='q' * 400)['question'] == 'q' * 299 + '…'
    assert one(finding(), q=None)['question'] is None


def test_timeline_exhibit():
    e = one(finding(kind='timeline', cols=('time', 'kind'), rows=[('t1', 'deny')]))
    assert e['kind'] == 'timeline' and e['subject'] == '10.0.0.5' and e['window'] == '24h'
    assert e['question'] is None
    assert e['frozen_at'] == '2026-11-19 08:30 UTC'


def test_garbage_row_count_never_below_rows_given():
    e = one(finding(rows=[('1', '2')] * 5, row_count='x'))
    assert e['total'] == 5 and e['shown'] == 5
    assert not any(n.startswith('Showing') for n in e['notes'])


def test_missing_or_garbage_evidence_does_not_crash():
    f = {'id': 1, 'title': 'T', 'note': '', 'evidence_kind': 'query',
         'evidence': {'columns': None, 'rows': 'nope', 'row_count': 'x', 'snapshot_at': 'zzz'}}
    e = one(f)
    assert e['columns'] == [] and e['rows'] == [] and e['total'] == 0
    assert e['frozen_at'] == 'zzz'


def test_letters_follow_input_order():
    items = [{'finding': finding(title=f'F{i}'), 'row_limit': 25, 'question': None}
             for i in range(28)]
    out = ri.build_exhibits(items)
    assert [x['letter'] for x in out[:3]] == ['A', 'B', 'C'] and out[26]['letter'] == 'AA'


def test_print_totals_and_budget_use_printed_rows_only():
    ev = {'columns': ['a', 'b'], 'rows': [['xx', 'y']] * 50, 'row_count': 50}
    ex = ri.build_exhibits([{'finding': {'id': 1, 'title': 't', 'evidence_kind': 'timeline',
                                      'evidence': ev}, 'row_limit': 10}])
    assert ri.print_totals(ex) == (10, 20, 2 + 10 * 3)
    assert ri.budget_error(ex) is None
    huge = [dict(ex[0], rows=[['x'] * 2] * (ri.MAX_REPORT_ROWS + 1))]
    assert 'limit 500 rows' in ri.budget_error(huge)


@pytest.mark.parametrize('raw,out', [
    ('2026-11-18T17:17:26.443452+00:00', '2026-11-18 17:17:26 UTC'),
    ('2026-11-18T17:17:26Z', '2026-11-18 17:17:26 UTC'),
    ('2026-11-18T17:17:26', '2026-11-18 17:17:26'),
    ('2026-11-18T17:17:26+02:00', '2026-11-18T17:17:26+02:00'),     # non-UTC offsets left untouched
    ('x2026-11-18T17:17:26Z', 'x2026-11-18T17:17:26Z'),
])
def test_timestamp_cells_are_compacted(raw, out):
    assert one(finding(rows=[(raw, 'x')]))['rows'][0][0] == out
