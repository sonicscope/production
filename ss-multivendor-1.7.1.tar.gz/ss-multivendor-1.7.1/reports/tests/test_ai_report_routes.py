"""Stage 3 route: POST /investigate/report (findings -> Investigation Report PDF)."""
import psycopg2
import pytest

from reports import generator
from reports.ai import investigations
from reports.tests.test_ai_investigations_routes import make
from reports.tests.test_ai_routes import ai_ready, audit_rows  # noqa: F401

HDR = 'X-CSRF-Token'
GENERIC = 'Something went wrong. The error was logged.'


def db(app_module):
    return psycopg2.connect(**app_module.DB_CONFIG)


def sql_one(app_module, sql, params=()):
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return cur.fetchall() if cur.description else None


@pytest.fixture
def report_env(app_module, ai_ready, seed_msp_profile, tmp_path, monkeypatch):
    """OUTPUT_DIR -> tmp_path and an MSP profile linked to the AI-enabled tenant."""
    monkeypatch.setattr(app_module, 'OUTPUT_DIR', str(tmp_path))
    msp = seed_msp_profile('Report MSP')
    sql_one(app_module, 'UPDATE tenants SET msp_profile_id = %s WHERE id = %s', (msp, ai_ready))
    return ai_ready


def pin(client, csrf_of, app_module, inv_id, title='A finding'):
    rid = sql_one(app_module, 'SELECT id FROM ai_query_results WHERE investigation_id = %s '
                  'ORDER BY id', (inv_id,))[0][0]
    resp = client.post(f'/investigate/{inv_id}/pin', headers={HDR: csrf_of(client)},
                       json={'kind': 'query', 'result_id': rid, 'title': title})
    assert resp.status_code == 200, resp.get_data(as_text=True)
    return resp.get_json()['id']


def post(client, csrf_of, **body):
    return client.post('/investigate/report', json=body, headers={HDR: csrf_of(client)})


@pytest.fixture
def one(client, app_module, login_as, csrf_of, report_env, monkeypatch):
    """A staff user with one saved investigation and one pinned finding."""
    uid, inv = make(client, login_as, csrf_of, report_env, monkeypatch)
    return {'uid': uid, 'inv': inv, 'fid': pin(client, csrf_of, app_module, inv),
            'tenant': report_env}


def counts(app_module):
    return sql_one(app_module, "SELECT count(*) FROM generated_reports WHERE report_type = "
                   "'ai_investigation'")[0][0]


def test_happy_path(client, app_module, csrf_of, one, tmp_path):
    resp = post(client, csrf_of, title='  Weekly   review ', summary='All good.',
                items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 200, resp.get_data(as_text=True)
    rid = resp.get_json()['report_id']
    assert resp.get_json()['download_url'] == f'/reports/{rid}/download'
    dl = client.get(resp.get_json()['download_url'])
    assert dl.status_code == 200 and dl.data.startswith(b'%PDF-')
    assert sql_one(app_module, 'SELECT report_type FROM generated_reports WHERE id = %s',
                   (rid,)) == [('ai_investigation',)]
    assert sql_one(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s',
                   (one['fid'],)) == [(rid,)]
    rows = sql_one(app_module, "SELECT row_count, question, sql, user_id, tenant_id FROM ai_audit "
                   "WHERE kind = 'report'")
    assert rows == [(1, None, None, one['uid'], one['tenant'])]


@pytest.mark.parametrize('bad', [
    {'title': 5, 'items': 'x'}, {'title': 'T', 'items': []}, {'title': 'T', 'items': 'x'},
    {'title': '', 'items': [{'finding_id': 1, 'row_limit': 25}]},
    {'title': '   ', 'items': [{'finding_id': 1, 'row_limit': 25}]},
    {'title': 'x' * 201, 'items': [{'finding_id': 1, 'row_limit': 25}]},
    {'title': 'T', 'summary': 'x' * 2001, 'items': [{'finding_id': 1, 'row_limit': 25}]},
    {'title': 'T', 'summary': 5, 'items': [{'finding_id': 1, 'row_limit': 25}]},
    {'title': 'T', 'items': [{'finding_id': 1, 'row_limit': 25}] * 26},
    {'title': 'T', 'items': [{'finding_id': '1', 'row_limit': 25}]},
    {'title': 'T', 'items': [{'finding_id': True, 'row_limit': 25}]},
    {'title': 'T', 'items': [{'finding_id': 0, 'row_limit': 25}]},
    {'title': 'T', 'items': [{'finding_id': -3, 'row_limit': 25}]},
    {'title': 'T', 'items': [{'finding_id': 1, 'row_limit': 7}]},
    {'title': 'T', 'items': [{'finding_id': 1, 'row_limit': True}]},
    {'title': 'T', 'items': [{'finding_id': 1}]},
    {'title': 'T', 'items': ['nope']},
    {'title': 'T', 'items': [{'finding_id': 1, 'row_limit': 25}, {'finding_id': 1, 'row_limit': 10}]},
])
def test_bad_shape_is_400_and_creates_nothing(bad, client, app_module, csrf_of, one, monkeypatch):
    monkeypatch.setattr(generator, 'generate_investigation_report',
                        lambda *a, **k: pytest.fail('generator must not run'))
    resp = post(client, csrf_of, **bad)
    assert resp.status_code == 400
    assert counts(app_module) == 0
    assert sql_one(app_module, "SELECT count(*) FROM ai_audit WHERE kind = 'report'") == [(0,)]


def test_malformed_json_is_400(client, csrf_of, one):
    resp = client.post('/investigate/report', data='{not json',
                       headers={HDR: csrf_of(client), 'Content-Type': 'application/json'})
    assert resp.status_code == 400


def test_missing_csrf_is_400_and_customer_is_404(client, app_module, login_as, csrf_of, one):
    body = {'title': 'T', 'items': [{'finding_id': one['fid'], 'row_limit': 25}]}
    assert client.post('/investigate/report', json=body).status_code == 400
    login_as('customer', [one['tenant']])
    resp = client.post('/investigate/report', json=body, headers={HDR: csrf_of(client)})
    assert resp.status_code in (302, 404)       # customers are bounced by the global guard
    assert counts(app_module) == 0


def test_cross_tenant_findings_rejected(client, app_module, login_as, csrf_of, report_env,
                                        seed_tenants, monkeypatch):
    other, = seed_tenants('Other')
    uid, inv_a = make(client, login_as, csrf_of, report_env, monkeypatch)
    fa = pin(client, csrf_of, app_module, inv_a)
    with db(app_module) as conn, conn.cursor() as cur:
        inv_b = investigations.create(cur, tenant_id=other, owner_user_id=uid, title='b')
        fb = investigations.add_finding(cur, inv_b, tenant_id=other, created_by=uid, title='b',
                                        note='', evidence_kind='query',
                                        evidence={'sql': 'SELECT 1', 'columns': ['n'],
                                                  'rows': [[1]], 'row_count': 1})
        cur.execute('INSERT INTO ui_user_tenants (user_id, tenant_id) VALUES (%s, %s)',
                    (uid, other))
    resp = post(client, csrf_of, title='T', items=[{'finding_id': fa, 'row_limit': 25},
                                                   {'finding_id': fb, 'row_limit': 25}])
    assert resp.status_code == 400
    assert resp.get_json()['error'] == 'Findings must be from one customer.'
    assert counts(app_module) == 0


def test_invisible_findings_look_like_unknown_ids(client, app_module, login_as, csrf_of, one,
                                                  report_env, seed_tenants):
    other, = seed_tenants('Other')
    with db(app_module) as conn, conn.cursor() as cur:
        inv_o = investigations.create(cur, tenant_id=other, owner_user_id=one['uid'], title='o')
        f_other_tenant = investigations.add_finding(
            cur, inv_o, tenant_id=other, created_by=one['uid'], title='o', note='',
            evidence_kind='query', evidence={'columns': [], 'rows': []})
    # same tenant, but another user's un-shared investigation
    login_as('user', [one['tenant']])
    unknown = post(client, csrf_of, title='T', items=[{'finding_id': 2**31 - 1, 'row_limit': 25}])
    own_private = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    no_tenant = post(client, csrf_of, title='T',
                     items=[{'finding_id': f_other_tenant, 'row_limit': 25}])
    for r in (unknown, own_private, no_tenant):
        assert r.status_code == 404
    assert {r.get_data() for r in (unknown, own_private, no_tenant)} == {unknown.get_data()}
    assert counts(app_module) == 0


def test_shared_investigation_finding_usable_by_other_staff(client, app_module, login_as,
                                                            csrf_of, report_env, monkeypatch):
    uid, inv = make(client, login_as, csrf_of, report_env, monkeypatch, share=True)
    fid = pin(client, csrf_of, app_module, inv)
    other_uid = login_as('user', [report_env])
    assert other_uid != uid
    resp = post(client, csrf_of, title='T', items=[{'finding_id': fid, 'row_limit': 10}])
    assert resp.status_code == 200, resp.get_data(as_text=True)


def test_ai_disabled_for_tenant_is_403(client, app_module, csrf_of, one):
    sql_one(app_module, 'UPDATE tenants SET ai_enabled = false WHERE id = %s', (one['tenant'],))
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 403 and counts(app_module) == 0


def _seed_attempts(app_module, one, n, kind='report_start'):
    sql_one(app_module, "INSERT INTO ai_audit (kind, user_id, tenant_id, row_count) "
            "SELECT %s, %s, %s, 1 FROM generate_series(1, %s)",
            (kind, one['uid'], one['tenant'], n))


def test_rate_limit_with_5_prior_attempts_is_429(client, app_module, csrf_of, one):
    _seed_attempts(app_module, one, 5)
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 429 and counts(app_module) == 0


def test_rate_limit_with_4_prior_attempts_is_allowed(client, app_module, csrf_of, one):
    _seed_attempts(app_module, one, 4)
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 200, resp.get_data(as_text=True)
    assert client.application.extensions['ai_report_inflight'] == {}


def test_old_success_rows_do_not_count_toward_limit(client, app_module, csrf_of, one):
    _seed_attempts(app_module, one, 5, kind='report')       # only 'report_start' is counted
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 200


def test_failed_attempts_are_audited_and_rate_limited(client, app_module, csrf_of, one,
                                                      monkeypatch):
    def boom(*a, **k):
        raise RuntimeError('render failed')
    monkeypatch.setattr(generator, 'generate_investigation_report', boom)
    body = dict(title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    for _ in range(5):
        assert post(client, csrf_of, **body).status_code == 500
    assert sql_one(app_module, "SELECT kind, row_count, question, sql FROM ai_audit "
                   "WHERE kind LIKE 'report%%'") == [('report_start', 1, None, None)] * 5
    assert post(client, csrf_of, **body).status_code == 429
    assert client.application.extensions['ai_report_inflight'] == {}


def _big_finding(app_module, one, rows, cols=2, cell='x', title='big'):
    with db(app_module) as conn, conn.cursor() as cur:
        return investigations.add_finding(
            cur, one['inv'], tenant_id=one['tenant'], created_by=one['uid'], title=title,
            note='', evidence_kind='timeline',
            evidence={'subject': 's', 'window': '1h', 'columns': [f'c{i}' for i in range(cols)],
                      'rows': [[cell] * cols for _ in range(rows)], 'row_count': rows})


def _no_render(monkeypatch):
    monkeypatch.setattr(generator, 'generate_investigation_report',
                        lambda *a, **k: pytest.fail('render must not start'))


def _assert_rejected(resp, app_module, limit_word):
    assert resp.status_code == 400
    assert 'would print too much evidence' in resp.get_json()['error']
    assert limit_word in resp.get_json()['error']
    assert counts(app_module) == 0
    assert sql_one(app_module, "SELECT count(*) FROM ai_audit WHERE kind LIKE 'report%%'") == [(0,)]


def test_budget_rows_exceeded_is_400_without_render(client, app_module, csrf_of, one, monkeypatch):
    _no_render(monkeypatch)
    fids = [_big_finding(app_module, one, 100, title=f'b{i}') for i in range(6)]   # 600 rows
    resp = post(client, csrf_of, title='T',
                items=[{'finding_id': f, 'row_limit': 100} for f in fids])
    _assert_rejected(resp, app_module, '500 rows')


def test_budget_cells_exceeded_is_400_without_render(client, app_module, csrf_of, one, monkeypatch):
    _no_render(monkeypatch)
    # 5 x 100 rows = 500 rows (at the row limit) but x 12 cols = 6000 cells > 5000
    fids = [_big_finding(app_module, one, 100, cols=12, title=f'b{i}') for i in range(5)]
    resp = post(client, csrf_of, title='T',
                items=[{'finding_id': f, 'row_limit': 100} for f in fids])
    _assert_rejected(resp, app_module, '5000 cells')


def test_budget_chars_exceeded_is_400_without_render(client, app_module, csrf_of, one, monkeypatch):
    _no_render(monkeypatch)
    # 130 rows and 1300 cells (both within limits) but 1300 x 200 chars = 260k > 250k
    fids = [_big_finding(app_module, one, 65, cols=10, cell='y' * 200, title=f'b{i}')
            for i in range(2)]
    resp = post(client, csrf_of, title='T',
                items=[{'finding_id': f, 'row_limit': 100} for f in fids])
    _assert_rejected(resp, app_module, '250000 characters')


def test_budget_at_limit_passes(client, app_module, csrf_of, one, monkeypatch):
    fids = [_big_finding(app_module, one, 100, cols=10, title=f'b{i}') for i in range(5)]
    # exactly 500 rows and 5000 cells
    monkeypatch.setattr(generator, 'generate_investigation_report',
                        lambda *a, **k: ('/x.pdf', 9001))
    resp = post(client, csrf_of, title='T',
                items=[{'finding_id': f, 'row_limit': 100} for f in fids])
    assert resp.status_code == 200, resp.get_data(as_text=True)
    assert sql_one(app_module, "SELECT row_count FROM ai_audit WHERE kind = 'report'") == [(500,)]


def test_budget_counts_printed_rows_not_stored_rows(client, app_module, csrf_of, one,
                                                    monkeypatch):
    monkeypatch.setattr(generator, 'generate_investigation_report',
                        lambda *a, **k: ('/x.pdf', 9002))
    fids = [_big_finding(app_module, one, 100, title=f'b{i}') for i in range(10)]   # 1000 stored
    resp = post(client, csrf_of, title='T',
                items=[{'finding_id': f, 'row_limit': 25} for f in fids])           # 250 printed
    assert resp.status_code == 200, resp.get_data(as_text=True)


def test_mixed_invisible_and_visible_is_404_not_one_customer_400(client, app_module, login_as,
                                                                  csrf_of, one, seed_tenants):
    other, = seed_tenants('Hidden')
    with db(app_module) as conn, conn.cursor() as cur:
        inv_o = investigations.create(cur, tenant_id=other, owner_user_id=one['uid'], title='o')
        hidden = investigations.add_finding(
            cur, inv_o, tenant_id=other, created_by=one['uid'], title='o', note='',
            evidence_kind='query', evidence={'columns': [], 'rows': []})
    login_as('user', [one['tenant']])                      # cannot see tenant 'other'
    resp = post(client, csrf_of, title='T',
                items=[{'finding_id': hidden, 'row_limit': 25}])
    assert resp.status_code == 404
    assert counts(app_module) == 0


def test_failure_after_generation_leaves_no_row_or_link(client, app_module, csrf_of, one,
                                                        monkeypatch):
    def bad_link(*a, **k):
        raise RuntimeError('link failed')
    monkeypatch.setattr(investigations, 'link_report', bad_link)
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 500 and resp.get_json() == {'error': GENERIC}
    assert counts(app_module) == 0
    assert sql_one(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s',
                   (one['fid'],)) == [(None,)]
    assert sql_one(app_module, "SELECT count(*) FROM ai_audit WHERE kind = 'report'") == [(0,)]
    assert sql_one(app_module, "SELECT count(*) FROM ai_audit WHERE kind = 'report_start'") == [(1,)]
    import glob
    assert glob.glob(app_module.OUTPUT_DIR + '/*.pdf') == []          # orphan PDF removed
    assert client.application.extensions['ai_report_inflight'] == {}


def test_success_is_single_transaction(client, app_module, csrf_of, one, monkeypatch):
    seen = {}
    real = generator.generate_investigation_report

    def spy(*a, **k):
        seen['commit'] = k.get('commit')
        return real(*a, **k)
    monkeypatch.setattr(generator, 'generate_investigation_report', spy)
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 200
    assert seen['commit'] is False
    rid = resp.get_json()['report_id']
    assert sql_one(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s',
                   (one['fid'],)) == [(rid,)]
    assert sql_one(app_module, "SELECT count(*) FROM ai_audit WHERE kind = 'report'") == [(1,)]
    assert client.application.extensions['ai_report_inflight'] == {}


def test_msp_fallback_single_profile_used(client, app_module, csrf_of, one):
    sql_one(app_module, 'UPDATE tenants SET msp_profile_id = NULL WHERE id = %s', (one['tenant'],))
    sql_one(app_module, 'DELETE FROM msp_profiles WHERE id <> (SELECT min(id) FROM msp_profiles)')
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 200, resp.get_data(as_text=True)


def test_msp_fallback_refused_with_several_profiles(client, app_module, csrf_of, one,
                                                    seed_msp_profile):
    seed_msp_profile('Second MSP')
    sql_one(app_module, 'UPDATE tenants SET msp_profile_id = NULL WHERE id = %s', (one['tenant'],))
    assert sql_one(app_module, 'SELECT count(*) FROM msp_profiles')[0][0] >= 2
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 409
    assert counts(app_module) == 0


def test_inflight_slot_held_is_429(client, app_module, csrf_of, one):
    inflight = client.application.extensions['ai_report_inflight']
    inflight[one['uid']] = 1
    try:
        resp = post(client, csrf_of, title='T',
                    items=[{'finding_id': one['fid'], 'row_limit': 25}])
        assert resp.status_code == 429 and counts(app_module) == 0
    finally:
        inflight.clear()


def test_generator_failure_is_generic_500_and_releases_slot(client, app_module, csrf_of, one,
                                                            monkeypatch):
    def boom(*a, **k):
        raise RuntimeError('secret-internal-detail /var/lib/x')
    monkeypatch.setattr(generator, 'generate_investigation_report', boom)
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 500
    assert resp.get_json() == {'error': GENERIC}
    assert 'secret' not in resp.get_data(as_text=True)
    assert counts(app_module) == 0
    assert sql_one(app_module, 'SELECT report_id FROM ai_findings WHERE id = %s',
                   (one['fid'],)) == [(None,)]
    assert client.application.extensions['ai_report_inflight'] == {}


def test_no_msp_profile_is_409(client, app_module, csrf_of, one):
    # Exercise the real app helper with no profiles at all.
    sql_one(app_module, 'UPDATE tenants SET msp_profile_id = NULL')
    sql_one(app_module, 'DELETE FROM msp_profiles')
    resp = post(client, csrf_of, title='T', items=[{'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 409
    assert resp.get_json()['error'] == 'No MSP profile is configured for this customer.'
    assert counts(app_module) == 0


def test_order_row_limit_and_question_lookup(client, app_module, csrf_of, one, monkeypatch):
    with db(app_module) as conn, conn.cursor() as cur:
        tl = investigations.add_finding(
            cur, one['inv'], tenant_id=one['tenant'], created_by=one['uid'], title='tl', note='',
            evidence_kind='timeline',
            evidence={'subject': '10.0.0.1', 'window': '24h', 'columns': ['a'],
                      'rows': [[i] for i in range(40)], 'row_count': 40,
                      'sql': 'SELECT 1 -- must not become a question'})
    captured = {}

    def fake(db_conn, tenant_id, msp_id, title, summary, exhibits, output_dir, commit=True):
        captured.update(title=title, summary=summary, exhibits=exhibits, out=output_dir)
        return '/x.pdf', 4242
    monkeypatch.setattr(generator, 'generate_investigation_report', fake)
    resp = post(client, csrf_of, title='T', summary='S',
                items=[{'finding_id': tl, 'row_limit': 10},
                       {'finding_id': one['fid'], 'row_limit': 25}])
    assert resp.status_code == 200 and resp.get_json()['report_id'] == 4242
    ex = captured['exhibits']
    assert [e['finding_id'] for e in ex] == [tl, one['fid']]
    assert [e['letter'] for e in ex] == ['A', 'B']
    assert ex[0]['shown'] == 10 and ex[0]['question'] is None
    assert ex[1]['question'] == 'what happened?'
    assert captured['out'] == app_module.OUTPUT_DIR
    assert sql_one(app_module, 'SELECT report_id FROM ai_findings WHERE id = ANY(%s)',
                   ([tl, one['fid']],)) == [(4242,), (4242,)]
