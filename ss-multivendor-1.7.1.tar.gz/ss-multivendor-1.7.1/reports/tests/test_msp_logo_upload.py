"""MSP logo upload: content (magic-byte) verification on /msp-profiles/<id>/edit.

The extension and client-sent mimetype are attacker-controlled, so the file
content must match the claimed type. An EPS/PS file renamed .png must never
reach disk (it would otherwise reach WeasyPrint/Pillow and Ghostscript).
"""
from __future__ import annotations

import io
import os

import psycopg2
import pytest

PNG = b'\x89PNG\r\n\x1a\n' + b'\x00' * 32
JPEG = b'\xff\xd8\xff\xe0' + b'\x00' * 32
EPS = b'%!PS-Adobe-3.0 EPSF-3.0\n%%BoundingBox: 0 0 10 10\n'
EPS_BINARY = b'\xc5\xd0\xd3\xc6' + b'\x00' * 28
SVG = b'<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>'


def _post(client, csrf_of, pid, filename, content, mimetype):
    data = {
        '_csrf': csrf_of(client),
        'name': 'Acme MSP',
        'logo': (io.BytesIO(content), filename, mimetype),
    }
    return client.post(f'/msp-profiles/{pid}/edit', data=data,
                       content_type='multipart/form-data')


def _logo_path(app_module, pid):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute('SELECT logo_path FROM msp_profiles WHERE id=%s', (pid,))
        return cur.fetchone()[0]


def _files(app_module):
    d = app_module.LOGO_DIR
    return sorted(os.listdir(d)) if os.path.isdir(d) else []


@pytest.fixture
def setup(app_module, client, login_as, csrf_of, seed_msp_profile):
    login_as('admin')
    pid = seed_msp_profile('Acme MSP')
    return app_module, client, csrf_of, pid


@pytest.mark.parametrize('filename,content,mime', [
    ('logo.png', PNG, 'image/png'),
    ('logo.jpg', JPEG, 'image/jpeg'),
    ('logo.jpeg', JPEG, 'image/jpeg'),
    ('logo.svg', SVG, 'image/svg+xml'),
])
def test_valid_logo_accepted(setup, filename, content, mime):
    app_module, client, csrf_of, pid = setup
    r = _post(client, csrf_of, pid, filename, content, mime)
    assert r.status_code == 302
    path = _logo_path(app_module, pid)
    assert path and os.path.isfile(path)
    assert os.path.dirname(path) == app_module.LOGO_DIR
    if not filename.endswith('svg'):
        with open(path, 'rb') as fh:
            assert fh.read() == content  # stream position reset before save


@pytest.mark.parametrize('filename,content,mime', [
    ('logo.png', EPS, 'image/png'),
    ('logo.png', EPS_BINARY, 'image/png'),
    ('logo.jpg', EPS, 'image/jpeg'),
    ('logo.png', b'just some text, not an image', 'image/png'),
    ('logo.png', JPEG, 'image/png'),   # mismatch: JPEG named .png
    ('logo.jpg', PNG, 'image/jpeg'),   # mismatch: PNG named .jpg
    ('logo.png', b'', 'image/png'),
    ('logo.png', b'\x89PNG', 'image/png'),  # truncated signature
    ('logo.svg', EPS, 'image/svg+xml'),
    ('logo.svg', PNG, 'image/svg+xml'),
    ('logo.svg', b'<html><body>x</body></html>', 'image/svg+xml'),
])
def test_bad_content_rejected_without_side_effects(setup, filename, content, mime):
    app_module, client, csrf_of, pid = setup
    before = _logo_path(app_module, pid)
    r = _post(client, csrf_of, pid, filename, content, mime)
    assert r.status_code == 302
    assert '/edit' in r.headers['Location']  # bounced back, not saved
    assert _logo_path(app_module, pid) == before
    assert _files(app_module) == []
    with client.session_transaction() as sess:
        assert any(cat == 'error' for cat, _ in sess.get('_flashes', []))
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute('SELECT name FROM msp_profiles WHERE id=%s', (pid,))
        assert cur.fetchone()[0] == 'Acme MSP'  # name unchanged: no DB write


def test_saved_name_is_server_generated(setup):
    app_module, client, csrf_of, pid = setup
    _post(client, csrf_of, pid, '../../etc/evil.png', PNG, 'image/png')
    assert _files(app_module) == [f'msp_{pid}.png']


def test_non_admin_blocked(app_module, client, login_as, csrf_of, seed_msp_profile):
    login_as('user')
    pid = seed_msp_profile('Acme MSP')
    r = _post(client, csrf_of, pid, 'logo.png', PNG, 'image/png')
    assert r.status_code in (403, 404)
    assert _files(app_module) == []
