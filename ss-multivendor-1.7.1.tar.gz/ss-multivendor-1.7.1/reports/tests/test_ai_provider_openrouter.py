import pytest

from reports.ai import net
from reports.ai.net import ProviderError
from reports.ai.providers import get_provider
from reports.ai.providers.base import validate_model
from reports.ai.providers.openrouter import OpenRouterProvider


def test_registered_and_host_allowed():
    assert isinstance(get_provider('openrouter'), OpenRouterProvider)
    assert 'openrouter.ai' in net.ALLOWED_HOSTS


def test_request_uses_max_tokens():
    req = OpenRouterProvider().build_request('a/b', 's', [{'role': 'user', 'content': 'x'}], [], 64)
    assert req['max_tokens'] == 64 and 'max_completion_tokens' not in req


def test_complete_posts_to_openrouter(monkeypatch):
    seen = {}

    def fake_post(url, headers, body, **kw):
        seen.update(url=url, headers=headers, body=body, kw=kw)
        return {'choices': [{'message': {'content': 'ok'}}], 'usage': {}}

    monkeypatch.setattr(net, 'post_json', fake_post)
    turn = OpenRouterProvider().complete(api_key='sk-or-1', model='anthropic/claude-x', system='s',
                                         messages=[{'role': 'user', 'content': 'hi'}], tools=[])
    assert turn.text == 'ok'
    assert seen['url'] == 'https://openrouter.ai/api/v1/chat/completions'
    assert seen['headers'] == {'Authorization': 'Bearer sk-or-1'}
    assert seen['body']['model'] == 'anthropic/claude-x'
    assert seen['kw']['secrets'] == ['sk-or-1']


@pytest.mark.parametrize('bad', ['a/', '/a', 'a//b', '../x', 'a/b/c', 'a b/c', 'a/b?x=1'])
def test_slash_models_still_strict(bad):
    with pytest.raises(ProviderError):
        validate_model(bad, allow_slash=True)


def test_slash_rejected_for_other_providers():
    with pytest.raises(ProviderError):
        validate_model('a/b')
    assert validate_model('openai/gpt-x:free', allow_slash=True)


@pytest.mark.parametrize('bare', ['openai', 'claude-haiku-5-5', 'gpt-4o'])
def test_openrouter_requires_vendor_prefix(bare):
    with pytest.raises(ProviderError, match='vendor/model'):
        validate_model(bare, allow_slash=True)
