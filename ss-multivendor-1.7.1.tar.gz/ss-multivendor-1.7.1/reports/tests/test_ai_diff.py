from reports.ai.diff import diff_results as d


def test_identical():
    r = d(['a'], [[1], [2]], ['a'], [[1], [2]], 2, 2)
    assert r['identical'] and r['added'] == r['removed'] == r['changed'] == 0


def test_keyed_added_removed_changed():
    old = [['x', 1], ['y', 2], ['z', 3]]
    new = [['x', 1], ['y', 9], ['w', 4]]
    r = d(['k', 'v'], old, ['k', 'v'], new, 3, 3)
    assert r['mode'] == 'keyed'
    assert (r['added'], r['removed'], r['changed']) == (1, 1, 1)
    assert r['added_rows'] == [['w', 4]] and r['removed_rows'] == [['z', 3]]
    assert not r['identical']


def test_multiset_when_first_column_not_unique():
    old = [['x', 1], ['x', 2]]
    new = [['x', 1], ['x', 3]]
    r = d(['k', 'v'], old, ['k', 'v'], new, 2, 2)
    assert r['mode'] == 'multiset' and r['added'] == 1 and r['removed'] == 1 and r['changed'] == 0


def test_row_count_delta_uses_true_counts_not_snapshot_len():
    r = d(['a'], [[1]], ['a'], [[1]], 120, 134)
    assert r['delta'] == 14 and not r['identical']          # counts differ even if sampled rows match


def test_column_change_flagged():
    r = d(['a'], [[1]], ['a', 'b'], [[1, 2]], 1, 1)
    assert r['columns_changed'] and not r['identical']


def test_nested_values_compare_by_json():
    r = d(['a'], [[[1, 2]]], ['a'], [[[1, 2]]], 1, 1)
    assert r['identical']


def test_sample_lists_are_capped():
    new = [[n] for n in range(100)]
    r = d(['a'], [], ['a'], new, 0, 100)
    assert r['added'] == 100 and len(r['added_rows']) == 20
