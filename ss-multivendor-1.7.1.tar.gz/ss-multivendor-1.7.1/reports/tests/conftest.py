"""Pytest fixtures for the reports Flask app (reports/web/app.py).

Test-DB strategy
-----------------
Real, ephemeral PostgreSQL — no mocks — so auth and tenant-isolation
behaviour is exercised against genuine schema/constraints.

For the whole test session, a *dedicated, freshly-created* Postgres
role + database are provisioned on the local Postgres server that already
runs on this box (the same server the app talks to in production):

  * Role `sonicscope_test` — LOGIN, random password generated per run
  * DB   `sonicscope_test` — owned by that role, dropped + recreated fresh

Both are created/dropped via `sudo -n -u postgres psql ...` (the `-n` flag
makes sudo fail immediately instead of prompting, so a misconfigured box
fails fast instead of hanging). The schema files are now idempotent
(`CREATE TABLE IF NOT EXISTS`, named `CREATE INDEX IF NOT EXISTS`,
`create_hypertable(... if_not_exists => TRUE)`, duplicate-safe policies —
added in Task 4), but this fixture still drops + recreates a fresh, empty
database each session so every run starts from a known-clean state
independent of any prior run. Schema + migrations are applied in the same
order (and the same full set) the `apply_schema_file()` calls in
scripts/install.sh use, so the test DB matches production:
    database/schema.sql
    database/aggregates.sql            (continuous-aggregate views: daily_*/hourly_*)
    database/identity_schema.sql       (identity_users / identity_devices)
    database/migrations/002_auth.sql
    database/migrations/003_passwords.sql
    database/migrations/004_identity_toggle.sql
    database/migrations/005_customer_role.sql
    database/migrations/006_collector_health.sql
                                        (collector_health heartbeat row for
                                        GET /healthz — on production this one
                                        is applied by scripts/update.sh's
                                        numbered-migration loop rather than an
                                        explicit scripts/install.sh line, but
                                        the resulting schema is identical)
    database/migrations/007_live_tap.sql
    database/migrations/008_ipfix_templates.sql
    database/migrations/009_domain_category.sql
    database/migrations/010_ai_investigate.sql
    database/migrations/011_ai_investigations.sql

aggregates.sql applies cleanly to an EMPTY test DB: every materialized view is
created `WITH NO DATA` and its final `refresh_continuous_aggregate(...)` calls
are no-ops against empty source tables, so no data is required. identity_schema
.sql is fully `CREATE TABLE IF NOT EXISTS` / `ALTER TABLE ... ADD COLUMN IF NOT
EXISTS`. Both need TimescaleDB, which is present (schema.sql's `CREATE EXTENSION
timescaledb` runs first). Omitting these two previously meant Task 1/5 tests
hitting identity or report-data routes would crash with UndefinedTable on
`identity_users` / `daily_user_traffic` / `hourly_*`.

We deliberately did NOT add pytest-postgresql (see requirements-dev.txt):
this box already has a real, reachable Postgres server with TimescaleDB
installed, so spinning up a second, self-managed ephemeral cluster just
for tests would be unnecessary overhead.

CI / boxes without passwordless `sudo -u postgres`
----------------------------------------------------
Set TEST_DB_SKIP_PROVISION=1 plus TEST_DB_HOST / TEST_DB_PORT / TEST_DB_NAME
/ TEST_DB_USER / TEST_DB_PASSWORD to point at a throwaway database that some
other CI setup step has ALREADY created AND loaded with the schema/migrations
(and granted TEST_DB_USER SELECT/INSERT/UPDATE/DELETE/TRUNCATE on the app
tables). In that mode this fixture does NOT create the DB/role, apply any
schema, or make any `sudo -u postgres` calls — it only yields the DSN; the
per-test `app_module` fixture then TRUNCATEs the app tables so each test
starts clean. (The non-skip path below is the one that creates the role +
database and applies the schema itself via `sudo -u postgres`.)

Fixtures
--------
- `app_module`   — the (re)imported reports/web/app.py module with its env
                    pointed at the ephemeral test DB. Tables are truncated
                    before the module is handed back, so every test starts
                    from a clean, empty database.
- `client`        — Flask test client for `app_module.app`.
- `seed_tenants`  — factory fixture: `seed_tenants('Acme', 'Globex')` ->
                    `[1, 2]` (inserts rows into `tenants`, returns new ids).
- `login_as`      — factory fixture: `login_as('admin')` or
                    `login_as('user', tenant_ids=[1, 2])` inserts a
                    `ui_users` row (+ `ui_user_tenants` grants) and sets the
                    Flask test-client session cookie so subsequent requests
                    on `client` are authenticated as that user. Returns the
                    new user id.

  Note: `ui_users.role` accepts 'admin' | 'user' | 'customer' — migration
  005_customer_role.sql (added under Task 1, P0 launch remediation) widened
  the CHECK constraint from 002_auth.sql's original 'admin'/'user'-only rule
  so that customer-portal accounts (role='customer'), which app.py has
  referenced since Phase 5 but which the DB previously rejected on INSERT,
  can actually be created. `login_as(role='customer', tenant_ids=[tid])`
  seeds one such account.
"""
from __future__ import annotations

import importlib
import os
import time
import secrets
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

import psycopg2
import pytest

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
_REPORTS_DIR = os.path.dirname(_TESTS_DIR)
REPO_ROOT = os.path.dirname(_REPORTS_DIR)
WEB_DIR = os.path.join(_REPORTS_DIR, 'web')

# Mirrors the schema files applied by scripts/install.sh's apply_schema_file()
# calls, minus 000_schema_migrations.sql (the ledger — the reports app never
# queries it) and 001_tenant_subnets.sql (schema.sql already creates that
# table). Order matches production.
SCHEMA_FILES = [
    os.path.join(REPO_ROOT, 'database', 'schema.sql'),
    os.path.join(REPO_ROOT, 'database', 'aggregates.sql'),
    os.path.join(REPO_ROOT, 'database', 'identity_schema.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '002_auth.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '003_passwords.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '004_identity_toggle.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '005_customer_role.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '006_collector_health.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '007_live_tap.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '008_ipfix_templates.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '009_domain_category.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '010_ai_investigate.sql'),
    os.path.join(REPO_ROOT, 'database', 'migrations', '011_ai_investigations.sql'),
]

# App-owned tables truncated between tests (see app_module fixture).
_APP_TABLES = [
    'tenants', 'msp_profiles', 'sensors', 'identity_mappings', 'tenant_subnets',
    'fw_events', 'report_schedules', 'generated_reports',
    'ui_users', 'ui_user_tenants', 'ui_login_codes',
    'identity_users', 'identity_devices', 'collector_health',
    'live_tap_feed', 'live_tap_sample', 'live_tap_watch',
    'ipfix_templates',
    'domain_category', 'domain_category_stage',
    'ai_settings', 'ai_audit',
    'ai_findings', 'ai_query_results', 'ai_messages', 'ai_investigations',
]

_TEST_DB_NAME = os.environ.get('TEST_DB_NAME', 'sonicscope_test')
_TEST_DB_ROLE = os.environ.get('TEST_DB_ROLE', 'sonicscope_test')
_TEST_DB_HOST = os.environ.get('TEST_DB_HOST', '127.0.0.1')
_TEST_DB_PORT = int(os.environ.get('TEST_DB_PORT', '5432'))


def _sudo_psql(dbname: str, *, sql: str | None = None, sql_file: str | None = None) -> None:
    """Run one psql command as the `postgres` superuser via passwordless sudo.

    `-n` makes sudo fail immediately (never prompt) if it would need a
    password. Raises RuntimeError with full stdout/stderr on any failure.

    Note: when `sql_file` is given, the file is first copied to a
    world-readable path under /tmp — the `postgres` OS user cannot read
    files under /home/<user>/... on this box (0750 home dir), the same
    workaround scripts/install.sh uses.
    """
    tmp_copy = None
    cmd = ['sudo', '-n', '-u', 'postgres', 'psql', '-v', 'ON_ERROR_STOP=1', '-d', dbname]
    if sql_file:
        fd, tmp_copy = tempfile.mkstemp(prefix='ss_test_schema_', suffix='.sql')
        os.close(fd)
        shutil.copy(sql_file, tmp_copy)
        os.chmod(tmp_copy, 0o644)
        cmd += ['-f', tmp_copy]
    elif sql:
        cmd += ['-c', sql]
    else:
        raise ValueError('_sudo_psql requires sql or sql_file')

    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        # TimescaleDB flake: aggregates.sql's explicit refresh collides with the
        # policy job scheduled at creation. Files are idempotent: retry.
        for _ in range(4):
            if proc.returncode == 0 or 'concurrent refresh' not in proc.stderr:
                break
            time.sleep(3)
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if proc.returncode != 0:
            raise RuntimeError(
                f"psql (as postgres) failed for db={dbname!r}: {' '.join(cmd)}\n"
                f"--- stdout ---\n{proc.stdout}\n--- stderr ---\n{proc.stderr}"
            )
    finally:
        if tmp_copy:
            os.remove(tmp_copy)


@pytest.fixture(scope='session')
def _test_db_dsn():
    """Session-scoped: provision the ephemeral test DB, yield connection
    kwargs (host/port/dbname/user/password), then tear it all down."""
    if os.environ.get('TEST_DB_SKIP_PROVISION') == '1':
        yield {
            'host': os.environ.get('TEST_DB_HOST', _TEST_DB_HOST),
            'port': int(os.environ.get('TEST_DB_PORT', _TEST_DB_PORT)),
            'dbname': os.environ.get('TEST_DB_NAME', _TEST_DB_NAME),
            'user': os.environ.get('TEST_DB_USER', _TEST_DB_ROLE),
            'password': os.environ.get('TEST_DB_PASSWORD', ''),
        }
        return

    # Non-interactive capability check: fail fast with a clear message
    # instead of letting a later step hang on a sudo password prompt.
    check = subprocess.run(
        ['sudo', '-n', '-u', 'postgres', 'psql', '-c', 'SELECT 1;'],
        capture_output=True, text=True, timeout=15,
    )
    if check.returncode != 0:
        pytest.exit(
            "BLOCKED: passwordless 'sudo -u postgres psql' is required to "
            "provision the ephemeral test DB and is not available here.\n"
            "Command that would otherwise prompt: sudo -u postgres psql -c 'SELECT 1;'\n"
            f"stderr: {check.stderr.strip()}\n"
            "Fix: grant passwordless sudo for this command, or set "
            "TEST_DB_SKIP_PROVISION=1 plus TEST_DB_HOST/PORT/NAME/USER/PASSWORD "
            "to point at an already-provisioned empty database instead.",
            returncode=1,
        )

    # Safety guard: never let a misconfigured TEST_DB_NAME/TEST_DB_ROLE env
    # var point the DROP DATABASE / DROP ROLE statements at the production
    # database or role. This fixture drops+recreates whatever these name.
    assert _TEST_DB_NAME != 'sonicscope', (
        "Refusing to provision: TEST_DB_NAME must not be the production DB "
        "'sonicscope' — this fixture DROPs the database it targets."
    )
    assert _TEST_DB_ROLE != 'sonicscope', (
        "Refusing to provision: TEST_DB_ROLE must not be the production role "
        "'sonicscope' — this fixture DROPs the role it targets."
    )

    password = secrets.token_hex(16)

    # Drop leftovers from a previous crashed run, then create fresh.
    _sudo_psql('postgres', sql=f'DROP DATABASE IF EXISTS "{_TEST_DB_NAME}";')
    _sudo_psql('postgres', sql=f'DROP ROLE IF EXISTS "{_TEST_DB_ROLE}";')
    _sudo_psql('postgres', sql=f"CREATE ROLE \"{_TEST_DB_ROLE}\" LOGIN PASSWORD '{password}';")
    _sudo_psql('postgres', sql=f'CREATE DATABASE "{_TEST_DB_NAME}" OWNER "{_TEST_DB_ROLE}";')

    for path in SCHEMA_FILES:
        _sudo_psql(_TEST_DB_NAME, sql_file=path)

    # Migration files GRANT to the literal role name 'sonicscope' (the prod
    # role, which exists cluster-wide); grant our ephemeral role separately.
    # TRUNCATE is included in addition to scripts/install.sh's usual set
    # (SELECT/INSERT/UPDATE/DELETE) because app_module truncates tables
    # between tests. (Not using REASSIGN OWNED BY postgres here: it fails
    # because schema.sql's CREATE EXTENSION timescaledb/pg_trgm leave
    # some objects owned by `postgres` that Postgres refuses to reassign.)
    _sudo_psql(_TEST_DB_NAME, sql=(
        f'GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON ALL TABLES IN SCHEMA public TO "{_TEST_DB_ROLE}";'
        f'GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO "{_TEST_DB_ROLE}";'
    ))
    # The UT1 refresh swaps domain_category <-> domain_category_stage by
    # renaming them, which requires ownership (prod: migration 009 hands them
    # to the app role).
    _sudo_psql(_TEST_DB_NAME, sql=(
        f'ALTER TABLE domain_category OWNER TO "{_TEST_DB_ROLE}";'
        f'ALTER TABLE domain_category_stage OWNER TO "{_TEST_DB_ROLE}";'
        f'ALTER TABLE category_list_state OWNER TO "{_TEST_DB_ROLE}";'
    ))
    # TEST-ONLY override: in production migration 010 hands the ai schema and
    # views to the `sonicscope` role. Tests connect as the ephemeral test role,
    # which must be able to use schema ai, so reassign it here.
    _sudo_psql(_TEST_DB_NAME, sql=(
        f'ALTER SCHEMA ai OWNER TO "{_TEST_DB_ROLE}";'
        "DO $$ DECLARE v text; BEGIN "
        "FOR v IN SELECT viewname FROM pg_views WHERE schemaname = 'ai' LOOP "
        f"EXECUTE format('ALTER VIEW ai.%I OWNER TO %I', v, '{_TEST_DB_ROLE}'); "
        "END LOOP; END $$;"
    ))

    dsn = {
        'host': _TEST_DB_HOST,
        'port': _TEST_DB_PORT,
        'dbname': _TEST_DB_NAME,
        'user': _TEST_DB_ROLE,
        'password': password,
    }
    try:
        yield dsn
    finally:
        _sudo_psql('postgres', sql=(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity "
            f"WHERE datname = '{_TEST_DB_NAME}' AND pid <> pg_backend_pid();"
        ))
        _sudo_psql('postgres', sql=f'DROP DATABASE IF EXISTS "{_TEST_DB_NAME}";')
        _sudo_psql('postgres', sql=f'DROP ROLE IF EXISTS "{_TEST_DB_ROLE}";')


@pytest.fixture
def app_module(tmp_path, monkeypatch, _test_db_dsn):
    """Reload reports/web/app.py with its env pointed at the ephemeral test
    DB, then truncate all app tables so the test starts from an empty DB.

    App import must happen AFTER the test DB env is set, because app.py
    reads DB_CONFIG/SMTP_CONFIG/OUTPUT_DIR/FLASK_SECRET from the
    environment at import time.
    """
    monkeypatch.setenv('DB_HOST', _test_db_dsn['host'])
    monkeypatch.setenv('DB_PORT', str(_test_db_dsn['port']))
    monkeypatch.setenv('DB_NAME', _test_db_dsn['dbname'])
    monkeypatch.setenv('DB_USER', _test_db_dsn['user'])
    monkeypatch.setenv('DB_PASSWORD', _test_db_dsn['password'])
    monkeypatch.setenv('FLASK_SECRET', 'test-secret')
    monkeypatch.setenv('REPORT_OUTPUT_DIR', str(tmp_path / 'reports'))
    monkeypatch.setenv('REPORT_LOGO_DIR', str(tmp_path / 'logos'))
    monkeypatch.setenv('COOKIE_SECURE', 'false')
    # Blank out SMTP so a real /etc/ss-multivendor/collector.env on this box
    # (if present) can never leak real creds into the test process — app.py's
    # _load_env() only sets values that are NOT already in os.environ.
    monkeypatch.setenv('SMTP_HOST', '')
    monkeypatch.setenv('SMTP_USER', '')
    monkeypatch.setenv('SMTP_PASSWORD', '')
    monkeypatch.setenv('SMTP_FROM', '')

    if WEB_DIR not in sys.path:
        sys.path.insert(0, WEB_DIR)

    if 'app' in sys.modules:
        mod = importlib.reload(sys.modules['app'])
    else:
        mod = importlib.import_module('app')
    mod.app.config.update(TESTING=True)

    # CONTINUE IDENTITY (the default): our ephemeral test role only has
    # TRUNCATE privilege on these tables, not ownership of their id
    # sequences, so RESTART IDENTITY (which needs to ALTER the sequence)
    # is not available. Ids are therefore monotonically increasing across
    # tests within a session rather than resetting to 1 — seed_tenants/
    # login_as always return the actual new ids, so tests must not assume
    # ids start at 1.
    with psycopg2.connect(**mod.DB_CONFIG) as conn:
        with conn.cursor() as cur:
            cur.execute('TRUNCATE TABLE ' + ', '.join(_APP_TABLES) + ' CASCADE;')
            # Single seeded status row: reset in place rather than truncate.
            cur.execute(
                'UPDATE category_list_state SET list_version = NULL, domains = 0, '
                'refreshed_at = NULL, last_attempt_at = NULL, last_error = NULL')
        conn.commit()

    yield mod

    if getattr(mod, '_scheduler', None) is not None:
        try:
            mod.stop_scheduler(mod._scheduler)
        except Exception:
            pass


@pytest.fixture
def client(app_module):
    """Flask test client for the reloaded reports app."""
    return app_module.app.test_client()


@pytest.fixture
def seed_tenants(app_module):
    """Factory fixture: seed_tenants('Acme', 'Globex') -> [id1, id2].

    Inserts one row per positional tenant name into `tenants` (auto-generating
    a unique slug) and returns the new tenant ids, in the same order.
    """
    def _seed(*names: str) -> list[int]:
        ids = []
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                for name in names:
                    slug = f"{name.lower().replace(' ', '-')}-{secrets.token_hex(4)}"
                    cur.execute(
                        'INSERT INTO tenants (name, slug) VALUES (%s, %s) RETURNING id',
                        (name, slug),
                    )
                    ids.append(cur.fetchone()[0])
            conn.commit()
        return ids

    return _seed


@pytest.fixture
def login_as(app_module, client):
    """Factory fixture: login_as('admin') or login_as('user', tenant_ids=[1, 2]).

    Inserts a `ui_users` row (role must be 'admin' or 'user' per the
    ui_users CHECK constraint), grants access to the given tenant ids via
    `ui_user_tenants`, and sets the Flask test-client session cookie so
    subsequent requests on `client` are authenticated as that user.
    Returns the new user id.
    """
    def _login(role: str = 'admin', tenant_ids: list[int] | None = None,
               email: str | None = None, full_name: str | None = None) -> int:
        tenant_ids = tenant_ids or []
        email = email or f"{role}-{secrets.token_hex(4)}@example.test"
        full_name = full_name or f"Test {role.title()}"

        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    'INSERT INTO ui_users (email, full_name, role, is_active) '
                    'VALUES (%s, %s, %s, true) RETURNING id',
                    (email, full_name, role),
                )
                user_id = cur.fetchone()[0]
                for tenant_id in tenant_ids:
                    cur.execute(
                        'INSERT INTO ui_user_tenants (user_id, tenant_id) VALUES (%s, %s)',
                        (user_id, tenant_id),
                    )
            conn.commit()

        with client.session_transaction() as sess:
            sess['user_id'] = user_id
            sess['user_role'] = role

        return user_id

    return _login


@pytest.fixture
def seed_report(app_module):
    """Factory fixture: seed_report(tenant_id=1) -> generated_reports.id.

    Inserts a `generated_reports` row owned by `tenant_id` and writes a real
    (minimal but valid) PDF file at its `file_path`, inside
    `app_module.OUTPUT_DIR`, so `/reports/<id>/download` can genuinely
    `send_file()` it end-to-end rather than 500-ing on a missing file.
    """
    def _seed(tenant_id: int, report_type: str = 'monthly') -> int:
        os.makedirs(app_module.OUTPUT_DIR, exist_ok=True)
        file_path = os.path.join(
            app_module.OUTPUT_DIR, f'report-{secrets.token_hex(8)}.pdf'
        )
        with open(file_path, 'wb') as f:
            f.write(b'%PDF-1.4\n% minimal test fixture PDF\n%%EOF\n')

        now = datetime.now(timezone.utc)
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO generated_reports
                        (tenant_id, report_type, period_start, period_end,
                         file_path, delivery_status)
                    VALUES (%s, %s, %s, %s, %s, 'ready')
                    RETURNING id
                    """,
                    (tenant_id, report_type, now, now, file_path),
                )
                report_id = cur.fetchone()[0]
            conn.commit()
        return report_id

    return _seed


@pytest.fixture
def seed_identity_user(app_module):
    """Factory fixture: seed_identity_user(tenant_id=1) -> identity_users.id.

    Inserts a minimal `identity_users` row owned by `tenant_id`.
    """
    def _seed(tenant_id: int, full_name: str | None = None) -> int:
        full_name = full_name or f"Test User {secrets.token_hex(4)}"
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO identity_users (tenant_id, full_name) "
                    "VALUES (%s, %s) RETURNING id",
                    (tenant_id, full_name),
                )
                user_id = cur.fetchone()[0]
            conn.commit()
        return user_id

    return _seed


@pytest.fixture
def csrf_of():
    """Factory fixture: csrf_of(client) -> str.

    Returns the current session's CSRF token, generating and persisting one
    via Flask's test-client `session_transaction()` if none exists yet —
    mirrors how `app.py`'s `_csrf_token()` lazily stores it in
    `session['csrf']`, without needing to render a page first just to
    obtain a token ahead of a POST-only test.
    """
    def _csrf(client) -> str:
        with client.session_transaction() as sess:
            token = sess.get('csrf')
            if not token:
                token = secrets.token_hex(32)
                sess['csrf'] = token
            return token

    return _csrf


@pytest.fixture
def seed_msp_profile(app_module):
    """Factory fixture: seed_msp_profile('Acme MSP') -> msp_profiles.id.

    Inserts a `msp_profiles` row. `name` is the only required value (needed
    because `report_schedules.msp_profile_id` is NOT NULL); the keyword-only
    `logo_path` / `primary_color` / `footer_text` args are optional and let
    login-branding tests (reports/tests/test_login_branding.py) seed the
    columns `_login_branding()` reads, without touching every existing
    caller that only ever needed a bare profile id.
    """
    def _seed(name: str | None = None, *, logo_path: str | None = None,
               primary_color: str | None = None, footer_text: str | None = None) -> int:
        name = name or f"MSP {secrets.token_hex(4)}"
        columns = ['name']
        values = [name]
        if logo_path is not None:
            columns.append('logo_path')
            values.append(logo_path)
        if primary_color is not None:
            columns.append('primary_color')
            values.append(primary_color)
        if footer_text is not None:
            columns.append('footer_text')
            values.append(footer_text)
        placeholders = ', '.join(['%s'] * len(values))
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"INSERT INTO msp_profiles ({', '.join(columns)}) "
                    f"VALUES ({placeholders}) RETURNING id",
                    values,
                )
                profile_id = cur.fetchone()[0]
            conn.commit()
        return profile_id

    return _seed


@pytest.fixture
def write_logo_file(app_module):
    """Factory fixture: write_logo_file('logo.png') -> absolute path under
    `app_module.LOGO_DIR` (REPORT_LOGO_DIR, pointed at a tmp_path directory
    for the test). Writes real, minimal-but-valid bytes so
    `_validated_logo_path()`'s `os.path.isfile()` check and `send_file()`
    both succeed — needed to test `/brand/logo` and the login-page logo
    `<img>` end to end.
    """
    def _write(filename: str = 'logo.png', content: bytes = b'\x89PNG\r\n\x1a\n\x00fake-png-bytes') -> str:
        os.makedirs(app_module.LOGO_DIR, exist_ok=True)
        path = os.path.join(app_module.LOGO_DIR, filename)
        with open(path, 'wb') as f:
            f.write(content)
        return path

    return _write


@pytest.fixture
def seed_schedule(app_module, seed_msp_profile):
    """Factory fixture: seed_schedule(tenant_id=1) -> report_schedules.id.

    Inserts a minimal `report_schedules` row owned by `tenant_id`, auto-
    creating an MSP profile for the required `msp_profile_id` FK.
    """
    def _seed(tenant_id: int, report_type: str = 'monthly') -> int:
        msp_profile_id = seed_msp_profile()
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO report_schedules
                        (tenant_id, msp_profile_id, report_type, schedule_cron,
                         recipient_name, recipient_emails, is_active)
                    VALUES (%s, %s, %s, %s, %s, %s, TRUE)
                    RETURNING id
                    """,
                    (tenant_id, msp_profile_id, report_type, '0 7 * * 1',
                     'Test Recipient', ['test@example.test']),
                )
                schedule_id = cur.fetchone()[0]
            conn.commit()
        return schedule_id

    return _seed


@pytest.fixture
def seed_identity_device(app_module):
    """Factory fixture: seed_identity_device(tenant_id=1) -> identity_devices.id.

    Inserts a minimal `identity_devices` row owned by `tenant_id`, not
    linked to any `identity_users` row (`user_id` NULL is legal).
    """
    def _seed(tenant_id: int, ip_address: str = '10.0.0.1') -> int:
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "INSERT INTO identity_devices (tenant_id, ip_address) "
                    "VALUES (%s, %s) RETURNING id",
                    (tenant_id, ip_address),
                )
                device_id = cur.fetchone()[0]
            conn.commit()
        return device_id

    return _seed


@pytest.fixture
def ai_ro_config(app_module):
    """psycopg2 kwargs that connect as the restricted `ss_ai_ro` role.

    The role is created by migration 010 without a password; the test sets a
    random one (as postgres) so it can log in over TCP.
    """
    password = secrets.token_hex(16)
    _sudo_psql('postgres', sql=f"ALTER ROLE ss_ai_ro PASSWORD '{password}';")
    cfg = dict(app_module.DB_CONFIG)
    cfg['user'] = 'ss_ai_ro'
    cfg['password'] = password
    return cfg


@pytest.fixture
def seed_fw_event(app_module):
    """Factory: seed_fw_event(tenant_id, **cols) inserts one fw_events row
    (creating a sensor for the tenant on first use). Returns None."""
    sensors: dict[int, int] = {}
    counter = [0]

    def _seed(tenant_id: int, **cols) -> None:
        with psycopg2.connect(**app_module.DB_CONFIG) as conn:
            with conn.cursor() as cur:
                if tenant_id not in sensors:
                    counter[0] += 1
                    cur.execute(
                        "INSERT INTO sensors (tenant_id, name, vendor, ip_address, data_sources) "
                        "VALUES (%s, %s, 'sonicwall', %s::inet, %s) RETURNING id",
                        (tenant_id, f'fw{tenant_id}', f'10.9.{tenant_id % 250}.{counter[0] % 250 + 1}',
                         ['syslog']))
                    sensors[tenant_id] = cur.fetchone()[0]
                row = {
                    'time': 'now()', 'tenant_id': tenant_id, 'sensor_id': sensors[tenant_id],
                    'vendor': 'sonicwall', 'data_source': 'syslog', 'event_type': 'traffic',
                    'action': 'allow',
                }
                row.update(cols)
                names = list(row)
                values = []
                params = []
                for k in names:
                    if row[k] == 'now()':
                        values.append('now()')
                    else:
                        values.append('%s')
                        params.append(row[k])
                cur.execute(
                    f"INSERT INTO fw_events ({', '.join(names)}) VALUES ({', '.join(values)})",
                    params)
            conn.commit()

    return _seed
