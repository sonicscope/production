"""Stage 2 routes: auto-save, list/open/rename/share/delete, access rules (spec §3, §4)."""
import psycopg2
import pytest

from reports.ai import executor, investigations, routes
from reports.ai.net import ProviderError
from reports.ai.providers.base import ToolCall
from reports.tests.test_ai_routes import (FakeProvider, T, ai_ready, audit_rows,  # noqa: F401
                                          chat, sse, use)

SQL = 'SELECT count(*) AS n FROM ai.events'


def db(app_module):
    return psycopg2.connect(**app_module.DB_CONFIG)


def inv_rows(app_module):
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('SELECT id, tenant_id, owner_user_id, title, shared FROM ai_investigations '
                    'ORDER BY id')
        return cur.fetchall()


def detail(app_module, inv_id):
    with db(app_module) as conn, conn.cursor() as cur:
        return investigations.detail(cur, inv_id)


def saved_id(resp):
    ev = [e for e in sse(resp) if e['type'] == 'saved']
    assert len(ev) == 1, ev
    return ev[0]['investigation_id']


def one_turn(monkeypatch, answer='Done.'):
    use(monkeypatch, FakeProvider(T('', ToolCall('c1', 'run_sql', {'sql': SQL})), T(answer)))


def make(client, login_as, csrf_of, ai_ready, monkeypatch, *, role='user', share=False):
    """Log in as a fresh staff user, save one investigation, return (user_id, inv_id)."""
    uid = login_as(role, [ai_ready])
    one_turn(monkeypatch)
    inv_id = saved_id(chat(client, csrf_of(client), ai_ready, question='what happened?'))
    if share:
        assert client.post(f'/investigate/{inv_id}/share', json={'shared': True},
                           headers={'X-CSRF-Token': csrf_of(client)}).status_code == 200
    return uid, inv_id


def test_chat_autosaves_after_first_answer(client, app_module, login_as, csrf_of, ai_ready,
                                           monkeypatch):
    login_as('user', [ai_ready])
    one_turn(monkeypatch)
    events = sse(chat(client, csrf_of(client), ai_ready, question='how many events?'))
    saved = [e for e in events if e['type'] == 'saved']
    assert len(saved) == 1 and saved[0]['title'] == 'how many events?'
    d = detail(app_module, saved[0]['investigation_id'])
    assert [m['role'] for m in d['messages']] == ['user', 'assistant']
    assert len(d['results']) == 1
    assert d['results'][0]['sql'] == SQL and 'tenant_id' not in d['results'][0]['sql']
    assert [r[0] for r in audit_rows(app_module, 'save')] == ['save']


def test_followup_with_investigation_id_appends(client, app_module, login_as, csrf_of, ai_ready,
                                                monkeypatch, seed_tenants):
    other, = seed_tenants('Other')
    uid, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    use(monkeypatch, FakeProvider(T('Second.')))
    resp = chat(client, csrf_of(client), ai_ready, question='and then?', investigation_id=inv_id)
    assert saved_id(resp) == inv_id
    assert [m['seq'] for m in detail(app_module, inv_id)['messages']] == [1, 2, 3, 4]
    # another tenant than the investigation's -> 404
    use(monkeypatch, FakeProvider(T('x')))
    login_as('admin', [ai_ready, other])
    assert chat(client, csrf_of(client), other, question='q',
                investigation_id=inv_id).status_code == 404
    # a different non-admin user -> 404
    login_as('user', [ai_ready])
    assert chat(client, csrf_of(client), ai_ready, question='q',
                investigation_id=inv_id).status_code == 404
    # malformed ids -> 400
    for bad in (0, -1, '5', True, 1.5):
        assert chat(client, csrf_of(client), ai_ready, question='q',
                    investigation_id=bad).status_code == 400
    assert len(inv_rows(app_module)) == 1


def test_error_turn_is_not_saved(client, app_module, login_as, csrf_of, ai_ready, monkeypatch):
    class Boom(FakeProvider):
        def complete(self, **kw):
            raise ProviderError('provider down')

    use(monkeypatch, Boom())
    login_as('user', [ai_ready])
    events = sse(chat(client, csrf_of(client), ai_ready, question='q'))
    assert events[-1]['type'] == 'error' and not any(e['type'] == 'saved' for e in events)
    assert inv_rows(app_module) == []


def test_list_tabs_and_isolation(client, app_module, login_as, csrf_of, ai_ready, monkeypatch):
    owner, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    items = client.get('/investigate/list?tab=mine').get_json()['items']
    assert [i['id'] for i in items] == [inv_id]
    assert items[0]['owner_is_me'] is True and items[0]['shared'] is False
    assert items[0]['tenant_name'] == 'Acme' and items[0]['finding_count'] == 0
    assert client.get('/investigate/list?tab=all').get_json()['items'] == []
    assert client.get('/investigate/list?tab=bogus').status_code == 404

    login_as('user', [ai_ready])                                  # peer
    assert client.get('/investigate/list?tab=shared').get_json()['items'] == []
    login_as('user', [ai_ready])
    # share as the owner, via a fresh owner session
    with client.session_transaction() as s:
        s['user_id'] = owner
    assert client.post(f'/investigate/{inv_id}/share', json={'shared': True},
                       headers={'X-CSRF-Token': csrf_of(client)}).status_code == 200
    login_as('user', [ai_ready])
    shared = client.get('/investigate/list?tab=shared').get_json()['items']
    assert [i['id'] for i in shared] == [inv_id] and shared[0]['owner_is_me'] is False
    assert client.get('/investigate/list?tab=mine').get_json()['items'] == []
    login_as('admin', [ai_ready])
    assert [i['id'] for i in client.get('/investigate/list?tab=all').get_json()['items']] == [inv_id]


def test_open_private_404_for_peer(client, login_as, csrf_of, ai_ready, monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    d = client.get(f'/investigate/{inv_id}').get_json()
    assert d['can_edit'] is True and len(d['messages']) == 2 and len(d['results']) == 1
    assert d['investigation']['id'] == inv_id and d['findings'] == []
    login_as('user', [ai_ready])
    assert client.get(f'/investigate/{inv_id}').status_code == 404
    assert client.get('/investigate/999999').status_code == 404


def test_open_shared_read_only_flag(client, login_as, csrf_of, ai_ready, monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch, share=True)
    login_as('user', [ai_ready])
    resp = client.get(f'/investigate/{inv_id}')
    assert resp.status_code == 200 and resp.get_json()['can_edit'] is False
    login_as('admin', [ai_ready])
    assert client.get(f'/investigate/{inv_id}').get_json()['can_edit'] is True


def test_rename_share_delete_owner_only_and_csrf(client, app_module, login_as, csrf_of, ai_ready,
                                                 monkeypatch):
    owner, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch, share=True)
    tok = csrf_of(client)
    for path, body in (('rename', {'title': 'x'}), ('share', {'shared': False}), ('delete', {})):
        assert client.post(f'/investigate/{inv_id}/{path}', json=body).status_code == 400
    assert client.post(f'/investigate/{inv_id}/rename', json={'title': '  '},
                       headers={'X-CSRF-Token': tok}).status_code == 400
    assert client.post(f'/investigate/{inv_id}/share', json={'shared': 'yes'},
                       headers={'X-CSRF-Token': tok}).status_code == 400
    assert client.post(f'/investigate/{inv_id}/rename', json={'title': 'Renamed'},
                       headers={'X-CSRF-Token': tok}).get_json() == {'ok': True}
    assert inv_rows(app_module)[0][3] == 'Renamed'
    assert client.post(f'/investigate/{inv_id}/share', json={'shared': False},
                       headers={'X-CSRF-Token': tok}).status_code == 200
    assert client.post(f'/investigate/{inv_id}/share', json={'shared': True},
                       headers={'X-CSRF-Token': tok}).status_code == 200
    assert [r[0] for r in audit_rows(app_module, 'share')] == ['share'] * 3   # incl. make()

    login_as('user', [ai_ready])                                   # peer, shared inv
    ptok = csrf_of(client)
    for path, body in (('rename', {'title': 'x'}), ('share', {'shared': False}), ('delete', {})):
        assert client.post(f'/investigate/{inv_id}/{path}', json=body,
                           headers={'X-CSRF-Token': ptok}).status_code == 404
    assert len(inv_rows(app_module)) == 1

    login_as('admin', [ai_ready])                                  # admin deletes any
    assert client.post(f'/investigate/{inv_id}/delete', json={},
                       headers={'X-CSRF-Token': csrf_of(client)}).get_json() == {'ok': True}
    assert inv_rows(app_module) == []
    assert len(audit_rows(app_module, 'save')) == 1                 # creation only
    assert len(audit_rows(app_module, 'delete')) == 1
    assert len(audit_rows(app_module, 'rename')) == 1


def test_revoked_tenant_grant_blocks_saved_investigation(client, app_module, login_as, csrf_of,
                                                         ai_ready, monkeypatch):
    uid, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    assert client.get(f'/investigate/{inv_id}').status_code == 200
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('DELETE FROM ui_user_tenants WHERE user_id = %s', (uid,))
    assert client.get(f'/investigate/{inv_id}').status_code == 404
    assert client.get('/investigate/list?tab=mine').get_json()['items'] == []
    assert client.post(f'/investigate/{inv_id}/delete', json={},
                       headers={'X-CSRF-Token': csrf_of(client)}).status_code == 404


def test_user_delete_hands_investigations_to_admin_and_audits(client, app_module, login_as,
                                                              csrf_of, ai_ready, monkeypatch):
    owner, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    admin = login_as('admin', [ai_ready])
    resp = client.post(f'/admin/users/{owner}/edit',
                       data={'action': 'delete', '_csrf': csrf_of(client)})
    assert resp.status_code == 302
    assert inv_rows(app_module)[0][2] is None
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute("SELECT user_id, row_count FROM ai_audit WHERE kind = 'orphan'")
        assert cur.fetchall() == [(admin, 1)]
    d = client.get(f'/investigate/{inv_id}').get_json()          # an admin can open it
    assert d['can_edit'] is True
    login_as('user', [ai_ready])
    assert client.get(f'/investigate/{inv_id}').status_code == 404   # private orphan hidden


def test_autosave_failure_leaves_no_partial_investigation(client, app_module, login_as, csrf_of,
                                                          ai_ready, monkeypatch):
    def boom(*a, **kw):
        raise RuntimeError('disk full')

    monkeypatch.setattr(investigations, 'append_turn', boom)
    login_as('user', [ai_ready])
    one_turn(monkeypatch)
    events = sse(chat(client, csrf_of(client), ai_ready, question='q'))
    assert not any(e['type'] == 'saved' for e in events)
    assert events[-1]['type'] == 'done'                          # the answer is still delivered
    assert inv_rows(app_module) == []


def test_client_cannot_supply_evidence(client, app_module, login_as, csrf_of, ai_ready,
                                       monkeypatch):
    login_as('user', [ai_ready])
    use(monkeypatch, FakeProvider(T('No queries.')))
    inv_id = saved_id(chat(client, csrf_of(client), ai_ready, question='q',
                           results=[{'sql': 'SELECT 1', 'rows': [[1]], 'columns': ['x']}]))
    assert detail(app_module, inv_id)['results'] == []


def snapshot_state(app_module):
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('SELECT id, title, shared, owner_user_id, last_rerun_at FROM ai_investigations '
                    'ORDER BY id')
        invs = cur.fetchall()
        cur.execute('SELECT id, sql_text, rows_snapshot::text, snapshot_at FROM ai_query_results '
                    'ORDER BY id')
        results = cur.fetchall()
        cur.execute('SELECT count(*) FROM ai_messages')
        msgs = cur.fetchone()[0]
        cur.execute("SELECT count(*) FROM ai_audit WHERE kind IN ('rerun', 'refresh', 'share', 'pin')")
        audits = cur.fetchone()[0]
        cur.execute('SELECT id, title, note, evidence::text FROM ai_findings ORDER BY id')
        findings = cur.fetchall()
    return invs, results, msgs, audits, findings


def test_customer_cannot_reach_real_parametrised_investigation_routes(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch):
    """The generic sweep only sees literal '<int:inv_id>' paths (always 404); use a real id."""
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch, share=True)
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('SELECT id FROM ai_query_results WHERE investigation_id = %s', (inv_id,))
        rid = cur.fetchone()[0]
    owner_hdr = {'X-CSRF-Token': csrf_of(client)}
    fid = client.post(f'/investigate/{inv_id}/pin', json={'kind': 'query', 'result_id': rid,
                      'title': 'keep'}, headers=owner_hdr).get_json()['id']
    before = snapshot_state(app_module)
    login_as('customer', [ai_ready])
    tok = csrf_of(client)
    hdr = {'X-CSRF-Token': tok}
    calls = [('GET', f'/investigate/{inv_id}', None),
             ('POST', f'/investigate/{inv_id}/rename', {'title': 'pwned'}),
             ('POST', f'/investigate/{inv_id}/share', {'shared': False}),
             ('POST', f'/investigate/{inv_id}/delete', {})]
    calls += [('POST', f'/investigate/{inv_id}/rerun', {'result_id': rid}),
              ('POST', f'/investigate/{inv_id}/rerun', {'result_id': rid, 'update_snapshot': True}),
              ('POST', f'/investigate/{inv_id}/refresh', {'message_seq': 1}),
              ('POST', f'/investigate/{inv_id}/pin',
               {'kind': 'query', 'result_id': rid, 'title': 'pwned'}),
              ('PATCH', f'/investigate/{inv_id}/findings/{fid}', {'title': 'pwned'}),
              ('DELETE', f'/investigate/{inv_id}/findings/{fid}', None),
             ('POST', f'/investigate/{inv_id}/pin',
              {'kind': 'timeline', 'ip': '10.9.9.9', 'window': '24h', 'title': 'pwned'}),
             ('POST', '/investigate/timeline',
              {'tenant_id': ai_ready, 'ip': '10.9.9.9', 'window': '24h'})]
    for method, path, body in calls:
        resp = client.open(path, method=method, json=body, headers=hdr)
        assert resp.status_code in (302, 404), (method, path, resp.status_code)
        if resp.status_code == 302:
            assert '/portal' in resp.headers['Location'], (method, path)
    assert snapshot_state(app_module) == before


def test_shared_orphan_is_read_only_visible_to_non_admin_peer(client, app_module, login_as,
                                                              csrf_of, ai_ready, monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch, share=True)
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE ai_investigations SET owner_user_id = NULL WHERE id = %s', (inv_id,))
    login_as('user', [ai_ready])
    resp = client.get(f'/investigate/{inv_id}')
    assert resp.status_code == 200 and resp.get_json()['can_edit'] is False
    assert client.post(f'/investigate/{inv_id}/rename', json={'title': 'x'},
                       headers={'X-CSRF-Token': csrf_of(client)}).status_code == 404


# ── Task 3: re-run with diff ────────────────────────────────────────────────
DOM_SQL = 'SELECT domain FROM ai.events'


def make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, *, role='user',
                 share=False, domains=('a.example', 'b.example')):
    for dom in domains:
        seed_fw_event(ai_ready, domain=dom)
    uid = login_as(role, [ai_ready])
    use(monkeypatch, FakeProvider(T('', ToolCall('c1', 'run_sql', {'sql': DOM_SQL})), T('Done.')))
    inv_id = saved_id(chat(client, csrf_of(client), ai_ready, question='which domains?'))
    if share:
        assert client.post(f'/investigate/{inv_id}/share', json={'shared': True},
                           headers={'X-CSRF-Token': csrf_of(client)}).status_code == 200
    return uid, inv_id


def result_id(app_module, inv_id):
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('SELECT id FROM ai_query_results WHERE investigation_id = %s ORDER BY id',
                    (inv_id,))
        return cur.fetchone()[0]


def rerun(client, csrf_of, inv_id, **body):
    return client.post(f'/investigate/{inv_id}/rerun', json=body,
                       headers={'X-CSRF-Token': csrf_of(client)})


class NoProvider:
    """get_provider replacement proving a re-run never reaches the AI provider."""

    def __init__(self):
        self.calls = 0

    def __call__(self, name):
        self.calls += 1
        raise AssertionError('provider must not be used by re-run')


@pytest.fixture
def exec_spy(monkeypatch):
    calls = []
    real = executor.run_query

    def spy(config, tenant_id, guarded, **kw):
        calls.append((tenant_id, guarded))
        return real(config, tenant_id, guarded, **kw)

    monkeypatch.setattr(executor, 'run_query', spy)
    return calls


def test_rerun_reexecutes_stored_sql_and_diffs(client, app_module, login_as, csrf_of, ai_ready,
                                               monkeypatch, seed_fw_event, exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    exec_spy.clear()
    seed_fw_event(ai_ready, domain='c.example')
    np = NoProvider()
    monkeypatch.setattr(routes, 'get_provider', np)
    resp = rerun(client, csrf_of, inv_id, result_id=rid)
    assert resp.status_code == 200
    j = resp.get_json()
    assert sorted(r[0] for r in j['rows']) == ['a.example', 'b.example', 'c.example']
    assert j['row_count'] == 3 and j['truncated'] is False and j['snapshot_updated'] is False
    assert j['columns'] == ['domain']
    assert j['diff']['delta'] == 1 and j['diff']['added'] == 1 and not j['diff']['identical']
    assert j['diff']['added_rows'] == [['c.example']]
    assert len(exec_spy) == 1 and exec_spy[0][0] == ai_ready
    assert exec_spy[0][1].original == DOM_SQL            # stored SQL only, via the guard
    assert np.calls == 0
    # snapshot untouched, last_rerun_at set, audit row written
    r = detail(app_module, inv_id)
    assert len(r['results'][0]['rows']) == 2 and r['investigation']['last_rerun_at'] is not None
    rows = audit_rows(app_module, 'rerun')
    assert len(rows) == 1 and rows[0][2] == ai_ready and rows[0][5] is None
    assert rows[0][6] == DOM_SQL


def test_rerun_identical_and_update_snapshot(client, app_module, login_as, csrf_of, ai_ready,
                                             monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    assert rerun(client, csrf_of, inv_id, result_id=rid).get_json()['diff']['identical'] is True
    seed_fw_event(ai_ready, domain='c.example')
    j = rerun(client, csrf_of, inv_id, result_id=rid, update_snapshot=True).get_json()
    assert j['snapshot_updated'] is True
    res = detail(app_module, inv_id)['results'][0]
    assert sorted(r[0] for r in res['rows']) == ['a.example', 'b.example', 'c.example']
    assert res['row_count'] == 3
    again = rerun(client, csrf_of, inv_id, result_id=rid).get_json()
    assert again['diff']['identical'] is True


def test_rerun_guard_rejected_stored_sql_never_executes(client, app_module, login_as, csrf_of,
                                                        ai_ready, monkeypatch, seed_fw_event,
                                                        exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE ai_query_results SET sql_text = %s WHERE id = %s',
                    ('SELECT * FROM pg_user', rid))
    exec_spy.clear()
    resp = rerun(client, csrf_of, inv_id, result_id=rid)
    assert resp.status_code == 422 and resp.get_json()['error']
    assert exec_spy == []
    rows = audit_rows(app_module, 'rerun')
    assert len(rows) == 1 and rows[0][5]                      # error recorded
    assert detail(app_module, inv_id)['investigation']['last_rerun_at'] is None


def test_rerun_tenant_lock_follows_investigation_row(client, app_module, login_as, csrf_of,
                                                     ai_ready, monkeypatch, seed_fw_event,
                                                     seed_tenants, exec_spy):
    other, = seed_tenants('Other')
    seed_fw_event(other, domain='other.example')
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('INSERT INTO ui_user_tenants (user_id, tenant_id) VALUES (%s, %s)',
                    (uid, other))
    rid = result_id(app_module, inv_id)
    exec_spy.clear()
    j = rerun(client, csrf_of, inv_id, result_id=rid, tenant_id=other).get_json()
    assert exec_spy[0][0] == ai_ready                          # a client tenant_id is ignored
    assert 'other.example' not in [r[0] for r in j['rows']]


def test_rerun_requires_current_tenant_access_and_ai_enabled(client, app_module, login_as,
                                                             csrf_of, ai_ready, monkeypatch,
                                                             seed_fw_event, exec_spy):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    exec_spy.clear()
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE tenants SET ai_enabled = false WHERE id = %s', (ai_ready,))
    assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 403
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE tenants SET ai_enabled = true WHERE id = %s', (ai_ready,))
        cur.execute('DELETE FROM ui_user_tenants WHERE user_id = %s', (uid,))
    assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 404
    assert exec_spy == []


def test_rerun_validation_csrf_and_wrong_result(client, app_module, login_as, csrf_of, ai_ready,
                                                monkeypatch, seed_fw_event, exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    # second investigation, owned by a fresh user (login_as replaces the session)
    _, inv2 = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                           domains=())
    other_rid = result_id(app_module, inv2)
    exec_spy.clear()
    assert client.post(f'/investigate/{inv2}/rerun',
                       json={'result_id': other_rid}).status_code == 400      # no CSRF header
    for bad in ({}, {'result_id': '1'}, {'result_id': True}, {'result_id': 1.5}):
        assert rerun(client, csrf_of, inv2, **bad).status_code == 400
    assert rerun(client, csrf_of, inv2, result_id=other_rid,
                 update_snapshot='yes').status_code == 400
    assert rerun(client, csrf_of, inv2, result_id=rid).status_code == 404     # other investigation
    assert rerun(client, csrf_of, inv2, result_id=10**9).status_code == 404
    assert rerun(client, csrf_of, 10**9, result_id=other_rid).status_code == 404
    assert exec_spy == []


def test_rerun_shared_peer_allowed_but_not_snapshot_update_private_hidden(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy):
    owner, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                                 share=True)
    rid = result_id(app_module, inv_id)
    seed_fw_event(ai_ready, domain='c.example')
    login_as('user', [ai_ready])                                # peer
    before = detail(app_module, inv_id)['results'][0]['rows']
    assert rerun(client, csrf_of, inv_id, result_id=rid, update_snapshot=True).status_code == 404
    assert detail(app_module, inv_id)['results'][0]['rows'] == before
    j = rerun(client, csrf_of, inv_id, result_id=rid)
    assert j.status_code == 200 and j.get_json()['diff']['added'] == 1
    assert detail(app_module, inv_id)['results'][0]['rows'] == before
    # unshare as the owner -> peer gets 404
    with client.session_transaction() as sess:
        sess['user_id'] = owner
    assert client.post(f'/investigate/{inv_id}/share', json={'shared': False},
                       headers={'X-CSRF-Token': csrf_of(client)}).status_code == 200
    login_as('user', [ai_ready])
    n = len(exec_spy)
    assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 404
    assert len(exec_spy) == n


# ── Task 3: Ask-AI-refresh ──────────────────────────────────────────────────
def refresh(client, csrf_of, inv_id, **body):
    return client.post(f'/investigate/{inv_id}/refresh', json=body,
                       headers={'X-CSRF-Token': csrf_of(client)})


def test_refresh_appends_a_turn_with_one_provider_call(client, app_module, login_as, csrf_of,
                                                       ai_ready, monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    prov = FakeProvider(T('Fresh answer.'))
    use(monkeypatch, prov)
    resp = refresh(client, csrf_of, inv_id, message_seq=1)
    assert resp.status_code == 200
    events = sse(resp)
    assert events[-1]['type'] == 'done'
    assert [e['investigation_id'] for e in events if e['type'] == 'saved'] == [inv_id]
    assert len(prov.seen) == 1
    d = detail(app_module, inv_id)
    assert [m['seq'] for m in d['messages']] == [1, 2, 3, 4]
    assert d['messages'][2]['content'] == d['messages'][0]['content'] == 'what happened?'
    assert d['messages'][3]['content'] == 'Fresh answer.'
    assert d['messages'][1]['content'] == 'Done.'                 # the original answer is kept
    assert len(audit_rows(app_module, 'refresh')) == 1
    assert len(audit_rows(app_module, 'chat')) == 2               # make() + refresh


def test_refresh_sends_only_earlier_history_of_that_investigation(client, app_module, login_as,
                                                                  csrf_of, ai_ready, monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    use(monkeypatch, FakeProvider(T('Second.')))
    second = chat(client, csrf_of(client), ai_ready, question='and then?', investigation_id=inv_id)
    assert saved_id(second) == inv_id
    prov = FakeProvider(T('Again.'))
    use(monkeypatch, prov)
    resp = refresh(client, csrf_of, inv_id, message_seq=3)
    assert resp.status_code == 200 and sse(resp)[-1]['type'] == 'done'
    msgs = prov.seen[0]['messages']
    assert [m['content'] for m in msgs] == ['what happened?', 'Done.', 'and then?']


def test_refresh_is_edit_only_and_validates(client, app_module, login_as, csrf_of, ai_ready,
                                            monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch, share=True)
    assert client.post(f'/investigate/{inv_id}/refresh',
                       json={'message_seq': 1}).status_code == 400            # no CSRF header
    prov = FakeProvider(T('x'))
    use(monkeypatch, prov)
    for bad in ({}, {'message_seq': '1'}, {'message_seq': True}, {'message_seq': 0}):
        assert refresh(client, csrf_of, inv_id, **bad).status_code == 400
    assert refresh(client, csrf_of, inv_id, message_seq=2).status_code == 404   # assistant seq
    assert refresh(client, csrf_of, inv_id, message_seq=99).status_code == 404
    assert refresh(client, csrf_of, 10**9, message_seq=1).status_code == 404
    login_as('user', [ai_ready])                                 # shared peer: read-only
    assert refresh(client, csrf_of, inv_id, message_seq=1).status_code == 404
    assert prov.seen == [] and len(detail(app_module, inv_id)['messages']) == 2
    assert audit_rows(app_module, 'refresh') == []


def test_refresh_respects_rate_limit_and_token_budget(client, app_module, login_as, csrf_of,
                                                      ai_ready, monkeypatch):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    prov = FakeProvider(T('x'))
    use(monkeypatch, prov)
    monkeypatch.setenv('AI_RATE_PER_MIN', '1')                    # make() already used the minute
    assert refresh(client, csrf_of, inv_id, message_seq=1).status_code == 429
    monkeypatch.setenv('AI_RATE_PER_MIN', '100')
    monkeypatch.setenv('AI_DAILY_TOKEN_BUDGET', '1')              # make() spent 15 tokens
    assert refresh(client, csrf_of, inv_id, message_seq=1).status_code == 429
    assert prov.seen == [] and len(detail(app_module, inv_id)['messages']) == 2


# ── Task 4: CSV export + execution rate limit + unexpected-error handling ───
import csv as _csv
import io as _io
import logging

from reports.ai import export as ai_export


def export(client, csrf_of, inv_id, **body):
    return client.post(f'/investigate/{inv_id}/export', json=body,
                       headers={'X-CSRF-Token': csrf_of(client)})


def parse_csv(resp):
    return list(_csv.reader(_io.StringIO(resp.get_data(as_text=True).lstrip('﻿'))))


def set_setting(app_module, **cols):
    with db(app_module) as conn, conn.cursor() as cur:
        for k, v in cols.items():
            cur.execute(f'UPDATE ai_settings SET {k} = %s WHERE id = 1', (v,))


def test_export_downloads_csv_with_safe_headers_and_audit(client, app_module, login_as, csrf_of,
                                                          ai_ready, monkeypatch, seed_fw_event,
                                                          exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                             domains=('a.example', '=cmd|calc'))
    rid = result_id(app_module, inv_id)
    exec_spy.clear()
    np = NoProvider()
    monkeypatch.setattr(routes, 'get_provider', np)
    resp = export(client, csrf_of, inv_id, result_id=rid)
    assert resp.status_code == 200
    assert resp.headers['Content-Type'] == 'text/csv; charset=utf-8'
    assert resp.headers['Content-Disposition'].startswith('attachment; filename="')
    assert '"' not in resp.headers['Content-Disposition'][len('attachment; filename="'):-1]
    assert resp.headers['Content-Disposition'].endswith(f'-{rid}.csv"')
    assert resp.headers['X-Content-Type-Options'] == 'nosniff'
    assert resp.headers['Cache-Control'] == 'no-store'
    rows = parse_csv(resp)
    assert rows[0] == ['domain'] and sorted(r[0] for r in rows[1:]) == ["'=cmd|calc", 'a.example']
    assert len(exec_spy) == 1 and exec_spy[0][1].original == DOM_SQL and np.calls == 0
    a = audit_rows(app_module, 'export')
    assert len(a) == 1 and a[0][2] == ai_ready and a[0][5] is None and a[0][6] == DOM_SQL
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute("SELECT row_count FROM ai_audit WHERE kind = 'export'")
        assert cur.fetchone()[0] == 2


def test_export_caps_rows_to_setting_and_notes_truncation(client, app_module, login_as, csrf_of,
                                                          ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                             domains=[f'd{i}.example' for i in range(105)])
    rid = result_id(app_module, inv_id)
    set_setting(app_module, export_max_rows=100)
    seen = []
    real = executor.run_query

    def spy(cfg, tid, guarded, **kw):
        seen.append(kw.get('max_rows'))
        return real(cfg, tid, guarded, **kw)

    monkeypatch.setattr(executor, 'run_query', spy)
    rows = parse_csv(export(client, csrf_of, inv_id, result_id=rid))
    assert seen == [100]
    assert rows[0] == ['domain'] and len(rows) == 1 + 100 + 1
    assert rows[-1] == ['Showing the first 100 rows only']


def test_export_hard_ceiling_applies_over_stored_setting(client, app_module, login_as, csrf_of,
                                                         ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                             domains=[f'd{i}.example' for i in range(105)])
    rid = result_id(app_module, inv_id)
    set_setting(app_module, export_max_rows=50000)
    monkeypatch.setattr(ai_export, 'EXPORT_HARD_CAP', 100)
    rows = parse_csv(export(client, csrf_of, inv_id, result_id=rid, limit=10**9, max_rows=10**9))
    assert len(rows) == 1 + 100 + 1 and rows[-1] == ['Showing the first 100 rows only']


def test_export_filename_is_sanitised(client, app_module, login_as, csrf_of, ai_ready,
                                      monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE ai_investigations SET title = %s WHERE id = %s',
                    ('../a"b\r\nX: y/é ' + 'z' * 80, inv_id))
    cd = export(client, csrf_of, inv_id, result_id=rid).headers['Content-Disposition']
    import re
    assert re.fullmatch(r'attachment; filename="[A-Za-z0-9_-]{1,40}-\d+\.csv"', cd), cd


def test_export_shared_peer_allowed_private_404_and_validation(client, app_module, login_as,
                                                               csrf_of, ai_ready, monkeypatch,
                                                               seed_fw_event, exec_spy):
    owner, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                                 share=True)
    rid = result_id(app_module, inv_id)
    login_as('user', [ai_ready])
    assert export(client, csrf_of, inv_id, result_id=rid).status_code == 200      # view is enough
    for bad in ({}, {'result_id': '1'}, {'result_id': True}, {'result_id': 1.5}):
        assert export(client, csrf_of, inv_id, **bad).status_code == 400
    assert export(client, csrf_of, inv_id, result_id=10**9).status_code == 404
    assert client.post(f'/investigate/{inv_id}/export', json={'result_id': rid}).status_code == 400
    with client.session_transaction() as sess:
        sess['user_id'] = owner
    client.post(f'/investigate/{inv_id}/share', json={'shared': False},
                headers={'X-CSRF-Token': csrf_of(client)})
    login_as('user', [ai_ready])
    n = len(exec_spy)
    assert export(client, csrf_of, inv_id, result_id=rid).status_code == 404
    assert len(exec_spy) == n


def test_export_requires_tenant_access_enabled_and_blocks_customer(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                             share=True)
    rid = result_id(app_module, inv_id)
    exec_spy.clear()
    login_as('customer', [ai_ready])
    assert export(client, csrf_of, inv_id, result_id=rid).status_code in (302, 404)
    login_as('user', [])                                         # no grant on the tenant
    assert export(client, csrf_of, inv_id, result_id=rid).status_code == 404
    assert exec_spy == []


def test_export_guard_rejected_stored_sql_never_executes(client, app_module, login_as, csrf_of,
                                                         ai_ready, monkeypatch, seed_fw_event,
                                                         exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE ai_query_results SET sql_text = %s WHERE id = %s',
                    ('SELECT * FROM pg_user', rid))
    exec_spy.clear()
    resp = export(client, csrf_of, inv_id, result_id=rid)
    assert resp.status_code == 422 and resp.get_json()['error'] and exec_spy == []
    assert audit_rows(app_module, 'export')[0][5]


def seed_exec_audit(app_module, user_id, tenant_id, n):
    with db(app_module) as conn, conn.cursor() as cur:
        for i in range(n):
            cur.execute("INSERT INTO ai_audit (kind, user_id, tenant_id) VALUES (%s, %s, %s)",
                        ('rerun' if i % 2 else 'export', user_id, tenant_id))


@pytest.mark.parametrize('first', ['rerun', 'export'])
def test_exec_endpoints_rate_limited_per_user_at_21st_call(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy,
        first):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                               share=True)
    rid = result_id(app_module, inv_id)
    seed_exec_audit(app_module, uid, ai_ready, 19)
    call = rerun if first == 'rerun' else export
    other = export if first == 'rerun' else rerun
    exec_spy.clear()
    assert call(client, csrf_of, inv_id, result_id=rid).status_code == 200     # the 20th
    assert len(exec_spy) == 1
    for fn in (call, other):                                                   # the 21st
        resp = fn(client, csrf_of, inv_id, result_id=rid)
        assert resp.status_code == 429
        assert resp.get_json()['error'] == 'Too many requests — try again in a minute.'
    assert len(exec_spy) == 1                                                  # executor untouched
    # another user is unaffected
    login_as('user', [ai_ready])
    assert call(client, csrf_of, inv_id, result_id=rid).status_code == 200
    # rows older than a minute do not count
    uid2 = login_as('user', [ai_ready])
    with db(app_module) as conn, conn.cursor() as cur:
        for _ in range(25):
            cur.execute("INSERT INTO ai_audit (kind, user_id, tenant_id, ts) "
                        "VALUES ('rerun', %s, %s, now() - interval '2 minutes')", (uid2, ai_ready))
    assert call(client, csrf_of, inv_id, result_id=rid).status_code == 200


@pytest.mark.parametrize('endpoint', ['rerun', 'export'])
def test_unexpected_executor_error_is_generic_logged_and_gate_released(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, caplog,
        endpoint):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)

    def boom(*a, **k):
        raise RuntimeError('secret-internal-detail')

    monkeypatch.setattr(executor, 'run_query', boom)
    call = rerun if endpoint == 'rerun' else export
    with caplog.at_level(logging.ERROR):
        for _ in range(routes.MAX_CONCURRENT + 1):          # a leaked gate would turn this into 429
            resp = call(client, csrf_of, inv_id, result_id=rid)
            assert resp.status_code == 500
            assert resp.get_json() == {'error': 'Something went wrong. The error was logged.'}
            assert 'secret-internal-detail' not in resp.get_data(as_text=True)
    assert any(r.exc_info and 'secret-internal-detail' in str(r.exc_info[1]) for r in caplog.records)


# ── Task 5: pin / findings PATCH / DELETE ───────────────────────────────────
def hdr(client, csrf_of):
    return {'X-CSRF-Token': csrf_of(client)}


def pin_call(client, csrf_of, inv_id, **body):
    return client.post(f'/investigate/{inv_id}/pin', json=body, headers=hdr(client, csrf_of))


def finding_rows(app_module, inv_id=None):
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('SELECT id, investigation_id, title, note, evidence_kind, evidence, report_id '
                    'FROM ai_findings ORDER BY id')
        return cur.fetchall()


def stored_result(app_module, inv_id):
    with db(app_module) as conn, conn.cursor() as cur:
        return investigations.get_result(cur, inv_id, result_id(app_module, inv_id))


def test_pin_freezes_server_side_evidence_and_ignores_client_keys(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    old = stored_result(app_module, inv_id)
    resp = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='  Odd   domains ',
                    note=' look ', rows=[['forged']], columns=['x'], sql='SELECT 1',
                    evidence={'rows': [['forged']]})
    assert resp.status_code == 200 and isinstance(resp.get_json()['id'], int)
    (fid, finv, title, note, kind, ev, report_id), = finding_rows(app_module)
    assert (finv, title, note, kind, report_id) == (inv_id, 'Odd domains', 'look', 'query', None)
    assert ev == {'sql': old['sql'], 'columns': old['columns'], 'rows': old['rows'],
                  'row_count': old['row_count'], 'truncated': old['truncated'],
                  'snapshot_at': old['snapshot_at'].isoformat(), 'duration_ms': old['duration_ms']}
    assert 'forged' not in str(ev)
    # listed by GET /investigate/<id>, JSON-safe
    got = client.get(f'/investigate/{inv_id}').get_json()['findings']
    assert [f['id'] for f in got] == [fid] and got[0]['evidence'] == ev
    assert got[0]['pinned_at'] and got[0]['report_id'] is None
    rows = audit_rows(app_module, 'pin')
    assert len(rows) == 1 and rows[0][6] == old['sql']


def test_pin_validation_idor_and_csrf(client, app_module, login_as, csrf_of, ai_ready,
                                      monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    assert client.post(f'/investigate/{inv_id}/pin',
                       json={'kind': 'query', 'result_id': rid, 'title': 't'}).status_code == 400
    for body in ({'kind': 'other', 'result_id': rid, 'title': 't'},
                 {'kind': 'timeline', 'timeline_token': 'x', 'title': 't'},
                 {'result_id': rid, 'title': 't'},
                 {'kind': 'query', 'result_id': 'x', 'title': 't'},
                 {'kind': 'query', 'result_id': True, 'title': 't'},
                 {'kind': 'query', 'result_id': rid},
                 {'kind': 'query', 'result_id': rid, 'title': 5},
                 {'kind': 'query', 'result_id': rid, 'title': ''},
                 {'kind': 'query', 'result_id': rid, 'title': '   '},
                 {'kind': 'query', 'result_id': rid, 'title': 'x' * 201},
                 {'kind': 'query', 'result_id': rid, 'title': 't', 'note': 'n' * 4001},
                 {'kind': 'query', 'result_id': rid, 'title': 't', 'note': 7}):
        r = pin_call(client, csrf_of, inv_id, **body)
        assert r.status_code == 400, body
        assert r.get_json()['error'], body
    assert pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='x' * 200,
                    note='n' * 4000).status_code == 200
    # a result id of ANOTHER investigation is 404, nothing stored for it
    use(monkeypatch, FakeProvider(T('', ToolCall('c1', 'run_sql', {'sql': SQL})), T('ok')))
    other = saved_id(chat(client, csrf_of(client), ai_ready, question='another one'))
    other_rid = result_id(app_module, other)
    n = len(finding_rows(app_module))
    assert pin_call(client, csrf_of, inv_id, kind='query', result_id=other_rid,
                    title='t').status_code == 404
    assert pin_call(client, csrf_of, inv_id, kind='query', result_id=10**12,
                    title='t').status_code == 404
    assert len(finding_rows(app_module)) == n


def test_pin_edit_delete_owner_admin_only_shared_peer_404(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                             share=True)
    rid = result_id(app_module, inv_id)
    fid = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid,
                   title='Mine').get_json()['id']
    login_as('user', [ai_ready])                                  # peer on a shared investigation
    assert client.get(f'/investigate/{inv_id}').get_json()['findings'][0]['title'] == 'Mine'
    ph = hdr(client, csrf_of)
    assert client.post(f'/investigate/{inv_id}/pin', json={'kind': 'query', 'result_id': rid,
                       'title': 'x'}, headers=ph).status_code == 404
    assert client.patch(f'/investigate/{inv_id}/findings/{fid}', json={'title': 'x'},
                        headers=ph).status_code == 404
    assert client.delete(f'/investigate/{inv_id}/findings/{fid}', headers=ph).status_code == 404
    assert [r[2] for r in finding_rows(app_module)] == ['Mine']
    login_as('admin', [ai_ready])                                 # admin may edit and delete
    ah = hdr(client, csrf_of)
    assert client.patch(f'/investigate/{inv_id}/findings/{fid}', json={'title': 'By admin'},
                        headers=ah).status_code == 200
    assert pin_call(client, csrf_of, inv_id, kind='query', result_id=rid,
                    title='Admin pin').status_code == 200
    assert client.delete(f'/investigate/{inv_id}/findings/{fid}', headers=ah).get_json() == {'ok': True}
    assert [r[2] for r in finding_rows(app_module)] == ['Admin pin']


def test_finding_patch_delete_validation_csrf_and_scoping(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    fid = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='T',
                   note='N').get_json()['id']
    url = f'/investigate/{inv_id}/findings/{fid}'
    assert client.patch(url, json={'title': 'x'}).status_code == 400         # no CSRF
    assert client.delete(url).status_code == 400
    h = hdr(client, csrf_of)
    for body in ({}, {'title': ''}, {'title': 5}, {'note': 'n' * 4001}, {'note': None}, {'title': 'x' * 201}):
        r = client.patch(url, json=body, headers=h)
        assert r.status_code == 400 and r.get_json()['error'], body
    assert client.patch(url, json={'note': 'only note', 'rows': [[1]], 'evidence': {}},
                        headers=h).get_json() == {'ok': True}
    (_, _, title, note, _, ev, _), = finding_rows(app_module)
    assert (title, note) == ('T', 'only note') and 'rows' in ev and ev['rows'] != [[1]]
    xss = '<img src=x onerror=1><script>alert(1)</script>'
    assert client.patch(url, json={'title': xss, 'note': xss}, headers=h).status_code == 200
    assert client.get(f'/investigate/{inv_id}').get_json()['findings'][0]['title'] == xss
    # a finding id from another investigation is not reachable through this one
    use(monkeypatch, FakeProvider(T('', ToolCall('c1', 'run_sql', {'sql': SQL})), T('ok')))
    other = saved_id(chat(client, csrf_of(client), ai_ready, question='another one'))
    ofid = pin_call(client, csrf_of, other, kind='query', result_id=result_id(app_module, other),
                    title='Other').get_json()['id']
    h = hdr(client, csrf_of)
    assert client.patch(f'/investigate/{inv_id}/findings/{ofid}', json={'title': 'x'},
                        headers=h).status_code == 404
    assert client.delete(f'/investigate/{inv_id}/findings/{ofid}', headers=h).status_code == 404
    assert client.delete(f'/investigate/{inv_id}/findings/99999999', headers=h).status_code == 404
    assert client.delete(url, headers=h).get_json() == {'ok': True}
    assert [r[2] for r in finding_rows(app_module)] == ['Other']


def test_revoked_grant_blocks_pin_and_finding_routes(client, app_module, login_as, csrf_of,
                                                     ai_ready, monkeypatch, seed_fw_event):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    fid = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid,
                   title='T').get_json()['id']
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('DELETE FROM ui_user_tenants WHERE user_id = %s', (uid,))
    h = hdr(client, csrf_of)
    assert pin_call(client, csrf_of, inv_id, kind='query', result_id=rid,
                    title='x').status_code == 404
    assert client.patch(f'/investigate/{inv_id}/findings/{fid}', json={'title': 'x'},
                        headers=h).status_code == 404
    assert client.delete(f'/investigate/{inv_id}/findings/{fid}', headers=h).status_code == 404
    assert len(finding_rows(app_module)) == 1


def test_pin_does_not_touch_report_id(client, app_module, login_as, csrf_of, ai_ready,
                                      monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    fid = pin_call(client, csrf_of, inv_id, kind='query', result_id=result_id(app_module, inv_id),
                   title='T', report_id=5).get_json()['id']
    client.patch(f'/investigate/{inv_id}/findings/{fid}', json={'title': 'U', 'report_id': 9},
                 headers=hdr(client, csrf_of))
    assert [r[6] for r in finding_rows(app_module)] == [None]


# ── unexpected errors anywhere in a handler become the generic JSON 500 ────
@pytest.mark.parametrize('endpoint,target', [('rerun', 'diff'), ('export', 'export')])
def test_unexpected_error_after_executor_is_generic_json_500(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, caplog,
        endpoint, target):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)

    def boom(*a, **k):
        raise RuntimeError('late-secret-detail')

    if target == 'diff':
        monkeypatch.setattr(routes.diff, 'diff_results', boom)
        call = rerun
    else:
        monkeypatch.setattr(routes.export, 'to_csv', boom)
        call = export
    with caplog.at_level(logging.ERROR):
        resp = call(client, csrf_of, inv_id, result_id=rid)
    assert resp.status_code == 500 and resp.is_json
    assert resp.get_json() == {'error': 'Something went wrong. The error was logged.'}
    assert 'late-secret-detail' not in resp.get_data(as_text=True)
    assert any(r.exc_info and 'late-secret-detail' in str(r.exc_info[1]) for r in caplog.records)


def test_unexpected_error_in_settings_load_and_http_errors_still_propagate(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    real = routes.store.load_settings
    monkeypatch.setattr(routes.store, 'load_settings',
                        lambda *a, **k: (_ for _ in ()).throw(RuntimeError('x')))
    assert export(client, csrf_of, inv_id, result_id=rid).status_code == 500
    monkeypatch.setattr(routes.store, 'load_settings', real)
    assert rerun(client, csrf_of, inv_id, result_id=10**12).status_code == 404       # abort(404)
    assert rerun(client, csrf_of, inv_id, result_id='x').status_code == 400
    assert export(client, csrf_of, 10**9, result_id=rid).status_code == 404
    assert client.post(f'/investigate/{inv_id}/export', json={'result_id': rid}).status_code == 400


@pytest.mark.parametrize('what', ['pin', 'patch', 'delete'])
def test_unexpected_error_in_finding_routes_is_generic_json_500(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, what):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    fid = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid,
                   title='T').get_json()['id']

    def boom(*a, **k):
        raise RuntimeError('db-down-detail')

    h = hdr(client, csrf_of)
    if what == 'pin':
        monkeypatch.setattr(routes.investigations, 'add_finding', boom)
        resp = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='x')
    elif what == 'patch':
        monkeypatch.setattr(routes.investigations, 'update_finding', boom)
        resp = client.patch(f'/investigate/{inv_id}/findings/{fid}', json={'title': 'x'}, headers=h)
    else:
        monkeypatch.setattr(routes.investigations, 'delete_finding', boom)
        resp = client.delete(f'/investigate/{inv_id}/findings/{fid}', headers=h)
    assert resp.status_code == 500 and resp.get_json() == {'error': routes._GENERIC_ERROR}
    assert 'db-down-detail' not in resp.get_data(as_text=True)


def test_saved_event_carries_this_turns_result_ids_in_order(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch):
    login_as('user', [ai_ready])
    use(monkeypatch, FakeProvider(
        T('', ToolCall('c1', 'run_sql', {'sql': SQL}), ToolCall('c2', 'run_sql', {'sql': SQL}),
          ToolCall('c3', 'run_sql', {'sql': 'DROP TABLE x'})), T('Done.')))
    events = sse(chat(client, csrf_of(client), ai_ready, question='two queries'))
    saved, = [e for e in events if e['type'] == 'saved']
    ok_sql = [e for e in events if e['type'] == 'sql' and not e.get('error')]
    assert len(ok_sql) == 2 and len(saved['result_ids']) == 2
    assert all(type(x) is int for x in saved['result_ids'])
    d = detail(app_module, saved['investigation_id'])
    assert [r['id'] for r in d['results']] == saved['result_ids']
    assert saved['assistant_seq'] == d['messages'][-1]['seq'] == d['results'][0]['message_seq']
    # a follow-up turn reports only its own ids
    use(monkeypatch, FakeProvider(T('', ToolCall('c1', 'run_sql', {'sql': SQL})), T('Again.')))
    second = sse(chat(client, csrf_of(client), ai_ready, question='more',
                      investigation_id=saved['investigation_id']))
    s2, = [e for e in second if e['type'] == 'saved']
    assert len(s2['result_ids']) == 1 and s2['result_ids'][0] not in saved['result_ids']


def test_saved_event_has_empty_result_ids_without_queries(
        client, login_as, csrf_of, ai_ready, monkeypatch):
    login_as('user', [ai_ready])
    use(monkeypatch, FakeProvider(T('No query needed.')))
    saved, = [e for e in sse(chat(client, csrf_of(client), ai_ready, question='hi'))
              if e['type'] == 'saved']
    assert saved['result_ids'] == []


def test_pin_is_capped_at_100_per_investigation(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    with db(app_module) as conn, conn.cursor() as cur:
        for n in range(99):
            investigations.add_finding(cur, inv_id, tenant_id=ai_ready, created_by=uid,
                                       title=f'f{n}', note='', evidence_kind='query', evidence={})
        conn.commit()
    ok = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='100th')
    assert ok.status_code == 200
    audits = len(audit_rows(app_module, 'pin'))
    bad = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='101st')
    assert bad.status_code == 400
    assert bad.get_json()['error'] == 'This investigation already has 100 pinned findings.'
    assert len(finding_rows(app_module)) == 100
    assert len(audit_rows(app_module, 'pin')) == audits


# ── Task 6: timeline pin ────────────────────────────────────────────────────
TL_IP = '10.9.9.9'


def test_timeline_pin_reruns_server_side_and_ignores_client_rows(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy):
    seed_fw_event(ai_ready, src_ip=TL_IP, dst_ip='1.1.1.1', action='deny', rule_name='r1')
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    exec_spy.clear()
    resp = pin_call(client, csrf_of, inv_id, kind='timeline', ip=f' {TL_IP} ', window='7d',
                    title='Host 10.9.9.9', note='n', rows=[['forged']], columns=['x'],
                    evidence={'rows': [['forged']]}, sql='SELECT 1')
    assert resp.status_code == 200
    (fid, finv, title, note, kind, ev, rep), = finding_rows(app_module)
    assert kind == 'timeline' and finv == inv_id and rep is None
    assert set(ev) == {'subject', 'window', 'columns', 'rows', 'row_count', 'truncated',
                       'generated_at'}
    assert ev['subject'] == TL_IP and ev['window'] == '7d' and ev['row_count'] == 1
    assert ev['rows'][0][1] == 'denied' and ev['rows'][0][7] == 'r1' and 'forged' not in str(ev)
    assert len(exec_spy) == 1 and exec_spy[0][0] == ai_ready
    assert len(audit_rows(app_module, 'pin')) == 1 and len(audit_rows(app_module, 'timeline')) == 1
    got = client.get(f'/investigate/{inv_id}').get_json()['findings']
    assert got[0]['evidence_kind'] == 'timeline' and got[0]['evidence'] == ev


def test_timeline_pin_empty_evidence_allowed_and_validation(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    ok = pin_call(client, csrf_of, inv_id, kind='timeline', ip='10.250.1.1', window='24h',
                  title='quiet host')
    assert ok.status_code == 200
    ev = finding_rows(app_module)[0][5]
    assert ev['rows'] == [] and ev['row_count'] == 0
    for bad in ({'ip': 'nope', 'window': '24h'}, {'ip': TL_IP, 'window': '1y'},
                {'ip': TL_IP, 'window': '24h', 'include_allowed': 1}, {'window': '24h'}):
        assert pin_call(client, csrf_of, inv_id, kind='timeline', title='t', **bad
                        ).status_code == 400
    assert len(finding_rows(app_module)) == 1


def test_timeline_pin_needs_edit_rights_and_csrf(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                               share=True)
    assert client.post(f'/investigate/{inv_id}/pin', json={'kind': 'timeline', 'ip': TL_IP,
                       'title': 't'}).status_code == 400                      # no CSRF
    login_as('user', [ai_ready])                                              # shared peer
    exec_spy.clear()
    assert pin_call(client, csrf_of, inv_id, kind='timeline', ip=TL_IP, window='24h',
                    title='t').status_code == 404
    assert exec_spy == [] and finding_rows(app_module) == []


def test_timeline_pin_capped_at_100(client, app_module, login_as, csrf_of, ai_ready,
                                    monkeypatch, seed_fw_event, exec_spy):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    with db(app_module) as conn, conn.cursor() as cur:
        for n in range(100):
            investigations.add_finding(cur, inv_id, tenant_id=ai_ready, created_by=uid,
                                       title=f'f{n}', note='', evidence_kind='query', evidence={})
        conn.commit()
    exec_spy.clear()
    bad = pin_call(client, csrf_of, inv_id, kind='timeline', ip=TL_IP, window='24h', title='101st')
    assert bad.status_code == 400 and 'already has 100' in bad.get_json()['error']
    assert exec_spy == [] and len(finding_rows(app_module)) == 100


def test_timeline_pin_requires_tenant_enabled_and_counts_toward_rate_limit(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    seed_exec_audit(app_module, uid, ai_ready, 20)
    exec_spy.clear()
    assert pin_call(client, csrf_of, inv_id, kind='timeline', ip=TL_IP, window='24h',
                    title='t').status_code == 429
    assert exec_spy == [] and finding_rows(app_module) == []


@pytest.mark.parametrize('bad', ["fe80::1%x' OR '1'='1", 'fe80::1%eth0'])
def test_timeline_pin_scoped_ip_is_400_without_executor_finding_or_audit(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy, bad):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    exec_spy.clear()
    resp = pin_call(client, csrf_of, inv_id, kind='timeline', ip=bad, window='24h', title='t')
    assert resp.status_code == 400 and resp.get_json()['error'] == 'Enter a valid IP address.'
    assert exec_spy == [] and finding_rows(app_module) == []
    assert audit_rows(app_module, 'timeline') == [] or len(audit_rows(app_module, 'timeline')) == 0


@pytest.mark.parametrize('title,note,msg', [
    ('', '', 'Enter a title (up to 200 characters).'),
    ('x' * 201, '', 'Enter a title (up to 200 characters).'),
    ('ok', 'n' * 4001, 'The note is too long (up to 4000 characters).')])
def test_timeline_pin_validates_text_before_rerun(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy,
        title, note, msg):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    exec_spy.clear()
    before = len(audit_rows(app_module, 'timeline'))
    resp = pin_call(client, csrf_of, inv_id, kind='timeline', ip=TL_IP, window='24h',
                    title=title, note=note)
    assert resp.status_code == 400 and resp.get_json()['error'] == msg
    assert exec_spy == [] and finding_rows(app_module) == []
    assert len(audit_rows(app_module, 'timeline')) == before


def test_timeline_pin_freezes_truncated_flag(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, exec_spy):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    for _ in range(501):
        seed_fw_event(ai_ready, src_ip='10.77.7.7', dst_ip='1.1.1.1', action='deny')
    resp = pin_call(client, csrf_of, inv_id, kind='timeline', ip='10.77.7.7', window='24h',
                    title='big')
    assert resp.status_code == 200
    ev = finding_rows(app_module)[0][5]
    assert ev['truncated'] is True and ev['row_count'] == 500 and len(ev['rows']) == 500


# ── Final review fixes ──────────────────────────────────────────────────────
import threading  # noqa: E402


def audit_kinds(app_module):
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('SELECT kind, row_count FROM ai_audit ORDER BY id')
        return cur.fetchall()


def test_audit_rows_for_rename_delete_and_finding_edit_delete(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    fid = pin_call(client, csrf_of, inv_id, kind='query', result_id=rid, title='T').get_json()['id']
    h = hdr(client, csrf_of)
    assert client.post(f'/investigate/{inv_id}/rename', json={'title': 'New'},
                       headers=h).status_code == 200
    assert client.patch(f'/investigate/{inv_id}/findings/{fid}', json={'title': 'T2'},
                        headers=h).status_code == 200
    assert client.delete(f'/investigate/{inv_id}/findings/{fid}', headers=h).status_code == 200
    assert client.post(f'/investigate/{inv_id}/delete', json={}, headers=h).status_code == 200
    kinds = audit_kinds(app_module)
    assert ('rename', inv_id) in kinds
    assert ('finding_edit', fid) in kinds
    assert ('finding_delete', fid) in kinds
    assert ('delete', inv_id) in kinds
    # deletion no longer reuses the 'save' kind
    assert [k for k in kinds if k[0] == 'save'] == [('save', inv_id)]       # creation only


def _clone(client, app_module):
    c = app_module.app.test_client()
    with client.session_transaction() as src, c.session_transaction() as dst:
        dst.update(dict(src))
    return c


def _call_endpoint(c, name, inv_id, rid, tenant, tok):
    h = {'X-CSRF-Token': tok}
    if name == 'rerun':
        return c.post(f'/investigate/{inv_id}/rerun', json={'result_id': rid}, headers=h)
    if name == 'export':
        return c.post(f'/investigate/{inv_id}/export', json={'result_id': rid}, headers=h)
    if name == 'timeline':
        return c.post('/investigate/timeline', json={'tenant_id': tenant, 'ip': TL_IP}, headers=h)
    return c.post(f'/investigate/{inv_id}/pin', json={'kind': 'timeline', 'ip': TL_IP,
                                                      'title': 't'}, headers=h)


@pytest.mark.parametrize('name', ['rerun', 'export', 'timeline', 'pin_timeline'])
def test_per_user_inflight_limit_429_before_executor_and_released(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event, name):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event,
                               share=True)
    rid = result_id(app_module, inv_id)
    tok = csrf_of(client)
    real = executor.run_query
    entered, release, calls = threading.Semaphore(0), threading.Event(), []

    def spy(config, tenant_id, guarded, **kw):
        calls.append(guarded)
        if len(calls) <= routes.MAX_INFLIGHT_PER_USER:
            entered.release()
            assert release.wait(20)
        return real(config, tenant_id, guarded, **kw)

    monkeypatch.setattr(executor, 'run_query', spy)
    codes = []
    threads = [threading.Thread(
        target=lambda c=_clone(client, app_module): codes.append(
            _call_endpoint(c, name, inv_id, rid, ai_ready, tok).status_code))
        for _ in range(routes.MAX_INFLIGHT_PER_USER)]
    for t in threads:
        t.start()
    for _ in threads:
        assert entered.acquire(timeout=20)
    inflight = app_module.app.extensions['ai_inflight']
    assert inflight == {uid: routes.MAX_INFLIGHT_PER_USER}
    resp = _call_endpoint(client, name, inv_id, rid, ai_ready, tok)           # the third
    assert resp.status_code == 429
    assert resp.get_json()['error'] == 'Too many requests — try again in a minute.'
    assert len(calls) == routes.MAX_INFLIGHT_PER_USER                          # no executor call
    # another user is unaffected while the first user is saturated
    login_as('user', [ai_ready])
    assert _call_endpoint(client, name, inv_id, rid, ai_ready,
                          csrf_of(client)).status_code in (200, 404)
    release.set()
    for t in threads:
        t.join(30)
    assert sorted(codes) == [200] * routes.MAX_INFLIGHT_PER_USER
    assert app_module.app.extensions['ai_inflight'] == {}


def test_inflight_counter_returns_to_zero_on_error_and_exception_paths(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    uid, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    inflight = app_module.app.extensions['ai_inflight']
    assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 200
    assert inflight == {}
    real = executor.run_query

    def guard_error(*a, **k):
        raise executor.ExecutorError('rejected')

    monkeypatch.setattr(executor, 'run_query', guard_error)
    for _ in range(routes.MAX_INFLIGHT_PER_USER + 2):
        assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 422
        assert inflight == {}

    def boom(*a, **k):
        raise RuntimeError('x')

    monkeypatch.setattr(executor, 'run_query', boom)
    for _ in range(routes.MAX_INFLIGHT_PER_USER + 2):
        assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 500
        assert inflight == {}
    monkeypatch.setattr(executor, 'run_query', real)
    # failure AFTER the executor (diff) also releases
    monkeypatch.setattr(routes.diff, 'diff_results', boom)
    assert rerun(client, csrf_of, inv_id, result_id=rid).status_code == 500
    assert inflight == {}


# json_errors coverage for the remaining handlers (late failure -> generic JSON 500)
@pytest.mark.parametrize('group', ['rename', 'share', 'delete', 'open', 'list', 'refresh'])
def test_late_failure_in_remaining_handlers_is_generic_json_500(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, group):
    _, inv_id = make(client, login_as, csrf_of, ai_ready, monkeypatch)
    h = hdr(client, csrf_of)

    def boom(*a, **k):
        raise RuntimeError('late-detail')

    if group == 'rename':
        monkeypatch.setattr(routes.investigations, 'rename', boom)
        resp = client.post(f'/investigate/{inv_id}/rename', json={'title': 'x'}, headers=h)
    elif group == 'share':
        monkeypatch.setattr(routes.investigations, 'set_shared', boom)
        resp = client.post(f'/investigate/{inv_id}/share', json={'shared': True}, headers=h)
    elif group == 'delete':
        monkeypatch.setattr(routes.investigations, 'delete', boom)
        resp = client.post(f'/investigate/{inv_id}/delete', json={}, headers=h)
    elif group == 'open':
        monkeypatch.setattr(routes.investigations, 'detail', boom)
        resp = client.get(f'/investigate/{inv_id}')
    elif group == 'list':
        monkeypatch.setattr(routes.investigations, 'list_for', boom)
        resp = client.get('/investigate/list?tab=mine')
    else:
        monkeypatch.setattr(routes, '_clean_history', boom)
        resp = client.post(f'/investigate/{inv_id}/refresh', json={'message_seq': 1}, headers=h)
    assert resp.status_code == 500 and resp.get_json() == {'error': routes._GENERIC_ERROR}
    assert 'late-detail' not in resp.get_data(as_text=True)
    # HTTP errors still propagate
    assert client.get('/investigate/999999999').status_code == 404
    assert client.get('/investigate/list?tab=bogus').status_code == 404


def test_rerun_response_has_snapshot_at_and_export_bumps_last_rerun(
        client, app_module, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event):
    _, inv_id = make_domains(client, login_as, csrf_of, ai_ready, monkeypatch, seed_fw_event)
    rid = result_id(app_module, inv_id)
    j = rerun(client, csrf_of, inv_id, result_id=rid).get_json()
    assert j['snapshot_at'].startswith('20')
    with db(app_module) as conn, conn.cursor() as cur:
        cur.execute('UPDATE ai_investigations SET last_rerun_at = NULL WHERE id = %s', (inv_id,))
    assert export(client, csrf_of, inv_id, result_id=rid).status_code == 200
    assert detail(app_module, inv_id)['investigation']['last_rerun_at'] is not None


def test_end_to_end_flow(client, app_module, login_as, csrf_of, ai_ready, monkeypatch,
                         seed_fw_event):
    """Spec §8: chat -> auto-save -> new events -> re-run diff -> export -> pin -> timeline."""
    for dom in ('a.example', 'b.example'):
        seed_fw_event(ai_ready, domain=dom, src_ip=TL_IP, dst_ip='1.1.1.1', action='deny',
                      rule_name='r1')
    uid = login_as('user', [ai_ready])
    use(monkeypatch, FakeProvider(T('', ToolCall('c1', 'run_sql', {'sql': DOM_SQL})), T('Done.')))
    inv_id = saved_id(chat(client, csrf_of(client), ai_ready, question='which domains?'))
    rid = result_id(app_module, inv_id)
    seed_fw_event(ai_ready, domain='c.example', src_ip=TL_IP, dst_ip='1.1.1.1', action='deny',
                  rule_name='r1')
    j = rerun(client, csrf_of, inv_id, result_id=rid).get_json()
    assert j['diff']['identical'] is False and j['diff']['delta'] == 1
    csv_text = export(client, csrf_of, inv_id, result_id=rid).get_data(as_text=True)
    assert 'c.example' in csv_text and len(csv_text.strip().splitlines()) == 4   # header + 3
    assert pin_call(client, csrf_of, inv_id, kind='query', result_id=rid,
                    title='Domains').status_code == 200
    tl = client.post('/investigate/timeline', json={'tenant_id': ai_ready, 'ip': TL_IP},
                     headers=hdr(client, csrf_of))
    assert tl.status_code == 200 and tl.get_json()['row_count'] == 3
    assert pin_call(client, csrf_of, inv_id, kind='timeline', ip=TL_IP,
                    title='Host').status_code == 200
    opened = client.get(f'/investigate/{inv_id}').get_json()
    assert sorted(f['evidence_kind'] for f in opened['findings']) == ['query', 'timeline']
    assert opened['can_edit'] is True
    kinds = {k for k, _ in audit_kinds(app_module)}
    assert {'chat_start', 'chat', 'query', 'save', 'rerun', 'export', 'pin',
            'timeline'} <= kinds
