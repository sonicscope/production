import os
import re
import sys

from reports.ai import page as ai_page
from reports.ai.store import AISettings

WEB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'web')
if WEB_DIR not in sys.path:
    sys.path.insert(0, WEB_DIR)


def inv(**kw):
    args = dict(configured=True, is_admin=True, tenants=[(1, 'Acme'), (2, '<b>Evil</b>')],
                has_tenants=True, csrf='CSRF123', nonce='NONCE456')
    args.update(kw)
    return ai_page.investigate_html(**args)


def test_script_uses_nonce_and_no_inline_handlers_or_innerhtml():
    html = inv()
    assert '<script nonce="NONCE456">' in html
    assert 'innerHTML' not in html and 'insertAdjacentHTML' not in html
    assert 'eval(' not in html and 'document.write' not in html
    assert not re.search(r'\son\w+\s*=', html)             # no onclick= etc.
    assert 'cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js' in html


def test_tenant_names_are_escaped_and_csrf_embedded():
    html = inv()
    assert '&lt;b&gt;Evil&lt;/b&gt;' in html and '<b>Evil</b>' not in html
    assert 'data-csrf="CSRF123"' in html


def test_states():
    assert 'Set up AI assistant' in inv(configured=False, is_admin=True)
    assert '/settings/ai' in inv(configured=False, is_admin=True)
    assert 'ask an administrator' in inv(configured=False, is_admin=False).lower()
    assert 'enabled for AI' in inv(tenants=[], has_tenants=True)
    assert 'id="inv-send"' in inv()


def test_empty_state_copy_and_starters():
    html = inv()
    assert "Ask about this customer's network" in html
    for s in ai_page.STARTERS:
        assert s in html
    assert html.count('data-starter') == 4
    assert 'Ask about traffic, threats, apps or countries' in html
    assert 'Query results are sent to your configured AI provider. ' \
           'Check the SQL before you rely on an answer.' in html


def test_accessibility_hooks():
    html = inv()
    assert re.search(r'id="inv-msgs"[^>]*role="log"[^>]*aria-live="polite"', html)
    assert '<label for="inv-input"' in html and 'id="inv-input"' in html
    assert 'focus-visible' in html and 'prefers-reduced-motion' in html


def test_settings_page_never_contains_a_key_and_shows_last4():
    s = AISettings('openai', 'gpt-x', '9999', 1, None, 'openai')
    html = ai_page.settings_html(settings=s, providers=('anthropic', 'openai', 'gemini'),
                                 tenants=[(1, 'Acme <x>', True), (2, 'Beta', False)])
    assert '••••9999' in html and 'type="password"' in html
    assert 'value="sk-' not in html
    assert 'Acme &lt;x&gt;' in html
    assert 'name="consent"' in html and 'POPIA' in html
    assert re.search(r'name="tenant_ids"[^>]*value="1"[^>]*checked', html)
    assert 'action="/settings/ai/test"' in html


def test_settings_page_without_settings():
    html = ai_page.settings_html(settings=None, providers=('anthropic',), tenants=[])
    assert '••••' not in html and 'name="api_key"' in html


def test_settings_values_are_escaped():
    s = AISettings('openai', 'x"><script>alert(1)</script>', '9999', 1, None, 'o"x')
    html = ai_page.settings_html(settings=s, providers=('openai',), tenants=[])
    assert '<script>alert(1)</script>' not in html
    assert 'value="x&quot;&gt;&lt;script&gt;' in html


def test_nav_entries_present_for_admin_and_user_and_absent_in_portal(app_module, client,
                                                                      login_as):
    login_as('admin')
    html = client.get('/').get_data(as_text=True)
    assert 'href="/investigate"' in html and 'href="/settings/ai"' in html
    login_as('user')
    html = client.get('/').get_data(as_text=True)
    assert 'href="/investigate"' in html and 'href="/settings/ai"' not in html
    with app_module.app.test_request_context('/portal'):
        portal = app_module._portal_page(
            'Dashboard', '<p>x</p>',
            {'id': 1, 'name': 'M', 'footer_text': '', 'logo_path': None,
             'contact_email': None, 'website': None,
             **app_module._portal_brand({'primary_color': '#001133'})},
            {'id': 1, 'name': 'T', 'contact_email': None, 'timezone': 'UTC'})
    assert '/investigate' not in portal and '/settings/ai' not in portal


def test_nav_active_class_on_ai_pages(app_module, client, login_as, seed_tenants, monkeypatch):
    login_as('admin')
    html = client.get('/investigate').get_data(as_text=True)
    assert re.search(r'class="nav-link active"\s+href="/investigate"', html)
    html = client.get('/settings/ai').get_data(as_text=True)
    assert re.search(r'class="nav-link active"\s+href="/settings/ai"', html)


def test_settings_form_has_export_and_retention_inputs():
    s = AISettings('openai', 'gpt-x', '9999', 1, None, 'openai', 20000, 30)
    html = ai_page.settings_html(settings=s, providers=["openai"], tenants=[])
    assert 'name="export_max_rows"' in html and 'min="100" max="50000"' in html
    assert 'value="20000"' in html and 'Hard limit 50,000' in html
    assert 'name="retention_days"' in html and 'min="7" max="365"' in html and 'value="30"' in html


def test_retention_field_has_help_text():
    s = AISettings('openai', 'gpt-x', '9999', 1, None, 'openai', 20000, 30)
    html = ai_page.settings_html(settings=s, providers=["openai"], tenants=[])
    assert ('Saved investigations are deleted after this many days (7–365). '
            'Findings added to a report are kept.') in html


def test_tray_has_generate_report_footer_inside_the_tray():
    html = inv()
    tray = html[html.index('id="inv-tray"'):]
    tray = tray[:tray.index('</aside>')]
    assert 'id="report-open"' in tray and 'Generate report' in tray and 'id="report-hint"' in tray
    assert 'id="report-open" class="btn btn-sm btn-ss" disabled aria-describedby="report-hint"' in tray
    assert tray.index('id="tray-list"') < tray.index('id="report-open"')
    assert not re.search(r'\son\w+\s*=', tray)


def test_stage3_js_has_no_innerhtml_and_is_wired():
    from reports.ai.page_stage3 import STAGE3_CSS, STAGE3_JS, TRAY_FOOTER_HTML
    assert 'innerHTML' not in STAGE3_JS and 'insertAdjacentHTML' not in STAGE3_JS
    assert not re.search(r'\son\w+\s*=', TRAY_FOOTER_HTML)
    html = inv()
    assert 'openReport' in html and '.rp-overlay' in html and '@@STAGE3@@' not in html
    assert STAGE3_CSS.count('z-index:1050') >= 1


def test_provider_labels_keep_brand_case():
    html = ai_page.settings_html(settings=None, providers=('openai', 'openrouter', 'gemini'),
                                 tenants=[])
    assert '>OpenRouter</option>' in html and '>OpenAI</option>' in html
    assert '>Gemini</option>' in html


def test_settings_load_models_ui_only_when_enabled():
    plain = ai_page.settings_html(settings=None, providers=('openai',), tenants=[])
    assert 'load_models' not in plain and '<script' not in plain
    html = ai_page.settings_html(settings=None, providers=('openai',), tenants=[],
                                 csrf='tok"1', models_ui=True)
    assert 'id="load_models"' in html and 'id="model_pick"' in html
    assert '<script>' in html and 'data-csrf="tok&quot;1"' in html
    assert 'innerHTML' not in html
