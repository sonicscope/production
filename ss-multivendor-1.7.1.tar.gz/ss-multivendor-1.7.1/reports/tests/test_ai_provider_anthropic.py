import pytest

from reports.ai import net
from reports.ai.providers import PROVIDER_NAMES, get_provider
from reports.ai.providers.base import ToolCall, ToolSpec, Usage, as_int, make_tool_call, validate_model
from reports.ai.providers.anthropic import AnthropicProvider

TOOLS = [ToolSpec('run_sql', 'Run SQL', {'type': 'object',
                                         'properties': {'sql': {'type': 'string'}},
                                         'required': ['sql']})]
MSGS = [
    {'role': 'user', 'content': 'top talkers?'},
    {'role': 'assistant', 'content': 'Checking.',
     'tool_calls': (ToolCall('c1', 'run_sql', {'sql': 'SELECT 1'}),
                    ToolCall('c2', 'describe_schema', {}))},
    {'role': 'tool', 'tool_call_id': 'c1', 'name': 'run_sql', 'content': 'rows'},
    {'role': 'tool', 'tool_call_id': 'c2', 'name': 'describe_schema', 'content': 'doc'},
]
HOSTILE = [
    None, [], 'x', 5, {'content': 'x'}, {'content': [None]},
    {'content': [{'type': 'text', 'text': None}]},
    {'content': [{'type': 'tool_use', 'id': 'a', 'name': 'b', 'input': 'x'}]},
    {'content': [{'type': 'tool_use', 'id': ['a'], 'name': 'b'}]},
    {'usage': 'x'}, {'usage': {'input_tokens': 1e999}}, {'usage': {'output_tokens': [1]}},
    {'content': [{'type': 'text', 'text': 'x'}], 'usage': 'x'},
]


def test_factory_and_names():
    assert PROVIDER_NAMES == ('anthropic', 'openai', 'gemini', 'openrouter')
    assert get_provider('anthropic').name == 'anthropic'
    with pytest.raises(ValueError):
        get_provider('nope')


@pytest.mark.parametrize('bad', ['', 'a b', 'x/../y', '-x', 'a' * 101, 'm?x=1', 'gpt-4\n'])
def test_validate_model_rejects(bad):
    with pytest.raises(net.ProviderError):
        validate_model(bad)


def test_build_request_shapes():
    req = AnthropicProvider().build_request('claude-x', 'SYS', MSGS, TOOLS, 512)
    assert req['model'] == 'claude-x' and req['system'] == 'SYS' and req['max_tokens'] == 512
    assert req['tools'] == [{'name': 'run_sql', 'description': 'Run SQL',
                             'input_schema': TOOLS[0].parameters}]
    roles = [m['role'] for m in req['messages']]
    assert roles == ['user', 'assistant', 'user']           # tool results merged
    assistant = req['messages'][1]['content']
    assert assistant[0] == {'type': 'text', 'text': 'Checking.'}
    assert assistant[1] == {'type': 'tool_use', 'id': 'c1', 'name': 'run_sql',
                            'input': {'sql': 'SELECT 1'}}
    results = req['messages'][2]['content']
    assert [r['tool_use_id'] for r in results] == ['c1', 'c2']
    assert all(r['type'] == 'tool_result' for r in results)


def test_build_request_omits_empty_tools():
    req = AnthropicProvider().build_request('m', 's', [{'role': 'user', 'content': 'x'}], [], 8)
    assert 'tools' not in req


def test_build_request_skips_empty_assistant():
    req = AnthropicProvider().build_request('m', 's', [
        {'role': 'user', 'content': 'x'},
        {'role': 'assistant', 'content': ''},
        {'role': 'user', 'content': 'y'}], [], 8)
    assert [m['role'] for m in req['messages']] == ['user', 'user']


def test_parse_response_text_and_tool_use():
    turn = AnthropicProvider().parse_response({
        'content': [{'type': 'text', 'text': 'Hello'},
                    {'type': 'tool_use', 'id': 't1', 'name': 'run_sql',
                     'input': {'sql': 'SELECT 2'}}],
        'usage': {'input_tokens': 11, 'output_tokens': 7}})
    assert turn.text == 'Hello'
    assert turn.tool_calls == (ToolCall('t1', 'run_sql', {'sql': 'SELECT 2'}),)
    assert (turn.usage.input_tokens, turn.usage.output_tokens) == (11, 7)


def test_parse_response_malformed():
    with pytest.raises(net.ProviderError):
        AnthropicProvider().parse_response({'content': [{'type': 'tool_use'}]})


def test_parse_response_huge_and_missing_usage():
    turn = AnthropicProvider().parse_response({
        'content': [{'type': 'text', 'text': 'x'}],
        'usage': {'input_tokens': 1e999, 'output_tokens': 4}})
    assert (turn.usage.input_tokens, turn.usage.output_tokens) == (0, 4)
    turn = AnthropicProvider().parse_response({'content': [{'type': 'text', 'text': 'x'}]})
    assert turn.usage == Usage()


def test_parse_response_missing_input_becomes_empty_dict():
    turn = AnthropicProvider().parse_response(
        {'content': [{'type': 'tool_use', 'id': 't', 'name': 'n'}]})
    assert turn.tool_calls == (ToolCall('t', 'n', {}),)


@pytest.mark.parametrize('block', [
    {'type': 'tool_use', 'id': 't', 'name': 'n', 'input': 'x'},
    {'type': 'tool_use', 'id': 't', 'name': 'n', 'input': [1]},
    {'type': 'tool_use', 'id': 5, 'name': 'n', 'input': {}},
    {'type': 'tool_use', 'id': 't', 'name': None, 'input': {}},
])
def test_parse_response_rejects_bad_tool_use(block):
    with pytest.raises(net.ProviderError):
        AnthropicProvider().parse_response({'content': [block]})


@pytest.mark.parametrize('data', HOSTILE)
def test_parse_response_hostile_only_provider_error(data):
    try:
        AnthropicProvider().parse_response(data)
    except net.ProviderError:
        pass


@pytest.mark.parametrize('value, expected', [
    (5, 5), (2.7, 2), (0, 0), (10 ** 12, 10 ** 12),
    (True, 0), ('5', 0), (None, 0), (-1, 0), (10 ** 13, 0),
    (float('inf'), 0), (1e999, 0), (float('nan'), 0),
])
def test_as_int(value, expected):
    assert as_int(value) == expected


@pytest.mark.parametrize('call_id, name, args', [
    (None, 'n', {}), ('', 'n', {}), (5, 'n', {}),
    ('i', None, {}), ('i', '', {}), ('i', 7, {}),
    ('i', 'n', 'x'), ('i', 'n', [1]), ('i', 'n', None),
])
def test_make_tool_call_rejects(call_id, name, args):
    with pytest.raises(net.ProviderError):
        make_tool_call(call_id, name, args)


def test_make_tool_call_accepts_with_meta():
    call = make_tool_call('i', 'n', {'a': 1}, {'thoughtSignature': 'S'})
    assert call == ToolCall('i', 'n', {'a': 1}, {'thoughtSignature': 'S'})


def test_complete_sends_key_in_header_and_secrets_for_redaction(monkeypatch):
    seen = {}

    def fake_post(url, headers, payload, **kw):
        seen.update(url=url, headers=headers, kw=kw)
        return {'content': [{'type': 'text', 'text': 'ok'}], 'usage': {}}

    monkeypatch.setattr(net, 'post_json', fake_post)
    turn = AnthropicProvider().complete(api_key='sk-ant-1', model='claude-x', system='s',
                                        messages=[{'role': 'user', 'content': 'hi'}], tools=[])
    assert turn.text == 'ok'
    assert seen['url'] == 'https://api.anthropic.com/v1/messages'
    assert seen['headers']['x-api-key'] == 'sk-ant-1'
    assert seen['headers']['anthropic-version'] == '2023-06-01'
    assert seen['kw']['secrets'] == ['sk-ant-1']
