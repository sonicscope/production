import json

import psycopg2
import pytest

from reports.ai import credentials, models, net, store


def test_parse_anthropic_and_openai_filter():
    assert models.parse_models('anthropic', {'data': [{'id': 'b-2'}, {'id': 'a-1'}, {'id': 'a-1'}]}) \
        == ['a-1', 'b-2']
    data = {'data': [{'id': i} for i in (
        'gpt-x', 'text-embedding-3', 'whisper-1', 'tts-1', 'gpt-image-1', 'o9-mini',
        'omni-moderation', 'gpt-x-realtime', 'bad id!')]}
    assert models.parse_models('openai', data) == ['gpt-x', 'o9-mini']


def test_parse_gemini_needs_generate_content():
    data = {'models': [
        {'name': 'models/g-pro', 'supportedGenerationMethods': ['generateContent']},
        {'name': 'models/embed', 'supportedGenerationMethods': ['embedContent']},
        {'name': 'models/x'}]}
    assert models.parse_models('gemini', data) == ['g-pro']


def test_parse_openrouter_needs_tools_and_slash():
    data = {'data': [
        {'id': 'a/tool', 'supported_parameters': ['tools', 'temperature']},
        {'id': 'a/notool', 'supported_parameters': ['temperature']},
        {'id': 'bare', 'supported_parameters': ['tools']},
        {'id': 'a/b/c', 'supported_parameters': ['tools']}]}
    assert models.parse_models('openrouter', data) == ['a/tool']


@pytest.mark.parametrize('bad', [{}, {'data': 'x'}, {'data': None}])
def test_parse_hostile_shapes(bad):
    with pytest.raises(net.ProviderError):
        models.parse_models('anthropic', bad)


def test_parse_caps_the_list():
    data = {'data': [{'id': f'm{i:04d}'} for i in range(models.MAX_MODELS + 50)]}
    assert len(models.parse_models('anthropic', data)) == models.MAX_MODELS


def test_list_models_headers_and_url(monkeypatch):
    seen = {}

    def fake_get(url, headers, **kw):
        seen.update(url=url, headers=headers, kw=kw)
        return {'data': [{'id': 'm1'}], 'models': []}

    monkeypatch.setattr(net, 'get_json', fake_get)
    assert models.list_models('openrouter', 'sk-or-1') == []   # no 'tools' support -> filtered
    assert seen['url'] == 'https://openrouter.ai/api/v1/models'
    assert seen['headers'] == {'Authorization': 'Bearer sk-or-1'}
    assert seen['kw']['secrets'] == ['sk-or-1']
    models.list_models('gemini', 'k')
    assert seen['headers'] == {'x-goog-api-key': 'k'}
    models.list_models('anthropic', 'k')
    assert seen['headers']['x-api-key'] == 'k'
    with pytest.raises(net.ProviderError):
        models.list_models('nope', 'k')


def _post(client, token, body):
    return client.post('/settings/ai/models', data=json.dumps(body),
                       headers={'X-CSRF-Token': token, 'Content-Type': 'application/json'})


def test_models_route_rules(client, app_module, login_as, csrf_of, tmp_path, monkeypatch,
                            seed_tenants):
    key_path = str(tmp_path / 'ai.key')
    credentials.generate_key_file(key_path)
    monkeypatch.setenv('AI_KEY_FILE', key_path)
    t, = seed_tenants('Acme')
    login_as('user', [t])
    assert _post(client, csrf_of(client), {'provider': 'openai'}).status_code == 404

    login_as('admin')
    token = csrf_of(client)
    assert client.post('/settings/ai/models', data='{}',
                       headers={'Content-Type': 'application/json'}).status_code == 400
    assert _post(client, token, {'provider': 'nope'}).status_code == 400
    r = _post(client, token, {'provider': 'openai'})           # nothing saved, nothing typed
    assert r.status_code == 400 and 'API key' in r.get_json()['error']

    calls = []
    monkeypatch.setattr(models, 'list_models', lambda p, k: calls.append((p, k)) or ['m-a'])
    r = _post(client, token, {'provider': 'openai', 'api_key': ' sk-typed-0001 '})
    assert r.status_code == 200 and r.get_json() == {'models': ['m-a']}
    assert calls == [('openai', 'sk-typed-0001')]

    with psycopg2.connect(**app_module.DB_CONFIG) as conn:
        uid = None
        store.save_settings(conn.cursor(), provider='openai', model='gpt-x',
                            api_key='sk-saved-7777', consent_user_id=uid or 1, key_path=key_path)
    calls.clear()
    assert _post(client, token, {'provider': 'openai'}).status_code == 200
    assert calls == [('openai', 'sk-saved-7777')]          # saved key reused, same provider
    r = _post(client, token, {'provider': 'gemini'})        # different provider: no reuse
    assert r.status_code == 400 and calls == [('openai', 'sk-saved-7777')]

    def boom(p, k):
        raise net.ProviderError('provider returned HTTP 401')
    monkeypatch.setattr(models, 'list_models', boom)
    r = _post(client, token, {'provider': 'openai', 'api_key': 'sk-bad-0000'})
    assert r.status_code == 502 and 'sk-bad' not in r.get_data(as_text=True)
