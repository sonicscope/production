"""Real WeasyPrint render smoke tests (guards dependency bumps)."""
from __future__ import annotations

import base64
import io
import os

import weasyprint
from PIL import Image


def _png_bytes() -> bytes:
    buf = io.BytesIO()
    Image.new('RGB', (40, 20), (55, 138, 221)).save(buf, 'PNG')
    return buf.getvalue()


def test_minimal_pdf_with_data_uri_image(tmp_path):
    b64 = base64.b64encode(_png_bytes()).decode()
    out = tmp_path / 'min.pdf'
    weasyprint.HTML(
        string=f'<h1>x</h1><img src="data:image/png;base64,{b64}">',
        base_url='file:///',
    ).write_pdf(str(out))
    data = out.read_bytes()
    assert data.startswith(b'%PDF')
    assert len(data) > 1000


def test_pdf_with_logo_file_path_as_generator_does(tmp_path):
    """Same mechanism as generator.py: file:// logo path embedded via base_url='file:///'."""
    logo = tmp_path / 'msp_1.png'
    logo.write_bytes(_png_bytes())
    out = tmp_path / 'logo.pdf'
    weasyprint.HTML(
        string=f'<h1>Report</h1><img src="file://{logo}" style="height:30px">',
        base_url='file:///',
    ).write_pdf(str(out))
    data = out.read_bytes()
    assert data.startswith(b'%PDF')
    assert len(data) > 1000
    assert os.path.getsize(out) == len(data)
