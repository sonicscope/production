-- 012_ai_openrouter.sql — allow OpenRouter as an AI provider. Additive and idempotent.
ALTER TABLE ai_settings DROP CONSTRAINT IF EXISTS ai_settings_provider_check;
ALTER TABLE ai_settings ADD CONSTRAINT ai_settings_provider_check
    CHECK (provider IN ('anthropic', 'openai', 'gemini', 'openrouter'));
