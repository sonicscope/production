-- 011_ai_investigations.sql — AI Investigate Stage 2 (saved investigations, findings)
-- Additive and idempotent. All tables are owned by the migration role (sonicscope);
-- the AI read-only role ss_ai_ro must never read them.

CREATE TABLE IF NOT EXISTS ai_investigations (
    id             serial PRIMARY KEY,
    tenant_id      integer NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    -- NULL = orphaned (owner account deleted): owned collectively by global admins.
    owner_user_id  integer REFERENCES ui_users(id) ON DELETE SET NULL,
    title          text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
    shared         boolean NOT NULL DEFAULT false,
    created_at     timestamptz NOT NULL DEFAULT now(),
    updated_at     timestamptz NOT NULL DEFAULT now(),
    last_rerun_at  timestamptz
);
CREATE INDEX IF NOT EXISTS ai_inv_owner_idx  ON ai_investigations (owner_user_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS ai_inv_tenant_idx ON ai_investigations (tenant_id, shared, updated_at DESC);

CREATE TABLE IF NOT EXISTS ai_messages (
    id               bigserial PRIMARY KEY,
    investigation_id integer NOT NULL REFERENCES ai_investigations(id) ON DELETE CASCADE,
    seq              integer NOT NULL,
    role             text NOT NULL CHECK (role IN ('user', 'assistant')),
    content          text NOT NULL,
    created_at       timestamptz NOT NULL DEFAULT now(),
    UNIQUE (investigation_id, seq)
);

CREATE TABLE IF NOT EXISTS ai_query_results (
    id               bigserial PRIMARY KEY,
    investigation_id integer NOT NULL REFERENCES ai_investigations(id) ON DELETE CASCADE,
    message_id       bigint  NOT NULL REFERENCES ai_messages(id) ON DELETE CASCADE,
    ordinal          integer NOT NULL,
    sql_text         text NOT NULL,
    columns          jsonb NOT NULL,
    rows_snapshot    jsonb NOT NULL,
    row_count        integer NOT NULL,
    truncated        boolean NOT NULL DEFAULT false,
    snapshot_at      timestamptz NOT NULL DEFAULT now(),
    duration_ms      integer
);
CREATE INDEX IF NOT EXISTS ai_qr_inv_idx ON ai_query_results (investigation_id, message_id, ordinal);

CREATE INDEX IF NOT EXISTS ai_qr_msg_idx ON ai_query_results (message_id);

CREATE TABLE IF NOT EXISTS ai_findings (
    id               serial PRIMARY KEY,
    investigation_id integer NOT NULL REFERENCES ai_investigations(id) ON DELETE CASCADE,
    tenant_id        integer NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    created_by       integer REFERENCES ui_users(id) ON DELETE SET NULL,
    title            text NOT NULL CHECK (char_length(title) BETWEEN 1 AND 200),
    note             text NOT NULL DEFAULT '' CHECK (char_length(note) <= 4000),
    evidence_kind    text NOT NULL CHECK (evidence_kind IN ('query', 'timeline')),
    evidence         jsonb NOT NULL,
    pinned_at        timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    report_id        integer          -- Stage 3 links a finding to generated_reports.id (no FK yet)
);
CREATE INDEX IF NOT EXISTS ai_findings_inv_idx ON ai_findings (investigation_id, pinned_at);

ALTER TABLE ai_settings ADD COLUMN IF NOT EXISTS export_max_rows integer NOT NULL DEFAULT 5000
    CHECK (export_max_rows BETWEEN 100 AND 50000);
ALTER TABLE ai_settings ADD COLUMN IF NOT EXISTS retention_days integer NOT NULL DEFAULT 90
    CHECK (retention_days BETWEEN 7 AND 365);

COMMENT ON COLUMN ai_audit.kind IS
  'chat_start | chat | query | settings | test | save | rename | delete | share | rerun | refresh | export | pin | timeline | finding_edit | finding_delete | purge | orphan';

-- ss_ai_ro must have no access to saved investigations (defence in depth: it has no grant
-- today, this makes sure a future blanket grant or PUBLIC default cannot expose them).
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ss_ai_ro') THEN
        REVOKE ALL ON ai_investigations, ai_messages, ai_query_results, ai_findings FROM ss_ai_ro;
        REVOKE ALL ON ai_investigations, ai_messages, ai_query_results, ai_findings FROM PUBLIC;
    END IF;
END
$$;
