"""
SonicScope Report Scheduler — standalone service
================================================
Runs the report-schedule APScheduler in its **own process**
(systemd unit ``ss-scheduler.service``), decoupled from the gunicorn web
workers.

Why it is separate: the scheduler used to start once per gunicorn worker at
import time, which forced ``ss-reports`` to run with ``--workers 1`` — a
second worker would fire every scheduled report a second time. With the
scheduler in its own single process, the web tier can scale to multiple
workers freely and there is exactly one scheduler.

How schedule edits propagate: there is **no cross-process signalling**. The
web UI writes schedule changes to ``report_schedules``; this service
re-reads that table every ``SCHEDULE_RELOAD_INTERVAL_SEC`` (default 30s) and
rebuilds its jobs. The database is the single source of truth. A new or
edited schedule therefore becomes active within one poll interval.

Run (production):  ${INSTALL_DIR}/venv/bin/python reports/scheduler_service.py
Run (local/dev):   python3 reports/scheduler_service.py
"""
from __future__ import annotations

import logging
import signal
import sys
import threading
from pathlib import Path

# Resolve imports relative to the ss-multivendor project root (…/reports/..).
_PROJECT_ROOT = str(Path(__file__).resolve().parent.parent)
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

from reports.runtime_config import (  # noqa: E402
    DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR, SCHEDULE_RELOAD_INTERVAL_SEC,
)
from reports.scheduler import (  # noqa: E402
    start_scheduler, reload_schedules, stop_scheduler,
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
)
log = logging.getLogger('ss.reports.scheduler_service')

# Job id for the periodic DB-poll reload. Deliberately NOT prefixed
# 'schedule_' so reload_schedules() (which removes every 'schedule_*' job)
# never removes its own trigger.
_RELOAD_JOB_ID = '__schedule_reload__'


def install_reload_job(scheduler, interval_sec: int = SCHEDULE_RELOAD_INTERVAL_SEC):
    """Add the periodic DB-poll reload job to `scheduler` and return it.

    Kept separate from main() so it can be unit-tested. The job id is
    deliberately not 'schedule_'-prefixed so reload_schedules() (which removes
    every 'schedule_*' job) never removes this trigger.
    """
    return scheduler.add_job(
        reload_schedules,
        trigger='interval',
        seconds=interval_sec,
        args=[scheduler, DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR],
        id=_RELOAD_JOB_ID,
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )


def main() -> int:
    stop_event = threading.Event()

    def _handle_signal(signum, _frame):
        log.info('Received signal %s — shutting down scheduler service', signum)
        stop_event.set()

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    try:
        scheduler = start_scheduler(DB_CONFIG, SMTP_CONFIG, OUTPUT_DIR)
    except Exception:
        log.exception(
            'Scheduler failed to start — is the database reachable? '
            'The service will exit non-zero so systemd restarts it.'
        )
        return 1

    # Poll the DB for schedule changes so the web UI never has to signal us.
    install_reload_job(scheduler)
    log.info(
        'Scheduler service running — re-reading schedules every %ds',
        SCHEDULE_RELOAD_INTERVAL_SEC,
    )

    stop_event.wait()  # block the main thread until SIGTERM/SIGINT

    try:
        stop_scheduler(scheduler)
    except Exception:
        log.exception('Error during scheduler shutdown')
    return 0


if __name__ == '__main__':
    sys.exit(main())
