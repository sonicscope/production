#!/bin/bash
# =============================================================================
# SonicScope Multi-Vendor — Backup
# =============================================================================
# Backs up the small, IRREPLACEABLE parts of a deployment:
#   - Config/identity/report-metadata table DATA (tenants, ui_users,
#     ui_user_tenants, ui_login_codes, sensors, msp_profiles, report
#     schedules, identity_users, identity_devices, identity_mappings,
#     tenant_subnets, generated_reports metadata, schema_migrations) —
#     captured as "everything except fw_events + TimescaleDB internal
#     catalog/config data", no hand-maintained table list needed.
#   - /etc/ss-multivendor/collector.env (licence, DB/SMTP creds — secrets)
#   - /var/lib/ss-multivendor/logos/ (uploaded MSP logos)
#
# Deliberately NOT backed up (see docs/handover.md "Backup & Disaster
# Recovery" for the full DR runbook):
#   - fw_events flow history (80 GB+, high-volume time-series). Recover via
#     ZFS snapshot of the PG data dir or pg_basebackup + WAL archiving.
#   - Generated PDF reports (derived, regeneratable while data exists).
#   - GeoIP databases (regeneratable via download-geoip.sh).
#
# Run as root (systemd ss-backup.service does this daily at 02:30):
#   sudo bash scripts/backup.sh
#
# Config: BACKUP_DIR / BACKUP_KEEP are read from the environment (systemd's
# EnvironmentFile=/etc/ss-multivendor/collector.env populates them); sane
# defaults are baked in below when unset (e.g. manual run before those keys
# exist in collector.env).
#
# Fail-loud: any error aborts with a non-zero exit and a clear message —
# under systemd this surfaces in `journalctl -u ss-backup`. No silent
# failures, and no partial/half-written tarball is ever left in BACKUP_DIR.
# =============================================================================
set -euo pipefail

# ── Config (env-overridable; SS_* vars exist so tests can point at scratch
#    paths/DBs without touching /etc, /opt or the real 'sonicscope' DB) ──────
CONFIG_FILE="${SS_CONFIG_FILE:-/etc/ss-multivendor/collector.env}"
LOGO_DIR="${SS_LOGO_DIR:-/var/lib/ss-multivendor/logos}"
INSTALL_DIR="${SS_INSTALL_DIR:-/opt/ss-multivendor}"
PG_DB="${SS_PG_DB:-sonicscope}"

# Spec defaults — baked in here so a manual run before install.sh/
# install-reports.sh have written these keys into collector.env still works.
BACKUP_DIR="${BACKUP_DIR:-/var/backups/ss-multivendor}"
BACKUP_KEEP="${BACKUP_KEEP:-14}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

# Never let a stray BACKUP_KEEP make prune_backups misbehave. Must be >= 1:
# BACKUP_KEEP=0 would prune EVERY tarball including the one just written,
# leaving zero backups — never a sane retention policy, reject it loudly.
[[ "$BACKUP_KEEP" =~ ^[0-9]+$ ]] || error "BACKUP_KEEP must be a positive integer, got: '$BACKUP_KEEP'"
(( BACKUP_KEEP >= 1 )) || error "BACKUP_KEEP must be >= 1 (got '$BACKUP_KEEP') — 0 would delete every backup, including the one just written"

# ── prune_backups — keep the newest $BACKUP_KEEP tarballs, delete older ─────
# Filenames embed a sortable UTC timestamp (ss-multivendor-backup-<UTC>.tar.gz)
# so a plain lexical sort is a correct chronological sort.
prune_backups() {
    local files=() total remove_count i
    while IFS= read -r -d '' f; do
        files+=("$f")
    done < <(find "$BACKUP_DIR" -maxdepth 1 -type f -name 'ss-multivendor-backup-*.tar.gz' -print0 2>/dev/null | sort -z)

    total=${#files[@]}
    if (( total > BACKUP_KEEP )); then
        remove_count=$(( total - BACKUP_KEEP ))
        for (( i=0; i<remove_count; i++ )); do
            info "Pruning old backup: ${files[$i]}"
            rm -f -- "${files[$i]}"
        done
    fi
    info "Retention: $(( total > BACKUP_KEEP ? BACKUP_KEEP : total )) backup(s) kept (BACKUP_KEEP=$BACKUP_KEEP, had $total)"
}

# ── run_backup — the entire backup: dump, stage, tar, retention ────────────
run_backup() {
    section "SonicScope backup starting (DB '$PG_DB' -> $BACKUP_DIR)"

    mkdir -p "$BACKUP_DIR"
    [ -r "$CONFIG_FILE" ] || error "Config file not found or not readable: $CONFIG_FILE"

    local ts stage tarball
    ts=$(date -u +%Y%m%dT%H%M%SZ)
    stage=$(mktemp -d /tmp/ss_backup_stage_XXXXXX)
    tarball="$BACKUP_DIR/ss-multivendor-backup-${ts}.tar.gz"

    # DB dump: config/identity/report-metadata DATA only. --data-only avoids
    # the TimescaleDB schema-restore dance entirely — restore always targets
    # an already-installed schema (install.sh must have run first).
    #
    # TimescaleDB's own catalog/config data (hypertable, dimension,
    # continuous_agg, bgw_job, compression_settings, metadata, ...) is
    # registered via pg_extension_config_dump and so --data-only pulls it in
    # by default even though it lives OUTSIDE fw_events. It is split across
    # FOUR internal schemas, not just _timescaledb_internal — confirmed by
    # querying pg_depend/pg_extension on a real install (see
    # scripts/tests/test_backup_restore.sh step 2). Every one of them must be
    # excluded or pg_restore collides with the TARGET database's own
    # already-installed TimescaleDB catalog rows (verified: restoring without
    # this produces duplicate-key errors on hypertable/continuous_agg/
    # bgw_job/compression_settings/dimension/metadata).
    # schema_migrations (the migration ledger) is also excluded: it is NOT
    # config to preserve — the restore TARGET's own ledger already reflects the
    # schema install.sh/update.sh built there, and it's seeded by install.sh
    # (one PK row per migration file). Restoring an old ledger over it is both
    # wrong AND would collide on its filename PK.
    info "Dumping config-only data from '$PG_DB' (excluding fw_events + ledger + TimescaleDB internals)..."
    if ! sudo -u postgres pg_dump -Fc --data-only \
            --exclude-table='fw_events' \
            --exclude-table='schema_migrations' \
            --exclude-schema='_timescaledb_internal' \
            --exclude-schema='_timescaledb_catalog' \
            --exclude-schema='_timescaledb_config' \
            --exclude-schema='_timescaledb_cache' \
            "$PG_DB" > "$stage/db-config.dump"; then
        rm -rf "$stage"
        error "pg_dump failed — aborting backup, no tarball written"
    fi
    [ -s "$stage/db-config.dump" ] || { rm -rf "$stage"; error "pg_dump produced an empty dump file — aborting"; }

    cp "$CONFIG_FILE" "$stage/collector.env"

    if [ -d "$LOGO_DIR" ]; then
        cp -r "$LOGO_DIR" "$stage/logos"
    else
        warn "Logo directory $LOGO_DIR not found — backing up an empty logos/"
        mkdir -p "$stage/logos"
    fi

    # MANIFEST — lets restore.sh (and a human) sanity-check tarball contents
    # before trusting it.
    {
        echo "SonicScope ss-multivendor backup"
        echo "created_at: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "hostname: $(hostname -f 2>/dev/null || hostname)"
        echo "app_version: $(cat "$INSTALL_DIR/VERSION" 2>/dev/null || echo unknown)"
        echo "pg_db: $PG_DB"
        echo "contents:"
        echo "  - db-config.dump  (pg_dump -Fc --data-only; excludes fw_events + schema_migrations + TimescaleDB internals)"
        echo "  - collector.env   (secrets: DB/SMTP credentials, licence)"
        echo "  - logos/          (uploaded MSP logos)"
        echo "excludes:"
        echo "  - fw_events flow history       — see docs/handover.md DR runbook (ZFS snapshot / pg_basebackup+WAL)"
        echo "  - generated PDF reports        — derived, regeneratable"
        echo "  - GeoIP databases              — regeneratable via download-geoip.sh"
    } > "$stage/MANIFEST"

    info "Writing tarball: $tarball"
    tar -czf "$tarball" -C "$stage" . || { rm -rf "$stage"; rm -f "$tarball"; error "Failed to create backup tarball"; }
    chmod 600 "$tarball"   # contains secrets — root-only

    rm -rf "$stage"

    info "Backup written: $tarball ($(du -h "$tarball" 2>/dev/null | cut -f1))"

    prune_backups

    section "Backup complete"
}

# ── Entrypoint (skipped when this file is sourced for tests — the test only
#    extracts and sources run_backup/prune_backups) ─────────────────────────
[ "$(id -u)" -ne 0 ] && error "Must be run as root: sudo bash scripts/backup.sh (needs sudo -u postgres and read access to $CONFIG_FILE)"
run_backup
