#!/bin/bash
# =============================================================================
# SonicScope Multi-Vendor — Restore
# =============================================================================
# Restores a backup tarball produced by scripts/backup.sh:
#   - Config/identity/report-metadata table DATA (pg_restore --data-only)
#   - /etc/ss-multivendor/collector.env (existing file backed up first)
#   - /var/lib/ss-multivendor/logos/
#
# Does NOT restore fw_events flow history — that is out of scope for the
# logical backup by design. See docs/handover.md "Backup & Disaster Recovery"
# for the ZFS-snapshot / pg_basebackup+WAL flow-data DR options.
#
# Usage:
#   sudo bash scripts/restore.sh <backup-tarball>
#
# Preconditions (checked before anything is touched):
#   - A fresh SonicScope install already exists — install.sh (and, for full
#     restores, install-reports.sh) must have been run so the DB schema and
#     $INSTALL_DIR are present. restore.sh only restores DATA into an
#     already-installed schema; it never creates one.
#
# Interactive confirmation is required (type "restore") because this
# OVERWRITES current config-table data and collector.env.
# =============================================================================
set -euo pipefail

# ── Config (env-overridable; SS_* vars let tests point at scratch paths/DBs
#    instead of the real /etc, /opt, /var/lib and 'sonicscope' DB) ──────────
CONFIG_FILE="${SS_CONFIG_FILE:-/etc/ss-multivendor/collector.env}"
DATA_DIR="${SS_DATA_DIR:-/var/lib/ss-multivendor}"
LOGO_DIR="${SS_LOGO_DIR:-${DATA_DIR}/logos}"
INSTALL_DIR="${SS_INSTALL_DIR:-/opt/ss-multivendor}"
PG_DB="${SS_PG_DB:-sonicscope}"
SERVICE_USER="${SS_SERVICE_USER:-ss-collector}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

# ── check_preconditions — a fresh install must already exist ───────────────
check_preconditions() {
    local tarball="$1"

    [ -n "$tarball" ] || error "Usage: sudo bash scripts/restore.sh <backup-tarball>"
    [ -f "$tarball" ] || error "Backup tarball not found: $tarball"
    [ -r "$tarball" ] || error "Backup tarball not readable: $tarball"

    [ -d "$INSTALL_DIR" ] || error "$INSTALL_DIR not found — run install.sh first, then retry restore"

    local schema_present
    schema_present=$(sudo -u postgres psql -d "$PG_DB" -tAc \
        "SELECT to_regclass('public.tenants') IS NOT NULL;" 2>/dev/null || echo f)
    [ "$schema_present" = "t" ] || \
        error "DB '$PG_DB' has no 'tenants' table — schema not present. Run install.sh (schema install) before restoring."
}

# ── do_restore — confirm, extract, pg_restore, restore config + logos ──────
do_restore() {
    local tarball="$1" stage confirm bak

    check_preconditions "$tarball"

    echo
    warn "This will OVERWRITE config-table data in DB '$PG_DB' and $CONFIG_FILE."
    warn "fw_events flow history is NOT part of this backup and is left untouched."
    echo -n "Type 'restore' to continue: "
    read -r confirm
    [ "$confirm" = "restore" ] || error "Confirmation not received — aborted, nothing was changed"

    stage=$(mktemp -d /tmp/ss_restore_stage_XXXXXX)
    info "Extracting $tarball..."
    tar -xzf "$tarball" -C "$stage" || { rm -rf "$stage"; error "Failed to extract tarball — corrupt or invalid backup file"; }

    # The postgres OS user needs to read db-config.dump (it runs pg_restore),
    # but the staging dir also holds the extracted collector.env (licence +
    # DB/SMTP secrets), and the dump itself carries ui_users PASSWORD HASHES.
    # So do NOT make anything world-readable in /tmp: make ONLY the dir
    # traversable, and hand the dump to the postgres user as an owner-only 600
    # file (not a+r) so no other local user can read the hashes mid-restore.
    # collector.env keeps its restrictive extracted mode. (mktemp -d created
    # $stage 0700.)
    chmod a+x "$stage"
    if chown postgres "$stage/db-config.dump" 2>/dev/null; then
        chmod 600 "$stage/db-config.dump"          # prod (root): postgres-only
    else
        # Non-root fallback — only reachable from the test harness, which
        # sources do_restore() directly and bypasses the root guard above.
        # Real restores always run as root (enforced at the top of this
        # script), so production never hits this world-readable path.
        chmod a+r "$stage/db-config.dump" 2>/dev/null || true
    fi

    [ -f "$stage/db-config.dump" ] || { rm -rf "$stage"; error "Tarball missing db-config.dump — not a valid ss-multivendor backup"; }
    if [ -f "$stage/MANIFEST" ]; then
        info "MANIFEST:"
        sed 's/^/    /' "$stage/MANIFEST"
    else
        warn "Tarball missing MANIFEST — proceeding anyway"
    fi

    # A fresh install.sh SEEDS the config tables (id=1 rows in tenants/
    # msp_profiles/sensors, and the default MSP). pg_restore --data-only only
    # suppresses FK triggers with --disable-triggers — PK/UNIQUE constraints
    # STILL fire, so a straight restore would collide on those seed rows and
    # reject each colliding table's COPY wholesale (the customer's real data
    # would silently NOT be restored, and pg_restore would exit non-zero).
    #
    # So empty exactly the tables the dump will load, first. The table list is
    # derived FROM THE DUMP (pg_restore -l -> "TABLE DATA" entries) rather than
    # hardcoded, so it stays correct as config tables are added/removed.
    # RESTART IDENTITY resets their sequences (the dump's setval()s then set
    # them correctly); CASCADE keeps FK-referencing config tables consistent.
    # fw_events has no real FK to these tables (tenant_id/sensor_id are plain
    # columns), so CASCADE never touches flow history.
    local trunc_list=() pair sch tbl trunc_sql=""
    while IFS= read -r pair; do
        [ -n "$pair" ] && trunc_list+=("$pair")
    done < <(pg_restore -l "$stage/db-config.dump" 2>/dev/null \
        | awk '/ TABLE DATA /{for(i=1;i<=NF;i++) if($i=="TABLE" && $(i+1)=="DATA"){print $(i+2)"|"$(i+3); break}}')

    local truncate_stmt=""
    if (( ${#trunc_list[@]} > 0 )); then
        for pair in "${trunc_list[@]}"; do
            sch="${pair%%|*}"; tbl="${pair##*|}"
            trunc_sql+="\"${sch}\".\"${tbl}\", "
        done
        trunc_sql="${trunc_sql%, }"
        truncate_stmt="TRUNCATE TABLE ${trunc_sql} RESTART IDENTITY CASCADE;"
    else
        warn "Dump lists no config tables to restore — proceeding (nothing to load?)"
    fi

    # Restore atomically: the TRUNCATE (which removes install.sh's seed rows)
    # and the pg_restore data load run as ONE transaction. pg_restore writes the
    # data-load SQL to stdout (-f -) instead of applying it itself, so it shares
    # the single psql transaction with the TRUNCATE. If anything fails, psql
    # (ON_ERROR_STOP + --single-transaction) rolls the whole thing back — a
    # mid-restore error can therefore never leave the config tables
    # truncated-but-empty; the DB stays exactly as it was before. (An empty
    # truncate_stmt just prints a harmless blank line.)
    info "Restoring config data into '$PG_DB' (atomic TRUNCATE + pg_restore, single transaction)..."
    if ! { printf '%s\n' "$truncate_stmt"; \
           sudo -u postgres pg_restore --data-only --disable-triggers -f - "$stage/db-config.dump"; } \
         | sudo -u postgres psql -d "$PG_DB" -v ON_ERROR_STOP=1 --single-transaction -q; then
        rm -rf "$stage"
        error "Restore failed and rolled back — config in DB '$PG_DB' is unchanged. Inspect the error above and retry."
    fi

    if [ -f "$stage/collector.env" ]; then
        if [ -f "$CONFIG_FILE" ]; then
            bak="${CONFIG_FILE}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
            cp "$CONFIG_FILE" "$bak"
            info "Existing $CONFIG_FILE backed up to $bak"
        fi
        cp "$stage/collector.env" "$CONFIG_FILE"
        chmod 660 "$CONFIG_FILE"
        chown "root:${SERVICE_USER}" "$CONFIG_FILE" 2>/dev/null || warn "Could not chown $CONFIG_FILE to root:${SERVICE_USER} (user may not exist here)"
        info "Restored $CONFIG_FILE"
    else
        warn "Tarball has no collector.env — config file not restored"
    fi

    if [ -d "$stage/logos" ]; then
        mkdir -p "$LOGO_DIR"
        cp -r "$stage/logos/." "$LOGO_DIR/"
        chown -R "${SERVICE_USER}:${SERVICE_USER}" "$LOGO_DIR" 2>/dev/null || warn "Could not chown $LOGO_DIR to ${SERVICE_USER} (user may not exist here)"
        info "Restored logos to $LOGO_DIR"
    fi

    rm -rf "$stage"

    info "Restarting services..."
    systemctl restart ss-collector 2>/dev/null && info "ss-collector restarted" || warn "Could not restart ss-collector — restart it manually"
    systemctl restart ss-reports   2>/dev/null && info "ss-reports restarted"   || warn "Could not restart ss-reports — restart it manually"

    section "Restore complete"
    echo "Next steps:"
    echo "  - Log in to the Reports UI and confirm tenants/users/sensors are present"
    echo "  - Firewalls reconnect automatically (sensors/allowlist data was restored)"
    echo "  - fw_events flow history was NOT restored — see docs/handover.md"
    echo "    'Backup & Disaster Recovery' for flow-data DR options"
}

# ── Entrypoint (skipped when this file is sourced for tests — the test only
#    extracts and sources check_preconditions/do_restore) ──────────────────
[ "$(id -u)" -ne 0 ] && error "Must be run as root: sudo bash scripts/restore.sh <backup-tarball>"
[ $# -eq 1 ] || error "Usage: sudo bash scripts/restore.sh <backup-tarball>"
do_restore "$1"
