#!/bin/bash
# SonicScope Multi-Vendor Collector — Installer
# Tested on Ubuntu 22.04 / 24.04 / 26.04+ LTS and Debian 13 (trixie)
# Run as root: sudo bash install.sh

set -euo pipefail

INSTALL_DIR="/opt/ss-multivendor"
CONFIG_DIR="/etc/ss-multivendor"
LOG_DIR="/var/log/ss-multivendor"
GEOIP_DIR="/opt/ss-multivendor/geoip"
SERVICE_USER="ss-collector"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
ok()      { echo -e "${GREEN}[OK]${NC}   $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

[ "$(id -u)" -ne 0 ] && error "Must be run as root"

# ── Detect existing SonicScope installs ──────────────────────────────────────
section "Checking existing SonicScope installations"

HAS_FLOW=false; HAS_SYSLOG=false
systemctl is-active --quiet swfr-collector 2>/dev/null   && HAS_FLOW=true
systemctl is-active --quiet syslog-receiver 2>/dev/null  && HAS_SYSLOG=true

if $HAS_FLOW;   then info "SS-FLOW collector detected — will share TimescaleDB"; fi
if $HAS_SYSLOG; then info "SS-SYSLOG receiver detected — will coexist on different ports"; fi

# ── System packages ──────────────────────────────────────────────────────────
section "Installing system packages"

# Harden apt against flaky/slow mirrors. A single failed .deb download (e.g. a
# sluggish regional mirror) otherwise aborts the entire deploy. This persistent
# drop-in makes apt retry transient fetch failures and cap per-request timeouts,
# and covers every later apt call in the deploy (install-reports.sh, grafana,
# certbot) too — not just this script.
mkdir -p /etc/apt/apt.conf.d
cat > /etc/apt/apt.conf.d/80-sonicscope-resilience <<'APTEOF'
Acquire::Retries "3";
Acquire::http::Timeout "30";
Acquire::https::Timeout "30";
APTEOF

# Normalise slow regional Ubuntu mirrors (e.g. za.archive.ubuntu.com — seen
# crawling at ~36 KB/s and taking 1h+ on a deploy) to the geo-balanced
# archive.ubuntu.com. Only rewrites the <cc>.archive.ubuntu.com regional
# hostnames; a custom/local mirror on any other hostname is left untouched.
# Covers both the 24.04-style sources.list and the 26.04 deb822 ubuntu.sources.
for _src in /etc/apt/sources.list /etc/apt/sources.list.d/ubuntu.sources; do
    [ -f "$_src" ] && sed -i -E 's#([a-z]{2})\.archive\.ubuntu\.com#archive.ubuntu.com#g' "$_src"
done

apt-get update -qq
apt-get install -y -qq \
    python3 python3-pip python3-venv \
    postgresql-common apt-transport-https \
    openssl curl wget gnupg lsb-release

# Distro family: Timescale's apt repo path differs (ubuntu/ vs debian/).
OS_ID=$(grep -E '^ID=' /etc/os-release | cut -d= -f2 | tr -d '"')
case "$OS_ID" in
    ubuntu|debian) ;;
    *) echo "[ERROR] Unsupported OS '$OS_ID' (need Ubuntu or Debian)"; exit 1 ;;
esac

# TimescaleDB packages are built against PGDG PostgreSQL, not Ubuntu's repo.
# Installing Ubuntu's postgresql causes "held broken packages" when TimescaleDB
# tries to install. Always use PGDG so the versions match on all Ubuntu releases.
info "Setting up PGDG PostgreSQL repo..."
/usr/share/postgresql-common/pgdg/apt.postgresql.org.sh -y

apt-get install -y -qq postgresql

# ── Detect installed PostgreSQL version ──────────────────────────────────────
# Use dpkg — reliable immediately after apt install, no PATH or cluster-init
# race conditions. Picks the highest installed major version.
PG_VER=$(dpkg -l 'postgresql-[0-9]*' 2>/dev/null \
    | awk '/^ii/{print $2}' \
    | grep -oP '(?<=postgresql-)\d+' \
    | sort -rn | head -1) || true   # empty is handled below; don't let pipefail abort
[[ -n "$PG_VER" ]] || { echo "[ERROR] Could not detect installed PostgreSQL version"; exit 1; }
info "PostgreSQL version: ${PG_VER}"

# ── TimescaleDB (matching the installed PostgreSQL version) ───────────────────
section "Checking TimescaleDB"
if ! psql -U postgres -c "SELECT default_version FROM pg_available_extensions WHERE name='timescaledb'" 2>/dev/null | grep -q "[0-9]"; then
    info "Installing TimescaleDB for PostgreSQL ${PG_VER}..."

    # Use the actual OS codename so packages are built for this release.
    TSB_CODENAME=$(lsb_release -cs)
    # Fetch the signing key with a timeout + retries — a bare `wget -qO-` has NO
    # timeout, so an intermittent stall to packagecloud.io hangs the deploy
    # forever (observed). Fetch to a file, retry, and fail loud on give-up.
    if ! wget -q --timeout=30 --tries=3 -O /tmp/timescaledb.gpgkey \
            https://packagecloud.io/timescale/timescaledb/gpgkey; then
        echo "[ERROR] Could not fetch the TimescaleDB signing key from packagecloud.io"
        echo "[ERROR] after 3 tries. Check outbound connectivity/DNS to packagecloud.io"
        echo "[ERROR] from this host (curl -sSI --max-time 15 https://packagecloud.io)."
        exit 1
    fi
    gpg --dearmor -o /etc/apt/trusted.gpg.d/timescaledb.gpg < /tmp/timescaledb.gpgkey
    rm -f /tmp/timescaledb.gpgkey
    echo "deb https://packagecloud.io/timescale/timescaledb/${OS_ID}/ ${TSB_CODENAME} main" \
        > /etc/apt/sources.list.d/timescaledb.list
    apt-get update -qq
    apt-get install -y -qq "timescaledb-2-postgresql-${PG_VER}"

    # timescaledb-tune sets shared_preload_libraries and tunes memory settings.
    timescaledb-tune --quiet --yes

    # Restart Postgres so timescaledb loads via shared_preload_libraries. Wrap in
    # `timeout`: Ubuntu's postgresql@.service is Type=notify with effectively no
    # start timeout, so if Postgres can't reach "ready" (bad preload / stuck
    # startup) a plain `systemctl restart` hangs FOREVER — observed as a silent
    # 1h+ stall on step 3. Fail loud in ~2 min and print the Postgres log so the
    # actual cause is visible instead of a mystery hang.
    if ! timeout 120 systemctl restart "postgresql@${PG_VER}-main" 2>/dev/null \
       && ! timeout 120 systemctl restart postgresql 2>/dev/null; then
        echo "[ERROR] PostgreSQL did not restart within 120s after enabling TimescaleDB"
        echo "[ERROR] (shared_preload_libraries='timescaledb'). Last 40 log lines:"
        tail -n 40 "/var/log/postgresql/postgresql-${PG_VER}-main.log" 2>/dev/null \
            || journalctl -u "postgresql@${PG_VER}-main" -n 40 --no-pager 2>/dev/null || true
        exit 1
    fi
    info "TimescaleDB installed"
fi

# ── Create DB user and database ──────────────────────────────────────────────
section "Setting up PostgreSQL database"
DB_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=')

if sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='sonicscope'" | grep -q 1; then
    sudo -u postgres psql -c "ALTER USER sonicscope WITH PASSWORD '$DB_PASSWORD';" >/dev/null
    info "DB user 'sonicscope' exists — password synced to collector.env"
else
    sudo -u postgres psql -c "CREATE USER sonicscope WITH PASSWORD '$DB_PASSWORD';" >/dev/null
    info "DB user 'sonicscope' created"
fi

sudo -u postgres psql -tc \
    "SELECT 1 FROM pg_database WHERE datname='sonicscope'" | grep -q 1 || \
    sudo -u postgres psql -c \
    "CREATE DATABASE sonicscope OWNER sonicscope;"

# apply_schema_file — apply one SQL file to the sonicscope DB, fail-loud.
#
# The postgres OS user cannot read files under /home/<user>/... (0750 home
# dir), so each file is copied to a world-readable /tmp path first.
#
# ON_ERROR_STOP=1 makes a genuine SQL error a HARD failure that aborts the
# install: bare `psql -f` exits 0 even on a SQL error, so plain `set -e` would
# happily "succeed" with a half-built schema. Plain-DDL files run inside
# --single-transaction so a mid-file error rolls back cleanly; TimescaleDB
# continuous-aggregate files (aggregates.sql) CANNOT run inside a transaction
# block, so they are applied without it (still with ON_ERROR_STOP=1).
#
# Every successfully-applied file is recorded in the schema_migrations ledger
# so scripts/update.sh treats a fresh install as already-migrated and its first
# run is a clean no-op instead of blindly re-applying everything.
apply_schema_file() {
    local label="$1" src="$2" base
    base=$(basename "$src")
    local tmp
    tmp=$(mktemp /tmp/ss_install_XXXXXX.sql)
    cp "$src" "$tmp"
    chmod 644 "$tmp"

    # Strip `--` line comments before matching so a plain-DDL file that only
    # MENTIONS these tokens in a comment isn't wrongly run without a transaction.
    local txn=(--single-transaction)
    if sed 's/--.*//' "$tmp" | grep -qiE 'timescaledb\.continuous|refresh_continuous_aggregate'; then
        txn=()   # cannot run inside a transaction block
    fi

    info "$label"
    if sudo -u postgres psql -d sonicscope -v ON_ERROR_STOP=1 "${txn[@]}" -q -f "$tmp"; then
        sudo -u postgres psql -d sonicscope -q -c \
            "INSERT INTO schema_migrations(filename) VALUES('$base') ON CONFLICT DO NOTHING" >/dev/null
        rm -f "$tmp"   # remove on success
    else
        rm -f "$tmp"   # ...and on failure — never leak /tmp/ss_install_*.sql
        error "$label FAILED — schema error, install aborted. Fix the SQL error above and re-run install.sh."
    fi
}

# 000 (the ledger table) must be applied first so the recording INSERT above
# has a table to write to, then the base schema files, then every remaining
# numbered migration in sorted order. This loop (mirroring update.sh's
# run_migrations) means a NEW migration file is picked up automatically — no
# need to hand-add a line here for each one (006 previously needed that).
apply_schema_file "Creating migration ledger..." "$REPO_DIR/database/migrations/000_schema_migrations.sql"
apply_schema_file "Creating schema..."           "$REPO_DIR/database/schema.sql"
apply_schema_file "Creating aggregates..."       "$REPO_DIR/database/aggregates.sql"
apply_schema_file "Creating identity schema..."  "$REPO_DIR/database/identity_schema.sql"

for mig in $(ls "$REPO_DIR/database/migrations/"*.sql 2>/dev/null | sort); do
    base=$(basename "$mig")
    [ "$base" = "000_schema_migrations.sql" ] && continue   # already applied first
    apply_schema_file "Applying migration ${base}..." "$mig"
done
info "Schema created"

# Grant the sonicscope app user access to all tables and sequences
sudo -u postgres psql -d sonicscope -c "
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO sonicscope;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO sonicscope;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO sonicscope;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO sonicscope;
" >/dev/null
info "Database permissions granted"

# ── Service user ─────────────────────────────────────────────────────────────
section "Creating service user"
id -u $SERVICE_USER &>/dev/null || \
    useradd -r -s /usr/sbin/nologin -d $INSTALL_DIR -m $SERVICE_USER
info "Service user: $SERVICE_USER"

# ── Install application ───────────────────────────────────────────────────────
section "Installing collector"
mkdir -p $INSTALL_DIR $CONFIG_DIR/certs $LOG_DIR $GEOIP_DIR

# Detect binary vs Python distribution
# v1.1.0+: ss-collector compiled binary present at dist root (Nuitka build)
# v1.0.x:  Python source in collector/ directory (legacy)
BINARY_DIST=false
[[ -f "$REPO_DIR/ss-collector" ]] && BINARY_DIST=true

if $BINARY_DIST; then
    info "Binary distribution detected (v1.1.0+)"

    # Install compiled collector binary — collector is self-contained
    install -m 755 "$REPO_DIR/ss-collector" "$INSTALL_DIR/ss-collector"
    ok "Collector binary installed: $INSTALL_DIR/ss-collector"

    # Copy VERSION file
    [[ -f "$REPO_DIR/VERSION" ]] && cp "$REPO_DIR/VERSION" "$INSTALL_DIR/VERSION"

    # The Reports UI (install-reports.sh) requires a venv at $INSTALL_DIR/venv
    # even in binary builds — Flask and WeasyPrint run as Python, not in the binary.
    python3 -m venv "$INSTALL_DIR/venv"
    "$INSTALL_DIR/venv/bin/pip" install -q --upgrade pip
else
    info "Python distribution detected (legacy)"

    # Python virtual environment for the collector
    python3 -m venv $INSTALL_DIR/venv
    $INSTALL_DIR/venv/bin/pip install -q --upgrade pip
    $INSTALL_DIR/venv/bin/pip install -q -r "$REPO_DIR/collector/requirements.txt"

    # Copy collector Python source
    cp -r "$REPO_DIR/collector/"* $INSTALL_DIR/
fi

chown -R $SERVICE_USER:$SERVICE_USER $INSTALL_DIR $LOG_DIR $GEOIP_DIR

# ── TLS certificate for syslog ────────────────────────────────────────────────
section "Generating TLS certificate for syslog"
HOSTNAME=$(hostname -f)
openssl req -x509 -newkey rsa:4096 -sha256 -days 3650 -nodes \
    -keyout $CONFIG_DIR/certs/server.key \
    -out    $CONFIG_DIR/certs/server.crt \
    -subj   "/CN=$HOSTNAME" \
    -addext "subjectAltName=IP:$(hostname -I | awk '{print $1}'),DNS:$HOSTNAME" \
    2>/dev/null
cp $CONFIG_DIR/certs/server.crt $CONFIG_DIR/certs/ca.crt
chmod 640 $CONFIG_DIR/certs/server.key
chown -R $SERVICE_USER:$SERVICE_USER $CONFIG_DIR/certs
info "TLS certificate generated: $CONFIG_DIR/certs/server.crt"

# ── Write configuration file ──────────────────────────────────────────────────
section "Writing configuration"

# Helper: run a single psql query and return trimmed output
pg() { sudo -u postgres psql -d sonicscope -tAc "$1" | tr -d ' \n'; }

# MSP profile — insert if not exists, then fetch id
sudo -u postgres psql -d sonicscope -c \
    "INSERT INTO msp_profiles (name) VALUES ('Default MSP') ON CONFLICT DO NOTHING;" >/dev/null
MSP_ID=$(pg "SELECT id FROM msp_profiles ORDER BY id LIMIT 1;")
[ -z "$MSP_ID" ] && error "Could not create msp_profiles row"

# Tenant
sudo -u postgres psql -d sonicscope -c \
    "INSERT INTO tenants (msp_profile_id, name, slug)
     VALUES ($MSP_ID, 'Site 1', 'site-1') ON CONFLICT DO NOTHING;" >/dev/null
TENANT_DB_ID=$(pg "SELECT id FROM tenants WHERE slug='site-1';")
[ -z "$TENANT_DB_ID" ] && error "Could not create tenants row"

# Sensor
sudo -u postgres psql -d sonicscope -c \
    "INSERT INTO sensors (tenant_id, name, vendor, data_sources)
     VALUES ($TENANT_DB_ID, 'SonicWall Firewall', 'sonicwall', '{ipfix,syslog}')
     ON CONFLICT DO NOTHING;" >/dev/null
SENSOR_DB_ID=$(pg "SELECT id FROM sensors WHERE tenant_id=$TENANT_DB_ID ORDER BY id LIMIT 1;")
[ -z "$SENSOR_DB_ID" ] && error "Could not create sensors row"

cat > $CONFIG_DIR/collector.env <<EOF
# SonicScope Multi-Vendor Collector — $(date +%Y-%m-%d)
SS_TENANT_ID=${TENANT_DB_ID:-1}
SS_SENSOR_ID=${SENSOR_DB_ID:-1}

DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=sonicscope
DB_USER=sonicscope
DB_PASSWORD=$DB_PASSWORD

ENABLE_IPFIX=true
IPFIX_LISTEN_IP=0.0.0.0
IPFIX_LISTEN_PORT=2055
IPFIX_ALLOWED_SOURCES=

ENABLE_SYSLOG=true
SYSLOG_LISTEN_IP=0.0.0.0
SYSLOG_UDP_PORT=514
SYSLOG_TCP_PORT=514
SYSLOG_TLS_PORT=6514
SYSLOG_ALLOWED_SOURCES=
SYSLOG_TLS_CERT=/etc/ss-multivendor/certs/server.crt
SYSLOG_TLS_KEY=/etc/ss-multivendor/certs/server.key
SYSLOG_TLS_CA=/etc/ss-multivendor/certs/ca.crt

ENABLE_GEOIP=true
GEOIP_DB_DIR=/opt/ss-multivendor/geoip

ENABLE_DNS=true
DNS_TIMEOUT=1.0

ENABLE_APP_CLASSIFIER=true
ENABLE_THREAT_INTEL=true
THREAT_INTEL_BLOCKLIST=

LOG_DIR=/var/log/ss-multivendor

# SonicScope Licence — paste the block from your licence email here
SONICSCOPE_LICENSE=
SONICSCOPE_PRODUCT=SS-MULTIVENDOR
SONICSCOPE_CUSTOMER_ID=
SONICSCOPE_EXPIRY=
SONICSCOPE_MAX_SENSORS=
EOF

chmod 660 $CONFIG_DIR/collector.env
chown root:$SERVICE_USER $CONFIG_DIR/collector.env

# Allow the ss-reports Flask app (runs as ss-collector) to restart the collector
# when firewall allowlists change — no password required for this one command only
SUDOERS_FILE="/etc/sudoers.d/ss-collector"
echo "ss-collector ALL=(root) NOPASSWD: /usr/bin/systemctl restart ss-collector" \
    > "$SUDOERS_FILE"
chmod 440 "$SUDOERS_FILE"
info "Sudoers rule added: ss-collector can restart ss-collector"
info "Config written to $CONFIG_DIR/collector.env"

# ── systemd service ───────────────────────────────────────────────────────────
section "Installing systemd service"
if $BINARY_DIST; then
    EXEC_START="$INSTALL_DIR/ss-collector"
else
    EXEC_START="$INSTALL_DIR/venv/bin/python3 $INSTALL_DIR/main.py"
fi

cat > /etc/systemd/system/ss-collector.service <<EOF
[Unit]
Description=SonicScope Multi-Vendor Collector
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
Environment="SS_ENV=$CONFIG_DIR/collector.env"
ExecStart=$EXEC_START
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-collector

# Allow binding to ports < 1024
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ss-collector
info "Service installed: ss-collector"

# ── Backup / Disaster Recovery ────────────────────────────────────────────────
section "Installing backup service"

mkdir -p "$INSTALL_DIR/scripts"
install -m 750 "$REPO_DIR/scripts/backup.sh"  "$INSTALL_DIR/scripts/backup.sh"
install -m 750 "$REPO_DIR/scripts/restore.sh" "$INSTALL_DIR/scripts/restore.sh"
info "backup.sh / restore.sh installed to $INSTALL_DIR/scripts/"

# Add BACKUP_DIR / BACKUP_KEEP to collector.env if not already present —
# guarded the same way install-reports.sh appends its own settings, so this
# is a no-op (and safe to re-run) on installs that already have them.
if ! grep -q "^BACKUP_DIR=" "$CONFIG_DIR/collector.env"; then
    cat >> "$CONFIG_DIR/collector.env" << 'EOF'

# ── Backup / Disaster Recovery ────────────────────────────────────────────────
# Where scripts/backup.sh writes timestamped tarballs (config-only DB dump +
# collector.env + logos/). Read by ss-backup.service via EnvironmentFile.
BACKUP_DIR=/var/backups/ss-multivendor
# Number of newest tarballs to retain in BACKUP_DIR; older ones are pruned
# automatically on every run.
BACKUP_KEEP=14
EOF
    info "Added BACKUP_DIR and BACKUP_KEEP to $CONFIG_DIR/collector.env"
else
    info "BACKUP_DIR already set in $CONFIG_DIR/collector.env"
fi

mkdir -p /var/backups/ss-multivendor
chmod 700 /var/backups/ss-multivendor

cat > /etc/systemd/system/ss-backup.service << EOF
[Unit]
Description=SonicScope Multi-Vendor Backup
After=postgresql.service
Wants=postgresql.service

[Service]
Type=oneshot
User=root
EnvironmentFile=$CONFIG_DIR/collector.env
ExecStart=$INSTALL_DIR/scripts/backup.sh
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-backup

NoNewPrivileges=yes
EOF

cat > /etc/systemd/system/ss-backup.timer << 'EOF'
[Unit]
Description=Daily SonicScope Multi-Vendor Backup

[Timer]
OnCalendar=*-*-* 02:30:00
Persistent=true

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now ss-backup.timer
info "ss-backup.service + ss-backup.timer installed and enabled (daily 02:30, Persistent)"

# ── UFW rules ─────────────────────────────────────────────────────────────────
if command -v ufw &>/dev/null && ufw status | grep -q "Status: active"; then
    section "Configuring firewall (UFW)"
    ufw allow 2055/udp  comment "SonicScope IPFIX"  >/dev/null
    ufw allow 514/udp   comment "SonicScope Syslog UDP" >/dev/null
    ufw allow 514/tcp   comment "SonicScope Syslog TCP" >/dev/null
    ufw allow 6514/tcp  comment "SonicScope Syslog TLS" >/dev/null
    info "UFW rules added"
fi

# ── Final instructions ────────────────────────────────────────────────────────
echo
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  SonicScope Multi-Vendor Collector installed${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo
echo "  Config:   $CONFIG_DIR/collector.env"
echo "  Logs:     $LOG_DIR/"
echo "  TLS cert: $CONFIG_DIR/certs/ca.crt  (upload to SonicWall for TLS syslog)"
echo "  Backups:  /var/backups/ss-multivendor/  (daily 02:30 — ss-backup.timer)"
echo
echo "  Before starting:"
echo "  1. Edit $CONFIG_DIR/collector.env"
echo "     — Add SONICSCOPE_LICENSE, SONICSCOPE_CUSTOMER_ID, SONICSCOPE_EXPIRY"
echo "     — Set IPFIX_ALLOWED_SOURCES to your firewall's IP"
echo
echo "  2. Download GeoIP databases (free MaxMind account required):"
echo "     sudo bash $REPO_DIR/scripts/download-geoip.sh <MaxMind_Key>"
echo
echo "  3. Start the collector:"
echo "     sudo systemctl start ss-collector"
echo "     sudo journalctl -u ss-collector -f"
echo
echo "  4. Install Grafana dashboards (requires Grafana to be running):"
echo "     sudo bash $REPO_DIR/scripts/install-grafana-dashboards.sh"
echo
echo "  5. Install report engine and web UI:"
echo "     sudo bash $REPO_DIR/scripts/install-reports.sh"
echo "     Then configure SMTP in $CONFIG_DIR/collector.env"
echo
