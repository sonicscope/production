#!/bin/bash
# SonicScope Reports Engine — Installer
# Installs the report engine, Flask UI, and configures the ss-reports systemd service.
# Run as root: sudo bash scripts/install-reports.sh
# Tested on Ubuntu 22.04 / 24.04 / 26.04+ LTS and Debian 13 (trixie)

set -euo pipefail

INSTALL_DIR="/opt/ss-multivendor"
VENV_PIP="${INSTALL_DIR}/venv/bin/pip"
VENV_PYTHON="${INSTALL_DIR}/venv/bin/python3"
CONFIG_FILE="/etc/ss-multivendor/collector.env"
DATA_DIR="/var/lib/ss-multivendor"
LOG_DIR="/var/log/ss-multivendor"
SERVICE_USER="ss-collector"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

[ "$(id -u)" -ne 0 ] && error "Must be run as root"

# ── System dependencies for WeasyPrint ───────────────────────────────────────
# WeasyPrint >= 61 uses Pango + Cairo for rendering; GDK-PixBuf is no longer
# required. Package names are consistent across Ubuntu 22.04 / 24.04 / 26.04+ and Debian 13.
section "Installing system packages for WeasyPrint"
apt-get update -qq
apt-get install -y -qq \
    python3 python3-pip python3-venv rsync \
    libpango-1.0-0 libpangocairo-1.0-0 \
    libcairo2 libharfbuzz0b \
    libffi-dev shared-mime-info \
    fonts-liberation fonts-dejavu-core

# ── System dependencies for TLS-terminating reverse proxy ────────────────────
# nginx is the ONLY public listener for the Reports UI; gunicorn binds to
# 127.0.0.1:8080 only (see the systemd unit below).
section "Installing nginx + openssl (TLS reverse proxy)"
apt-get install -y -qq nginx openssl

# ── Python packages ───────────────────────────────────────────────────────────
section "Installing Python packages"
[ -x "${VENV_PIP}" ] || error "Venv not found at ${INSTALL_DIR}/venv — run install.sh first"
"${VENV_PIP}" install --quiet \
    "weasyprint>=61.0" \
    "jinja2>=3.1" \
    "apscheduler>=3.10" \
    "psycopg2-binary>=2.9" \
    "flask>=3.0" \
    "werkzeug>=3.0" \
    "gunicorn==22.0.0"

info "Python packages installed"

# ── Directories ───────────────────────────────────────────────────────────────
section "Creating data directories"
mkdir -p "${DATA_DIR}/reports"
mkdir -p "${DATA_DIR}/logos"
mkdir -p "${LOG_DIR}"

if id "${SERVICE_USER}" &>/dev/null; then
    chown -R "${SERVICE_USER}:${SERVICE_USER}" "${DATA_DIR}" "${LOG_DIR}"
    info "Ownership set to ${SERVICE_USER}"
else
    warn "Service user '${SERVICE_USER}' not found — directories created but ownership not set"
fi

# ── Install source files ──────────────────────────────────────────────────────
section "Installing report engine to ${INSTALL_DIR}"
mkdir -p "${INSTALL_DIR}"
rsync -av --delete \
    "${REPO_DIR}/reports/" \
    "${INSTALL_DIR}/reports/"
info "Report engine installed to ${INSTALL_DIR}/reports/"

# ── Add env vars to collector.env if not already set ─────────────────────────
section "Updating ${CONFIG_FILE}"

if [ -f "${CONFIG_FILE}" ]; then
    if ! grep -q "^REPORT_OUTPUT_DIR=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << EOF

# ── Report Engine ──────────────────────────────────────────────────────────
REPORT_OUTPUT_DIR=${DATA_DIR}/reports
REPORT_LOGO_DIR=${DATA_DIR}/logos
EOF
        info "Added REPORT_OUTPUT_DIR and REPORT_LOGO_DIR to ${CONFIG_FILE}"
    else
        info "REPORT_OUTPUT_DIR already set in ${CONFIG_FILE}"
    fi

    if ! grep -q "^SMTP_HOST=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << 'EOF'

# ── SMTP (for scheduled report delivery and login codes) ──────────────────────
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_FROM=
SMTP_USE_TLS=true
EOF
        info "Added SMTP settings placeholder to ${CONFIG_FILE}"
    fi

    # Generate a stable Flask secret key (persisted so sessions survive restarts)
    if ! grep -q "^FLASK_SECRET=" "${CONFIG_FILE}"; then
        FLASK_SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
        echo "FLASK_SECRET=${FLASK_SECRET}" >> "${CONFIG_FILE}"
        info "Generated and saved FLASK_SECRET"
    fi

    if ! grep -q "^LOGIN_RATELIMIT_MAX=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << 'EOF'

# ── Login / forgot-password rate limiting (brute-force protection) ────────────
# Per-IP sliding window; 0 disables a limiter. See reports/web/rate_limit.py.
LOGIN_RATELIMIT_MAX=10
LOGIN_RATELIMIT_WINDOW_SEC=900
LOGIN_RATELIMIT_BLOCK_SEC=900
# Limits are per client IP. At sites where many users share one public IP
# (NAT/office gateway), that whole site counts as one client — raise these
# maxes if legitimate users there hit the limit.
FORGOT_RATELIMIT_MAX=5
FORGOT_RATELIMIT_WINDOW_SEC=900
FORGOT_RATELIMIT_BLOCK_SEC=900
RATELIMIT_MAX_TRACKED_IPS=10000
EOF
        info "Added login/forgot-password rate-limit settings to ${CONFIG_FILE}"
    fi

    # HEALTH_HEARTBEAT_SEC is read by ss-collector; HEALTH_STALE_SEC by
    # ss-reports' GET /healthz. Both settings live in this shared env file
    # (ss-reports already reads collector.env — see app.py's _load_env call).
    if ! grep -q "^HEALTH_HEARTBEAT_SEC=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << 'EOF'

# ── Health / /healthz (P1 launch-readiness) ───────────────────────────────────
# How often the collector writes its collector_health heartbeat. <= 0 disables it.
HEALTH_HEARTBEAT_SEC=15
# Age (seconds) past which GET /healthz reports the collector "stale" (no
# heartbeat) or ingest "no_recent_events" (heartbeat alive but no rows inserted).
HEALTH_STALE_SEC=60
EOF
        info "Added HEALTH_HEARTBEAT_SEC and HEALTH_STALE_SEC to ${CONFIG_FILE}"
    fi

    if ! grep -q "^# LOGIN_MSP_ID=" "${CONFIG_FILE}" && ! grep -q "^LOGIN_MSP_ID=" "${CONFIG_FILE}"; then
        cat >> "${CONFIG_FILE}" << 'EOF'

# ── Per-MSP login branding (P1 white-label) ───────────────────────────────────
# One MSP per install — the /login, /forgot-password and /reset-password
# pages brand for a single msp_profiles row (name/logo/primary_color/
# footer_text), never resolved by hostname. Most single-MSP installs need
# no value here: with exactly one msp_profiles row, it is auto-detected.
# Set this only if the install has more than one msp_profiles row and you
# need to pin which one brands the login screen.
# LOGIN_MSP_ID=
EOF
        info "Added LOGIN_MSP_ID (commented) to ${CONFIG_FILE}"
    fi
else
    warn "${CONFIG_FILE} not found — SMTP and report settings not added"
fi

# ── TLS certificate + nginx reverse proxy ─────────────────────────────────────
# gunicorn (below) binds ONLY to 127.0.0.1:8080. nginx is the sole public
# listener and terminates TLS. Customers self-deploy on arbitrary hostnames
# with no guaranteed public DNS, so the default is a self-signed certificate
# generated here; set TLS_DOMAIN= in ${CONFIG_FILE} (the licence/config file)
# before running this installer to get a real Let's Encrypt cert via certbot
# instead.
section "Provisioning TLS certificate for the Reports UI"

TLS_CERT_DIR="/etc/ss-multivendor/tls"
mkdir -p "${TLS_CERT_DIR}"
chmod 750 "${TLS_CERT_DIR}"

TLS_DOMAIN=""
if [ -f "${CONFIG_FILE}" ]; then
    TLS_DOMAIN=$(grep -m1 "^TLS_DOMAIN=" "${CONFIG_FILE}" | cut -d= -f2- | tr -d "\"'" | xargs || true)
fi

NGINX_SERVER_NAME="_"
SSL_CERT="${TLS_CERT_DIR}/server.crt"
SSL_KEY="${TLS_CERT_DIR}/server.key"

if [ -n "${TLS_DOMAIN}" ]; then
    info "TLS_DOMAIN=${TLS_DOMAIN} found in ${CONFIG_FILE} — obtaining a Let's Encrypt certificate via certbot"
    apt-get install -y -qq certbot

    # certbot's standalone plugin runs its own temporary listener on :80, so
    # nginx (not yet configured/started for this vhost) does not need to be
    # up first. Falls back to a self-signed cert if issuance fails (e.g. no
    # public DNS/port 80 reachability yet) so the service still comes up.
    systemctl stop nginx 2>/dev/null || true
    if certbot certonly --standalone --non-interactive --agree-tos \
        -m "admin@${TLS_DOMAIN}" -d "${TLS_DOMAIN}"; then
        SSL_CERT="/etc/letsencrypt/live/${TLS_DOMAIN}/fullchain.pem"
        SSL_KEY="/etc/letsencrypt/live/${TLS_DOMAIN}/privkey.pem"
        NGINX_SERVER_NAME="${TLS_DOMAIN}"
        info "Let's Encrypt certificate issued for ${TLS_DOMAIN}"

        # Reload nginx after certbot's automatic renewals.
        mkdir -p /etc/letsencrypt/renewal-hooks/deploy
        cat > /etc/letsencrypt/renewal-hooks/deploy/ss-reports-nginx-reload.sh << 'HOOKEOF'
#!/bin/bash
systemctl reload nginx || true
HOOKEOF
        chmod +x /etc/letsencrypt/renewal-hooks/deploy/ss-reports-nginx-reload.sh
    else
        warn "certbot could not issue a certificate for ${TLS_DOMAIN} — falling back to a self-signed certificate"
        TLS_DOMAIN=""
    fi
fi

if [ -z "${TLS_DOMAIN}" ]; then
    if [ ! -f "${SSL_CERT}" ] || [ ! -f "${SSL_KEY}" ]; then
        SS_HOSTNAME=$(hostname -f 2>/dev/null || hostname)
        openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
            -keyout "${SSL_KEY}" -out "${SSL_CERT}" \
            -subj "/CN=${SS_HOSTNAME}" \
            -addext "subjectAltName=IP:$(hostname -I | awk '{print $1}'),DNS:${SS_HOSTNAME}" \
            2>/dev/null
        # nginx (running as root) is the only reader of the TLS key — gunicorn
        # binds plain HTTP on localhost and never touches it. So keep the key
        # root-only 600; granting the ss-collector group read added no access
        # and only widened exposure.
        chmod 600 "${SSL_KEY}"
        chown root:root "${SSL_KEY}" 2>/dev/null || true
    fi
    echo
    warn "Using a SELF-SIGNED TLS certificate — browsers will show a security"
    warn "warning on first visit (expected: click through / add an exception)."
    warn "To use a trusted certificate instead, set TLS_DOMAIN=<your-domain> in"
    warn "${CONFIG_FILE} and re-run this installer."
    echo
fi

# ── DH parameters (for the DHE cipher suites in the hardened vhost) ───────────
# Shipped pre-generated with the release rather than produced here with
# `openssl dhparam` (a 2048-bit generation can take 30s+ and would risk
# stalling the deploy). DH parameters are public by design — a shared
# well-known group is safe; forward secrecy comes from the ephemeral keys.
SSL_DHPARAM="${TLS_CERT_DIR}/dhparam.pem"
if [ ! -f "${SSL_DHPARAM}" ]; then
    if [ -f "${REPO_DIR}/scripts/templates/dhparam.pem" ]; then
        cp "${REPO_DIR}/scripts/templates/dhparam.pem" "${SSL_DHPARAM}"
    else
        # Fallback for a build missing the shipped file — generate locally.
        warn "Shipped dhparam.pem not found — generating 2048-bit DH params (may take ~30s)"
        openssl dhparam -out "${SSL_DHPARAM}" 2048 2>/dev/null
    fi
    chmod 640 "${SSL_DHPARAM}"
    chown "root:${SERVICE_USER}" "${SSL_DHPARAM}" 2>/dev/null || true
fi

# ── OCSP stapling — only with a real CA-issued cert ───────────────────────────
# TLS_DOMAIN is non-empty only when certbot successfully issued a Let's Encrypt
# cert above (it is reset to "" on self-signed fallback). Self-signed certs have
# no OCSP responder, so stapling is left as a no-op comment in that case.
# `resolver` uses the systemd-resolved stub (127.0.0.53) to look up the OCSP
# responder hostname. Kept on a SINGLE line on purpose: nginx parses
# `;`-terminated directives regardless of newlines, and a single-line value
# avoids sed injecting un-commented lines where the placeholder also appears in
# the template's header doc-comment.
if [ -n "${TLS_DOMAIN}" ]; then
    OCSP_STAPLING="ssl_stapling on; ssl_stapling_verify on; ssl_trusted_certificate ${SSL_CERT}; resolver 127.0.0.53 valid=300s; resolver_timeout 5s;"
else
    OCSP_STAPLING="# OCSP stapling disabled — self-signed certificate has no OCSP responder."
fi

section "Configuring nginx reverse proxy (TLS termination -> gunicorn:8080)"
sed \
    -e "s|__SERVER_NAME__|${NGINX_SERVER_NAME}|g" \
    -e "s|__SSL_CERT__|${SSL_CERT}|g" \
    -e "s|__SSL_KEY__|${SSL_KEY}|g" \
    -e "s|__SSL_DHPARAM__|${SSL_DHPARAM}|g" \
    -e "s|__OCSP_STAPLING__|${OCSP_STAPLING}|g" \
    "${REPO_DIR}/scripts/templates/ss-reports-nginx.conf" > /etc/nginx/sites-available/ss-reports.conf

mkdir -p /etc/nginx/sites-enabled
ln -sf /etc/nginx/sites-available/ss-reports.conf /etc/nginx/sites-enabled/ss-reports.conf
rm -f /etc/nginx/sites-enabled/default

nginx -t
info "nginx vhost written to /etc/nginx/sites-available/ss-reports.conf"

# ── Start nginx after ss-reports on boot ──────────────────────────────────────
# nginx proxies to gunicorn on 127.0.0.1:8080; if nginx wins the boot race it
# serves 502s until gunicorn is up. A drop-in orders nginx after ss-reports so
# the proxy target is ready first (Wants= keeps it non-fatal if ss-reports is
# briefly down — nginx still starts and Restart=on-failure recovers gunicorn).
mkdir -p /etc/systemd/system/nginx.service.d
cat > /etc/systemd/system/nginx.service.d/ss-reports-after.conf << 'EOF'
[Unit]
After=ss-reports.service
Wants=ss-reports.service
EOF

# ── Systemd services ──────────────────────────────────────────────────────────
section "Installing ss-reports.service and ss-scheduler.service"

# Number of gunicorn workers. The report scheduler now runs in its own service
# (ss-scheduler.service, below), so the web tier is free to run multiple
# workers — no scheduled report is fired here. Override with REPORTS_WORKERS=
# in ${CONFIG_FILE}; defaults to 3.
REPORTS_WORKERS=3
if [ -f "${CONFIG_FILE}" ]; then
    _rw=$(grep -m1 "^REPORTS_WORKERS=" "${CONFIG_FILE}" | cut -d= -f2- | tr -dc '0-9' || true)
    [ -n "${_rw}" ] && REPORTS_WORKERS="${_rw}"
fi

cat > /etc/systemd/system/ss-reports.service << EOF
[Unit]
Description=SonicScope Reports Web UI
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_FILE}
# gunicorn, bound to localhost ONLY — nginx (installed above) terminates TLS
# on :443 and is the sole public listener. Multiple workers are safe: the
# report scheduler lives in ss-scheduler.service (a single process), so no
# scheduled report is ever fired from a web worker.
ExecStart=${INSTALL_DIR}/venv/bin/gunicorn --workers ${REPORTS_WORKERS} --threads 8 --timeout 120 \\
    --bind 127.0.0.1:8080 --chdir ${INSTALL_DIR}/reports/web app:app
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-reports

NoNewPrivileges=yes
ProtectSystem=full
ReadWritePaths=/etc/ss-multivendor /var/lib/ss-multivendor /var/log/ss-multivendor /var/lib/grafana/dashboards
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
EOF

# ── ss-scheduler.service ──────────────────────────────────────────────────────
# The report-schedule APScheduler runs here, in exactly ONE process, decoupled
# from the gunicorn workers. It re-reads report_schedules from the DB on a short
# interval so UI schedule changes take effect without any cross-process
# signalling. NOTE: update.sh writes an identical unit on upgrades — keep the
# two definitions in sync.
cat > /etc/systemd/system/ss-scheduler.service << EOF
[Unit]
Description=SonicScope Report Scheduler
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_FILE}
ExecStart=${INSTALL_DIR}/venv/bin/python ${INSTALL_DIR}/reports/scheduler_service.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-scheduler

NoNewPrivileges=yes
ProtectSystem=full
ReadWritePaths=/etc/ss-multivendor /var/lib/ss-multivendor /var/log/ss-multivendor
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable ss-reports
systemctl restart ss-reports
systemctl enable ss-scheduler
systemctl restart ss-scheduler
systemctl enable nginx
systemctl restart nginx

sleep 3
if systemctl is-active --quiet ss-reports && systemctl is-active --quiet nginx; then
    info "ss-reports (gunicorn, ${REPORTS_WORKERS} workers) and nginx are running"
    if systemctl is-active --quiet ss-scheduler; then
        info "ss-scheduler (report scheduler) is running"
    else
        warn "ss-scheduler did not start — scheduled reports will not fire; check: sudo journalctl -u ss-scheduler -n 50"
    fi
    if [ -n "${NGINX_SERVER_NAME}" ] && [ "${NGINX_SERVER_NAME}" != "_" ]; then
        info "Web UI: https://${NGINX_SERVER_NAME}/"
    else
        info "Web UI: https://$(hostname -I | awk '{print $1}')/ (self-signed cert — browser warning expected)"
    fi
else
    warn "ss-reports or nginx did not start — check: sudo journalctl -u ss-reports -n 50"
    warn "and: sudo journalctl -u nginx -n 50 / sudo nginx -t"
fi

# ── Create default admin user ─────────────────────────────────────────────────
section "Creating default admin user"

GF_PASS_FILE="/etc/ss-multivendor/grafana-admin-password"
if [[ -f "$GF_PASS_FILE" ]]; then
    ADMIN_PASS=$(cat "$GF_PASS_FILE")
    info "Using Grafana admin password for Reports UI admin"
else
    ADMIN_PASS=$(openssl rand -base64 12 | tr -d '/+=')
    info "Grafana not yet installed — generated new admin password"
fi

# Write password to temp file to avoid shell injection when passing to Python
PASS_TMP=$(mktemp /tmp/ss_adminpw_XXXXXX)
chmod 600 "$PASS_TMP"
echo "$ADMIN_PASS" > "$PASS_TMP"

ADMIN_RESULT=$(${VENV_PYTHON} - "$PASS_TMP" "${CONFIG_FILE}" << 'PYEOF'
import sys, os
from werkzeug.security import generate_password_hash
import psycopg2

pass_file, env_file = sys.argv[1], sys.argv[2]

with open(pass_file) as f:
    admin_pass = f.read().strip()

env = {}
with open(env_file) as f:
    for line in f:
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            k, _, v = line.partition('=')
            env[k.strip()] = v.strip().strip('"').strip("'")

ph = generate_password_hash(admin_pass)
try:
    conn = psycopg2.connect(
        host=env.get('DB_HOST', '127.0.0.1'),
        port=int(env.get('DB_PORT', '5432')),
        dbname=env.get('DB_NAME', 'sonicscope'),
        user=env.get('DB_USER', 'sonicscope'),
        password=env.get('DB_PASSWORD', ''),
    )
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM ui_users WHERE role='admin' LIMIT 1")
        if not cur.fetchone():
            cur.execute(
                "INSERT INTO ui_users (email, full_name, role, password_hash) "
                "VALUES (%s, %s, %s, %s)",
                ('admin@sonicscope.local', 'Administrator', 'admin', ph),
            )
            print('CREATED')
        else:
            print('EXISTS')
    conn.close()
except Exception as e:
    print(f'ERROR: {e}', file=sys.stderr)
    sys.exit(1)
PYEOF
)

rm -f "$PASS_TMP"

if [[ "$ADMIN_RESULT" == "CREATED" ]]; then
    info "Default admin created"
    echo
    echo -e "${YELLOW}  ╔══════════════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}  ║  DEFAULT ADMIN — change password after first login   ║${NC}"
    echo -e "${YELLOW}  ║  Email:    admin@sonicscope.local                    ║${NC}"
    echo -e "${YELLOW}  ║  Password: ${ADMIN_PASS}$(printf '%*s' $((22 - ${#ADMIN_PASS})) '')║${NC}"
    echo -e "${YELLOW}  ╚══════════════════════════════════════════════════════╝${NC}"
    echo
elif [[ "$ADMIN_RESULT" == "EXISTS" ]]; then
    info "Admin user already exists — skipping default admin creation"
else
    warn "Could not create default admin — check DB connection and try again"
fi

section "Installation complete"
echo
echo "Next steps:"
echo "  1. Configure SMTP in ${CONFIG_FILE}"
if [ -n "${NGINX_SERVER_NAME}" ] && [ "${NGINX_SERVER_NAME}" != "_" ]; then
    echo "  2. Open the web UI at https://${NGINX_SERVER_NAME}/"
else
    echo "  2. Open the web UI at https://$(hostname -I | awk '{print $1}')/"
    echo "     (self-signed cert — your browser will warn on first visit; this"
    echo "     is expected. Set TLS_DOMAIN=<your-domain> in ${CONFIG_FILE} and"
    echo "     re-run this installer for a trusted certificate instead.)"
fi
echo "  3. Log in as admin@sonicscope.local with the password shown above"
echo "  4. Create your MSP profile, add tenants, and configure report schedules"
echo
