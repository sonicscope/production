#!/bin/bash
# SonicScope Multi-Vendor — In-Place Updater
# Updates application code without touching the database or collector.env.
# Safe to run on a live system — data is preserved.
#
# Run as root: sudo bash scripts/update.sh
#
# What this does:
#   1. Stops ss-collector and ss-reports
#   2. Rsyncs collector/ and reports/ code to /opt/ss-multivendor/
#   3. Applies any new DB migrations (all are idempotent — safe to re-run)
#   4. Reinstalls Python packages if requirements.txt changed
#   5. Restarts both services
#
# What this does NOT touch:
#   - /etc/ss-multivendor/collector.env  (config, licence, SMTP)
#   - PostgreSQL data
#   - GeoIP databases
#   - Generated PDF reports
#   - TLS certificates
#   - Grafana dashboards (run install-grafana-dashboards.sh separately if needed)

set -euo pipefail

INSTALL_DIR="/opt/ss-multivendor"
SERVICE_USER="ss-collector"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)"
# DB name — overridable via SS_PG_DB so the migration runner can be exercised
# against a throwaway scratch database in tests without touching production.
PG_DB="${SS_PG_DB:-sonicscope}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

[ "$(id -u)" -ne 0 ] && error "Must be run as root"
[ -d "$INSTALL_DIR" ] || error "$INSTALL_DIR not found — run install.sh first"

# ── Detect binary vs Python distribution ──────────────────────────────────────
# v1.1.0+: ss-collector binary at dist root; VERSION file present
# v1.0.x:  Python source in collector/; __version__ in main.py
BINARY_DIST=false
[[ -f "$REPO_DIR/ss-collector" ]] && BINARY_DIST=true

# ── Detect versions ───────────────────────────────────────────────────────────
# New version: VERSION file (binary builds) or main.py (Python builds)
if [[ -f "$REPO_DIR/VERSION" ]]; then
    NEW_VER=$(cat "$REPO_DIR/VERSION")
else
    NEW_VER=$(grep '__version__' "$REPO_DIR/collector/main.py" 2>/dev/null \
        | head -1 | grep -oP '[\d.]+') || NEW_VER="unknown"
fi

# Installed version: VERSION file (binary builds) or main.py (Python builds)
if [[ -f "$INSTALL_DIR/VERSION" ]]; then
    CUR_VER=$(cat "$INSTALL_DIR/VERSION")
else
    CUR_VER=$(grep '__version__' "$INSTALL_DIR/main.py" 2>/dev/null \
        | head -1 | grep -oP '[\d.]+') || CUR_VER="unknown"
fi

echo
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  SonicScope ss-multivendor — Update${NC}"
echo -e "${GREEN}  Installed: ${CUR_VER}  →  New: ${NEW_VER}${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo
echo "  Database and collector.env will NOT be changed."
echo
read -r -p "Proceed with update? [y/N] " CONFIRM
[[ "${CONFIRM,,}" == "y" ]] || { echo "Aborted."; exit 0; }

# ── Ensure services are restarted even if something fails mid-update ──────────
_SERVICES_STOPPED=false
cleanup() {
    if $_SERVICES_STOPPED; then
        warn "Restarting services after early exit..."
        systemctl start ss-collector 2>/dev/null || true
        systemctl start ss-reports  2>/dev/null || true
        # Only (re)start the scheduler if its unit exists — a pre-v1.2.4 box
        # that fails an upgrade before the unit is written should not error.
        systemctl start ss-scheduler 2>/dev/null || true
    fi
}
trap cleanup EXIT

# ── Stop services ─────────────────────────────────────────────────────────────
section "Stopping services"
systemctl stop ss-reports  2>/dev/null && info "ss-reports stopped"  || info "ss-reports was not running"
# ss-scheduler exists only on v1.2.4+ installs; ignore if absent.
systemctl stop ss-scheduler 2>/dev/null && info "ss-scheduler stopped" || true
systemctl stop ss-collector 2>/dev/null && info "ss-collector stopped" || info "ss-collector was not running"
_SERVICES_STOPPED=true

# ── Sync application code ─────────────────────────────────────────────────────
section "Updating application code"

if $BINARY_DIST; then
    # Binary distribution (v1.1.0+): install compiled binary
    install -m 755 "$REPO_DIR/ss-collector" "$INSTALL_DIR/ss-collector"
    info "Collector binary updated: ss-collector"

    # Update VERSION file
    [[ -f "$REPO_DIR/VERSION" ]] && cp "$REPO_DIR/VERSION" "$INSTALL_DIR/VERSION"

    # Patch systemd service if upgrading from Python (v1.0.x) to binary (v1.1.0+)
    # Detects old ExecStart pointing to python3/main.py and replaces with binary path
    if grep -q "python3.*main.py" /etc/systemd/system/ss-collector.service 2>/dev/null; then
        warn "Upgrading from Python → binary distribution. Patching systemd service..."
        sed -i "s|ExecStart=.*python3.*main.py|ExecStart=$INSTALL_DIR/ss-collector|" \
            /etc/systemd/system/ss-collector.service
        systemctl daemon-reload
        info "systemd ExecStart updated to binary"
    fi
else
    # Python distribution (v1.0.x): rsync source files
    rsync -a --delete \
        --exclude '__pycache__' \
        --exclude '*.pyc' \
        --exclude '*.pyo' \
        --exclude '.env' \
        --exclude 'venv/' \
        --exclude 'geoip/' \
        "$REPO_DIR/collector/" \
        "$INSTALL_DIR/"
    info "Collector code updated"
fi

rsync -a --delete \
    --exclude '__pycache__' \
    --exclude '*.pyc' \
    "$REPO_DIR/reports/" \
    "$INSTALL_DIR/reports/"
info "Reports code updated"

chown -R $SERVICE_USER:$SERVICE_USER "$INSTALL_DIR"

# Ensure collector.env is writable by the service group (ss-reports needs to update allowlist)
chown root:$SERVICE_USER /etc/ss-multivendor/collector.env
chmod 660 /etc/ss-multivendor/collector.env

# ── Update Python packages if requirements changed ────────────────────────────
section "Checking Python packages"
if ! $BINARY_DIST; then
    # Collector pip install only needed for Python distribution
    $INSTALL_DIR/venv/bin/pip install -q --upgrade -r "$REPO_DIR/collector/requirements.txt"
fi
$INSTALL_DIR/venv/bin/pip install -q --upgrade -r "$REPO_DIR/reports/requirements.txt"
info "Python packages up to date"

# ── Apply DB migrations (all idempotent — safe to re-run) ────────────────────
section "Applying DB migrations"

# apply_sql — fail-loud, transactional, idempotent single-file migration runner.
#
#   * Skips files already recorded in schema_migrations (the ledger).
#   * Applies with ON_ERROR_STOP=1 so a genuine SQL error is a HARD failure
#     (bare psql exits 0 on SQL error — set -e would miss it).
#   * Wraps plain-DDL files in --single-transaction so a mid-file error rolls
#     back cleanly (never a half-applied schema). TimescaleDB continuous
#     aggregates and refresh_continuous_aggregate() CANNOT run inside a
#     transaction block, so files containing them are applied WITHOUT
#     --single-transaction (still WITH ON_ERROR_STOP=1).
#   * Records the file in the ledger only on success.
#   * On failure: keeps services STOPPED (disarms the restart trap) and exits
#     non-zero via error() BEFORE the restart section — a broken schema never
#     reaches "Restarting services", and the collector never crash-loops
#     against a half-applied DB.
apply_sql() {
    local label="$1" src="$2" base
    base=$(basename "$src")

    if sudo -u postgres psql -d "$PG_DB" -tAc \
        "SELECT 1 FROM schema_migrations WHERE filename='$base'" 2>/dev/null | grep -q 1; then
        info "$label already applied — skipping"
        return 0
    fi

    local tmp
    tmp=$(mktemp /tmp/ss_mig_XXXXXX.sql)
    cp "$src" "$tmp"
    chmod 644 "$tmp"

    # Segregate TimescaleDB continuous-aggregate files from plain DDL. Strip
    # `--` line comments before matching so a plain-DDL migration that merely
    # MENTIONS these tokens in a comment isn't wrongly run without a transaction
    # (which would lose mid-file rollback safety).
    local txn=(--single-transaction)
    if sed 's/--.*//' "$tmp" | grep -qiE 'timescaledb\.continuous|refresh_continuous_aggregate'; then
        txn=()   # cannot run inside a transaction block
    fi

    if sudo -u postgres psql -d "$PG_DB" -v ON_ERROR_STOP=1 "${txn[@]}" -q -f "$tmp"; then
        sudo -u postgres psql -d "$PG_DB" -q -c \
            "INSERT INTO schema_migrations(filename) VALUES('$base') ON CONFLICT DO NOTHING" >/dev/null
        info "$label applied"
        rm -f "$tmp"
    else
        rm -f "$tmp"
        _SERVICES_STOPPED=false   # do NOT auto-restart onto a broken schema
        error "$label FAILED — migration aborted, services NOT restarted. Fix the SQL error above and re-run update.sh."
    fi
}

# run_migrations — apply the full ordered set. The ledger dedupes, so re-runs
# are clean no-ops. 000 (the ledger table itself) must be applied first; the
# rest follow in a stable, dependency-safe order.
run_migrations() {
    apply_sql "000_schema_migrations" "$REPO_DIR/database/migrations/000_schema_migrations.sql"
    apply_sql "schema"                "$REPO_DIR/database/schema.sql"
    apply_sql "aggregates"            "$REPO_DIR/database/aggregates.sql"
    apply_sql "identity schema"       "$REPO_DIR/database/identity_schema.sql"

    # All remaining numbered migrations, in sorted order. 000 already applied.
    local f base
    for f in $(ls "$REPO_DIR/database/migrations/"*.sql 2>/dev/null | sort); do
        base=$(basename "$f")
        [[ "$base" == "000_schema_migrations.sql" ]] && continue
        apply_sql "$base" "$f"
    done
}

run_migrations

# Ensure sonicscope user has permissions on any new tables
sudo -u postgres psql -d "$PG_DB" -q -c "
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO sonicscope;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO sonicscope;
" >/dev/null
info "DB permissions refreshed"

# ── Scheduler service (v1.2.4+) ───────────────────────────────────────────────
# The report scheduler used to run inside the ss-reports gunicorn process. From
# v1.2.4 it runs as its own single-process service so the web tier can scale to
# multiple workers. On upgrade from an older install this unit does not exist
# yet — write it here, or scheduled reports would silently stop firing (app.py
# no longer starts a scheduler). Keep this definition in sync with the identical
# one in install-reports.sh.
section "Installing/refreshing ss-scheduler.service"
CONFIG_FILE="/etc/ss-multivendor/collector.env"
if [ -f "$INSTALL_DIR/reports/scheduler_service.py" ]; then
    cat > /etc/systemd/system/ss-scheduler.service << EOF
[Unit]
Description=SonicScope Report Scheduler
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${CONFIG_FILE}
ExecStart=${INSTALL_DIR}/venv/bin/python ${INSTALL_DIR}/reports/scheduler_service.py
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ss-scheduler

NoNewPrivileges=yes
ProtectSystem=full
ReadWritePaths=/etc/ss-multivendor /var/lib/ss-multivendor /var/log/ss-multivendor
PrivateTmp=yes

[Install]
WantedBy=multi-user.target
EOF
    # The scheduler no longer runs in the web workers, so lift the old
    # single-worker cap on an upgraded ss-reports.service (harmless no-op if it
    # already reads >1 or the pattern isn't present).
    if grep -q -- '--workers 1 ' /etc/systemd/system/ss-reports.service 2>/dev/null; then
        sed -i 's/--workers 1 /--workers 3 /' /etc/systemd/system/ss-reports.service
        info "ss-reports worker cap lifted (1 -> 3)"
    fi
    systemctl daemon-reload
    systemctl enable ss-scheduler 2>/dev/null || true
    info "ss-scheduler.service installed"
else
    warn "reports/scheduler_service.py not found in this build — skipping scheduler service"
fi

# ── Restart services ──────────────────────────────────────────────────────────
section "Restarting services"
_SERVICES_STOPPED=false   # disarm the trap — we're handling restart ourselves

systemctl start ss-collector
sleep 2
if systemctl is-active --quiet ss-collector; then
    info "ss-collector is running"
else
    error "ss-collector failed to start — check: sudo journalctl -u ss-collector -n 30"
fi

systemctl start ss-reports
sleep 3
if systemctl is-active --quiet ss-reports; then
    info "ss-reports is running"
else
    warn "ss-reports failed to start — check: sudo journalctl -u ss-reports -n 30"
fi

if [ -f /etc/systemd/system/ss-scheduler.service ]; then
    systemctl start ss-scheduler
    sleep 2
    if systemctl is-active --quiet ss-scheduler; then
        info "ss-scheduler is running"
    else
        warn "ss-scheduler failed to start — scheduled reports will not fire; check: sudo journalctl -u ss-scheduler -n 30"
    fi
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Update complete — now running v${NEW_VER}${NC}"
echo -e "${GREEN}════════════════════════════════════════════════════════${NC}"
echo
echo "  Verify collector is receiving data:"
echo "  sudo -u postgres psql -d sonicscope -c \\"
echo "    \"SELECT COUNT(*) FROM fw_events WHERE time > NOW() - INTERVAL '5 minutes';\""
echo
echo "  If Grafana dashboards need refreshing:"
echo "  sudo bash scripts/install-grafana-dashboards.sh"
echo
