#!/bin/bash
# SonicScope Multi-Vendor — Upgrade (version gate, backups, automatic rollback)
#
# Run as root from the extracted release directory:
#   sudo bash scripts/upgrade.sh [--yes] [--check] [--apply-licence FILE]
#
#   --yes                 do not ask for confirmation
#   --check               report the verdict and the preflight, change nothing
#   --apply-licence FILE  copy the SONICSCOPE_* licence keys from FILE into collector.env
#                         when they differ from the stored ones (renewals)
#
# What it does (spec: docs/superpowers/specs/2026-11-21-install-time-upgrade-design.md):
#   1. Detects the installed version and refuses downgrades, same-version runs and installs
#      older than MIN_UPGRADE_FROM.
#   2. Preflight (read-only): disk, database, PostgreSQL major, TimescaleDB versions, licence.
#   3. Takes rollback copies (binary, code, collector.env) and a config backup. Aborts if any
#      of them fails.
#   4. Runs scripts/update.sh (migrations are additive and idempotent, so a code rollback is
#      always safe).
#   5. Post-checks: services, /healthz, licence. On failure it rolls back automatically.
#   6. After a successful upgrade it brings the TimescaleDB extension up to the installed
#      package version (services stopped, fresh session).
# It never changes the PostgreSQL major and never touches Grafana dashboards.

set -euo pipefail

INSTALL_DIR="${SS_INSTALL_DIR:-/opt/ss-multivendor}"
CONFIG_DIR="${SS_CONFIG_DIR:-/etc/ss-multivendor}"
BACKUP_DIR="${SS_BACKUP_DIR:-/var/backups}"
LOG_DIR="${SS_LOG_DIR:-/var/log/ss-multivendor}"
PG_DB="${SS_PG_DB:-sonicscope}"
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MIN_UPGRADE_FROM="1.4.0"
PG_MIN_MAJOR=16

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }
section() { echo; echo -e "${GREEN}── $* ──${NC}"; }

# >>> upgrade_logic
# Pure functions (no side effects) so they can be unit tested by sourcing this file.

# Sortable key for X.Y.Z or X.Y.Z-rcN; empty when the string is not a version we understand.
# A release candidate sorts before the final release of the same number.
ss_version_key() {
    local v="${1:-}" maj min pat rc
    if [[ "$v" =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)(-rc([0-9]+))?$ ]]; then
        maj=$((10#${BASH_REMATCH[1]})); min=$((10#${BASH_REMATCH[2]})); pat=$((10#${BASH_REMATCH[3]}))
        rc="${BASH_REMATCH[5]:-}"
        if [[ -n "$rc" ]]; then
            printf '%05d%05d%05d0%05d' "$maj" "$min" "$pat" "$((10#$rc))"
        else
            printf '%05d%05d%05d1%05d' "$maj" "$min" "$pat" 0
        fi
    fi
}

# ss_version_gate CURRENT NEW MIN -> one word: proceed | same | downgrade | too-old |
#                                              unknown-installed | unknown-new
ss_version_gate() {
    local kc kn km
    kc=$(ss_version_key "$1"); kn=$(ss_version_key "$2"); km=$(ss_version_key "$3")
    if   [[ -z "$kn" ]]; then echo "unknown-new"
    elif [[ -z "$kc" ]]; then echo "unknown-installed"
    elif [[ "$kc" == "$kn" ]]; then echo "same"
    elif [[ "$kn" < "$kc" ]]; then echo "downgrade"
    elif [[ "$kc" < "$km" ]]; then echo "too-old"
    else echo "proceed"
    fi
}

# ss_db_exists: true when the application database exists (overridable in tests).
ss_db_exists() {
    [[ "$(sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='${PG_DB}'" 2>/dev/null)" == "1" ]]
}

# ss_detect_install -> "absent" | "complete" | "damaged:<what is missing>"
ss_detect_install() {
    local have=0 missing=""
    if [[ -f "$INSTALL_DIR/VERSION" || -f "$INSTALL_DIR/main.py" ]]; then have=$((have+1)); else missing+="application files "; fi
    if [[ -f "$CONFIG_DIR/collector.env" ]]; then have=$((have+1)); else missing+="collector.env "; fi
    if ss_db_exists; then have=$((have+1)); else missing+="database "; fi
    case "$have" in
        0) echo "absent" ;;
        3) echo "complete" ;;
        *) echo "damaged:${missing% }" ;;
    esac
}

# ss_licence_pairs FILE -> sorted KEY=VALUE lines for the SONICSCOPE_* keys (quotes/CR stripped)
ss_licence_pairs() {
    [[ -f "$1" ]] || return 0
    { grep -E '^SONICSCOPE_[A-Z0-9_]+=' "$1" || true; } | tr -d "\r'\"" | sort
}

# ss_licence_differs NEWFILE ENVFILE -> success when NEWFILE holds licence keys that are
# missing from, or different in, ENVFILE.
ss_licence_differs() {
    local new cur
    new=$(ss_licence_pairs "$1")
    [[ -n "$new" ]] || return 1
    cur=$(ss_licence_pairs "$2")
    while IFS= read -r line; do
        grep -qxF -- "$line" <<<"$cur" || return 0
    done <<<"$new"
    return 1
}

# ss_apply_licence NEWFILE ENVFILE: replace or append the SONICSCOPE_* keys of NEWFILE in
# ENVFILE. Only that key family is ever copied (never database or SMTP settings). The file's
# owner and mode are preserved.
ss_apply_licence() {
    local newfile="$1" envfile="$2" pairs tmp
    pairs=$(mktemp); tmp=$(mktemp)
    ss_licence_pairs "$newfile" > "$pairs"
    awk -v kv="$pairs" '
        BEGIN { while ((getline l < kv) > 0) { i = index(l, "="); k = substr(l, 1, i - 1); v[k] = substr(l, i + 1); order[++n] = k } }
        { i = index($0, "="); k = (i > 0) ? substr($0, 1, i - 1) : "";
          if (k != "" && (k in v)) { print k "=" v[k]; seen[k] = 1 } else print }
        END { for (j = 1; j <= n; j++) if (!(order[j] in seen)) print order[j] "=" v[order[j]] }
    ' "$envfile" > "$tmp"
    cat "$tmp" > "$envfile"          # keep the inode, owner and mode of the original file
    rm -f "$pairs" "$tmp"
}

# ss_ts_numeric "2.30.1~ubuntu24.04-1615" -> 2.30.1
ss_ts_numeric() {
    [[ "${1:-}" =~ ^([0-9]+\.[0-9]+(\.[0-9]+)?) ]] && echo "${BASH_REMATCH[1]}"
}

# ss_ts_needs_update PACKAGE_VERSION EXTENSION_VERSION -> success when the installed package is
# newer than the extension loaded in the database.
ss_ts_needs_update() {
    local pkg ext
    pkg=$(ss_ts_numeric "$1"); ext=$(ss_ts_numeric "$2")
    [[ -n "$pkg" && -n "$ext" && "$pkg" != "$ext" ]] || return 1
    [[ "$(printf '%s\n%s\n' "$ext" "$pkg" | sort -V | tail -1)" == "$pkg" ]]
}
# <<< upgrade_logic

installed_version() {
    if [[ -f "$INSTALL_DIR/VERSION" ]]; then cat "$INSTALL_DIR/VERSION"
    else grep '__version__' "$INSTALL_DIR/main.py" 2>/dev/null | head -1 | grep -oP "[\d.]+(-rc\d+)?" || echo "unknown"
    fi
}
new_version() {
    if [[ -f "$REPO_DIR/VERSION" ]]; then cat "$REPO_DIR/VERSION"
    else grep '__version__' "$REPO_DIR/collector/main.py" 2>/dev/null | head -1 | grep -oP "[\d.]+(-rc\d+)?" || echo "unknown"
    fi
}

pg_major() {
    local n
    n=$(sudo -u postgres psql -tAc "SHOW server_version_num" 2>/dev/null) || return 1
    echo $(( n / 10000 ))
}

ts_versions() {   # sets TS_PKG and TS_EXT (either may be empty)
    local major
    major=$(pg_major) || major=""
    TS_PKG=""; TS_EXT=""
    [[ -n "$major" ]] && TS_PKG=$(dpkg-query -W -f='${Version}' "timescaledb-2-postgresql-${major}" 2>/dev/null) || true
    TS_EXT=$(sudo -u postgres psql -d "$PG_DB" -tAc "SELECT extversion FROM pg_extension WHERE extname='timescaledb'" 2>/dev/null) || true
}

free_mb() { df -Pm "$1" 2>/dev/null | awk 'NR==2{print $4}'; }

preflight() {
    section "Preflight"
    local need_mb code_mb major fails=0 f
    code_mb=$(du -sm --exclude=venv "$INSTALL_DIR" 2>/dev/null | awk '{print $1}')
    need_mb=$(( ${code_mb:-300} * 2 + 500 ))
    for d in "$INSTALL_DIR" "$BACKUP_DIR"; do
        f=$(free_mb "$d")
        if [[ -n "$f" ]] && (( f < need_mb )); then
            warn "Only ${f} MB free on $d (need about ${need_mb} MB for the rollback copies)"; fails=1
        else
            info "Disk: ${f:-?} MB free on $d"
        fi
    done
    if sudo -u postgres psql -d "$PG_DB" -tAc "SELECT 1" >/dev/null 2>&1; then info "Database '$PG_DB' is reachable"
    else warn "Database '$PG_DB' is not reachable"; fails=1; fi
    major=$(pg_major) || major=""
    if [[ -z "$major" ]]; then warn "Could not read the PostgreSQL version"; fails=1
    elif (( major < PG_MIN_MAJOR )); then warn "PostgreSQL $major is older than the supported minimum ($PG_MIN_MAJOR)"; fails=1
    else info "PostgreSQL major $major (not changed by the upgrade)"; fi
    ts_versions
    info "TimescaleDB: package ${TS_PKG:-unknown}, extension ${TS_EXT:-unknown}"
    if grep -q '^SONICSCOPE_' "$CONFIG_DIR/collector.env" 2>/dev/null; then info "Licence settings present in collector.env"
    else warn "No SONICSCOPE_* licence settings in collector.env"; fi
    [[ -d "$REPO_DIR/reports" ]] || { warn "This does not look like a release directory (no reports/)"; fails=1; }
    return $fails
}

wait_ready() {   # post-upgrade health checks; echoes the reason on failure
    local start="$1" tries=0 reason="" code
    while (( tries < 20 )); do
        reason=""
        systemctl is-active --quiet ss-collector || reason="ss-collector is not active"
        systemctl is-active --quiet ss-reports   || reason="${reason:+$reason; }ss-reports is not active"
        if [[ -f /etc/systemd/system/ss-scheduler.service ]]; then
            systemctl is-active --quiet ss-scheduler || reason="${reason:+$reason; }ss-scheduler is not active"
        fi
        code=$(curl -ks -o /dev/null -w '%{http_code}' --max-time 5 https://127.0.0.1/healthz 2>/dev/null || true)
        [[ "$code" == "200" ]] || reason="${reason:+$reason; }/healthz returned ${code:-no answer}"
        # Capture first, then match: piping journalctl into a quiet grep fails under pipefail when grep
        # exits at its first match and journalctl gets SIGPIPE (it only shows on a busy journal).
        local jtxt; jtxt=$(journalctl -u ss-collector --since "$start" --no-pager 2>/dev/null || true)
        if ! grep -qi "licence valid" <<<"$jtxt"; then
            reason="${reason:+$reason; }no 'licence valid' line from the collector yet"
        fi
        [[ -z "$reason" ]] && return 0
        tries=$(( tries + 1 )); sleep 3
    done
    echo "$reason"
    return 1
}

stop_services() {
    systemctl stop ss-reports 2>/dev/null || true
    systemctl stop ss-scheduler 2>/dev/null || true
    systemctl stop ss-collector 2>/dev/null || true
}
start_services() {
    # A service that crash-looped (for example on an invalid licence) hits systemd's start-rate
    # limit and refuses further starts until its failed state is cleared.
    systemctl reset-failed ss-collector ss-reports ss-scheduler 2>/dev/null || true
    systemctl start ss-collector 2>/dev/null || true
    systemctl start ss-reports 2>/dev/null || true
    [[ -f /etc/systemd/system/ss-scheduler.service ]] && { systemctl start ss-scheduler 2>/dev/null || true; }
}

BIN_BAK=""; CODE_BAK=""; ENV_BAK=""
rollback() {
    section "ROLLING BACK to $CUR_VER"
    stop_services
    if [[ -f "$BIN_BAK" ]]; then
        install -o ss-collector -g ss-collector -m 755 "$BIN_BAK" "$INSTALL_DIR/ss-collector" \
            || warn "Could not restore the binary from $BIN_BAK"
    fi
    if [[ -f "$CODE_BAK" ]]; then
        tar xzf "$CODE_BAK" -C "$INSTALL_DIR" || warn "Could not restore the code from $CODE_BAK"
    fi
    if [[ -f "$ENV_BAK" ]]; then
        cat "$ENV_BAK" > "$CONFIG_DIR/collector.env" || warn "Could not restore collector.env from $ENV_BAK"
    fi
    systemctl daemon-reload 2>/dev/null || true
    start_services
    local why
    if why=$(wait_ready "$(date '+%Y-%m-%d %H:%M:%S' -d '-1 minute')"); then
        warn "Rolled back: SonicScope $CUR_VER is running again. The database keeps the new additive migrations, which the old version ignores."
    else
        warn "Rollback finished but the health checks still fail: $why"
        warn "Check: sudo journalctl -u ss-collector -n 50   and   sudo journalctl -u ss-reports -n 50"
    fi
}

update_timescaledb() {
    ts_versions
    if ! ss_ts_needs_update "$TS_PKG" "$TS_EXT"; then
        info "TimescaleDB extension ${TS_EXT:-unknown} already matches the installed package ${TS_PKG:-unknown}"
        return 0
    fi
    section "Updating the TimescaleDB extension $TS_EXT -> $(ss_ts_numeric "$TS_PKG")"
    local major; major=$(pg_major) || major=""
    stop_services
    # TimescaleDB's procedure: restart PostgreSQL so the new library is loaded, then run the
    # update as the first statement of a fresh session with no other connections.
    if ! { timeout 120 systemctl restart "postgresql@${major}-main" 2>/dev/null \
           || timeout 120 systemctl restart postgresql 2>/dev/null; }; then
        warn "PostgreSQL did not restart; skipping the extension update"
        start_services; return 0
    fi
    sleep 2
    if sudo -u postgres psql -X -d "$PG_DB" -v ON_ERROR_STOP=1 -c "ALTER EXTENSION timescaledb UPDATE" >/dev/null 2>"$LOG_DIR/ts-update.err"; then
        ts_versions
        info "TimescaleDB extension is now ${TS_EXT}"
    else
        warn "ALTER EXTENSION timescaledb UPDATE failed (the extension stays at $TS_EXT; the upgrade itself is fine): $(head -c 300 "$LOG_DIR/ts-update.err")"
    fi
    start_services
    local why
    if ! why=$(wait_ready "$(date '+%Y-%m-%d %H:%M:%S' -d '-1 minute')"); then
        warn "Health checks after the extension update are not clean: $why"
        warn "The extension update cannot be undone; check the logs before continuing"
    fi
}

usage() { sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; }

main() {
    local ASSUME_YES=false CHECK_ONLY=false LICENCE_FILE=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --yes) ASSUME_YES=true ;;
            --check) CHECK_ONLY=true ;;
            --apply-licence) shift; LICENCE_FILE="${1:-}"; [[ -n "$LICENCE_FILE" ]] || error "--apply-licence needs a file" ;;
            -h|--help) usage; exit 0 ;;
            *) error "Unknown option: $1 (see --help)" ;;
        esac
        shift
    done
    [ "$(id -u)" -ne 0 ] && error "Must be run as root"

    section "Checking the installed system"
    local state; state=$(ss_detect_install)
    case "$state" in
        absent)   error "No SonicScope installation found at $INSTALL_DIR. Use deploy.sh (or scripts/install.sh) for a new install." ;;
        damaged:*) error "The existing installation is incomplete (missing: ${state#damaged:}). Refusing to guess; restore it or reinstall deliberately." ;;
    esac
    CUR_VER=$(installed_version); NEW_VER=$(new_version)
    info "Installed: $CUR_VER   Package: $NEW_VER"

    case "$(ss_version_gate "$CUR_VER" "$NEW_VER" "$MIN_UPGRADE_FROM")" in
        proceed) ;;
        same)
            info "Already running $CUR_VER; there is no new version to install."
            if [[ -n "$LICENCE_FILE" ]] && ss_licence_differs "$LICENCE_FILE" "$CONFIG_DIR/collector.env"; then
                $CHECK_ONLY && { info "A different licence was supplied and would be applied"; exit 0; }
                info "A different licence was supplied: applying it"
                local lstart lbak why; lstart=$(date '+%Y-%m-%d %H:%M:%S')
                mkdir -p "$BACKUP_DIR/ss-multivendor"
                lbak="$BACKUP_DIR/ss-multivendor/collector.env.pre-licence-$(date +%Y%m%dT%H%M%S)"
                ( umask 077; cp "$CONFIG_DIR/collector.env" "$lbak" && chown root:root "$lbak" && chmod 600 "$lbak" ) \
                    || error "Could not back up collector.env; the licence was not changed."
                ss_apply_licence "$LICENCE_FILE" "$CONFIG_DIR/collector.env"
                systemctl restart ss-collector
                if why=$(wait_ready "$lstart"); then
                    info "Licence updated and accepted"
                else
                    warn "The new licence was not accepted ($why): restoring the previous licence"
                    cat "$lbak" > "$CONFIG_DIR/collector.env"
                    systemctl reset-failed ss-collector 2>/dev/null || true
                    systemctl restart ss-collector
                    wait_ready "$(date '+%Y-%m-%d %H:%M:%S' -d '-1 minute')" >/dev/null \
                        && warn "Previous licence restored and running." \
                        || warn "Previous licence restored but the collector is not healthy: check journalctl -u ss-collector"
                    exit 1
                fi
            fi
            exit 0 ;;
        downgrade) error "Refusing to downgrade from $CUR_VER to $NEW_VER." ;;
        too-old) error "Installed version $CUR_VER is older than the oldest version this upgrade supports ($MIN_UPGRADE_FROM). Contact support for a manual migration." ;;
        unknown-installed) error "Could not determine the installed version (found '$CUR_VER'); refusing to upgrade blindly." ;;
        unknown-new) error "Could not determine the version of this package (found '$NEW_VER')." ;;
    esac

    local pf=0; preflight || pf=1
    if $CHECK_ONLY; then
        [[ $pf -eq 0 ]] && info "Check passed: an upgrade $CUR_VER -> $NEW_VER would proceed" || warn "Check found problems (see above)"
        exit $pf
    fi
    [[ $pf -eq 0 ]] || error "Preflight failed; nothing was changed."

    echo
    echo -e "${GREEN}  Upgrade $CUR_VER -> $NEW_VER${NC}"
    echo "  Rollback copies and a config backup are taken first; if the checks fail afterwards the upgrade rolls back by itself."
    if ! $ASSUME_YES; then
        read -r -p "Proceed with the upgrade? [y/N] " CONFIRM
        [[ "${CONFIRM,,}" == "y" ]] || { echo "Aborted."; exit 0; }
    fi

    mkdir -p "$LOG_DIR" "$BACKUP_DIR/ss-multivendor"
    local TS LOG; TS=$(date +%Y%m%dT%H%M%S); LOG="$LOG_DIR/upgrade-$TS.log"
    exec > >(tee -a "$LOG") 2>&1
    info "Log: $LOG"

    section "Taking rollback copies"
    BIN_BAK="/opt/ss-multivendor-collector-${CUR_VER}-prev${NEW_VER}.bak"
    CODE_BAK="$BACKUP_DIR/ss-reports-code-${CUR_VER}-pre-${NEW_VER}.tar.gz"
    ENV_BAK="$BACKUP_DIR/ss-multivendor/collector.env.pre-${NEW_VER}"
    if [[ -f "$INSTALL_DIR/ss-collector" ]]; then cp -p "$INSTALL_DIR/ss-collector" "$BIN_BAK" || error "Could not copy the binary; nothing was changed."; fi
    tar czf "$CODE_BAK" --exclude=./venv --exclude=./ss-collector -C "$INSTALL_DIR" . || error "Could not archive the code; nothing was changed."
    # collector.env holds the database password: the copy is root-only, whatever the original's mode.
    ( umask 077; cp "$CONFIG_DIR/collector.env" "$ENV_BAK" && chown root:root "$ENV_BAK" && chmod 600 "$ENV_BAK" ) \
        || error "Could not copy collector.env; nothing was changed."
    info "Binary: $BIN_BAK"; info "Code: $CODE_BAK"; info "Config: $ENV_BAK"
    if [[ -f "$REPO_DIR/scripts/backup.sh" ]]; then
        bash "$REPO_DIR/scripts/backup.sh" >/dev/null 2>&1 \
            && info "Config backup written under $BACKUP_DIR/ss-multivendor" \
            || error "The config backup failed; nothing was changed."
    fi

    local START; START=$(date '+%Y-%m-%d %H:%M:%S')
    if [[ -n "$LICENCE_FILE" ]] && ss_licence_differs "$LICENCE_FILE" "$CONFIG_DIR/collector.env"; then
        info "Applying the supplied licence (it differs from the stored one)"
        ss_apply_licence "$LICENCE_FILE" "$CONFIG_DIR/collector.env"
    fi

    section "Running update.sh"
    local rc=0
    bash "$REPO_DIR/scripts/update.sh" --yes || rc=$?
    if (( rc != 0 )); then
        warn "update.sh failed (exit $rc)"
        rollback; exit 1
    fi

    section "Post-upgrade checks"
    local why
    if ! why=$(wait_ready "$START"); then
        warn "Health checks failed: $why"
        rollback; exit 1
    fi
    info "Services active, /healthz 200, licence accepted"

    update_timescaledb

    section "Upgrade complete: $CUR_VER -> $NEW_VER"
    echo "  Log:        $LOG"
    echo "  Rollback copies: $BIN_BAK, $CODE_BAK, $ENV_BAK"
    echo "  To roll back later (the database keeps the additive migrations, which the old version ignores):"
    echo "    sudo systemctl stop ss-collector ss-reports ss-scheduler"
    echo "    sudo install -o ss-collector -g ss-collector -m 755 $BIN_BAK $INSTALL_DIR/ss-collector"
    echo "    sudo tar xzf $CODE_BAK -C $INSTALL_DIR"
    echo "    sudo systemctl start ss-collector ss-reports ss-scheduler"
}

# Run only when executed, so tests can `source` this file for the functions above.
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then main "$@"; fi
