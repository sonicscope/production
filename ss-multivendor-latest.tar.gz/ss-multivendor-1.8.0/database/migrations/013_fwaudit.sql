-- 013_fwaudit.sql — Firewall Audit v2 (targets and runs). Additive and idempotent.
-- Tables are owned by the migration role; the AI read-only role ss_ai_ro must never read them.

CREATE TABLE IF NOT EXISTS audit_targets (
    id            serial PRIMARY KEY,
    tenant_id     integer NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name          text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 120),
    vendor        text NOT NULL
                  CHECK (vendor IN ('sonicwall', 'fortigate', 'paloalto', 'sophos', 'opnsense')),
    input_method  text NOT NULL DEFAULT 'file' CHECK (input_method IN ('file', 'api')),
    -- Collector sensor whose logs feed the traffic-aware checks (optional).
    sensor_id     integer REFERENCES sensors(id) ON DELETE SET NULL,
    created_by    integer REFERENCES ui_users(id) ON DELETE SET NULL,
    created_at    timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, name)
);

CREATE TABLE IF NOT EXISTS audit_runs (
    id              serial PRIMARY KEY,
    target_id       integer NOT NULL REFERENCES audit_targets(id) ON DELETE CASCADE,
    created_by      integer REFERENCES ui_users(id) ON DELETE SET NULL,
    started_at      timestamptz NOT NULL DEFAULT now(),
    score           smallint NOT NULL CHECK (score BETWEEN 0 AND 100),
    band            text NOT NULL,
    severity_counts jsonb NOT NULL,
    domain_scores   jsonb NOT NULL,
    coverage        jsonb NOT NULL,     -- {counts, ledger, frameworks}
    findings        jsonb NOT NULL,
    device          jsonb NOT NULL,
    notes           jsonb NOT NULL,
    traffic         jsonb NOT NULL,
    snapshot        jsonb NOT NULL,     -- redacted normalised config, kept for drift (phase B)
    report_id       integer REFERENCES generated_reports(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS audit_runs_target_idx ON audit_runs (target_id, started_at DESC);

-- ss_ai_ro must have no access to audit targets or runs: runs describe customer weaknesses
-- (defence in depth: it has no grant today, this makes sure a future blanket grant or PUBLIC
-- default cannot expose them).
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ss_ai_ro') THEN
        REVOKE ALL ON audit_targets, audit_runs FROM ss_ai_ro;
        REVOKE ALL ON audit_targets, audit_runs FROM PUBLIC;
    END IF;
END
$$;
