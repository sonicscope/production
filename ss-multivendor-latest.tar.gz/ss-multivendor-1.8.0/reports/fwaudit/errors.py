"""Errors whose message is safe to show to the user."""


class ConfigError(ValueError):
    """The uploaded file cannot be analysed (too large, not this vendor's format, ...)."""
