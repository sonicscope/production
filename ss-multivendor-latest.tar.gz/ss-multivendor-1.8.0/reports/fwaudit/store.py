"""Persistence for audit targets and runs: a pure DB layer over a psycopg2 cursor.

No Flask, and nothing here commits: the caller owns the transaction.
"""
from __future__ import annotations

import json

from reports.fwaudit import framework as fw
from reports.fwaudit.engine import SUPPORTED_VENDORS

NAME_MAX = 120
# Audit vendor -> the collector's sensors.vendor value for the same firewall family.
SENSOR_VENDOR = {'fortigate': 'fortinet', 'sonicwall': 'sonicwall', 'paloalto': 'paloalto',
                 'sophos': 'sophos', 'opnsense': 'opnsense'}
KEEP_RUNS = 24            # runs kept per target; older ones are pruned on insert


def _dicts(cur) -> list[dict]:
    names = [d[0] for d in cur.description]
    return [dict(zip(names, row)) for row in cur.fetchall()]


def clean_name(raw) -> str:
    name = ' '.join((raw or '').split())
    if not 1 <= len(name) <= NAME_MAX:
        raise ValueError(f'Enter a name (up to {NAME_MAX} characters).')
    return name


def create_target(cur, *, tenant_id: int, name: str, vendor: str, sensor_id: int | None,
                  created_by: int | None) -> int:
    name = clean_name(name)
    if vendor not in SUPPORTED_VENDORS:
        raise ValueError('Choose a supported vendor.')
    if sensor_id is not None:
        cur.execute('SELECT vendor FROM sensors WHERE id = %s AND tenant_id = %s',
                    (sensor_id, tenant_id))
        row = cur.fetchone()
        if row is None:
            raise ValueError('That collector sensor does not belong to this customer.')
        if row[0] != SENSOR_VENDOR.get(vendor):
            raise ValueError('That collector sensor receives logs from a different firewall vendor.')
    cur.execute('SELECT 1 FROM audit_targets WHERE tenant_id = %s AND name = %s',
                (tenant_id, name))
    if cur.fetchone() is not None:
        raise ValueError('This customer already has a firewall with that name.')
    cur.execute('INSERT INTO audit_targets (tenant_id, name, vendor, sensor_id, created_by) '
                'VALUES (%s, %s, %s, %s, %s) RETURNING id',
                (tenant_id, name, vendor, sensor_id, created_by))
    return cur.fetchone()[0]


def sensor_ok(cur, sensor_id: int, tenant_id: int, vendor: str) -> bool:
    """The linked sensor still belongs to the customer and logs the same vendor family."""
    cur.execute('SELECT vendor FROM sensors WHERE id = %s AND tenant_id = %s',
                (sensor_id, tenant_id))
    row = cur.fetchone()
    return row is not None and row[0] == SENSOR_VENDOR.get(vendor)


def get_target(cur, target_id: int) -> dict | None:
    cur.execute('SELECT t.id, t.tenant_id, tn.name AS tenant_name, t.name, t.vendor, '
                't.sensor_id, t.created_at FROM audit_targets t '
                'JOIN tenants tn ON tn.id = t.tenant_id WHERE t.id = %s', (target_id,))
    rows = _dicts(cur)
    return rows[0] if rows else None


def list_targets(cur, tenant_ids: list[int]) -> list[dict]:
    """Targets of the given tenants, each with its latest run's score."""
    cur.execute(
        'SELECT t.id, t.tenant_id, tn.name AS tenant_name, t.name, t.vendor, t.sensor_id, '
        'r.id AS run_id, r.started_at, r.score, r.band, r.report_id '
        'FROM audit_targets t JOIN tenants tn ON tn.id = t.tenant_id '
        'LEFT JOIN LATERAL (SELECT id, started_at, score, band, report_id FROM audit_runs '
        '  WHERE target_id = t.id ORDER BY started_at DESC, id DESC LIMIT 1) r ON true '
        'WHERE t.tenant_id = ANY(%s) ORDER BY lower(tn.name), lower(t.name)', (list(tenant_ids),))
    return _dicts(cur)


def delete_target(cur, target_id: int) -> None:
    cur.execute('DELETE FROM audit_targets WHERE id = %s', (target_id,))


def list_runs(cur, target_id: int) -> list[dict]:
    cur.execute('SELECT id, started_at, score, band, severity_counts, report_id '
                'FROM audit_runs WHERE target_id = %s ORDER BY started_at DESC, id DESC '
                'LIMIT %s', (target_id, KEEP_RUNS))
    return _dicts(cur)


def insert_run(cur, target_id: int, user_id: int | None, result: dict) -> int:
    """Store one audit result and prune this target's runs beyond KEEP_RUNS."""
    cur.execute(
        'INSERT INTO audit_runs (target_id, created_by, score, band, severity_counts, '
        'domain_scores, coverage, findings, device, notes, traffic, snapshot) '
        'VALUES (%s, %s, %s, %s, %s::jsonb, %s::jsonb, %s::jsonb, %s::jsonb, %s::jsonb, '
        '%s::jsonb, %s::jsonb, %s::jsonb) RETURNING id',
        (target_id, user_id, result['score'], result['band'],
         json.dumps(result['severity_counts']), json.dumps(result['domain_scores']),
         json.dumps({'counts': result['counts'], 'ledger': result['ledger'],
                     'frameworks': result['frameworks']}),
         json.dumps(result['findings']), json.dumps(result['device']),
         json.dumps(result['notes']), json.dumps(result['traffic']),
         json.dumps(result['snapshot'], default=str)))
    run_id = cur.fetchone()[0]
    cur.execute('DELETE FROM audit_runs WHERE target_id = %s AND id NOT IN '
                '(SELECT id FROM audit_runs WHERE target_id = %s '
                ' ORDER BY started_at DESC, id DESC LIMIT %s)',
                (target_id, target_id, KEEP_RUNS))
    return run_id


def set_run_report(cur, run_id: int, report_id: int) -> None:
    cur.execute('UPDATE audit_runs SET report_id = %s WHERE id = %s', (report_id, run_id))


def get_run(cur, run_id: int) -> dict | None:
    """A run with its target and customer; the stored result is rebuilt in engine shape."""
    cur.execute(
        'SELECT r.id, r.target_id, r.started_at, r.score, r.band, r.severity_counts, '
        'r.domain_scores, r.coverage, r.findings, r.device, r.notes, r.traffic, r.report_id, '
        't.name AS target_name, t.vendor, t.tenant_id, tn.name AS tenant_name '
        'FROM audit_runs r JOIN audit_targets t ON t.id = r.target_id '
        'JOIN tenants tn ON tn.id = t.tenant_id WHERE r.id = %s', (run_id,))
    rows = _dicts(cur)
    if not rows:
        return None
    run = rows[0]
    cov = run.pop('coverage')
    run.update(counts=cov['counts'], ledger=cov['ledger'], frameworks=cov['frameworks'],
               coverage=fw.coverage(cov['counts']))
    return run
