"""Well-known risky ports and predefined service names (vendor-neutral)."""
RISKY_PORTS = {
    21: 'FTP', 23: 'Telnet', 69: 'TFTP', 135: 'MS-RPC', 139: 'NetBIOS', 161: 'SNMP',
    445: 'SMB', 1433: 'MS-SQL', 3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL',
    5900: 'VNC', 5985: 'WinRM', 6379: 'Redis', 9200: 'Elasticsearch', 27017: 'MongoDB',
}
# Predefined service names used by vendors -> destination ports (upper-case keys).
NAMED_PORTS = {
    'FTP': (21,), 'TELNET': (23,), 'TFTP': (69,), 'SNMP': (161,), 'SMB': (445,),
    'RDP': (3389,), 'VNC': (5900,), 'MYSQL': (3306,), 'MS-SQL': (1433,), 'MSSQL': (1433,),
    'POSTGRESQL': (5432,), 'NETBIOS': (139,), 'WINRM': (5985,), 'REDIS': (6379,),
    'DCE-RPC': (135,), 'MS-RPC': (135,),
    'SSH': (22,), 'HTTP': (80,), 'HTTPS': (443,), 'DNS': (53,), 'SMTP': (25,),
}
ANY_NAMES = frozenset({'all', 'any', 'all_tcp', 'all_udp', 'all-services', '*'})


ALL_PORTS = ((1, 65535),)


def port_number(s: str) -> int | None:
    """A destination port from text; None unless it is plain ASCII digits within 0-65535."""
    if isinstance(s, str) and s.isascii() and s.isdecimal():
        n = int(s)
        if n <= 65535:
            return n
    return None


def ports_for(names, custom=None):
    """Return (intervals: list[(lo, hi)], any_service: bool, unknown: list[str]).

    ``custom`` maps a service name to a tuple of (lo, hi) port intervals, or to None when the
    service could not be read (then the name is reported as unknown, never as "no ports").
    """
    ranges, unknown, anyv = [], [], False
    custom = custom or {}
    for n in names:
        key = n.upper()
        if n.lower() in ANY_NAMES:
            anyv = True
        elif n in custom:
            if custom[n] is None:
                unknown.append(n)
            else:
                ranges.extend(custom[n])
        elif key in NAMED_PORTS:
            ranges.extend((p, p) for p in NAMED_PORTS[key])
        elif (p := port_number(n)) is not None:
            ranges.append((p, p))
        else:
            unknown.append(n)
    return ranges, anyv, unknown


def risky_in(ranges) -> list:
    """Risky ports that fall inside any of the (lo, hi) intervals, sorted."""
    return sorted(p for p in RISKY_PORTS if any(lo <= p <= hi for lo, hi in ranges))


def covers_all_ports(ranges) -> bool:
    """True when the intervals together cover every port 1-65535."""
    nxt = 1
    for lo, hi in sorted(ranges):
        if lo > nxt:
            return False
        nxt = max(nxt, hi + 1)
        if nxt > 65535:
            return True
    return False
