"""Run an audit: parse -> checks -> JSON-safe result."""
from __future__ import annotations

from reports.fwaudit import checks as _checks      # noqa: F401  (registers every check)
from reports.fwaudit import compliance, framework as fw, snapshot
from reports.fwaudit.parsers import fortigate, sonicwall

PARSERS = {'fortigate': fortigate.normalize, 'sonicwall': sonicwall.normalize}
SUPPORTED_VENDORS = tuple(PARSERS)


def run(vendor: str, text: str, hits=None, window_days: int = 90) -> dict:
    """Audit one configuration export. Raises ValueError for an unsupported vendor or a file
    the parser cannot read at all."""
    if vendor not in PARSERS:
        raise ValueError(f'unsupported vendor: {vendor}')
    cfg = PARSERS[vendor](text)
    res = fw.run_checks(cfg, hits)
    return {
        'vendor': vendor,
        'device': dict(cfg.device),
        'notes': list(cfg.notes),
        'score': res['score'], 'band': res['band'],
        'domain_scores': res['domain_scores'],
        'severity_counts': res['severity_counts'],
        'counts': res['counts'], 'coverage': res['coverage'],
        'ledger': res['ledger'],
        'findings': [f.to_dict() for f in res['findings']],
        'frameworks': compliance.matrix(res['ledger']),
        'traffic': ({'available': True, 'window_days': hits.window_days,
                     'events': hits.total_events} if hits is not None
                    else {'available': False, 'window_days': window_days, 'events': 0}),
        'snapshot': snapshot.to_snapshot(cfg),
    }
