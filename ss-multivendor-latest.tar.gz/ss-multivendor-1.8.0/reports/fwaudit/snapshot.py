"""Redacted, JSON-safe snapshot of a NormalizedConfig (kept for drift in a later phase)."""
from __future__ import annotations

from dataclasses import asdict

MAX_RULES = 5000


def to_snapshot(cfg) -> dict:
    """Secrets never reach the model, so this only needs to be bounded and serialisable."""
    return {
        'vendor': cfg.vendor,
        'device': dict(cfg.device),
        'facts': {k: {'value': f.value, 'src': f.src} for k, f in sorted(cfg.facts.items())},
        'rules': [asdict(r) for r in cfg.rules[:MAX_RULES]],
        'interfaces': [asdict(i) for i in cfg.interfaces],
        'nat': [asdict(n) for n in cfg.nat],
        'vpn': [asdict(v) for v in cfg.vpn],
        'sections': sorted(cfg.sections),
        'notes': list(cfg.notes),
    }
