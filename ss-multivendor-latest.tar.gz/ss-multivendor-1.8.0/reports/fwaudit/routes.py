"""Firewall Audit routes: targets, config upload + run, results, PDF.

Staff only. Customers never see audits: every route 404s for them, and the PDFs are hidden
from the customer portal (see reports/web/app.py INTERNAL_REPORT_TYPES).
"""
from __future__ import annotations

import logging
import os
import threading
import time
import traceback

from flask import Blueprint, Flask, abort, flash, redirect, request

from reports.ai import audit
from reports.ai.routes import Deps
from reports.fwaudit import engine, page, store, traffic
from reports.fwaudit.errors import ConfigError

log = logging.getLogger('ss.fwaudit.routes')

RUN_PER_MIN = 5
MAX_UPLOAD = 5 * 1024 * 1024        # matches the app-wide MAX_CONTENT_LENGTH
WINDOWS = (30, 90, 180)
_GENERIC_ERROR = 'Something went wrong. The error was logged.'


class _ParseFailed(Exception):
    """engine.run failed on the upload; already logged without its content."""


def register_fwaudit(app: Flask, deps: Deps) -> None:
    bp = Blueprint('fwaudit', __name__)
    inflight: dict[int, int] = {}
    inflight_lock = threading.Lock()
    app.extensions['fwaudit_inflight'] = inflight

    def staff_only() -> None:
        if deps.current_user_role() not in ('admin', 'user'):
            abort(404)

    def load_target(target_id: int):
        cur = deps.get_db().cursor()
        target = store.get_target(cur, target_id)
        if target is None:
            abort(404)
        deps.require_tenant_access(target['tenant_id'])
        return cur, target

    def load_run(run_id: int):
        cur = deps.get_db().cursor()
        run = store.get_run(cur, run_id)
        if run is None:
            abort(404)
        deps.require_tenant_access(run['tenant_id'])
        return cur, run

    def recent_starts(cur, user_id: int) -> int:
        cur.execute("SELECT count(*) FROM ai_audit WHERE kind = 'fwaudit_start' "
                    "AND user_id = %s AND ts > now() - interval '1 minute'", (user_id,))
        return cur.fetchone()[0]

    # ── pages ────────────────────────────────────────────────────────────────
    @bp.get('/audit')
    def audit_index():
        staff_only()
        cur = deps.get_db().cursor()
        tenant_ids = list(deps.user_tenant_ids())
        targets = store.list_targets(cur, tenant_ids)
        cur.execute('SELECT id, name FROM tenants WHERE id = ANY(%s) ORDER BY lower(name)',
                    (tenant_ids,))
        tenants = cur.fetchall()
        cur.execute('SELECT id, tenant_id, name, vendor FROM sensors WHERE tenant_id = ANY(%s) '
                    'ORDER BY lower(name)', (tenant_ids,))
        sensors = cur.fetchall()
        return deps.page('Firewall Audit', page.index_html(targets, tenants, sensors),
                         active='audit')

    @bp.get('/audit/targets/<int:target_id>')
    def audit_target(target_id: int):
        staff_only()
        cur, target = load_target(target_id)
        return deps.page('Firewall Audit', page.target_html(target, store.list_runs(cur, target_id)),
                         active='audit')

    @bp.get('/audit/runs/<int:run_id>')
    def audit_run(run_id: int):
        staff_only()
        _cur, run = load_run(run_id)
        return deps.page('Firewall Audit', page.run_html(
            run, sev=request.args.get('sev', ''), domain=request.args.get('domain', '')),
            active='audit')

    @bp.get('/audit/runs/<int:run_id>/pdf')
    def audit_pdf(run_id: int):
        staff_only()
        _cur, run = load_run(run_id)
        if not run['report_id']:
            abort(404)
        return redirect(f"/reports/{int(run['report_id'])}/download")

    # ── actions ──────────────────────────────────────────────────────────────
    @bp.post('/audit/targets')
    def audit_target_create():
        staff_only()
        deps.check_csrf()
        conn = deps.get_db()
        cur = conn.cursor()
        try:
            tenant_id = int(request.form.get('tenant_id', ''))
            sensor_raw = request.form.get('sensor_id', '').strip()
            sensor_id = int(sensor_raw) if sensor_raw else None
        except ValueError:
            abort(400)
        deps.require_tenant_access(tenant_id)
        try:
            tid = store.create_target(
                cur, tenant_id=tenant_id, name=request.form.get('name', ''),
                vendor=request.form.get('vendor', ''), sensor_id=sensor_id,
                created_by=deps.current_user_id())
            audit.log_event(cur, kind='fwaudit_target', user_id=deps.current_user_id(),
                            tenant_id=tenant_id, provider=None, model=None, row_count=tid)
            conn.commit()
        except ValueError as exc:
            conn.rollback()
            flash(str(exc), 'error')
            return redirect('/audit')
        flash('Firewall added. Upload its configuration to run the first audit.', 'success')
        return redirect(f'/audit/targets/{tid}')

    @bp.post('/audit/targets/<int:target_id>/delete')
    def audit_target_delete(target_id: int):
        staff_only()
        deps.check_csrf()
        conn = deps.get_db()
        cur, target = load_target(target_id)
        store.delete_target(cur, target_id)
        audit.log_event(cur, kind='fwaudit_target_delete', user_id=deps.current_user_id(),
                        tenant_id=target['tenant_id'], provider=None, model=None,
                        row_count=target_id)
        conn.commit()
        flash('Firewall removed. Generated PDFs stay in the Reports list.', 'success')
        return redirect('/audit')

    @bp.post('/audit/targets/<int:target_id>/run')
    def audit_run_create(target_id: int):
        staff_only()
        deps.check_csrf()
        conn = deps.get_db()
        cur, target = load_target(target_id)
        back = f'/audit/targets/{target_id}'
        uid = deps.current_user_id()
        upload = request.files.get('config')
        if upload is None or not upload.filename:
            flash('Choose a configuration file to audit.', 'error')
            return redirect(back)
        try:
            window = int(request.form.get('window_days', '90'))
        except ValueError:
            window = 90
        window = window if window in WINDOWS else 90

        # Attempts are counted before any work, so failed or abandoned runs also hit the limit.
        if recent_starts(cur, uid) >= RUN_PER_MIN:
            abort(429)
        with inflight_lock:
            if inflight.get(uid, 0) >= 1:
                abort(429)
            inflight[uid] = 1
        started = time.monotonic()
        report_path = None
        try:
            audit.log_event(cur, kind='fwaudit_start', user_id=uid,
                            tenant_id=target['tenant_id'], provider=None, model=None)
            conn.commit()
            raw = upload.stream.read(MAX_UPLOAD + 1)
            if len(raw) > MAX_UPLOAD:
                flash('That file is too large (limit 5 MB).', 'error')
                return redirect(back)
            hits, sensor_note = None, None
            if target['sensor_id']:
                # Re-checked at run time: the sensor may have moved since the target was made.
                if store.sensor_ok(cur, target['sensor_id'], target['tenant_id'], target['vendor']):
                    hits = traffic.load(cur, tenant_id=target['tenant_id'],
                                        sensor_id=target['sensor_id'], window_days=window)
                else:
                    sensor_note = ('The linked collector sensor no longer matches this customer '
                                   'or vendor, so its logs were not used.')
            try:
                result = engine.run(target['vendor'], raw.decode('utf-8', errors='replace'),
                                    hits, window)
            except ConfigError:
                raise
            except Exception as exc:
                # The message of a parse error can quote the uploaded config: log only the
                # exception type and where it was raised, never its text or a traceback.
                frame = traceback.extract_tb(exc.__traceback__)[-1]
                log.error('firewall audit could not process the upload: %s at %s:%s',
                          type(exc).__name__, os.path.basename(frame.filename), frame.lineno)
                raise _ParseFailed() from None
            if sensor_note:
                result['notes'].append(sensor_note)
            msp_id = deps.msp_profile_for_tenant(target['tenant_id'])
            run_id = store.insert_run(cur, target['id'], uid, result)
            if msp_id:
                from reports.generator import generate_audit_report
                report_path, report_id = generate_audit_report(
                    conn, target['tenant_id'], msp_id, target['name'], result,
                    deps.output_dir(), commit=False)
                store.set_run_report(cur, run_id, report_id)
            audit.log_event(cur, kind='fwaudit', user_id=uid, tenant_id=target['tenant_id'],
                            provider=None, model=None, row_count=len(result['findings']),
                            duration_ms=int((time.monotonic() - started) * 1000))
            conn.commit()
        except ConfigError as exc:
            conn.rollback()
            flash(f'Could not read this file: {exc}.', 'error')
            return redirect(back)
        except _ParseFailed:
            conn.rollback()
            flash(_GENERIC_ERROR, 'error')
            return redirect(back)
        except Exception:
            conn.rollback()
            log.exception('firewall audit run failed')
            if report_path:
                try:
                    os.remove(report_path)
                except OSError:
                    log.exception('could not remove orphan audit PDF %s', report_path)
            flash(_GENERIC_ERROR, 'error')
            return redirect(back)
        finally:
            with inflight_lock:
                inflight.pop(uid, None)
        if not msp_id:
            flash('Audit saved, but no PDF was made: no MSP profile is configured for this '
                  'customer.', 'error')
        return redirect(f'/audit/runs/{run_id}')

    app.register_blueprint(bp)
