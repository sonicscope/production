"""Check registry, outcomes, coverage ledger and scoring (Firewall Audit v2)."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field, asdict
from enum import IntEnum

from reports.fwaudit import compliance

log = logging.getLogger('ss.fwaudit')

PASSED, FINDING, NA, UNDETERMINED, SKIPPED = (
    'passed', 'finding', 'not_applicable', 'could_not_determine', 'skipped')
STATES = (PASSED, FINDING, NA, UNDETERMINED, SKIPPED)
DOMAINS = {
    'MGT': 'Management plane', 'RUL': 'Rule base', 'EXP': 'Inbound exposure',
    'VPN': 'VPN and crypto', 'THR': 'Threat prevention', 'SEG': 'Segmentation',
    'RES': 'Resilience and hygiene', 'TRF': 'Traffic-aware',
}
# Each finding multiplies the score by its factor (critical 0.80, high 0.90, medium 0.95,
# low 0.98, info 1.0). Diminishing returns: a flat sum floored at 0 made three critical and four
# high findings score 0 even when every area scored 65-100, and hid how much worse one more
# finding was. The factors are the same size as the old penalties; the weights still need an
# independent security review before release.
_FACTOR = {1: 0.80, 2: 0.90, 3: 0.95, 4: 0.98, 5: 1.0}


class Severity(IntEnum):
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4
    INFO = 5


@dataclass(frozen=True)
class CheckMeta:
    id: str
    title: str
    severity: Severity
    vendors: frozenset | None = None          # None = every vendor
    needs_logs: bool = False
    frameworks: dict = field(default_factory=dict)

    @property
    def domain(self) -> str:
        return self.id.split('-')[1]


@dataclass
class Finding:
    check_id: str
    domain: str
    title: str
    severity: int
    description: str
    evidence: list
    current: str
    recommended: str
    remediation: str
    frameworks: dict
    needs_validation: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Outcome:
    state: str
    findings: list = field(default_factory=list)
    reason: str = ''


def passed() -> Outcome:
    return Outcome(PASSED)


def undetermined(reason: str) -> Outcome:
    return Outcome(UNDETERMINED, reason=reason)


def not_applicable(reason: str) -> Outcome:
    return Outcome(NA, reason=reason)


@dataclass
class Ctx:
    cfg: object
    hits: object = None            # traffic.RuleHits | None
    meta: CheckMeta | None = None

    @property
    def vendor(self) -> str:
        return self.cfg.vendor

    def fail(self, *, description: str, evidence=(), current: str = '', recommended: str = '',
             fix=None, severity: Severity | None = None, needs_validation: bool = False,
             title: str | None = None) -> Finding:
        m = self.meta
        if isinstance(fix, dict):
            fix_text = fix.get(self.vendor) or fix.get('*', '')
        else:
            fix_text = fix or ''
        return Finding(
            check_id=m.id, domain=m.domain, title=title or m.title,
            severity=int(severity or m.severity), description=description,
            evidence=list(evidence)[:25], current=current, recommended=recommended,
            remediation=fix_text,
            frameworks=dict(m.frameworks) or compliance.tags_for(m.id),
            needs_validation=needs_validation)


REGISTRY: dict = {}


def check(id: str, title: str, severity: Severity, *, vendors=None, needs_logs: bool = False,
          frameworks=None):
    """Register a check: fn(ctx) -> Outcome."""
    def deco(fn):
        if id in REGISTRY:
            raise ValueError(f'duplicate check id {id}')
        parts = id.split('-')
        if len(parts) != 3 or parts[0] != 'FWA' or parts[1] not in DOMAINS:
            raise ValueError(f'bad check id {id}')
        REGISTRY[id] = (CheckMeta(id, title, severity,
                                  frozenset(vendors) if vendors else None, needs_logs,
                                  dict(frameworks or {})), fn)
        return fn
    return deco


def score(findings: list, domain: str | None = None) -> int:
    value = 100.0
    for f in findings:
        if domain is None or f.domain == domain:
            value *= _FACTOR[f.severity]
    return int(value + 0.5)


def band(value: int) -> str:
    return ('Excellent' if value >= 90 else 'Good' if value >= 70
            else 'Needs attention' if value >= 50 else 'At risk')


LIMITED_COVERAGE = 'Limited coverage'
MIN_COVERAGE_PCT = 50        # below this share of assessed checks the band is withheld


def coverage(counts: dict) -> dict:
    """How much of the audit actually ran: checks that passed or found something, out of the
    checks that apply to this vendor (not-applicable ones are left out)."""
    assessed = int(counts.get(PASSED, 0)) + int(counts.get(FINDING, 0))
    total = sum(int(counts.get(s, 0)) for s in STATES if s != NA)
    return {'assessed': assessed, 'total': total,
            'pct': round(100 * assessed / total) if total else 0}


def headline_band(value: int, cov: dict) -> str:
    return band(value) if cov['pct'] >= MIN_COVERAGE_PCT else LIMITED_COVERAGE


def run_checks(cfg, hits=None, registry=None) -> dict:
    """Run every registered check; each ends in exactly one ledger state."""
    reg = REGISTRY if registry is None else registry
    ledger, findings = [], []
    for cid in sorted(reg):
        meta, fn = reg[cid]
        entry = {'check_id': cid, 'domain': meta.domain, 'title': meta.title}
        if meta.vendors and cfg.vendor not in meta.vendors:
            entry.update(state=NA, reason=f'does not apply to {cfg.vendor}')
        elif meta.needs_logs and hits is None:
            entry.update(state=SKIPPED, reason='no log data for this firewall')
        else:
            try:
                out = fn(Ctx(cfg, hits, meta))
                if out.state not in STATES or (out.state == FINDING and not out.findings):
                    raise ValueError('invalid outcome')
                entry.update(state=out.state, reason=out.reason)
                findings.extend(out.findings)
            except Exception:                       # a broken check must not sink the audit
                log.exception('check %s failed', cid)
                entry.update(state=UNDETERMINED, reason='the check hit an internal error')
        ledger.append(entry)
    findings.sort(key=lambda f: (f.severity, f.check_id))
    counts = {s: sum(1 for e in ledger if e['state'] == s) for s in STATES}
    cov = coverage(counts)
    assessed_domains = {e['domain'] for e in ledger if e['state'] in (PASSED, FINDING)}
    return {
        'ledger': ledger, 'findings': findings, 'counts': counts, 'coverage': cov,
        'score': score(findings), 'band': headline_band(score(findings), cov),
        # A domain where no check passed or found anything is "not assessed" (None), not 100.
        'domain_scores': {d: (score(findings, d) if d in assessed_domains else None)
                          for d in DOMAINS},
        'severity_counts': {s.name.lower(): sum(1 for f in findings if f.severity == s)
                            for s in Severity},
    }
