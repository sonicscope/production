"""Framework tags for checks and the per-framework coverage matrix.

These are guidance mappings to support a review, not a certification. Frameworks: NIST CSF
2.0, NIST SP 800-53 Rev. 5, ISO 27001:2022, PCI DSS v4.0, CIS Controls v8 and POPIA s19. Tags
are domain-level defaults with per-check overrides (an override replaces that framework's
list for that check). The vendor-specific CIS *Benchmarks* (FortiGate, PAN-OS) are not tagged:
add them only after checking each control id against the published benchmark.
"""
from __future__ import annotations

FRAMEWORKS = {
    'nist': 'NIST CSF 2.0', 'sp80053': 'NIST SP 800-53 Rev. 5', 'iso': 'ISO 27001:2022',
    'pci': 'PCI DSS v4.0', 'cis': 'CIS Controls v8', 'popia': 'POPIA',
}

# Short labels for the per-finding tag line (the full names are in FRAMEWORKS).
SHORT = {'nist': 'NIST CSF', 'sp80053': '800-53', 'iso': 'ISO 27001', 'pci': 'PCI DSS',
         'cis': 'CIS v8', 'popia': 'POPIA'}

DOMAIN_TAGS = {
    'MGT': {'nist': ['PR.AA-03', 'PR.PS-01'], 'iso': ['A.8.5', 'A.8.9'],
            'pci': ['2.2.1', '8.4.2'], 'popia': ['s19'],
            'sp80053': ['AC-2', 'AC-17', 'CM-6', 'IA-2', 'IA-5'], 'cis': ['4.1', '4.2', '6.5']},
    'RUL': {'nist': ['PR.IR-01'], 'iso': ['A.8.20', 'A.8.22'],
            'pci': ['1.2.5', '1.2.7', '1.3.1', '1.3.2'], 'popia': ['s19'],
            'sp80053': ['AC-4', 'CM-6', 'SC-7'], 'cis': ['12.2', '13.4']},
    'EXP': {'nist': ['PR.IR-01'], 'iso': ['A.8.20', 'A.8.21'],
            'pci': ['1.3.1', '1.4.2'], 'popia': ['s19'],
            'sp80053': ['AC-4', 'CM-7', 'SC-7'], 'cis': ['12.2', '13.4']},
    'VPN': {'nist': ['PR.DS-02'], 'iso': ['A.8.24'], 'pci': ['4.2.1'], 'popia': ['s19'],
            'sp80053': ['AC-17', 'SC-8', 'SC-12', 'SC-13'], 'cis': ['3.10', '12.6']},
    'THR': {'nist': ['DE.CM-01'], 'iso': ['A.8.7', 'A.8.16'], 'pci': ['1.4.1', '5.2.1'],
            'popia': ['s19'],
            'sp80053': ['SC-7', 'SI-3', 'SI-4'], 'cis': ['10.1', '13.8']},
    'SEG': {'nist': ['PR.IR-01'], 'iso': ['A.8.22'], 'pci': ['1.2.1', '1.4.1'],
            'popia': ['s19'],
            'sp80053': ['AC-4', 'SC-7', 'SC-32'], 'cis': ['12.2', '13.4']},
    'RES': {'nist': ['PR.PS-04', 'DE.CM-01'], 'iso': ['A.8.8', 'A.8.15', 'A.8.17'],
            'pci': ['10.2.1', '10.6.1'], 'popia': ['s19'],
            'sp80053': ['AU-4', 'AU-8', 'AU-9', 'SC-5', 'SI-2'], 'cis': ['8.2', '8.4', '12.1']},
    'TRF': {'nist': ['DE.CM-01', 'ID.RA-01'], 'iso': ['A.8.9', 'A.8.16'],
            'pci': ['1.2.7', '10.4.1'], 'popia': ['s19'],
            'sp80053': ['AU-6', 'CA-7', 'SI-4'], 'cis': ['13.6', '13.4']},
}

CHECK_TAGS = {
    'FWA-MGT-001': {'sp80053': ['AC-11', 'AC-12'], 'cis': ['4.3']},
    'FWA-MGT-002': {'nist': ['PR.AA-03'], 'iso': ['A.8.5'], 'pci': ['8.4.2'],
                    'sp80053': ['IA-2'], 'cis': ['6.5']},
    'FWA-MGT-003': {'sp80053': ['AC-7'], 'cis': ['4.1']},
    'FWA-MGT-004': {'sp80053': ['CM-7', 'SC-8'], 'cis': ['4.8', '12.6']},
    'FWA-MGT-005': {'sp80053': ['CM-7', 'SC-8'], 'cis': ['12.6']},
    'FWA-MGT-006': {'sp80053': ['IA-5', 'CM-6'], 'cis': ['4.7', '12.6']},
    'FWA-MGT-007': {'sp80053': ['AC-2', 'IA-5'], 'cis': ['4.7', '5.4']},
    'FWA-MGT-008': {'sp80053': ['AC-8'], 'cis': []},
    'FWA-MGT-009': {'sp80053': ['IA-5'], 'cis': ['5.2']},
    'FWA-MGT-010': {'sp80053': ['AC-17', 'CM-7', 'SC-7'], 'cis': ['4.8', '12.3']},
    'FWA-MGT-011': {'sp80053': ['SC-8', 'SC-13'], 'cis': ['3.10', '12.6']},
    'FWA-MGT-012': {'sp80053': ['CM-7'], 'cis': ['4.8']},
    'FWA-RUL-005': {'sp80053': ['AU-2', 'AU-12'], 'cis': ['8.2', '13.6']},
    'FWA-RES-001': {'sp80053': ['SC-5'], 'cis': []},
    'FWA-RES-002': {'sp80053': ['CP-10'], 'cis': []},
    'FWA-RES-003': {'nist': ['PR.PS-04'], 'iso': ['A.8.17'], 'pci': ['10.6.1'],
                    'sp80053': ['AU-8'], 'cis': ['8.4']},
    'FWA-RES-004': {'nist': ['PR.PS-04'], 'iso': ['A.8.15'], 'pci': ['10.2.1'],
                    'sp80053': ['AU-4', 'AU-9'], 'cis': ['8.9']},
    'FWA-RES-005': {'sp80053': ['SA-22', 'SI-2'], 'cis': ['12.1']},
}


def tags_for(check_id: str) -> dict:
    """Framework tags (framework -> list of control ids) for a check id like FWA-MGT-001."""
    domain = check_id.split('-')[1]
    tags = {k: list(v) for k, v in DOMAIN_TAGS.get(domain, {}).items()}
    for framework, controls in CHECK_TAGS.get(check_id, {}).items():
        tags[framework] = list(controls)             # an override replaces that framework's list
    return tags


def _status(states: list) -> str:
    if 'finding' in states:
        return 'finding'
    unsure = 'could_not_determine' in states or 'skipped' in states
    if 'passed' in states and not unsure:
        return 'passed'
    # Skipped (no log data) next to a pass means part of the control was not checked.
    if 'could_not_determine' in states or 'passed' in states:
        return 'undetermined'
    return 'not_assessed'


_ORDER = {'finding': 0, 'undetermined': 1, 'passed': 2, 'not_assessed': 3}


def matrix(ledger: list) -> list:
    """Per framework, per control: the worst result among the checks mapped to it.

    status: finding (any check failed) > undetermined (no failure but something could not be
    determined, or was skipped next to a pass) > passed (every mapped check that applies
    passed) > not_assessed (only skipped or not applicable).
    """
    rows = []
    for key, label in FRAMEWORKS.items():
        by_control: dict = {}
        for entry in ledger:
            for control in tags_for(entry['check_id']).get(key, []):
                by_control.setdefault(control, []).append(entry['state'])
        if not by_control:
            continue
        controls = [{'control': c, 'checks': len(states), 'status': _status(states),
                     'findings': states.count('finding')} for c, states in by_control.items()]
        controls.sort(key=lambda r: (_ORDER[r['status']], r['control']))
        summary = {st: sum(1 for r in controls if r['status'] == st) for st in _ORDER}
        rows.append({'key': key, 'label': label, 'controls': controls, 'summary': summary})
    return rows
