"""Shape an audit result into bounded, render-ready data for the PDF (pure, no rendering)."""
from __future__ import annotations

from collections import Counter

from reports.fwaudit import compliance, framework as fw

MAX_FINDINGS = 200
MAX_EVIDENCE = 25
EVIDENCE_CHARS = 300
TEXT_CHARS = 700
SEVERITY_LABEL = {1: 'Critical', 2: 'High', 3: 'Medium', 4: 'Low', 5: 'Info'}
STATE_LABEL = {
    fw.PASSED: 'Passed', fw.FINDING: 'Finding', fw.NA: 'Not applicable',
    fw.UNDETERMINED: 'Could not determine', fw.SKIPPED: 'Skipped (no log data)',
}


def clip(value, limit: int) -> str:
    text = '' if value is None else str(value)
    return text if len(text) <= limit else text[:limit - 1] + '…'


def _finding(f: dict) -> dict:
    return {
        'check_id': f['check_id'], 'domain': f['domain'],
        'domain_label': fw.DOMAINS.get(f['domain'], f['domain']),
        'title': clip(f['title'], 200), 'severity': f['severity'],
        'severity_label': SEVERITY_LABEL.get(f['severity'], '?'),
        'description': clip(f['description'], TEXT_CHARS), 'current': clip(f['current'], 300),
        'recommended': clip(f['recommended'], 300), 'remediation': clip(f['remediation'], TEXT_CHARS),
        'evidence': [clip(e, EVIDENCE_CHARS) for e in f['evidence'][:MAX_EVIDENCE]],
        'evidence_more': max(0, len(f['evidence']) - MAX_EVIDENCE),
        'needs_validation': bool(f.get('needs_validation')),
        'frameworks': {k: [clip(c, 20) for c in v[:6]] for k, v in f['frameworks'].items()},
        'tag_list': [(compliance.SHORT.get(k, k), [clip(c, 20) for c in v[:6]])
                     for k, v in f['frameworks'].items() if v],
    }


def prepare(result: dict) -> dict:
    all_findings = [_finding(f) for f in result['findings']]
    shown = all_findings[:MAX_FINDINGS]
    traffic_findings = [f for f in shown if f['domain'] == 'TRF']
    config_findings = [f for f in shown if f['domain'] != 'TRF']
    groups = []
    for sev in sorted(SEVERITY_LABEL):
        items = [f for f in config_findings if f['severity'] == sev]
        if items:
            groups.append({'severity': sev, 'label': SEVERITY_LABEL[sev], 'findings': items})
    total_checks = len(result['ledger']) or 1
    segments = [{'state': s, 'label': STATE_LABEL[s], 'n': result['counts'].get(s, 0),
                 'pct': round(100 * result['counts'].get(s, 0) / total_checks, 1)}
                for s in fw.STATES]
    reasons = Counter(e['reason'] for e in result['ledger']
                      if e['state'] == fw.UNDETERMINED and e['reason'])
    domains = []
    for code, label in fw.DOMAINS.items():
        value = result['domain_scores'].get(code)         # None or missing = not assessed
        domains.append({'code': code, 'label': label,
                        'score': None if value is None else int(value),
                        'band': None if value is None else fw.band(int(value)),
                        'count': sum(1 for f in all_findings if f['domain'] == code)})
    seen, checklist = set(), []
    for f in shown:
        if f['check_id'] not in seen:
            seen.add(f['check_id'])
            checklist.append({'title': f['title'], 'severity_label': f['severity_label'],
                              'fix': f['remediation'] or f['recommended']})
    return {
        'score': result['score'], 'band': result['band'], 'domains': domains,
        'coverage': fw.coverage(result['counts']),
        'severity_counts': result['severity_counts'], 'segments': segments,
        'total_checks': len(result['ledger']), 'counts': result['counts'],
        'undetermined_reasons': reasons.most_common(8),
        'groups': groups, 'traffic_findings': traffic_findings,
        'top_risks': [f for f in all_findings if f['severity'] <= 2][:5],
        'omitted': max(0, len(all_findings) - len(shown)),
        'frameworks': result['frameworks'],
        'traffic': result['traffic'], 'device': result['device'],
        'notes': [clip(n, 300) for n in result['notes']][:10], 'vendor': result['vendor'],
        'checklist': checklist, 'finding_count': len(all_findings),
    }
