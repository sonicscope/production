"""Vendor-neutral firewall configuration model (Firewall Audit v2)."""
from __future__ import annotations

import ipaddress
from bisect import bisect_right
from dataclasses import dataclass, field

MAX_NETS = 256      # networks per address object and per rule; above this = unknown

# Facts: scalar settings. A key that is missing from NormalizedConfig.facts is UNKNOWN.
# A key set to a Fact(value=None) is known-and-absent.
FACT_KEYS = frozenset({
    'admin.timeout_min', 'admin.mfa', 'admin.lockout', 'admin.banner', 'admin.default_account',
    'admin.telnet', 'admin.snmp_v1v2', 'admin.snmp_default_community', 'admin.api',
    'admin.pw_min_len', 'admin.tls_min', 'admin.https_port_default',
    'services.ips', 'services.av', 'services.url', 'services.dpi_ssl', 'services.botnet',
    'services.geoip', 'services.licence_expired',
    'vpn.ssl_enabled', 'vpn.ssl_mfa', 'vpn.ssl_tls_min',
    'dos.enabled', 'antispoof.enabled', 'ha.enabled', 'ntp.enabled', 'dns.configured',
    'logging.remote', 'logging.local_disk', 'logging.admin_events',
    'system.firmware', 'system.model', 'system.hostname', 'system.config_backup',
    'system.export_epoch',
})


@dataclass(frozen=True)
class Fact:
    value: object = None
    src: str = ''             # path in the original config (evidence)
    known: bool = True


UNKNOWN = Fact(None, '', False)


def fact(value, src: str = '') -> Fact:
    return Fact(value, src, True)


ANY = 'any'


@dataclass
class Rule:
    idx: int                               # position in rule order, 0-based
    rid: str = ''                          # vendor rule id as a string ('' = none)
    name: str = ''
    # Match fields: (ANY,) = any; () = the export did not say (unknown, never "any");
    # otherwise object names, literals, or markers such as ('internet-service',).
    src_zone: tuple = (ANY,)
    dst_zone: tuple = (ANY,)
    src_addr: tuple = (ANY,)
    dst_addr: tuple = (ANY,)
    service: tuple = (ANY,)
    action: str = 'deny'                   # 'allow' | 'deny'
    enabled: bool = True
    log: str = ''                          # 'all' | 'utm' | 'none' | '' (could not tell)
    comment: str = ''
    profiles: dict = field(default_factory=dict)   # {'ips': bool, 'av': bool, 'url': bool}
    schedule: str = ''
    restricted: bool = False               # other match conditions the model omits (users, apps, negation...)
    builtin: bool = False                  # a factory default zone-pair rule, not one an administrator wrote
    generated: bool = False                # created automatically by the firewall (VPN, management, redirect)
    # Hit counters read from the export itself (None = the export does not carry them); times are
    # Unix seconds. Counters cover the time since they were last reset, which the export does not say.
    hits: int | None = None
    last_hit: int | None = None            # 0 = never hit
    created: int | None = None
    families: tuple = ()                   # IP versions the rule matches ('4', '6'); () = not known
    src: str = ''                          # config path
    display: str = ''                      # name for reports when `name` is not unique

    @property
    def label(self) -> str:
        return (self.display or self.name
                or (f'#{self.rid}' if self.rid else f'rule {self.idx + 1}'))


@dataclass
class Interface:
    name: str
    zone: str = ''
    role: str | None = None                # 'wan' | 'lan' | 'dmz' | 'guest' | 'iot' | 'mgmt' | None
    mgmt: tuple = ()                       # management services enabled: 'https','ssh','http',...
    trusted_hosts: bool | None = None      # True if mgmt access is limited to listed sources
    src: str = ''


@dataclass
class NatRule:
    name: str
    # Published destination ports as (lo, hi) intervals: ((1, 65535),) for a static 1:1 NAT
    # (every port), () for none, None when the export could not be read.
    ports: tuple | None = ()
    internal: str = ''
    source_restricted: bool | None = None
    ips: bool | None = None
    src: str = ''


@dataclass
class VpnTunnel:
    name: str
    ike_version: int | None = None
    aggressive: bool | None = None
    enc: tuple = ()                        # e.g. ('aes256', '3des')
    hashes: tuple = ()                     # e.g. ('sha256', 'md5')
    dh: tuple = ()                         # DH group numbers
    psk_weak: bool | None = None           # computed by the parser; the secret is never kept
    src: str = ''


@dataclass
class NormalizedConfig:
    vendor: str
    device: dict = field(default_factory=dict)      # model, firmware, hostname, serial, notes
    facts: dict = field(default_factory=dict)       # key -> Fact
    rules: list = field(default_factory=list)       # ordered
    interfaces: list = field(default_factory=list)
    nat: list = field(default_factory=list)
    vpn: list = field(default_factory=list)
    addresses: dict = field(default_factory=dict)   # name -> list[str] of CIDRs (expanded)
    services: dict = field(default_factory=dict)    # service name -> ((lo, hi), ...) | None (unreadable)
    sections: set = field(default_factory=set)      # parsed sections: rules interfaces nat vpn
    notes: list = field(default_factory=list)       # parser warnings, e.g. 'multi-VDOM: root only'
    rules_ordered: bool = True      # False: the vendor does not evaluate rules in list order

    def has(self, section: str) -> bool:
        """True when the parser actually read this section (empty then means none configured)."""
        return section in self.sections

    def fact(self, key: str) -> Fact:
        if key not in FACT_KEYS:
            raise KeyError(f'unknown fact key {key!r}')
        return self.facts.get(key, UNKNOWN)

    def set(self, key: str, value, src: str = '') -> None:
        if key not in FACT_KEYS:
            raise KeyError(f'unknown fact key {key!r}')
        self.facts[key] = fact(value, src)

    def nets(self, names: tuple):
        """Expand address names to IP networks.

        None = any, unknown (an empty tuple means the export did not say), not resolvable,
        or more than MAX_NETS networks (too large to compare).
        """
        if not names:
            return None
        out = []
        for n in names:
            if n == ANY:
                return None
            if n in self.addresses:
                cidrs = self.addresses[n]
            else:
                cidrs = [n]            # a literal CIDR/IP used directly
            for c in cidrs:
                try:
                    out.append(ipaddress.ip_network(c, strict=False))
                except ValueError:
                    return None
                if len(out) > MAX_NETS:
                    return None
        return out

    def ranges(self, names: tuple):
        """Merged integer intervals per IP version for address names, computed once per tuple:
        {version: (starts, intervals)}. None when nets() is None."""
        cache = self.__dict__.setdefault('_ranges', {})
        key = (id(self.addresses), names)
        if key not in cache:
            nets = self.nets(names)
            if nets is None:
                cache[key] = None
            else:
                by_ver: dict = {}
                for n in nets:
                    by_ver.setdefault(n.version, []).append(
                        (int(n.network_address), int(n.broadcast_address)))
                merged = {}
                for ver, ivs in by_ver.items():
                    ivs.sort()
                    out = [list(ivs[0])]
                    for lo, hi in ivs[1:]:
                        if lo <= out[-1][1] + 1:
                            out[-1][1] = max(out[-1][1], hi)
                        else:
                            out.append([lo, hi])
                    merged[ver] = (tuple(lo for lo, _ in out), tuple((lo, hi) for lo, hi in out))
                cache[key] = merged
        return cache[key]


def ranges_within(inner: dict, outer: dict) -> bool:
    """True when every interval of `inner` lies inside one merged interval of `outer`."""
    for ver, (_starts, ivs) in inner.items():
        if ver not in outer:
            return False
        starts, outs = outer[ver]
        for lo, hi in ivs:
            i = bisect_right(starts, lo) - 1
            if i < 0 or outs[i][1] < hi:
                return False
    return True
