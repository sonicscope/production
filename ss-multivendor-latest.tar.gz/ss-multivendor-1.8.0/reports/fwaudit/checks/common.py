"""Helpers shared by the check modules."""
from __future__ import annotations

from reports.fwaudit import framework as fw
from reports.fwaudit.model import ANY
from reports.fwaudit.services import covers_all_ports, ports_for


def found(*findings) -> fw.Outcome:
    return fw.Outcome(fw.FINDING, list(findings))


def fact_check(cid, title, severity, key, bad, *, desc, current, recommended, fix, vendors=None):
    """Register a check that tests one scalar fact: unknown -> could not determine."""
    @fw.check(cid, title, severity, vendors=vendors)
    def _fn(ctx):
        f = ctx.cfg.fact(key)
        if not f.known:
            return fw.undetermined('not present in this export')
        if bad(f.value):
            return found(ctx.fail(description=desc, evidence=[f'{f.src} = {f.value!r}'],
                                  current=current(f.value), recommended=recommended, fix=fix))
        return fw.passed()
    return _fn


def is_any(value: tuple) -> bool:
    """Only an explicit "any"; an empty tuple means the export did not say (unknown)."""
    return value == (ANY,)


def is_known(value: tuple) -> bool:
    return bool(value)


def service_open(cfg, service: tuple) -> bool:
    """Any service, or custom services that together cover every port."""
    if is_any(service):
        return True
    ranges, anyv, unknown = ports_for(service, cfg.services)
    return anyv or (not unknown and covers_all_ports(ranges))


def active_allow(cfg) -> list:
    return [r for r in cfg.rules if r.enabled and r.action == 'allow']


def role_map(cfg) -> dict:
    """Lower-case interface/zone name -> role, from the interfaces the parser read."""
    out: dict = {}
    zones: dict = {}
    for i in cfg.interfaces:
        if i.role:
            out[i.name.lower()] = i.role
        if i.zone:
            zones.setdefault(i.zone.lower(), set()).add(i.role)
    for zone, roles in zones.items():
        if len(roles) == 1 and None not in roles:      # a zone with mixed members gets no role
            out[zone] = next(iter(roles))
    return out


def roles_of(cfg, names: tuple) -> set:
    rm = role_map(cfg)
    return {rm[n.lower()] for n in names if n.lower() in rm}


def label_list(rules, limit: int = 25) -> list:
    return [f'{r.label} ({r.src})' if r.src else r.label for r in rules[:limit]]
