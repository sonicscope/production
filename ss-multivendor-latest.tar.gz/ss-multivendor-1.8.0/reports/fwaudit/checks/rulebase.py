"""Domain 2: rule-base hygiene."""
from __future__ import annotations

import time

from reports.fwaudit import framework as fw
from reports.fwaudit.checks.common import active_allow, found, is_any, is_known, label_list
from reports.fwaudit.framework import Severity
from reports.fwaudit.model import ranges_within

MAX_SHADOW_RULES = 1500        # the shadow scan is O(n^2); bigger rule bases are not scanned
SHADOW_BUDGET_S = 5.0          # wall-clock budget for the pairwise comparison


def _need_rules(ctx):
    if not ctx.cfg.has('rules'):
        return fw.undetermined('firewall rules were not read from this export')
    return None


@fw.check('FWA-RUL-001', 'Allow rule with any source, any destination and any service',
          Severity.CRITICAL)
def any_any(ctx):
    if (out := _need_rules(ctx)):
        return out
    # Rules limited by users, groups, applications or negation are not any/any: skipped.
    # Factory default zone rules are reported separately (FWA-RUL-010): they are the vendor's
    # starting point, not a rule an administrator wrote.
    bad = [r for r in active_allow(ctx.cfg) if not r.restricted and not r.builtin
           and is_any(r.src_addr) and is_any(r.dst_addr) and is_any(r.service)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} enabled allow rule(s) match all traffic, defeating the rule base.',
        evidence=label_list(bad), current=f'{len(bad)} any/any/any allow rule(s)',
        recommended='Replace with rules for specific sources, destinations and services',
        fix={'fortigate': 'config firewall policy: edit the rule and set srcaddr, dstaddr and service to specific objects (or disable it after a hit-count review).',
             '*': 'Replace the rule with specific source, destination and service objects.'}))


@fw.check('FWA-RUL-002', 'Allow rule with any service from any source address', Severity.HIGH)
def any_service(ctx):
    if (out := _need_rules(ctx)):
        return out
    # Any source + any service to a specific destination. Any destination is RUL-001 (with
    # any source) or RUL-009 (with a specific source), so one rule is penalised once.
    bad = [r for r in active_allow(ctx.cfg) if not r.restricted
           and is_any(r.service) and is_any(r.src_addr) and is_known(r.dst_addr)
           and not is_any(r.dst_addr)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} allow rule(s) permit every service from any source address.',
        evidence=label_list(bad), current=f'{len(bad)} rule(s)',
        recommended='Limit the service to what is needed',
        fix={'*': 'Replace "any" service with the specific services the rule needs.'}))


def _covers(a, b, cfg):
    """True if every packet matching rule b also matches rule a; None when it cannot be told."""
    if a.restricted or (a.schedule and a.schedule.lower() != 'always'):
        return False
    if a.families and b.families and not set(b.families) <= set(a.families):
        return False                     # e.g. an IPv4 rule never covers an IPv6-only rule
    fields = (a.src_zone, a.dst_zone, a.service, a.src_addr, a.dst_addr,
              b.src_zone, b.dst_zone, b.service, b.src_addr, b.dst_addr)
    if not all(is_known(f) for f in fields):
        return None                      # a field the export did not state
    for fa, fb in ((a.src_zone, b.src_zone), (a.dst_zone, b.dst_zone)):
        if not is_any(fa) and (is_any(fb) or not set(fb) <= set(fa)):
            return False
    if not is_any(a.service) and (is_any(b.service) or not set(b.service) <= set(a.service)):
        return False
    verdict = True
    for fa, fb in ((a.src_addr, b.src_addr), (a.dst_addr, b.dst_addr)):
        if is_any(fa):
            continue
        if is_any(fb):
            return False
        ra, rb = cfg.ranges(fa), cfg.ranges(fb)
        if ra is None or rb is None:
            verdict = None
            continue
        if not ranges_within(rb, ra):
            return False
    return verdict


def _shadowed(cfg):
    """List of (shadowed rule, covering rule) for enabled rules, first cover only.

    None when the comparison did not finish inside SHADOW_BUDGET_S. The result is cached on
    the config so RUL-003 and RUL-004 share one scan.
    """
    key = (tuple(map(id, cfg.rules)), id(cfg.addresses))
    cached = cfg.__dict__.get('_shadow')
    if cached is not None and cached[0] == key:
        return cached[1]
    rules = [r for r in cfg.rules if r.enabled]
    deadline = time.monotonic() + SHADOW_BUDGET_S
    out = []
    for j, b in enumerate(rules):
        for a in rules[:j]:
            if time.monotonic() > deadline:
                out = None
                break
            if _covers(a, b, cfg) is True:
                out.append((b, a))
                break
        if out is None:
            break
    cfg.__dict__['_shadow'] = (key, out)
    return out


def _shadow_check(ctx, opposite: bool):
    if (out := _need_rules(ctx)):
        return out
    if not ctx.cfg.rules_ordered:
        return fw.undetermined('this vendor does not evaluate rules in list order')
    if len(ctx.cfg.rules) > MAX_SHADOW_RULES:
        return fw.undetermined(f'{len(ctx.cfg.rules)} rules is above the {MAX_SHADOW_RULES} scan limit')
    pairs = _shadowed(ctx.cfg)
    if pairs is None:
        return fw.undetermined('rule base too large to compare in time')
    hits = [(b, a) for b, a in pairs if (b.action != a.action) == opposite]
    if not hits:
        return fw.passed()
    ev = [f'{b.label} is covered by earlier {a.label} ({a.src})' for b, a in hits]
    if opposite:
        return found(ctx.fail(
            description=f'{len(hits)} rule(s) can never match because an earlier rule with the '
                        'opposite action already covers all their traffic.',
            evidence=ev, current=f'{len(hits)} unreachable rule(s)',
            recommended='Reorder or remove the unreachable rules',
            fix={'*': 'Move the rule above the rule that covers it, or delete it.'},
            needs_validation=True))          # user/app/schedule conditions are only partly modelled
    return found(ctx.fail(
        description=f'{len(hits)} rule(s) are redundant: an earlier rule with the same action '
                    'already covers all their traffic.',
        evidence=ev, current=f'{len(hits)} redundant rule(s)',
        recommended='Remove redundant rules to keep the rule base reviewable',
        fix={'*': 'Delete the redundant rule after confirming it has no hits.'},
        needs_validation=True))


@fw.check('FWA-RUL-003', 'Rule is unreachable: an earlier rule with the opposite action covers it',
          Severity.MEDIUM)
def shadowed_opposite(ctx):
    return _shadow_check(ctx, True)


@fw.check('FWA-RUL-004', 'Redundant rule: an earlier rule with the same action covers it',
          Severity.LOW)
def shadowed_same(ctx):
    return _shadow_check(ctx, False)


@fw.check('FWA-RUL-005', 'Allow rules that do not log traffic', Severity.MEDIUM)
def no_logging(ctx):
    if (out := _need_rules(ctx)):
        return out
    known = [r for r in active_allow(ctx.cfg) if r.log]
    if not known:
        return fw.undetermined('logging settings are not in this export')
    bad = [r for r in known if r.log == 'none']
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} enabled allow rule(s) do not log, so their traffic is invisible '
                    'to reports and investigations.',
        evidence=label_list(bad), current=f'{len(bad)} rule(s) without logging',
        recommended='Log all allow rules',
        fix={'fortigate': 'config firewall policy / edit <id> / set logtraffic all / end',
             '*': 'Enable logging on the rule.'}))


@fw.check('FWA-RUL-006', 'Most rules have no description', Severity.LOW)
def no_comments(ctx):
    if (out := _need_rules(ctx)):
        return out
    rules = [r for r in ctx.cfg.rules if r.enabled]          # disabled rules are RUL-007
    if len(rules) < 5:
        return fw.not_applicable('fewer than 5 enabled rules')
    bad = [r for r in rules if not r.comment]
    if len(bad) * 2 < len(rules):
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} of {len(rules)} rules have no description, which makes reviews '
                    'and clean-ups unreliable.',
        evidence=label_list(bad), current=f'{len(bad)} of {len(rules)} rules undocumented',
        recommended='Describe the purpose and owner of every rule',
        fix={'*': 'Add a comment stating the purpose and owner of each rule.'}))


@fw.check('FWA-RUL-007', 'Many disabled rules left in the rule base', Severity.INFO)
def disabled_rules(ctx):
    if (out := _need_rules(ctx)):
        return out
    bad = [r for r in ctx.cfg.rules if not r.enabled]
    if len(bad) < 5:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} disabled rules remain; stale rules are easy to re-enable by mistake.',
        evidence=label_list(bad), current=f'{len(bad)} disabled rules',
        recommended='Delete disabled rules that are no longer needed',
        fix={'*': 'Delete obsolete disabled rules.'}))


@fw.check('FWA-RUL-008', 'Allow rules without security profiles', Severity.MEDIUM)
def no_profiles(ctx):
    if (out := _need_rules(ctx)):
        return out
    rated = [r for r in active_allow(ctx.cfg) if r.profiles]
    if not rated:
        return fw.undetermined('security profile attachments are not in this export')
    bad = [r for r in rated if not (r.profiles.get('ips') or r.profiles.get('av')
                                    or r.profiles.get('url'))]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} allow rule(s) pass traffic without IPS, antivirus or web filtering.',
        evidence=label_list(bad), current=f'{len(bad)} rule(s) without profiles',
        recommended='Attach IPS, antivirus and web filtering to allow rules',
        fix={'fortigate': 'config firewall policy / edit <id> / set ips-sensor default / set av-profile default / set utm-status enable / end',
             '*': 'Attach security profiles to the rule.'}))


@fw.check('FWA-RUL-009', 'Unrestricted outbound access (any service to any destination)',
          Severity.MEDIUM)
def open_egress(ctx):
    if (out := _need_rules(ctx)):
        return out
    bad = [r for r in active_allow(ctx.cfg) if not r.restricted
           and is_known(r.src_addr) and not is_any(r.src_addr)
           and is_any(r.dst_addr) and is_any(r.service)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} rule(s) let internal hosts reach any destination on any service, '
                    'which makes malware command-and-control and data theft easy.',
        evidence=label_list(bad), current=f'{len(bad)} open egress rule(s)',
        recommended='Allow only the services and destinations that are needed',
        fix={'*': 'Replace the rule with specific outbound services.'}))


@fw.check('FWA-RUL-010', 'Factory default rules still allow all traffic between zones',
          Severity.LOW, vendors=('sonicwall',))
def default_zone_rules(ctx):
    if (out := _need_rules(ctx)):
        return out
    bad = [r for r in active_allow(ctx.cfg) if r.builtin and not r.restricted
           and is_any(r.src_addr) and is_any(r.dst_addr) and is_any(r.service)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} built-in zone rule(s) allow every address and service between zones. '
                    'Some are normal (for example LAN to WAN), but each one is a decision to make '
                    'deliberately, and the ones that let wireless, guest or DMZ zones reach internal '
                    'networks are reported separately as segmentation findings.',
        evidence=label_list(bad), current=f'{len(bad)} default allow-all zone rule(s)',
        recommended='Keep allow-all only between zones that are meant to be fully trusted',
        fix={'sonicwall': 'Network > Firewall > Access Rules: for each zone pair that should not be fully open, '
                          'edit the Default Access Rule and replace it with specific rules and a deny.',
             '*': 'Replace the default allow-all rules with specific rules.'}))


UNUSED_IDLE_DAYS = 90          # last hit older than this = idle
UNUSED_GRACE_DAYS = 30         # a rule younger than this has had no time to be used


@fw.check('FWA-RUL-011', 'Allow rules with no recorded use (from the export hit counters)',
          Severity.LOW, vendors=('sonicwall',))
def unused_rules(ctx):
    if (out := _need_rules(ctx)):
        return out
    rules = [r for r in active_allow(ctx.cfg) if not r.builtin and not r.generated]
    if not any(r.hits is not None for r in ctx.cfg.rules):
        return fw.undetermined('this export carries no rule hit counters')
    now = ctx.cfg.fact('system.export_epoch')
    if not now.known:
        return fw.undetermined('the export time could not be worked out (no rule has been hit)')
    day = 86400
    never, idle = [], []
    for r in rules:
        if r.hits is None or r.last_hit is None:
            continue
        age_created = (now.value - r.created) // day if r.created else None
        if r.hits == 0 and not r.last_hit:
            if age_created is None or age_created >= UNUSED_GRACE_DAYS:
                never.append((age_created if age_created is not None else 0, r))
        elif r.last_hit and (now.value - r.last_hit) // day > UNUSED_IDLE_DAYS:
            idle.append(((now.value - r.last_hit) // day, r))
    if not never and not idle:
        return fw.passed()
    never.sort(key=lambda t: -t[0])
    idle.sort(key=lambda t: -t[0])
    lines = [f'{r.label} ({r.src}): never hit, created {age} days before the export' if age
             else f'{r.label} ({r.src}): never hit' for age, r in never]
    lines += [f'{r.label} ({r.src}): last hit {age} days before the export ({r.hits:,} hits in total)'
              for age, r in idle]
    return found(ctx.fail(
        description=f'{len(never)} enabled allow rule(s) have never been hit and {len(idle)} have not '
                    f'been hit for over {UNUSED_IDLE_DAYS} days. Unused rules widen the attack surface '
                    'and hide the rules that matter. The hit counters only cover the time since they '
                    'were last reset (a reboot, upgrade or manual clear), and the export time is '
                    'taken from the newest rule hit, so confirm each rule before removing it.',
        evidence=lines[:25], current=f'{len(never)} never hit, {len(idle)} idle over {UNUSED_IDLE_DAYS} days',
        recommended='Review each rule and delete or disable the ones no longer needed',
        fix={'sonicwall': 'Network > Firewall > Access Rules: sort by Hits, confirm the rule is not for '
                          'rare traffic (backups, failover, annual jobs), then disable it for a '
                          'trial period before deleting.',
             '*': 'Review and remove rules that are no longer used.'},
        needs_validation=True))
