"""Domain 7: resilience and hygiene."""
from __future__ import annotations

from reports.fwaudit.checks.common import fact_check
from reports.fwaudit.framework import Severity

fact_check('FWA-RES-001', 'Denial-of-service protection is not configured', Severity.MEDIUM,
           'dos.enabled', lambda v: v is False,
           desc='No DoS policy limits floods against the firewall or protected hosts.',
           current=lambda v: 'no DoS policy', recommended='DoS protection on internet-facing interfaces',
           fix={'fortigate': 'config firewall DoS-policy: create a policy on the WAN interface.',
                '*': 'Enable DoS / flood protection.'})
fact_check('FWA-RES-002', 'High availability is not configured', Severity.INFO, 'ha.enabled',
           lambda v: v is False,
           desc='A single firewall is a single point of failure.',
           current=lambda v: 'standalone', recommended='An HA pair for critical sites',
           fix={'*': 'Consider an HA pair if the site is business critical.'})
fact_check('FWA-RES-003', 'Time synchronisation (NTP) is not enabled', Severity.LOW, 'ntp.enabled',
           lambda v: v is False,
           desc='Wrong clocks break log correlation and certificate validation.',
           current=lambda v: 'NTP off', recommended='NTP enabled with reliable servers',
           fix={'fortigate': 'config system ntp / set ntpsync enable / end',
                '*': 'Enable NTP.'})
fact_check('FWA-RES-004', 'Logs are not sent to a remote system', Severity.MEDIUM, 'logging.remote',
           lambda v: v is False,
           desc='Logs kept only on the firewall can be lost or tampered with, and reports cannot see them.',
           current=lambda v: 'no remote logging', recommended='Send logs to a syslog/analytics server',
           fix={'fortigate': 'config log syslogd setting / set status enable / set server <collector> / end',
                'sonicwall': 'Log > Syslog: add the collector as a syslog server.',
                '*': 'Forward logs to a remote collector.'})
