"""Importing this package registers every check."""
from reports.fwaudit.checks import (  # noqa: F401
    exposure, lifecycle, management, resilience, rulebase, segmentation, threat, traffic, vpn)
