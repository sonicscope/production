"""Domain 5: threat prevention."""
from __future__ import annotations

from reports.fwaudit.checks.common import fact_check
from reports.fwaudit.framework import Severity

fact_check('FWA-THR-001', 'IPS is not applied to any rule', Severity.HIGH, 'services.ips',
           lambda v: v is False,
           desc='No allow rule inspects traffic with an intrusion-prevention sensor.',
           current=lambda v: 'IPS not in use', recommended='IPS on all internet-facing rules',
           fix={'fortigate': 'config firewall policy / edit <id> / set ips-sensor default / end',
                'sonicwall': 'Security Services > Intrusion Prevention: enable IPS and apply it to the zones.',
                '*': 'Enable IPS and apply it to the rules that pass internet traffic.'})
fact_check('FWA-THR-002', 'Antivirus is not applied to any rule', Severity.MEDIUM, 'services.av',
           lambda v: v is False,
           desc='No allow rule scans traffic for malware.',
           current=lambda v: 'antivirus not in use', recommended='Antivirus on internet-facing rules',
           fix={'fortigate': 'config firewall policy / edit <id> / set av-profile default / end',
                'sonicwall': 'Security Services > Gateway Anti-Virus: enable it.',
                '*': 'Enable gateway antivirus.'})
fact_check('FWA-THR-003', 'Web filtering is not applied to any rule', Severity.LOW, 'services.url',
           lambda v: v is False,
           desc='No allow rule filters web categories or known-malicious sites.',
           current=lambda v: 'web filtering not in use', recommended='Web filtering on outbound web traffic',
           fix={'fortigate': 'config firewall policy / edit <id> / set webfilter-profile default / end',
                '*': 'Enable content / web filtering.'})
fact_check('FWA-THR-004', 'Encrypted traffic is not inspected (no deep inspection)', Severity.LOW,
           'services.dpi_ssl', lambda v: v is False,
           desc='Most traffic is encrypted, so IPS and antivirus cannot see inside it without '
                'deep inspection.',
           current=lambda v: 'no deep inspection', recommended='Deep inspection where policy allows',
           fix={'*': 'Enable deep SSL/TLS inspection for outbound traffic (plan certificate rollout and exemptions).'})
fact_check('FWA-THR-005', 'Botnet / geo-IP filtering is disabled', Severity.LOW, 'services.botnet',
           lambda v: v is False,
           desc='Connections to known botnet infrastructure are not blocked.',
           current=lambda v: 'botnet filtering off', recommended='Enable botnet filtering',
           fix={'sonicwall': 'Security Services > Botnet Filter: enable it.',
                '*': 'Enable botnet / threat-feed blocking.'})
