"""Domain 6: segmentation."""
from __future__ import annotations

from reports.fwaudit import framework as fw
from reports.fwaudit.checks.common import active_allow, found, label_list, roles_of, service_open
from reports.fwaudit.framework import Severity


def _need(ctx):
    cfg = ctx.cfg
    if not cfg.has('rules') or not cfg.has('interfaces'):
        return fw.undetermined('rules or interfaces were not read from this export')
    if not any(i.role for i in cfg.interfaces):
        return fw.undetermined('no interface roles could be determined')
    return None


def _flows(ctx, src_roles: set, dst_roles: set):
    cfg = ctx.cfg
    return [r for r in active_allow(cfg)
            if src_roles & roles_of(cfg, r.src_zone) and dst_roles & roles_of(cfg, r.dst_zone)
            and service_open(cfg, r.service)]


@fw.check('FWA-SEG-001', 'Internet zone can reach internal networks on any service',
          Severity.CRITICAL)
def wan_to_lan(ctx):
    if (out := _need(ctx)):
        return out
    bad = _flows(ctx, {'wan'}, {'lan', 'mgmt'})
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='Allow rules let the internet reach internal networks without a service limit.',
        evidence=label_list(bad), current=f'{len(bad)} rule(s)',
        recommended='Publish only specific services through NAT with source limits',
        fix={'*': 'Remove the rule or limit the service and source.'},
        needs_validation=any(r.restricted for r in bad)))


@fw.check('FWA-SEG-002', 'Guest, IoT or DMZ zone can reach internal networks on any service',
          Severity.HIGH)
def untrusted_to_lan(ctx):
    if (out := _need(ctx)):
        return out
    bad = _flows(ctx, {'guest', 'iot', 'dmz'}, {'lan', 'mgmt'})
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='Lower-trust zones are not isolated from internal networks.',
        evidence=label_list(bad), current=f'{len(bad)} rule(s)',
        recommended='Allow only the specific services these zones need',
        fix={'*': 'Limit the service, or block the zone from internal networks.'},
        needs_validation=any(r.restricted for r in bad)))


@fw.check('FWA-SEG-003', 'No guest, IoT or DMZ segmentation present', Severity.LOW)
def flat_network(ctx):
    if (out := _need(ctx)):
        return out
    roles = {i.role for i in ctx.cfg.interfaces if i.role}
    if roles & {'guest', 'iot', 'dmz'}:
        return fw.passed()
    return found(ctx.fail(
        description='Only WAN and LAN roles were found; untrusted devices (guests, IoT, '
                    'servers) may share the internal network.',
        evidence=[f'roles found: {", ".join(sorted(roles))}'], current='no segmentation roles',
        recommended='Separate guest, IoT and server networks into their own zones',
        fix={'*': 'Create dedicated zones for guest, IoT and server networks.'},
        needs_validation=True))                # roles are inferred from names and settings
