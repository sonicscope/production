"""Domain 3: inbound exposure (port-forwards / published services)."""
from __future__ import annotations

from reports.fwaudit import framework as fw
from reports.fwaudit.checks.common import active_allow, found, is_any, roles_of
from reports.fwaudit.framework import Severity
from reports.fwaudit.services import RISKY_PORTS, covers_all_ports, ports_for, risky_in

_CRITICAL_PORTS = frozenset({23, 135, 139, 445, 3389, 5900})


def _need_nat(ctx):
    return None if ctx.cfg.has('nat') else fw.undetermined('NAT was not read from this export')


def _ports_text(n, risky: list) -> str:
    listed = ', '.join(f'{RISKY_PORTS[p]} ({p})' for p in risky)
    if covers_all_ports(n.ports):
        return f'all ports (static 1:1 NAT), including {listed}'
    return listed


@fw.check('FWA-EXP-001', 'Risky service published to the internet', Severity.HIGH)
def risky_published(ctx):
    if (out := _need_nat(ctx)):
        return out
    hits, unreadable = [], []
    for n in ctx.cfg.nat:
        if n.ports is None:
            unreadable.append(n)
            continue
        risky = risky_in(n.ports)
        if risky:
            hits.append((n, risky))
    if not hits:
        if unreadable:
            return fw.undetermined(f'{len(unreadable)} published service(s) have ports that '
                                   'could not be read')
        return fw.passed()
    crit = any(p in _CRITICAL_PORTS for _, ps in hits for p in ps)
    return found(ctx.fail(
        description='Services that are routinely attacked are forwarded straight from the internet.',
        evidence=[f'{n.name} ({n.src}): {_ports_text(n, ps)} -> {n.internal}' for n, ps in hits],
        current=f'{len(hits)} risky port-forward(s)',
        recommended='Remove the forward; publish via VPN or a reverse proxy with authentication',
        fix={'fortigate': 'config firewall vip: delete the virtual IP (and the policy that uses it), or restrict the policy source to known addresses.',
             '*': 'Remove the port-forward or restrict it to known source addresses.'},
        severity=Severity.CRITICAL if crit else Severity.HIGH,
        # No enabled allow rule could be matched to the forward: it may not be reachable.
        needs_validation=any(n.source_restricted is None for n, _ in hits)))


@fw.check('FWA-EXP-002', 'Port-forward open to any source address', Severity.HIGH)
def forward_any_source(ctx):
    if (out := _need_nat(ctx)):
        return out
    known = [n for n in ctx.cfg.nat if n.source_restricted is not None]
    if not known:
        return fw.undetermined('no port-forward is used by an enabled allow rule')
    bad = [n for n in known if n.source_restricted is False]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} published service(s) accept connections from any internet address.',
        evidence=[f'{n.name} ({n.src}) -> {n.internal}' for n in bad],
        current=f'{len(bad)} forward(s) with an open source',
        recommended='Restrict the source to the addresses that need access',
        fix={'*': 'Set the source address of the policy that uses the forward to specific addresses.'}))


@fw.check('FWA-EXP-003', 'Published service without IPS protection', Severity.MEDIUM)
def published_no_ips(ctx):
    if (out := _need_nat(ctx)):
        return out
    known = [n for n in ctx.cfg.nat if n.ips is not None]
    if not known:
        return fw.undetermined('no port-forward is used by an enabled allow rule')
    bad = [n for n in known if n.ips is False]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description=f'{len(bad)} published service(s) have no IPS sensor on the allowing policy.',
        evidence=[f'{n.name} ({n.src})' for n in bad], current=f'{len(bad)} forward(s) without IPS',
        recommended='Attach an IPS sensor to every policy that exposes a service',
        fix={'fortigate': 'config firewall policy / edit <id> / set ips-sensor default / end',
             '*': 'Enable IPS on the allowing rule.'}))


@fw.check('FWA-EXP-004', 'Inbound rule allows a risky service from any internet address',
          Severity.CRITICAL)
def inbound_risky_rule(ctx):
    cfg = ctx.cfg
    if not cfg.has('rules') or not cfg.has('interfaces'):
        return fw.undetermined('rules or interfaces were not read from this export')
    if not any(i.role == 'wan' for i in cfg.interfaces):
        return fw.undetermined('no interface is identified as WAN')
    bad, unknown = [], []
    for r in active_allow(cfg):
        if 'wan' not in roles_of(cfg, r.src_zone) or not is_any(r.src_addr):
            continue
        if not r.service:
            unknown.append(r)
            continue
        ranges, any_svc, unresolved = ports_for(r.service, cfg.services)
        risky = sorted(RISKY_PORTS) if any_svc else risky_in(ranges)
        if risky:
            bad.append((r, ', '.join(f'{RISKY_PORTS[p]} ({p})' for p in risky)))
        elif unresolved:
            unknown.append(r)
    if not bad:
        if unknown:
            return fw.undetermined(f'{len(unknown)} inbound rule(s) use services that could not '
                                   'be resolved')
        return fw.passed()
    return found(ctx.fail(
        description='Rules let any internet address reach services that are routinely attacked.',
        evidence=[f'{r.label} ({r.src}): {svc}' for r, svc in bad],
        current=f'{len(bad)} rule(s)',
        recommended='Restrict the source or remove the rule',
        fix={'*': 'Restrict the rule source to specific addresses, or remove the rule.'},
        # user, group or application conditions the model does not evaluate
        needs_validation=any(r.restricted for r, _ in bad)))
