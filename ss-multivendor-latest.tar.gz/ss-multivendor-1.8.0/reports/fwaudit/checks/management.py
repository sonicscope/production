"""Domain 1: management plane."""
from __future__ import annotations

from reports.fwaudit import framework as fw
from reports.fwaudit.checks.common import fact_check, found
from reports.fwaudit.framework import Severity

fact_check('FWA-MGT-001', 'Administrator session timeout is too long', Severity.MEDIUM,
           'admin.timeout_min', lambda v: v > 15,
           desc='A long idle timeout leaves an authenticated admin session open for hijacking.',
           current=lambda v: f'{v} minutes', recommended='15 minutes or less',
           fix={'fortigate': 'config system global / set admintimeout 10 / end',
                'sonicwall': 'Device > Settings > Administration: set the inactivity timeout to 15 minutes or less.',
                '*': 'Lower the administrator inactivity timeout to 15 minutes or less.'})
fact_check('FWA-MGT-002', 'Multi-factor authentication is not enforced for administrators',
           Severity.HIGH, 'admin.mfa', lambda v: v is False,
           desc='Administrator logins rely on a password alone.',
           current=lambda v: 'MFA not enforced for every administrator',
           recommended='MFA for all administrators',
           fix={'fortigate': 'config system admin / edit <name> / set two-factor fortitoken (or email/sms) / next / end',
                'sonicwall': 'Device > Settings > Administration: require one-time passwords for administrator login.',
                '*': 'Require MFA for every administrator account.'})
fact_check('FWA-MGT-003', 'Administrator account lockout is disabled', Severity.MEDIUM,
           'admin.lockout', lambda v: v is False,
           desc='Without lockout, administrator passwords can be guessed without limit.',
           current=lambda v: 'lockout disabled', recommended='Lock out after a few failed logins',
           fix={'fortigate': 'config system global / set admin-lockout-threshold 3 / set admin-lockout-duration 300 / end',
                '*': 'Enable administrator lockout after repeated failed logins.'})
# SonicOS has no telnet management service (HTTPS, SSH, HTTP, ping and SNMP only), so this check
# is not applicable to SonicWall; add each new vendor here only if it can offer telnet.
fact_check('FWA-MGT-004', 'Telnet administration is enabled', Severity.HIGH,
           'admin.telnet', lambda v: v is True, vendors=('fortigate',),
           desc='Telnet sends credentials and commands in clear text.',
           current=lambda v: 'telnet enabled', recommended='Disable telnet; use SSH',
           fix={'fortigate': 'config system global / set admin-telnet disable / end',
                '*': 'Disable telnet administration and use SSH.'})
fact_check('FWA-MGT-005', 'SNMP v1/v2c is in use', Severity.MEDIUM,
           'admin.snmp_v1v2', lambda v: v is True,
           desc='SNMP v1 and v2c use a shared community string sent in clear text.',
           current=lambda v: 'SNMP v1/v2c communities configured', recommended='SNMPv3 only',
           fix={'fortigate': 'config system snmp community: delete the entries; configure config system snmp user instead.',
                '*': 'Replace SNMP v1/v2c communities with SNMPv3.'})
fact_check('FWA-MGT-006', 'SNMP uses a default community string', Severity.HIGH,
           'admin.snmp_default_community', lambda v: v is True,
           desc='A well-known community string (public/private) gives anyone read access.',
           current=lambda v: 'default community string', recommended='Remove or change it',
           fix={'*': 'Remove the default SNMP community string.'})
fact_check('FWA-MGT-007', 'The default administrator account name is in use', Severity.LOW,
           'admin.default_account', lambda v: v is True,
           desc='The well-known account name "admin" halves the work of a password-guessing attack.',
           current=lambda v: 'account "admin" exists', recommended='Use named admin accounts',
           fix={'fortigate': 'Create named super_admin accounts, then delete or rename "admin".',
                '*': 'Use named administrator accounts and retire the default name.'})
fact_check('FWA-MGT-008', 'No login warning banner', Severity.LOW,
           'admin.banner', lambda v: v is False,
           desc='An authorised-use banner supports enforcement and is a common control requirement.',
           current=lambda v: 'no banner', recommended='Configure an authorised-use banner',
           fix={'fortigate': 'config system global / set pre-login-banner enable / end (then edit the replacement message).',
                '*': 'Configure a login warning banner.'})
fact_check('FWA-MGT-009', 'Weak or missing administrator password policy', Severity.MEDIUM,
           'admin.pw_min_len', lambda v: v is None or v < 12,
           desc='Administrator passwords are not required to be long enough.',
           current=lambda v: 'no password policy' if v is None else f'minimum length {v}',
           recommended='Minimum length of 12 or more',
           fix={'fortigate': 'config system password-policy / set status enable / set minimum-length 14 / end',
                '*': 'Enforce a minimum administrator password length of 12 or more.'})
fact_check('FWA-MGT-011', 'Administrator HTTPS allows old TLS versions', Severity.MEDIUM,
           'admin.tls_min', lambda v: v in ('1.0', '1.1'),
           desc='TLS 1.0 and 1.1 are deprecated and weak.',
           current=lambda v: f'TLS {v} allowed', recommended='TLS 1.2 or newer only',
           fix={'fortigate': 'config system global / set admin-https-ssl-versions tlsv1-2 tlsv1-3 / end',
                '*': 'Allow only TLS 1.2 and newer for the management interface.'})
fact_check('FWA-MGT-012', 'REST API access is enabled', Severity.LOW,
           'admin.api', lambda v: v is True,
           desc='API access widens the management attack surface; confirm it is needed and restricted.',
           current=lambda v: 'API enabled', recommended='Disable unless required; restrict sources',
           fix={'*': 'Disable API access if unused, otherwise restrict it to trusted hosts.'})

_EXPOSING = ('http', 'https', 'ssh', 'telnet', 'snmp')


@fw.check('FWA-MGT-010', 'Management access is enabled on an internet-facing interface',
          Severity.HIGH)
def mgmt_on_wan(ctx):
    if not ctx.cfg.has('interfaces'):
        return fw.undetermined('interfaces were not read from this export')
    wan = [i for i in ctx.cfg.interfaces if i.role == 'wan']
    if not wan:
        return fw.undetermined('no interface is identified as WAN')
    bad = [(i, [m for m in i.mgmt if m in _EXPOSING]) for i in wan]
    bad = [(i, ex) for i, ex in bad if ex and i.trusted_hosts is not True]
    if not bad:
        return fw.passed()
    clear = any(m in ('http', 'telnet') for _, ex in bad for m in ex)
    return found(ctx.fail(
        description='Administrative services answer on an internet-facing interface without '
                    'trusted-host restriction.',
        evidence=[f'{i.name} ({i.src}): {", ".join(ex)}' for i, ex in bad],
        current='; '.join(f'{i.name}: {", ".join(ex)}' for i, ex in bad),
        recommended='No management services on WAN interfaces; use a VPN or trusted hosts',
        fix={'fortigate': 'config system interface / edit <wan> / set allowaccess ping / end; also restrict each admin with trusthost1.',
             '*': 'Remove HTTP/HTTPS/SSH/SNMP from the WAN interface or restrict to trusted hosts.'},
        severity=Severity.CRITICAL if clear else Severity.HIGH,
        needs_validation=ctx.vendor == 'fortigate'))   # local-in policies are not evaluated
