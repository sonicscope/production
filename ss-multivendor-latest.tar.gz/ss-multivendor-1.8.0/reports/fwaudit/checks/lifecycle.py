"""Firmware lifecycle: end-of-support dates from a curated, dated table (never guessed)."""
from __future__ import annotations

import json
import os
import re
from datetime import date

from reports.fwaudit import framework as fw
from reports.fwaudit.checks.common import found
from reports.fwaudit.framework import Severity

TABLE_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data',
                          'firmware_lifecycle.json')
SOON_DAYS = 180


def load_table(path: str = TABLE_PATH) -> list:
    """Entries: {vendor, pattern (regex on the firmware string), label, end_of_support
    (YYYY-MM-DD), source (URL), checked (YYYY-MM-DD)}. Invalid entries are skipped."""
    try:
        with open(path, encoding='utf-8') as fh:
            raw = json.load(fh)
    except (OSError, ValueError):
        return []
    out = []
    for e in raw if isinstance(raw, list) else []:
        try:
            out.append({'vendor': str(e['vendor']), 're': re.compile(str(e['pattern'])),
                        'label': str(e['label']), 'eos': date.fromisoformat(e['end_of_support']),
                        'source': str(e['source']), 'checked': str(e['checked'])})
        except (KeyError, TypeError, ValueError, re.error):
            continue
    return out


def evaluate(vendor: str, firmware: str, table: list, today: date):
    """Return (state, entry, days_left): state is 'eol', 'soon', 'supported' or 'unknown'."""
    for e in table:
        if e['vendor'] == vendor and e['re'].search(firmware):
            left = (e['eos'] - today).days
            return ('eol' if left < 0 else 'soon' if left <= SOON_DAYS else 'supported'), e, left
    return 'unknown', None, 0


@fw.check('FWA-RES-005', 'Firmware release is out of vendor support', Severity.HIGH)
def firmware_support(ctx, table=None, today=None):
    f = ctx.cfg.fact('system.firmware')
    if not f.known or not f.value:
        return fw.undetermined('the firmware version is not in this export')
    state, e, left = evaluate(ctx.vendor, str(f.value), load_table() if table is None else table,
                              today or date.today())
    if state == 'unknown':
        return fw.undetermined(f'no lifecycle data for firmware {f.value}')
    if state == 'supported':
        return fw.passed()
    ev = [f'{e["label"]}: end of support {e["eos"].isoformat()} (source {e["source"]}, '
          f'checked {e["checked"]})', f'firmware in this export: {f.value}']
    if state == 'eol':
        return found(ctx.fail(
            description='This firmware release no longer receives security fixes.',
            evidence=ev, current=f'{e["label"]} ended support {-left} days ago',
            recommended='Upgrade to a supported release',
            fix={'*': 'Plan an upgrade to a release the vendor still supports.'}))
    return found(ctx.fail(
        description=f'This firmware release leaves vendor support in {left} days.',
        evidence=ev, current=f'{e["label"]} ends support in {left} days',
        recommended='Schedule the upgrade before support ends',
        fix={'*': 'Schedule an upgrade to a newer release.'}, severity=Severity.LOW))
