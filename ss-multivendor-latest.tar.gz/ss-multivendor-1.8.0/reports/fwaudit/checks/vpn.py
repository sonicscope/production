"""Domain 4: VPN and cryptography."""
from __future__ import annotations

from reports.fwaudit import framework as fw
from reports.fwaudit.checks.common import fact_check, found
from reports.fwaudit.framework import Severity

_WEAK_ENC = frozenset({'des', '3des'})
_WEAK_HASH = frozenset({'md5', 'sha1'})


def _tunnels(ctx):
    if not ctx.cfg.has('vpn'):
        return None, fw.undetermined('VPN settings were not read from this export')
    if not ctx.cfg.vpn:
        return None, fw.not_applicable('no IPsec tunnels configured')
    return ctx.cfg.vpn, None


@fw.check('FWA-VPN-001', 'IPsec tunnel uses IKE aggressive mode', Severity.HIGH)
def aggressive(ctx):
    tunnels, out = _tunnels(ctx)
    if out:
        return out
    known = [t for t in tunnels if t.aggressive is not None]
    if not known:
        return fw.undetermined('IKE mode is not in this export')
    bad = [t for t in known if t.aggressive]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='Aggressive mode exposes a hash of the pre-shared key to offline cracking.',
        evidence=[f'{t.name} ({t.src})' for t in bad], current=f'{len(bad)} tunnel(s)',
        recommended='Main mode with IKEv2',
        fix={'fortigate': 'config vpn ipsec phase1-interface / edit <name> / set ike-version 2 / end',
             '*': 'Use main mode (or IKEv2).'}))


@fw.check('FWA-VPN-002', 'IPsec tunnel allows weak encryption (DES/3DES)', Severity.HIGH)
def weak_enc(ctx):
    tunnels, out = _tunnels(ctx)
    if out:
        return out
    known = [t for t in tunnels if t.enc]
    if not known:
        return fw.undetermined('encryption proposals are not in this export')
    bad = [t for t in known if _WEAK_ENC & set(t.enc)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='Deprecated ciphers are accepted by the tunnel.',
        evidence=[f'{t.name} ({t.src}): {", ".join(t.enc)}' for t in bad],
        current=f'{len(bad)} tunnel(s)', recommended='AES-256 or AES-GCM only',
        fix={'*': 'Remove DES/3DES from the tunnel proposals.'}))


@fw.check('FWA-VPN-003', 'IPsec tunnel allows weak hashes (MD5/SHA1)', Severity.MEDIUM)
def weak_hash(ctx):
    tunnels, out = _tunnels(ctx)
    if out:
        return out
    known = [t for t in tunnels if t.hashes]
    if not known:
        return fw.undetermined('hash proposals are not in this export')
    bad = [t for t in known if _WEAK_HASH & set(t.hashes)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='MD5 and SHA1 are deprecated for IPsec authentication.',
        evidence=[f'{t.name} ({t.src}): {", ".join(t.hashes)}' for t in bad],
        current=f'{len(bad)} tunnel(s)', recommended='SHA-256 or stronger',
        fix={'*': 'Use SHA-256 or stronger in the tunnel proposals.'}))


@fw.check('FWA-VPN-004', 'IPsec tunnel allows weak Diffie-Hellman groups', Severity.MEDIUM)
def weak_dh(ctx):
    tunnels, out = _tunnels(ctx)
    if out:
        return out
    known = [t for t in tunnels if t.dh]
    if not known:
        return fw.undetermined('DH groups are not in this export')
    bad = [t for t in known if any(g < 14 for g in t.dh)]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='DH groups below 14 (2048-bit) are considered weak.',
        evidence=[f'{t.name} ({t.src}): groups {", ".join(map(str, t.dh))}' for t in bad],
        current=f'{len(bad)} tunnel(s)', recommended='Group 14 or higher (or ECP groups 19/20/21)',
        fix={'fortigate': 'config vpn ipsec phase1-interface / edit <name> / set dhgrp 14 19 / end',
             '*': 'Use DH group 14 or higher.'}))


@fw.check('FWA-VPN-005', 'IPsec tunnel uses IKEv1', Severity.LOW)
def ikev1(ctx):
    tunnels, out = _tunnels(ctx)
    if out:
        return out
    known = [t for t in tunnels if t.ike_version is not None]
    if not known:
        return fw.undetermined('IKE version is not in this export')
    bad = [t for t in known if t.ike_version == 1]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='IKEv1 is legacy; IKEv2 is more robust and supports modern algorithms.',
        evidence=[f'{t.name} ({t.src})' for t in bad], current=f'{len(bad)} tunnel(s) on IKEv1',
        recommended='IKEv2', fix={'*': 'Move the tunnel to IKEv2 (peer must support it).'}))


@fw.check('FWA-VPN-006', 'IPsec pre-shared key is weak', Severity.HIGH)
def weak_psk(ctx):
    tunnels, out = _tunnels(ctx)
    if out:
        return out
    known = [t for t in tunnels if t.psk_weak is not None]
    if not known:
        return fw.undetermined('pre-shared keys are stored encrypted and cannot be assessed')
    bad = [t for t in known if t.psk_weak]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='A short or guessable pre-shared key can be cracked offline.',
        evidence=[f'{t.name} ({t.src})' for t in bad], current=f'{len(bad)} tunnel(s)',
        recommended='A random key of 20+ characters, or certificates',
        fix={'*': 'Replace the pre-shared key with a random 20+ character key.'}))


fact_check('FWA-VPN-007', 'SSL-VPN is enabled without MFA', Severity.HIGH, 'vpn.ssl_mfa',
           lambda v: v is False,
           desc='Remote-access users authenticate with a password alone.',
           current=lambda v: 'MFA not enforced for SSL-VPN', recommended='MFA for all VPN users',
           fix={'*': 'Require MFA (token, email or SMS) for SSL-VPN users.'})
fact_check('FWA-VPN-008', 'SSL-VPN allows old TLS versions', Severity.MEDIUM, 'vpn.ssl_tls_min',
           lambda v: v in ('1.0', '1.1'),
           desc='TLS 1.0 and 1.1 are deprecated.',
           current=lambda v: f'TLS {v} allowed', recommended='TLS 1.2 or newer',
           fix={'fortigate': 'config vpn ssl settings / set ssl-min-proto-ver TLSv1-2 / end',
                '*': 'Set the SSL-VPN minimum TLS version to 1.2.'})
