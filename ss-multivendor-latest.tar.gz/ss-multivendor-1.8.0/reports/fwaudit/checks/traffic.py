"""Domain 8: traffic-aware checks (configuration compared with the logs)."""
from __future__ import annotations

from reports.fwaudit import framework as fw
from reports.fwaudit import traffic as tr
from reports.fwaudit.checks.common import active_allow, found, is_any
from reports.fwaudit.framework import Severity
from reports.fwaudit.services import RISKY_PORTS


def _gb(n: int) -> str:
    return f'{n / 1e9:.1f} GB' if n >= 1e9 else f'{n / 1e6:.1f} MB'


@fw.check('FWA-TRF-001', 'Allow rules with no traffic in the audit window', Severity.MEDIUM,
          needs_logs=True)
def zero_hit(ctx):
    if not ctx.cfg.has('rules'):
        return fw.undetermined('firewall rules were not read from this export')
    if ctx.hits.truncated:
        return fw.undetermined(f'only the {tr.MAX_ROWS:,} busiest log rules were read, so a quiet '
                               'rule could look unused')
    rules = active_allow(ctx.cfg)
    names = tr.name_counts(ctx.cfg.rules)
    eligible = [r for r in rules if tr.eligible_for_zero_hit(ctx.vendor, r, names)]
    skipped = len(rules) - len(eligible)
    if not eligible:
        return fw.undetermined('no rule logs every session with a log identity that maps '
                               'reliably to the configuration')
    dead = [r for r in eligible if tr.match(ctx.vendor, r, ctx.hits)[0] is None]
    if not dead:
        return fw.passed()
    note = (f' {skipped} other rule(s) could not be assessed (they do not log every '
            'session, or share their name with another rule).'
            if skipped else '')
    return found(ctx.fail(
        description=f'{len(dead)} allow rule(s) matched no traffic in the last '
                    f'{ctx.hits.window_days} days.{note}',
        evidence=[f'{r.label} ({r.src})' for r in dead],
        current=f'{len(dead)} unused rule(s)',
        recommended='Review, then disable and remove rules that are no longer needed',
        fix={'*': 'Disable the rule, watch for complaints for a few weeks, then delete it.'}))


@fw.check('FWA-TRF-002', 'Broad allow rules are carrying real traffic', Severity.HIGH,
          needs_logs=True)
def broad_in_use(ctx):
    if not ctx.cfg.has('rules'):
        return fw.undetermined('firewall rules were not read from this export')
    broad = [r for r in active_allow(ctx.cfg)
             if is_any(r.service) and (is_any(r.src_addr) or is_any(r.dst_addr))]
    if not broad:
        return fw.passed()
    used, critical, restricted_used = [], False, False
    for r in broad:
        row, _conf = tr.match(ctx.vendor, r, ctx.hits)
        if row and (row['allow'] or row['bytes']):
            restricted_used |= r.restricted
            ports = ', '.join(f"{RISKY_PORTS.get(p, p)}" for p, _ in row['ports'][:5])
            critical |= any(p in RISKY_PORTS for p, _ in row['ports'])
            used.append(f'{r.label} ({r.src}): {row["allow"]:,} sessions, '
                        f'{_gb(row["bytes"])}' + (f', top ports: {ports}' if ports else ''))
    if not used:
        return fw.undetermined('the broad rules could not be matched to log entries')
    return found(ctx.fail(
        description='Rules that allow any service are actively passing traffic, so tightening '
                    'them needs care: the logs show what they carry.',
        evidence=used, current=f'{len(used)} broad rule(s) in use',
        recommended='Replace each with rules for the services listed',
        fix={'*': 'Build specific rules from the top ports shown, then remove the broad rule.'},
        severity=Severity.CRITICAL if critical else Severity.HIGH,
        needs_validation=restricted_used))


@fw.check('FWA-TRF-003', 'Risky services were allowed from the internet', Severity.HIGH,
          needs_logs=True)
def risky_allowed(ctx):
    if not ctx.hits.allow_events:
        return fw.undetermined('no allowed sessions are logged for this firewall (enable '
                               'logging of all sessions on allow rules)')
    rows = ctx.hits.risky_allowed
    if not rows:
        return fw.passed()
    ev = [f'{RISKY_PORTS[r["port"]]} ({r["port"]}): {r["events"]:,} allowed connections from '
          f'{r["sources"]:,} internet address(es)' for r in sorted(rows, key=lambda r: -r['events'])]
    return found(ctx.fail(
        description='Connections from outside the private ranges were allowed to services that '
                    'are routinely attacked.',
        evidence=ev, current=f'{len(rows)} risky service(s) reachable',
        recommended='Remove the exposure or restrict the sources',
        fix={'*': 'Find the rule that allows it (see the rule base findings) and restrict or remove it.'},
        severity=Severity.CRITICAL if any(r['port'] in (23, 445, 3389, 5900) for r in rows)
        else Severity.HIGH))


@fw.check('FWA-TRF-004', 'Management ports are being probed from the internet', Severity.MEDIUM,
          needs_logs=True)
def mgmt_probes(ctx):
    if not ctx.hits.deny_events:
        return fw.undetermined('no blocked connections are logged for this firewall (enable '
                               'logging of denied traffic)')
    bad = [p for p in ctx.hits.probes
           if p['events'] >= tr.PROBE_MIN_EVENTS and p['sources'] >= tr.PROBE_MIN_SOURCES]
    if not bad:
        return fw.passed()
    return found(ctx.fail(
        description='Blocked connection attempts to administration and remote-access ports show '
                    'the firewall is being scanned; any exposure there will be found.',
        evidence=[f'port {p["port"]}: {p["events"]:,} blocked attempts from {p["sources"]:,} '
                  'addresses' for p in bad],
        current=f'{len(bad)} port(s) probed', recommended='Keep these ports closed to the internet',
        fix={'*': 'Confirm no rule or management setting exposes these ports; use a VPN for admin access.'}))


@fw.check('FWA-TRF-005', 'Traffic matched rules that are not in the configuration', Severity.LOW,
          needs_logs=True)
def stale_rules(ctx):
    if not ctx.cfg.has('rules') or not ctx.cfg.rules:
        return fw.undetermined('firewall rules were not read from this export')
    if tr.MATCHING.get(ctx.vendor, ('', '', 'low'))[2] != 'high':
        return fw.undetermined('log rule identity does not map reliably for this vendor')
    unknown = [row for row in ctx.hits.rows
               if not any(tr.row_matches(ctx.vendor, r, row) for r in ctx.cfg.rules)]
    if not unknown:
        return fw.passed()
    return found(ctx.fail(
        description='The logs name rules that do not exist in this configuration: the export may '
                    'be older than the running config, or rules were renamed or deleted.',
        evidence=[f'{row["name"] or "id " + str(row["id"])}: {row["allow"] + row["deny"]:,} events'
                  for row in unknown[:25]],
        current=f'{len(unknown)} unknown rule name(s)',
        recommended='Re-export the current configuration and re-run the audit',
        fix={'*': 'Export the running configuration again.'}, needs_validation=True))
