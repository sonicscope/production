"""Firewall Audit v2: vendor-neutral audit of firewall configuration, rules and traffic."""
