"""Rule hit counts and exposure probes from fw_events (the traffic-aware inputs)."""
from __future__ import annotations

from dataclasses import dataclass, field

from reports.fwaudit.services import RISKY_PORTS

MGMT_PROBE_PORTS = (22, 23, 3389, 4433, 4443, 8443, 10443)
PROBE_MIN_EVENTS = 100
PROBE_MIN_SOURCES = 5
MAX_ROWS = 5000
STATEMENT_TIMEOUT = '20s'
BLOCKED = ('deny', 'drop')       # 'reset' is an allowed session closed by a TCP reset: neither

# How each vendor identifies a rule in its logs, and how reliable a match is.
#   ('id', 'name') = try the rule id first, then the name; 'low' = the id is not stable.
MATCHING = {
    'fortigate': ('id', 'name', 'high'),
    'sophos': ('id', 'name', 'high'),
    'paloalto': ('name', '', 'high'),
    'sonicwall': ('name', '', 'high'),     # IPFIX only gives the low byte of the id: never used
    'opnsense': ('id', '', 'low'),         # pf rule number, not the config's stable tracker id
}


@dataclass
class RuleHits:
    window_days: int
    total_events: int
    rows: list = field(default_factory=list)       # {'name','id','allow','deny','bytes','last_seen','ports':[(port,n)]}
    probes: list = field(default_factory=list)     # {'port','events','sources'}
    risky_allowed: list = field(default_factory=list)   # {'port','events','sources'}
    allow_events: int = 0          # allowed sessions logged in the window
    deny_events: int = 0           # blocked (deny/drop) connections logged in the window
    truncated: bool = False        # the per-rule rows hit MAX_ROWS: quiet rules may be missing


def _norm_name(value) -> str:
    return (value or '').strip().lower()


def row_matches(vendor: str, rule, row: dict) -> bool:
    """Does one log row (a rule as it appears in fw_events) belong to this config rule?"""
    first, second, _confidence = MATCHING.get(vendor, ('name', '', 'low'))
    for method in (first, second):
        if method == 'id' and rule.rid and row['id'] is not None \
                and str(row['id']) == str(rule.rid):
            return True
        if method == 'name' and rule.name and _norm_name(row['name']) == _norm_name(rule.name):
            return True
    return False


def match(vendor: str, rule, hits: RuleHits):
    """Return (row | None, confidence). None means no log row matches this rule."""
    confidence = MATCHING.get(vendor, ('name', '', 'low'))[2]
    for row in hits.rows:
        if row_matches(vendor, rule, row):
            return row, confidence
    return None, confidence


def name_counts(rules) -> dict:
    """How many rules carry each (normalised) name."""
    out: dict = {}
    for r in rules:
        key = _norm_name(r.name)
        out[key] = out.get(key, 0) + 1
    return out


def eligible_for_zero_hit(vendor: str, rule, names: dict | None = None) -> bool:
    """A rule with zero hits only means 'unused' when it logs every session and the vendor's
    log identity maps reliably to the config. A rule matched by name needs a name that is
    unique in the config (``names`` from name_counts()): a shared name such as SonicWall's
    "Default Access Rule" cannot tell the rules apart in the logs."""
    if rule.log != 'all':
        return False
    first, _second, confidence = MATCHING.get(vendor, ('name', '', 'low'))
    if confidence != 'high':
        return False
    if first == 'id' and rule.rid:
        return True
    if not rule.name:
        return False
    return names is None or names.get(_norm_name(rule.name), 0) <= 1


_WHERE = 'tenant_id = %s AND sensor_id = %s AND time > now() - make_interval(days => %s)'
_INTERNAL = ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8', '169.254.0.0/16',
             '100.64.0.0/10', 'fc00::/7', 'fe80::/10', '::1/128')


def load(cur, *, tenant_id: int, sensor_id: int, window_days: int) -> RuleHits | None:
    """Query fw_events for one sensor of one tenant; None when it has no events in the window.

    Runs under a statement timeout (SET LOCAL: it ends with the caller's transaction)."""
    cur.execute(f"SET LOCAL statement_timeout = '{STATEMENT_TIMEOUT}'")
    base = (tenant_id, sensor_id, window_days)
    cur.execute(
        f"""SELECT count(*), count(*) FILTER (WHERE action = 'allow'),
                   count(*) FILTER (WHERE action = ANY(%s))
              FROM fw_events WHERE {_WHERE}""", (list(BLOCKED), *base))
    total, allow_total, deny_total = cur.fetchone()
    if not total:
        return None
    hits = RuleHits(window_days=window_days, total_events=int(total),
                    allow_events=int(allow_total), deny_events=int(deny_total))
    cur.execute(
        f"""SELECT rule_name, rule_id,
                  count(*) FILTER (WHERE action = 'allow') AS allow_n,
                  count(*) FILTER (WHERE action = ANY(%s)) AS deny_n,
                  COALESCE(sum(bytes_sent + bytes_received), 0) AS bytes,
                  max(time) AS last_seen
             FROM fw_events
            WHERE {_WHERE}
              AND (rule_name IS NOT NULL OR rule_id IS NOT NULL)
            GROUP BY rule_name, rule_id ORDER BY bytes DESC LIMIT %s""",
        (list(BLOCKED), *base, MAX_ROWS))
    fetched = cur.fetchall()
    hits.truncated = len(fetched) >= MAX_ROWS
    for name, rid, allow_n, deny_n, nbytes, last in fetched:
        hits.rows.append({'name': name, 'id': rid, 'allow': int(allow_n), 'deny': int(deny_n),
                          'bytes': int(nbytes), 'last_seen': last.isoformat() if last else '',
                          'ports': []})
    cur.execute(
        f"""SELECT rule_name, rule_id, dst_port, count(*) AS n
             FROM fw_events
            WHERE {_WHERE}
              AND action = 'allow' AND dst_port IS NOT NULL
              AND (rule_name IS NOT NULL OR rule_id IS NOT NULL)
            GROUP BY rule_name, rule_id, dst_port ORDER BY n DESC LIMIT %s""",
        (*base, MAX_ROWS))
    index = {(r['name'], r['id']): r for r in hits.rows}
    for name, rid, port, n in cur.fetchall():
        row = index.get((name, rid))
        if row is not None and len(row['ports']) < 10:
            row['ports'].append((int(port), int(n)))
    cur.execute(
        f"""SELECT dst_port, count(*), count(DISTINCT src_ip)
             FROM fw_events
            WHERE {_WHERE}
              AND action = ANY(%s) AND dst_port = ANY(%s)
            GROUP BY dst_port""", (*base, list(BLOCKED), list(MGMT_PROBE_PORTS)))
    hits.probes = [{'port': int(p), 'events': int(n), 'sources': int(s)}
                   for p, n, s in cur.fetchall()]
    cur.execute(
        f"""SELECT dst_port, count(*), count(DISTINCT src_ip)
             FROM fw_events
            WHERE {_WHERE}
              AND action = 'allow' AND dst_port = ANY(%s)
              AND src_ip IS NOT NULL
              AND NOT (src_ip <<= ANY(%s::inet[]))
            GROUP BY dst_port""", (*base, sorted(RISKY_PORTS), list(_INTERNAL)))
    hits.risky_allowed = [{'port': int(p), 'events': int(n), 'sources': int(s)}
                          for p, n, s in cur.fetchall()]
    return hits
