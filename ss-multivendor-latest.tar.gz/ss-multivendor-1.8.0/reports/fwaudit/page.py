"""Firewall Audit pages (server-rendered HTML; no JavaScript). Every dynamic value is escaped."""
from __future__ import annotations

from markupsafe import escape

from reports.fwaudit import compliance, framework as fw
from reports.fwaudit.report_data import SEVERITY_LABEL, STATE_LABEL

VENDOR_LABELS = {'sonicwall': 'SonicWall', 'fortigate': 'FortiGate', 'paloalto': 'Palo Alto',
                 'sophos': 'Sophos', 'opnsense': 'OPNsense'}
EXPORT_HINTS = {
    'fortigate': 'Run "show full-configuration" in the CLI, or System > Config > Backup, and '
                 'save the text. A full export lets more checks run.',
    'sonicwall': 'Device > Settings > Firmware & Backups > Export Settings; upload the .exp file.',
}
_SEV_COLOURS = {1: '#B3261E', 2: '#D9541E', 3: '#B7791F', 4: '#2F6F9F', 5: '#6B7A90'}
_STATE_COLOURS = {fw.PASSED: '#2E8B57', fw.FINDING: '#B3261E', fw.NA: '#A9B6C8',
                  fw.UNDETERMINED: '#D9A21E', fw.SKIPPED: '#6B7A90'}

_CSS = """
<style>
#fwaudit .sev{display:inline-block;padding:1px 8px;border-radius:3px;font-size:.72rem;font-weight:600;
  letter-spacing:.04em;text-transform:uppercase;color:#fff;white-space:nowrap;}
#fwaudit .score{font-size:2.6rem;line-height:1;font-weight:700;color:#E8EFF8;}
#fwaudit .muted{color:#8BA3C0;}
#fwaudit .dom{display:flex;align-items:center;gap:.6rem;margin:.25rem 0;font-size:.85rem;}
#fwaudit .dom .name{width:11rem;flex:none;}
#fwaudit .dom .bar{flex:1;height:8px;background:#1A2A4A;border-radius:4px;overflow:hidden;}
#fwaudit .dom .bar span{display:block;height:100%;background:#378ADD;}
#fwaudit .dom .val{width:2.5rem;text-align:right;font-family:ui-monospace,Menlo,Consolas,monospace;}
#fwaudit .finding{background:#0D1629;border:1px solid #1A2A4A;border-left:4px solid #6B7A90;
  border-radius:6px;padding:.75rem .9rem;margin:.6rem 0;overflow-wrap:anywhere;}
#fwaudit .finding h4{font-size:1rem;margin:.35rem 0;}
#fwaudit .fid{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.75rem;color:#8BA3C0;}
#fwaudit ul.ev{margin:.3rem 0;padding-left:1.1rem;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.78rem;}
#fwaudit .fix{background:#131F38;border-radius:4px;padding:.45rem .6rem;margin-top:.4rem;font-size:.88rem;}
#fwaudit .warn{color:#D9A21E;font-size:.82rem;margin-top:.3rem;}
#fwaudit .tags{color:#8BA3C0;font-size:.75rem;margin-top:.35rem;}
#fwaudit .chip{display:inline-block;padding:.15rem .6rem;border:1px solid #1A2A4A;border-radius:999px;
  color:#E8EFF8;text-decoration:none;font-size:.8rem;margin:0 .35rem .35rem 0;}
#fwaudit .chip.on{border-color:#00C9A7;color:#00C9A7;}
#fwaudit .chip:focus-visible,#fwaudit .btn:focus-visible,#fwaudit input:focus-visible,
#fwaudit select:focus-visible,#fwaudit summary:focus-visible{outline:2px solid #378ADD;outline-offset:2px;}
#fwaudit .ledger td,#fwaudit .ledger th{font-size:.82rem;}
@media (max-width:575.98px){#fwaudit .dom .name{width:7rem;}#fwaudit .btn{min-height:44px;}}
</style>
"""


def _sev(n: int) -> str:
    return (f'<span class="sev" style="background:{_SEV_COLOURS.get(n, "#6B7A90")}">'
            f'{escape(SEVERITY_LABEL.get(n, "?"))}</span>')


def _score_html(score, band, cov: dict | None = None) -> str:
    covered = (f'<div class="muted" style="font-size:.85rem">{int(cov["assessed"])} of '
               f'{int(cov["total"])} checks assessed</div>' if cov else '')
    return (f'<div class="score">{int(score)}<span class="muted" style="font-size:1rem"> / 100'
            f'</span></div><div>{escape(band)}</div>{covered}')


def _domain_html(label: str, value) -> str:
    if value is None:
        return (f'<div class="dom"><span class="name">{escape(label)}</span>'
                '<span class="muted" style="flex:1">Not assessed</span></div>')
    return (f'<div class="dom"><span class="name">{escape(label)}</span><span class="bar"><span '
            f'style="width:{int(value)}%"></span></span><span class="val">{int(value)}</span></div>')


def index_html(targets: list, tenants: list, sensors: list) -> str:
    rows = ''.join(
        f'<tr><td>{escape(t["tenant_name"])}</td>'
        f'<td><a href="/audit/targets/{int(t["id"])}">{escape(t["name"])}</a></td>'
        f'<td>{escape(VENDOR_LABELS.get(t["vendor"], t["vendor"]))}</td>'
        + (f'<td>{int(t["score"])} <span class="muted">{escape(t["band"])}</span></td>'
           f'<td class="muted">{escape(t["started_at"].strftime("%Y-%m-%d"))}</td>'
           if t['run_id'] else '<td class="muted" colspan="2">Not audited yet</td>')
        + '</tr>' for t in targets)
    table = (
        '<div class="table-responsive"><table class="table align-middle"><thead><tr>'
        '<th>Customer</th><th>Firewall</th><th>Vendor</th><th>Latest score</th><th>Last run</th>'
        f'</tr></thead><tbody>{rows}</tbody></table></div>'
        if targets else '<p class="muted">No firewalls yet. Add one below to run your first audit.</p>')
    topts = ''.join(f'<option value="{int(i)}">{escape(n)}</option>' for i, n in tenants)
    vopts = ''.join(f'<option value="{escape(v)}">{escape(VENDOR_LABELS[v])}</option>'
                    for v in ('sonicwall', 'fortigate'))
    sopts = ''.join(f'<option value="{int(i)}">{escape(n)} ({escape(v)}, '
                    f'{escape(next((tn for ti, tn in tenants if ti == t), ""))})</option>'
                    for i, t, n, v in sensors)
    return (
        _CSS + '<div id="fwaudit"><h3 class="mb-1">🛡 Firewall Audit</h3>'
        '<p class="muted">Checks a firewall\'s configuration, rule base and real traffic against '
        'good practice. Results are for your staff only; you choose what to send to customers.</p>'
        f'{table}<div class="card mt-3"><div class="card-body"><h5>Add a firewall</h5>'
        '<form method="post" action="/audit/targets">'
        '<div class="row g-3">'
        '<div class="col-md-3"><label class="form-label" for="a_tenant">Customer</label>'
        f'<select class="form-select" id="a_tenant" name="tenant_id" required>{topts}</select></div>'
        '<div class="col-md-3"><label class="form-label" for="a_name">Firewall name</label>'
        '<input class="form-control" id="a_name" name="name" maxlength="120" required></div>'
        '<div class="col-md-2"><label class="form-label" for="a_vendor">Vendor</label>'
        f'<select class="form-select" id="a_vendor" name="vendor" required>{vopts}</select></div>'
        '<div class="col-md-4"><label class="form-label" for="a_sensor">Collector sensor '
        '(optional)</label><select class="form-select" id="a_sensor" name="sensor_id">'
        f'<option value="">None: skip traffic-aware checks</option>{sopts}</select>'
        '<div class="form-text">Link the sensor that receives this firewall\'s logs.</div></div>'
        '</div><button class="btn btn-ss mt-3" type="submit">Add firewall</button></form>'
        '</div></div></div>')


def target_html(target: dict, runs: list) -> str:
    hint = EXPORT_HINTS.get(target['vendor'], '')
    linked = bool(target['sensor_id'])
    rows = ''.join(
        f'<tr><td>{escape(r["started_at"].strftime("%Y-%m-%d %H:%M"))}</td>'
        f'<td>{int(r["score"])} <span class="muted">{escape(r["band"])}</span></td>'
        f'<td>{int(r["severity_counts"].get("critical", 0))} critical, '
        f'{int(r["severity_counts"].get("high", 0))} high</td>'
        f'<td><a href="/audit/runs/{int(r["id"])}">Results</a>'
        + (f' · <a href="/audit/runs/{int(r["id"])}/pdf">PDF</a>' if r['report_id'] else '')
        + '</td></tr>' for r in runs)
    history = (
        '<div class="table-responsive"><table class="table"><thead><tr><th>Run</th><th>Score</th>'
        f'<th>Worst findings</th><th></th></tr></thead><tbody>{rows}</tbody></table></div>'
        if runs else '<p class="muted">No audits yet.</p>')
    window = (
        '<div class="col-md-3"><label class="form-label" for="a_window">Traffic window</label>'
        '<select class="form-select" id="a_window" name="window_days">'
        '<option value="30">30 days</option><option value="90" selected>90 days</option>'
        '<option value="180">180 days</option></select></div>' if linked else
        '<div class="col-md-6 muted">No collector sensor is linked, so traffic-aware checks '
        'will be skipped.</div>')
    return (
        _CSS + f'<div id="fwaudit"><p><a href="/audit">&larr; All firewalls</a></p>'
        f'<h3 class="mb-0">{escape(target["name"])}</h3>'
        f'<p class="muted">{escape(target["tenant_name"])} · '
        f'{escape(VENDOR_LABELS.get(target["vendor"], target["vendor"]))}</p>'
        '<div class="card mb-3"><div class="card-body"><h5>Run an audit</h5>'
        f'<p class="muted mb-2">{escape(hint)}</p>'
        f'<form method="post" action="/audit/targets/{int(target["id"])}/run" '
        'enctype="multipart/form-data"><div class="row g-3 align-items-end">'
        '<div class="col-md-6"><label class="form-label" for="a_file">Configuration file '
        '(up to 5 MB)</label><input class="form-control" id="a_file" name="config" type="file" '
        'required></div>' + window +
        '<div class="col-auto"><button class="btn btn-ss" type="submit">Run audit</button></div>'
        '</div><div class="form-text mt-2">The file is analysed in memory and not stored; '
        'secrets in it are never kept.</div></form></div></div>'
        f'<h5>History</h5>{history}'
        '<details class="mt-4"><summary class="muted">Remove this firewall</summary>'
        f'<form method="post" action="/audit/targets/{int(target["id"])}/delete" class="mt-2">'
        '<p class="muted">Removes the firewall and its audit history. PDFs stay in the Reports '
        'list.</p><button class="btn btn-outline-secondary btn-sm" type="submit">Remove firewall'
        '</button></form></details></div>')


def _finding_html(f: dict) -> str:
    ev = ''.join(f'<li>{escape(e)}</li>' for e in f['evidence'])
    tags = ' · '.join(f'{escape(compliance.SHORT.get(k, k))}: {escape(", ".join(v))}'
                      for k, v in f['frameworks'].items() if v)
    return (
        f'<div class="finding" style="border-left-color:{_SEV_COLOURS.get(f["severity"], "#6B7A90")}">'
        f'{_sev(f["severity"])} <span class="fid">{escape(f["check_id"])} · '
        f'{escape(fw.DOMAINS.get(f["domain"], f["domain"]))}</span>'
        f'<h4>{escape(f["title"])}</h4><div>{escape(f["description"])}</div>'
        + (f'<div><b>Found:</b> {escape(f["current"])}</div>' if f['current'] else '')
        + (f'<div><b>Recommended:</b> {escape(f["recommended"])}</div>' if f['recommended'] else '')
        + (f'<ul class="ev">{ev}</ul>' if ev else '')
        + (f'<div class="fix"><b>How to fix:</b> {escape(f["remediation"])}</div>'
           if f['remediation'] else '')
        + ('<div class="warn">Needs validation: this depends on settings the export only partly '
           'shows. Confirm on the firewall before acting.</div>' if f.get('needs_validation') else '')
        + (f'<div class="tags">{tags}</div>' if tags else '') + '</div>')


def _filters(sev: str, domain: str) -> tuple[set, str]:
    sevs = {int(s) for s in sev.split(',') if s.strip() in ('1', '2', '3', '4', '5')}
    return sevs, domain if domain in fw.DOMAINS else ''


def run_html(run: dict, *, sev: str = '', domain: str = '') -> str:
    sevs, dom = _filters(sev, domain)
    findings = [f for f in run['findings']
                if (not sevs or f['severity'] in sevs) and (not dom or f['domain'] == dom)]
    sev_chips = ''.join(
        f'<a class="chip{" on" if sevs == {n} else ""}" '
        f'href="?sev={n}{"&domain=" + dom if dom else ""}">{escape(SEVERITY_LABEL[n])} '
        f'({sum(1 for f in run["findings"] if f["severity"] == n)})</a>' for n in (1, 2, 3, 4, 5))
    dom_chips = ''.join(
        f'<a class="chip{" on" if dom == code else ""}" '
        f'href="?domain={escape(code)}{"&sev=" + ",".join(map(str, sorted(sevs))) if sevs else ""}">'
        f'{escape(label)}</a>' for code, label in fw.DOMAINS.items())
    domains = ''.join(_domain_html(label, run['domain_scores'].get(code))
                      for code, label in fw.DOMAINS.items())
    counts = run['counts']
    ledger_rows = ''.join(
        f'<tr><td class="fid">{escape(e["check_id"])}</td><td>{escape(e["title"])}</td>'
        f'<td style="color:{_STATE_COLOURS.get(e["state"], "#8BA3C0")}">'
        f'{escape(STATE_LABEL.get(e["state"], e["state"]))}</td>'
        f'<td class="muted">{escape(e["reason"])}</td></tr>' for e in run['ledger'])
    summary = ' · '.join(f'{int(counts.get(s, 0))} {escape(STATE_LABEL[s].lower())}'
                         for s in fw.STATES)
    notes = ''.join(f'<li>{escape(n)}</li>' for n in run['notes'])
    pdf = (f'<a class="btn btn-ss" href="/audit/runs/{int(run["id"])}/pdf">Download PDF</a>'
           if run['report_id'] else '')
    device = ' · '.join(escape(x) for x in (run['device'].get('model'),
                                            run['device'].get('firmware')) if x)
    traffic = run['traffic']
    return (
        _CSS + f'<div id="fwaudit"><p><a href="/audit/targets/{int(run["target_id"])}">'
        f'&larr; {escape(run["target_name"])}</a></p>'
        f'<div class="d-flex flex-wrap gap-4 align-items-start">'
        f'<div>{_score_html(run["score"], run["band"], fw.coverage(run["counts"]))}</div>'
        f'<div class="flex-grow-1"><h3 class="mb-0">{escape(run["target_name"])}</h3>'
        f'<p class="muted mb-1">{escape(run["tenant_name"])} · {escape(device)} · '
        f'{escape(run["started_at"].strftime("%Y-%m-%d %H:%M"))}</p>'
        + ('<p class="muted mb-1">Traffic compared: last %d days (%s events).</p>'
           % (int(traffic['window_days']), format(int(traffic['events']), ','))
           if traffic.get('available') else
           '<p class="muted mb-1">No traffic logs were used, so traffic-aware checks were '
           'skipped.</p>') + f'{pdf}</div></div>'
        f'<div class="mt-3">{domains}</div>'
        + (f'<ul class="muted mt-2">{notes}</ul>' if notes else '')
        + f'<h5 class="mt-4">Findings</h5><div>{sev_chips}</div><div>{dom_chips}</div>'
        + ('<a class="chip" href="?">Clear filters</a>' if sevs or dom else '')
        + (''.join(_finding_html(f) for f in findings) or '<p class="muted">No findings match.</p>')
        + f'<details class="mt-4"><summary>What was checked: {summary}</summary>'
        '<p class="muted mt-2">"Could not determine" means the export did not contain what the '
        'check needs. It is not a pass.</p><div class="table-responsive"><table class="table '
        'ledger"><thead><tr><th>Check</th><th>Title</th><th>Result</th><th>Reason</th></tr>'
        f'</thead><tbody>{ledger_rows}</tbody></table></div></details></div>')
