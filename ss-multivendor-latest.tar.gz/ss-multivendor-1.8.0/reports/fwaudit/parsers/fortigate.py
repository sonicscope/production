"""FortiGate (.conf) -> NormalizedConfig."""
from __future__ import annotations

import ipaddress
import re
from itertools import islice

from reports.fwaudit.errors import ConfigError
from reports.fwaudit.parsers import fortitree as tree_mod
from reports.fwaudit.model import ANY, MAX_NETS, Interface, NatRule, NormalizedConfig, Rule, VpnTunnel
from reports.fwaudit.services import ALL_PORTS, port_number, ports_for

_CORE_SECTIONS = ('system global', 'system interface', 'firewall policy', 'firewall address',
                  'global', 'vdom')
_RESTRICTING = ('users', 'groups', 'application', 'app-category', 'internet-service',
                'internet-service-src', 'fsso-groups', 'srcaddr-negate', 'dstaddr-negate',
                'service-negate', 'geoip-match')
_REMOTE_LOG_SECTIONS = ('log syslogd setting', 'log syslogd2 setting', 'log syslogd3 setting',
                        'log syslogd4 setting', 'log fortianalyzer setting',
                        'log fortianalyzer2 setting', 'log fortianalyzer3 setting',
                        'log fortianalyzer-cloud setting')
_DEFAULT_PROFILES = frozenset({'', 'no-inspection', 'certificate-inspection'})


def _first(d: dict, key: str, default=None):
    v = d.get(key)
    return v[0] if isinstance(v, list) and v else default


def _digits(value) -> bool:
    """Plain ASCII digits only: str.isdigit() also accepts characters int() rejects."""
    return isinstance(value, str) and value.isascii() and value.isdecimal()


def _int(value, default: int) -> int:
    return int(value) if _digits(value) else default


def _entries(sec):
    if not isinstance(sec, dict):
        return {}
    return {k: v for k, v in sec.items() if isinstance(v, dict) and not k.startswith('@')}


def _make_sec(tree: dict, cfg: NormalizedConfig):
    glob = tree.get('global') if isinstance(tree.get('global'), dict) else {}
    vd = None
    vdoms = tree.get('vdom')
    if isinstance(vdoms, dict) and vdoms:
        pick = 'root' if 'root' in vdoms else next(iter(vdoms))
        vd = vdoms[pick]
        cfg.notes.append(f'Multi-VDOM export: only VDOM "{pick}" was audited.')

    def sec(name: str):
        for src, prefix in ((vd, '@'), (glob, '@'), (tree, '')):
            if isinstance(src, dict):
                v = src.get(prefix + name)
                if isinstance(v, dict):
                    return v
        return None
    return sec


def _net(subnet: list) -> str | None:
    try:
        if len(subnet) == 2:
            return str(ipaddress.ip_network(f'{subnet[0]}/{subnet[1]}', strict=False))
        return str(ipaddress.ip_network(subnet[0], strict=False))
    except (ValueError, IndexError):
        return None


MAX_GROUP_RAW = 4096        # members x networks considered before a group is collapsed


def _collapse(cidrs: list) -> list | None:
    """Collapse CIDRs per IP version; None when still above MAX_NETS."""
    nets = [ipaddress.ip_network(c) for c in cidrs]
    out = []
    for ver in (4, 6):
        out += [str(n) for n in ipaddress.collapse_addresses(n for n in nets if n.version == ver)]
    return out if len(out) <= MAX_NETS else None


def _addresses(sec) -> dict:
    """Address name -> list of CIDRs. Objects that cannot be resolved, or that expand to more
    than MAX_NETS networks, are left out, which makes them unknown to the checks."""
    out: dict = {}
    for name, e in _entries(sec('firewall address')).items():
        kind = _first(e, 'type', 'ipmask')
        if kind == 'ipmask' and 'subnet' in e:
            n = _net(e['subnet'])
            if n:
                out[name] = [n]
        elif kind == 'iprange' and 'start-ip' in e and 'end-ip' in e:
            try:
                rng = list(islice(ipaddress.summarize_address_range(
                    ipaddress.ip_address(e['start-ip'][0]), ipaddress.ip_address(e['end-ip'][0])),
                    MAX_NETS + 1))
            except (ValueError, TypeError):
                continue
            if len(rng) <= MAX_NETS:
                out[name] = [str(n) for n in rng]
    expand_address_groups(out, {name: e.get('member', [])
                                for name, e in _entries(sec('firewall addrgrp')).items()})
    return out


def expand_address_groups(out: dict, groups: dict) -> None:
    """Add groups ({group name: [member names]}) to ``out`` (name -> CIDRs) in place, with
    bounded nesting. A group with an unresolvable member, or one that expands to more than
    MAX_NETS networks, is left out, which makes it unknown to the checks."""
    too_big: set = set()
    for _ in range(8):                                  # bounded group nesting
        changed = False
        for name, members in groups.items():
            if name in out or name in too_big:
                continue
            members = list(dict.fromkeys(members))
            if not members or not all(m in out for m in members):
                continue
            changed = True
            if sum(len(out[m]) for m in members) > MAX_GROUP_RAW:
                too_big.add(name)
                continue
            cidrs = list(dict.fromkeys(c for m in members for c in out[m]))
            if len(cidrs) > MAX_NETS:
                cidrs = _collapse(cidrs)
            if cidrs is None:
                too_big.add(name)
            else:
                out[name] = cidrs
        if not changed:
            break


MAX_SERVICE_RANGES = 64


def _port_ranges(items: list) -> list | None:
    """'lo[-hi][:src]' items -> [(lo, hi)]; None when any item cannot be read."""
    out = []
    for item in items:
        lo, _, hi = item.split(':')[0].partition('-')
        a, b = port_number(lo), port_number(hi or lo)
        if a is None or b is None or a > b:
            return None
        out.append((a, b))
    return out


def _custom_services(sec) -> dict:
    """Service name -> tuple of (lo, hi) destination port intervals, or None when unreadable."""
    out: dict = {}
    for name, e in _entries(sec('firewall service custom')).items():
        proto = (_first(e, 'protocol', 'TCP/UDP/SCTP') or '').upper()
        if proto in ('ICMP', 'ICMP6'):
            out[name] = ()
            continue
        if proto == 'IP':
            out[name] = ALL_PORTS if _first(e, 'protocol-number', '0') in ('0', '6', '17') else ()
            continue
        items = [i for k in ('tcp-portrange', 'udp-portrange', 'sctp-portrange')
                 for i in e.get(k, [])]
        ranges = _port_ranges(items) if items else None
        out[name] = (tuple(sorted(set(ranges)))
                     if ranges and len(ranges) <= MAX_SERVICE_RANGES else None)
    expand_service_groups(out, {name: e.get('member', [])
                                for name, e in _entries(sec('firewall service group')).items()})
    return out


def expand_service_groups(out: dict, groups: dict) -> None:
    """Add groups ({group name: [member names]}) to ``out`` (service name -> port intervals or
    None) in place, with bounded nesting; a group that cannot be resolved maps to None."""
    for _ in range(4):                                  # bounded group nesting
        for name, members in groups.items():
            if name in out or not members or any(m in groups and m not in out for m in members):
                continue
            ranges, anyv, unknown = ports_for(members, out)
            out[name] = (None if unknown else ALL_PORTS if anyv
                         else tuple(sorted(set(ranges))) if len(ranges) <= MAX_SERVICE_RANGES
                         else None)
    for name in groups:
        out.setdefault(name, None)                      # unresolved nesting: unknown


def _norm(vals: list, case_any=('all', 'any')) -> tuple:
    """Interface/service list -> tuple. Missing = () (unknown), never ANY."""
    if not vals:
        return ()
    if any(v.lower() in case_any for v in vals):
        return (ANY,)
    return tuple(vals)


def _addr(sets: dict, k4: str, k6: str) -> tuple:
    """Combine the IPv4 and IPv6 address fields. Missing = () (unknown). 'all' is ANY only
    when every family the rule uses says 'all'; otherwise it becomes that family's literal
    whole range so it is compared, not treated as any."""
    present = [(sets[k], lit) for k, lit in ((k4, '0.0.0.0/0'), (k6, '::/0')) if sets.get(k)]
    if not present:
        return ()
    if all(any(v.lower() in ('all', 'any') for v in vals) for vals, _ in present):
        return (ANY,)
    return tuple(lit if v.lower() in ('all', 'any') else v for vals, lit in present for v in vals)


_ROLE_TOKENS = (('wan', 'wan'), ('internet', 'wan'), ('guest', 'guest'), ('iot', 'iot'),
                ('dmz', 'dmz'), ('lan', 'lan'), ('internal', 'lan'), ('mgmt', 'mgmt'))


def _role(name: str, role: str | None) -> str | None:
    """The interface's configured role, else one inferred from whole name tokens: 'wan1' and
    'guest-wifi' match, 'vlan10', 'swan' and 'patriot' do not."""
    if role in ('wan', 'lan', 'dmz'):
        return role
    for token in re.split(r'[^a-z0-9]+', name.lower()):
        for key, r in _ROLE_TOKENS:
            if token == key or (token.startswith(key) and token[len(key):].isdecimal()
                                and token[len(key):].isascii()):
                return r
    return None


def _int_fact(cfg, key: str, sg: dict, name: str, default: str, src: str, conv=lambda v: v):
    """Set an integer fact from a setting; an unreadable value leaves the fact unknown."""
    raw = _first(sg, name, default)
    if _digits(raw):
        cfg.set(key, conv(int(raw)), src)


def normalize(text: str) -> NormalizedConfig:
    parsed = tree_mod.parse(text)
    tree, header = parsed['tree'], parsed['header']
    if not any(k in tree for k in _CORE_SECTIONS):
        raise ConfigError('this does not look like a FortiGate configuration')
    cfg = NormalizedConfig('fortigate')
    sec = _make_sec(tree, cfg)
    sg = sec('system global') or {}
    has_global = bool(sg)
    # A missing section only means "none configured" in a complete backup, which always
    # starts with the #config-version header; a pasted fragment does not.
    full = has_global and bool(header)
    parts = header.split('=', 1)[-1].split(':')[0].split('-') if header else []
    cfg.device = {'model': parts[0] if parts else '', 'firmware': parts[1] if len(parts) > 1 else '',
                  'hostname': _first(sg, 'hostname', ''), 'serial': ''}
    cfg.set('system.model', cfg.device['model'], 'header')
    cfg.set('system.firmware', cfg.device['firmware'], 'header')
    cfg.set('system.hostname', cfg.device['hostname'], 'system global/hostname')

    # ── management plane ──────────────────────────────────────────────────────
    if has_global:
        _int_fact(cfg, 'admin.timeout_min', sg, 'admintimeout', '5', 'system global/admintimeout')
        _int_fact(cfg, 'admin.lockout', sg, 'admin-lockout-threshold', '3',
                  'system global/admin-lockout-threshold', lambda n: n > 0)
        cfg.set('admin.banner', _first(sg, 'pre-login-banner') == 'enable'
                or _first(sg, 'post-login-banner') == 'enable', 'system global/*-login-banner')
        if 'admin-telnet' in sg:
            cfg.set('admin.telnet', _first(sg, 'admin-telnet') == 'enable',
                    'system global/admin-telnet')
        vers = [v for v in sg.get('admin-https-ssl-versions', [])]
        if vers:
            low = '1.0' if 'tlsv1-0' in vers else '1.1' if 'tlsv1-1' in vers else '1.2'
            cfg.set('admin.tls_min', low, 'system global/admin-https-ssl-versions')
        if 'admin-sport' in sg or 'admin-port' in sg:
            cfg.set('admin.https_port_default', _first(sg, 'admin-sport', '443') == '443',
                    'system global/admin-sport')
    admins = _entries(sec('system admin'))
    if admins:
        # Remote (RADIUS/LDAP/SAML) admins may get MFA from the identity provider: unknown.
        if not any(_first(a, 'remote-auth') == 'enable' for a in admins.values()):
            cfg.set('admin.mfa', all(_first(a, 'two-factor', 'disable') != 'disable'
                                     for a in admins.values()), 'system admin/*/two-factor')
        cfg.set('admin.default_account', 'admin' in admins, 'system admin')
    trusted = None
    if admins:
        trusted = all(any(k.startswith('trusthost') and v and v[0:2] != ['0.0.0.0', '0.0.0.0']
                          for k, v in a.items()) for a in admins.values())
    if full:
        snmp = _entries(sec('system snmp community'))
        cfg.set('admin.snmp_v1v2', bool(snmp), 'system snmp community')
        cfg.set('admin.snmp_default_community',
                any(_first(c, 'name', '').lower() in ('public', 'private') for c in snmp.values()),
                'system snmp community/*/name')
        cfg.set('admin.api', bool(_entries(sec('system api-user'))), 'system api-user')
        pol = sec('system password-policy')
        ok = pol is not None and _first(pol, 'status', 'disable') == 'enable'
        if not ok:
            cfg.set('admin.pw_min_len', None, 'system password-policy')
        else:
            _int_fact(cfg, 'admin.pw_min_len', pol, 'minimum-length', '8', 'system password-policy')

    # ── interfaces / zones ───────────────────────────────────────────────────
    zone_of: dict = {}
    for zname, z in _entries(sec('system zone')).items():
        for m in z.get('interface', []):
            zone_of[m] = zname
    for name, e in _entries(sec('system interface')).items():
        mgmt = tuple(e.get('allowaccess', []))
        cfg.interfaces.append(Interface(
            name=name, zone=zone_of.get(name, ''), role=_role(name, _first(e, 'role')),
            mgmt=mgmt, trusted_hosts=trusted, src=f'system interface/{name}'))

    # ── objects ──────────────────────────────────────────────────────────────
    cfg.addresses = _addresses(sec)
    custom = _custom_services(sec)
    cfg.services = custom

    # ── rules ────────────────────────────────────────────────────────────────
    ips_used = av_used = url_used = dpi_used = group_profiles = False
    for i, (rid, e) in enumerate(_entries(sec('firewall policy')).items()):
        sets = {k: v for k, v in e.items() if isinstance(v, list)}
        log = _first(sets, 'logtraffic', 'utm')
        if _first(sets, 'profile-type') == 'group' or 'profile-group' in sets:
            prof: dict = {}                   # profiles come from a group: not modelled
            group_profiles = True
        else:
            prof = {'ips': 'ips-sensor' in sets, 'av': 'av-profile' in sets,
                    'url': 'webfilter-profile' in sets,
                    'dpi': _first(sets, 'ssl-ssh-profile', '') not in _DEFAULT_PROFILES}
            ips_used |= prof['ips']
            av_used |= prof['av']
            url_used |= prof['url']
            dpi_used |= prof['dpi']
        src_addr = _addr(sets, 'srcaddr', 'srcaddr6')
        dst_addr = _addr(sets, 'dstaddr', 'dstaddr6')
        service = _norm(sets.get('service', []))
        # Internet Service (ISDB) policies match a vendor-maintained service list instead of
        # addresses and services: never "any", and not resolvable here.
        if _first(sets, 'internet-service') == 'enable' or _first(sets, 'internet-service6') == 'enable':
            dst_addr = ('internet-service',)
            service = service or ('internet-service',)
        if (_first(sets, 'internet-service-src') == 'enable'
                or _first(sets, 'internet-service6-src') == 'enable'):
            src_addr = ('internet-service-src',)
        fams = tuple(f for f, keys in (('4', ('srcaddr', 'dstaddr')), ('6', ('srcaddr6', 'dstaddr6')))
                     if any(sets.get(k) for k in keys))
        cfg.rules.append(Rule(
            idx=i, rid=rid, name=_first(sets, 'name', ''),
            src_zone=_norm(sets.get('srcintf', [])), dst_zone=_norm(sets.get('dstintf', [])),
            src_addr=src_addr, dst_addr=dst_addr, service=service, families=fams,
            action='allow' if _first(sets, 'action', 'deny') in ('accept', 'ipsec') else 'deny',
            enabled=_first(sets, 'status', 'enable') != 'disable',
            log={'all': 'all', 'utm': 'utm', 'disable': 'none'}.get(log, ''),
            comment=_first(sets, 'comments', ''), profiles=prof,
            schedule=_first(sets, 'schedule', ''),
            restricted=any(k in sets and sets[k] not in (['disable'], []) for k in _RESTRICTING),
            src=f'firewall policy/{rid}'))
    if full:
        # A "not used" verdict needs every rule's profiles; profile groups hide them.
        for key, used, src in (('services.ips', ips_used, 'ips-sensor'),
                               ('services.av', av_used, 'av-profile'),
                               ('services.url', url_used, 'webfilter-profile'),
                               ('services.dpi_ssl', dpi_used, 'ssl-ssh-profile')):
            if used or not group_profiles:
                cfg.set(key, used, f'firewall policy/*/{src}')
        cfg.set('dos.enabled', bool(_entries(sec('firewall DoS-policy'))), 'firewall DoS-policy')
        ha = sec('system ha')
        cfg.set('ha.enabled', ha is not None and _first(ha, 'mode', 'standalone') != 'standalone',
                'system ha/mode')
        remote = [n for n in _REMOTE_LOG_SECTIONS
                  if (st := sec(n)) is not None and _first(st, 'status') == 'enable']
        cfg.set('logging.remote', bool(remote),
                remote[0] if remote else 'log syslogd* / log fortianalyzer* setting')
        disk = sec('log disk setting')
        cfg.set('logging.local_disk', bool(disk and _first(disk, 'status') == 'enable'),
                'log disk setting')
        ntp = sec('system ntp')
        if ntp is not None:
            cfg.set('ntp.enabled', _first(ntp, 'ntpsync', 'enable') == 'enable', 'system ntp')
        dns = sec('system dns')
        cfg.set('dns.configured', bool(dns and _first(dns, 'primary')), 'system dns')

    for name, section in (('rules', 'firewall policy'), ('interfaces', 'system interface'),
                          ('nat', 'firewall vip'), ('vpn', 'vpn ipsec phase1-interface')):
        if full or sec(section) is not None:
            cfg.sections.add(name)

    # ── inbound NAT (virtual IPs) ────────────────────────────────────────────
    for name, e in _entries(sec('firewall vip')).items():
        ports: tuple | None
        if _first(e, 'portforward', 'disable') != 'enable':
            ports = ALL_PORTS                           # static 1:1 NAT publishes every port
        else:
            ranges = _port_ranges([_first(e, 'extport', '') or ''])
            ports = tuple(ranges) if ranges else None
        users = [r for r in cfg.rules if name in r.dst_addr and r.action == 'allow' and r.enabled]
        if not users:
            src_restricted = None
        elif any(r.src_addr == (ANY,) for r in users):
            src_restricted = False
        elif any(not r.src_addr for r in users):
            src_restricted = None                       # a user rule's source is unknown
        else:
            src_restricted = True
        cfg.nat.append(NatRule(
            name=name, ports=ports, internal=_first(e, 'mappedip', ''),
            source_restricted=src_restricted,
            ips=(all(r.profiles.get('ips') for r in users) if users else None),
            src=f'firewall vip/{name}'))

    # ── IPsec ────────────────────────────────────────────────────────────────
    for name, e in _entries(sec('vpn ipsec phase1-interface')).items():
        props = [p.lower() for p in e.get('proposal', [])]
        enc = tuple(sorted({p.split('-')[0] for p in props}))
        hashes = tuple(sorted({p.split('-')[1] for p in props if '-' in p}))
        cfg.vpn.append(VpnTunnel(
            name=name, ike_version=_int(_first(e, 'ike-version', '1'), 1),
            aggressive=_first(e, 'mode', 'main') == 'aggressive', enc=enc, hashes=hashes,
            dh=tuple(int(x) for x in e.get('dhgrp', []) if _digits(x)),
            psk_weak=None, src=f'vpn ipsec phase1-interface/{name}'))
    ssl = sec('vpn ssl settings')
    if ssl is not None:
        cfg.set('vpn.ssl_enabled', bool(ssl.get('source-interface')), 'vpn ssl settings')
        ver = _first(ssl, 'ssl-min-proto-ver')
        if ver:
            cfg.set('vpn.ssl_tls_min', ver.replace('TLSv', ''), 'vpn ssl settings/ssl-min-proto-ver')
    return cfg
