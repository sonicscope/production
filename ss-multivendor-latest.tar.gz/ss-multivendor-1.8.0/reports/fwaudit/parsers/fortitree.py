"""FortiOS config tree parser prototype."""
from __future__ import annotations
import shlex

from reports.fwaudit.errors import ConfigError

MAX_BYTES = 20 * 1024 * 1024
MAX_DEPTH = 8
MAX_LINES = 400_000
SECRET_KEYS = frozenset({'password', 'passwd', 'psksecret', 'psk', 'secret', 'private-key',
                         'ca', 'certificate', 'key', 'community-name', 'auth-pwd', 'priv-pwd',
                         'md5-key', 'radius-secret', 'tacacs-secret'})
# Any key containing one of these is redacted too (defence in depth: only normalised fields
# are ever persisted, but the raw tree must not hold secrets either).
SECRET_PATTERNS = ('password', 'passwd', 'secret', 'passphrase', 'psk', 'privatekey',
                   'private-key', 'authkey', 'enckey', 'api-key', 'key-string', 'community',
                   '-pwd', 'md5-key', 'secondary-key', 'tertiary-key', 'secret-key')


def is_secret(key: str) -> bool:
    k = key.lower()
    return k in SECRET_KEYS or any(p in k for p in SECRET_PATTERNS)


def _tokens(line: str) -> list[str]:
    try:
        return shlex.split(line, posix=True)
    except ValueError:
        return line.split()


def parse(text: str) -> dict:
    """Return {'header': str, 'tree': {section: {...}}}. Section keys are 'firewall policy'.

    A `config X` block holds either settings (dict of key -> list[str]) or, when it has
    `edit` entries, a dict of entry-name -> settings dict. Nested blocks live under the
    key '@<block name>' of their parent.
    """
    if len(text.encode('utf-8', 'ignore')) > MAX_BYTES:
        raise ConfigError('config file too large')
    header = ''
    root: dict = {}
    stack: list = []          # [(kind, container)]
    cur = root
    lines = text.splitlines()
    if len(lines) > MAX_LINES:
        raise ConfigError('config file has too many lines')
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith('#'):
            if line.startswith('#config-version=') and not header:
                header = line[1:]
            continue
        tok = _tokens(line)
        if not tok:
            continue
        head = tok[0]
        if head == 'config':
            if len(stack) >= MAX_DEPTH:
                raise ConfigError('config nesting too deep')
            name = ' '.join(tok[1:])
            key = name if not stack else '@' + name
            child: dict = cur.setdefault(key, {})
            stack.append(cur)
            cur = child
        elif head == 'edit':
            if len(stack) >= MAX_DEPTH:
                raise ConfigError('config nesting too deep')
            name = tok[1] if len(tok) > 1 else ''
            child = cur.setdefault(name, {})
            stack.append(cur)
            cur = child
        elif head in ('next', 'end'):
            if stack:
                cur = stack.pop()
        elif head == 'set':
            if len(tok) >= 2:
                key = tok[1]
                cur[key] = ['<redacted>'] if is_secret(key) else tok[2:]
        elif head == 'unset':
            if len(tok) >= 2:
                cur.pop(tok[1], None)
        # any other line (e.g. 'append', 'select') is ignored
    return {'header': header, 'tree': root}
