"""SonicWall (.exp) -> NormalizedConfig.

Reads the settings the V1 auditor proved against real exports (administration, MFA, banner,
API, NTP, syslog, DPI-SSL, geo-IP, botnet) and, from the SonicOS 7 key layout, the zones,
interfaces, address and service objects, access rules, NAT policies and IPsec policies.
Only codes confirmed against a real export or documented tooling are mapped; anything else
stays unknown so the checks say "could not determine" rather than guess. Secrets (pre-shared
keys, passwords, hashes) are never read.
"""
from __future__ import annotations

import base64
import binascii
import ipaddress
import re
from itertools import islice
from urllib.parse import unquote_plus

from reports.fwaudit.errors import ConfigError
from reports.fwaudit.model import ANY, MAX_NETS, Interface, NatRule, NormalizedConfig, Rule, VpnTunnel
from reports.fwaudit.parsers.fortigate import expand_address_groups, expand_service_groups
from reports.fwaudit.services import ALL_PORTS, port_number, ports_for

MAX_BYTES = 20 * 1024 * 1024
MAX_PAIRS = 200_000
_B64_BODY = re.compile(r'[A-Za-z0-9+/=\s]+')


def decode(text: str) -> dict:
    """An .exp file is base64 of a URL-encoded key=value&key=value string (or that string
    itself). Returns the flat key -> value mapping."""
    if len(text.encode('utf-8', 'ignore')) > MAX_BYTES:
        raise ConfigError('config file too large')
    body = text.strip()
    decoded = body                                      # an already-decoded key=value string
    # Real exports end in '&&': the padding may be written as '&' (or follow a padded body).
    # Drop it and re-pad, so both forms decode.
    candidate = body.rstrip('& \t\r\n')
    if candidate and _B64_BODY.fullmatch(candidate):
        b64 = ''.join(candidate.split()).rstrip('=')
        b64 += '=' * (-len(b64) % 4)
        try:
            decoded = base64.b64decode(b64, validate=True).decode('utf-8', errors='ignore')
        except (binascii.Error, ValueError):
            decoded = body
        if '=' not in decoded:                          # plain text that happened to decode
            decoded = body
    # Split first, then decode each key and value ('+' is a space), so an encoded '&' or '='
    # inside a value (a banner, a name) can never create or override another setting.
    pairs = decoded.split('&')
    if len(pairs) > MAX_PAIRS:
        raise ConfigError('config file has too many settings')
    out: dict = {}
    for pair in pairs:
        if '=' in pair:
            k, v = pair.split('=', 1)
            out[unquote_plus(k)] = unquote_plus(v)
    if not out:
        raise ConfigError('this does not look like a SonicWall .exp export')
    return out


_INDEXED = re.compile(r'^([A-Za-z][A-Za-z0-9_]*)_(\d{1,5})$')
MAX_INDEXED = 5000


def indexed(kv: dict, bases) -> dict:
    """Group settings named <base>_<n> by their number: {n: {base: value}}.

    SonicOS exports list repeated objects (rules, zones, ...) as one key per field per object,
    e.g. a name key and an action key that share a numeric suffix. Only the base names in
    ``bases`` are collected; objects are returned in numeric order.
    """
    wanted = frozenset(bases)
    groups: dict = {}
    for key, value in kv.items():
        m = _INDEXED.match(key)
        if m and m.group(1) in wanted:
            n = int(m.group(2))
            if n >= MAX_INDEXED:
                continue
            groups.setdefault(n, {})[m.group(1)] = value
    return dict(sorted(groups.items()))


def _overflow(kv: dict, base: str) -> bool:
    """True when a family has more objects than indexed() collects (it would be partial)."""
    return f'{base}_{MAX_INDEXED}' in kv


def _v(e: dict, key: str) -> str:
    return e.get(key, '').strip()


# zoneObjZoneType: 0 WAN, 1 LAN, 2 DMZ, 4 WLAN, 5 VPN, 6 multicast, 8 SSL VPN, 9 management.
ZONE_ROLES = {'0': 'wan', '1': 'lan', '2': 'dmz', '4': 'guest', '9': 'mgmt'}
_MGMT = (('https', 'iface_https_mgmt'), ('ssh', 'iface_ssh_mgmt'), ('http', 'iface_http_mgmt'),
         ('snmp', 'iface_snmp_mgmt'), ('ping', 'iface_ping_mgmt'))


def _zones(kv: dict) -> dict:
    """Zone name -> role (None for zone types without a role)."""
    out: dict = {}
    for z in indexed(kv, ('zoneObjId', 'zoneObjZoneType')).values():
        if (name := _v(z, 'zoneObjId')):
            out[name] = ZONE_ROLES.get(_v(z, 'zoneObjZoneType'))
    return out


def _interfaces(kv: dict, zones: dict) -> list:
    out = []
    fields = ('iface_name', 'interface_Zone') + tuple(k for _, k in _MGMT)
    for n, e in indexed(kv, fields).items():
        if not (name := _v(e, 'iface_name')):
            continue
        zone = _v(e, 'interface_Zone')
        out.append(Interface(name=name, zone=zone, role=zones.get(zone),
                             mgmt=tuple(svc for svc, key in _MGMT if _v(e, key) == '1'),
                             trusted_hosts=None, src=f'iface_name_{n}'))
    return out


def _addr_cidrs(kind: str, ip1: str, ip2: str) -> list | None:
    """addrObjType: 1 host (Ip1), 2 range (Ip1..Ip2), 4 network (Ip1 + mask in Ip2).
    Groups (8) are expanded from their members; FQDN (8192) and other types stay unknown."""
    try:
        if kind == '1':
            ip = ipaddress.ip_address(ip1)
            return None if ip.is_unspecified else [str(ipaddress.ip_network(ip))]
        if kind == '2':
            lo, hi = ipaddress.ip_address(ip1), ipaddress.ip_address(ip2)
            if lo.is_unspecified:
                return None
            rng = list(islice(ipaddress.summarize_address_range(lo, hi), MAX_NETS + 1))
            return [str(n) for n in rng] if len(rng) <= MAX_NETS else None
        if kind == '4':
            return [str(ipaddress.ip_network(f'{ip1}/{ip2}', strict=False))]
    except (ValueError, TypeError):
        return None
    return None


def _members(kv: dict, atom: str, grp: str) -> dict | None:
    """Group name -> member names from the paired <atom>_<k> / <grp>_<k> settings; None when
    there are more pairs than can be read (a partial group would be wrong)."""
    if _overflow(kv, atom):
        return None
    groups: dict = {}
    for p in indexed(kv, (atom, grp)).values():
        if p.get(grp) and p.get(atom):
            groups.setdefault(p[grp], []).append(p[atom])
    return groups


def _addresses(kv: dict) -> dict:
    """Address name -> CIDRs. Anything that cannot be resolved is left out (unknown)."""
    out: dict = {}
    fields = ('addrObjId', 'addrObjType', 'addrObjIp1', 'addrObjIp2')
    for e in indexed(kv, fields).values():
        name = e.get('addrObjId', '')
        if name.strip() and (cidrs := _addr_cidrs(_v(e, 'addrObjType'), _v(e, 'addrObjIp1'),
                                                  _v(e, 'addrObjIp2'))):
            out[name] = cidrs
    groups = _members(kv, 'addro_atomToGrp', 'addro_grpToGrp')
    if groups:
        expand_address_groups(out, groups)
    return out


def _services(kv: dict) -> dict:
    """Service name -> ((lo, hi), ...) destination ports, () for ICMP, None when unknown.
    svcObjType 1 = one service (svcObjIpType = IP protocol, ports Port1..Port2); 2 = group,
    whose own protocol and port values are meaningless: its ports come from its members."""
    out: dict = {}
    group_names = []
    fields = ('svcObjId', 'svcObjType', 'svcObjIpType', 'svcObjPort1', 'svcObjPort2')
    for e in indexed(kv, fields).values():
        name = e.get('svcObjId', '')
        if not name.strip():
            continue
        kind, proto = _v(e, 'svcObjType'), _v(e, 'svcObjIpType')
        if kind == '2':
            group_names.append(name)
        elif kind != '1' or proto not in ('1', '58', '6', '17'):
            out[name] = None
        elif proto in ('1', '58'):                      # ICMP / ICMPv6: no ports
            out[name] = ()
        else:
            lo, hi = port_number(_v(e, 'svcObjPort1')), port_number(_v(e, 'svcObjPort2'))
            out[name] = ((lo, hi),) if lo is not None and hi is not None and 1 <= lo <= hi else None
    groups = _members(kv, 'so_atomToGrp', 'so_grpToGrp')
    if groups is None:
        for name in group_names:
            out[name] = None
        return out
    for name in group_names:
        groups.setdefault(name, [])
    expand_service_groups(out, groups)
    return out


_RULE_FIELDS = ('policyName', 'policyDefaultRule', 'policyHitCount', 'policyTimeLastHit',
                'policyTimeCreated', 'policyAction', 'policyEnabled', 'policyLog', 'policySrcZone',
                'policyDstZone', 'policySrcNet', 'policyDstNet', 'policySrcSvc', 'policyDstSvc',
                'policyComment', 'policyWhom', 'policyWhomExcl', 'policyTime', 'policyNgApp')
_ACTIONS = {'2': 'allow', '1': 'deny', '0': 'deny'}       # 1 and 0 are discard / deny
_NO_USER = ('', '0')


def _is_any(value: str) -> bool:
    return not value.strip() or value.strip().lower() == 'any'


def _ref(value: str) -> tuple:
    """Network or service reference: empty means any."""
    return (ANY,) if _is_any(value) else (value,)


def _count(value: str):
    """A non-negative whole number, or None when the export does not carry one."""
    v = value.strip()
    return int(v) if v.isascii() and v.isdecimal() and len(v) <= 18 else None


def _service(e: dict) -> tuple:
    """A rule's service. Empty means any, except when the rule names only a source-side service
    object (a real export stores 'ICMP' or a Teams group there, with the destination service empty):
    then the service is unknown, never 'any', so the checks say "could not determine"."""
    dst = e.get('policyDstSvc', '')
    if _is_any(dst) and not _is_any(e.get('policySrcSvc', '')):
        return ()
    return _ref(dst)


def _zone(value: str) -> tuple:
    """Zone reference: empty is unknown, never any."""
    v = value.strip()
    return () if not v else (ANY,) if v.lower() == 'any' else (v,)


def _rules(kv: dict) -> tuple:
    """(rules in export order, number of rules with an unrecognised action)."""
    rules, unknown_action = [], 0
    for i, (n, e) in enumerate(indexed(kv, _RULE_FIELDS).items()):
        action = _ACTIONS.get(_v(e, 'policyAction'))
        unknown_action += action is None
        log = _v(e, 'policyLog')
        rules.append(Rule(
            idx=i, rid='', name=_v(e, 'policyName'),
            src_zone=_zone(e.get('policySrcZone', '')), dst_zone=_zone(e.get('policyDstZone', '')),
            src_addr=_ref(e.get('policySrcNet', '')), dst_addr=_ref(e.get('policyDstNet', '')),
            service=_service(e), action=action or 'deny',
            enabled=_v(e, 'policyEnabled') != '0',
            log={'1': 'all', '0': 'none'}.get(log, ''), comment=_v(e, 'policyComment'),
            schedule=_v(e, 'policyTime'),
            # SonicOS's built-in zone-to-zone "Default Access Rule" entries (every one in a real
            # NSa export has policyDefaultRule=2; administrator rules have 1)
            builtin=_v(e, 'policyDefaultRule') == '2',
            generated=_v(e, 'policyComment').lower().startswith('auto'),
            hits=_count(e.get('policyHitCount', '')), last_hit=_count(e.get('policyTimeLastHit', '')),
            created=_count(e.get('policyTimeCreated', '')),
            # user/group, schedule, application or source-port conditions the model omits
            restricted=(not _is_any(e.get('policySrcSvc', ''))
                        or _v(e, 'policyWhom') not in _NO_USER
                        or _v(e, 'policyWhomExcl') not in _NO_USER
                        or bool(_v(e, 'policyTime')) or bool(_v(e, 'policyNgApp'))),
            src=f'policyName_{n}'))
    counts: dict = {}
    for r in rules:
        counts[r.name.lower()] = counts.get(r.name.lower(), 0) + 1
    for r in rules:                     # e.g. "Default Access Rule (LAN -> WAN)"
        if r.name and counts[r.name.lower()] > 1:
            zones = [z[0] if z else '?' for z in (r.src_zone, r.dst_zone)]
            r.display = f'{r.name} ({zones[0]} -> {zones[1]})'
    return rules, unknown_action


_NAT_FIELDS = ('natPolicyName', 'natPolicyEnabled', 'natPolicyOrigDst', 'natPolicyOrigSvc',
               'natPolicyTransDst')


def _nat(kv: dict, services: dict) -> list:
    """Enabled policies that translate the destination: inbound forwards."""
    out = []
    for n, e in indexed(kv, _NAT_FIELDS).items():
        internal = _v(e, 'natPolicyTransDst')
        if _v(e, 'natPolicyEnabled') == '0' or not _v(e, 'natPolicyOrigDst') or not internal:
            continue
        svc = e.get('natPolicyOrigSvc', '')
        if _is_any(svc):
            ports = ALL_PORTS
        else:
            ranges, anyv, unknown = ports_for([svc], services)
            ports = None if unknown else ALL_PORTS if anyv else tuple(sorted(set(ranges)))
        out.append(NatRule(name=_v(e, 'natPolicyName'), ports=ports, internal=internal,
                           source_restricted=None, ips=None, src=f'natPolicyName_{n}'))
    return out


def _vpn(kv: dict) -> list:
    """Enabled IPsec policies. Only confirmed codes are mapped (P1Exch 2 = aggressive,
    Version 0 = IKEv1); the numeric crypto codes are not, so proposals stay unknown."""
    out = []
    fields = ('ipsecName', 'ipsecP1Exch', 'ipsecVersion', 'ipsecSaDisabled')
    for n, e in indexed(kv, fields).items():
        if _v(e, 'ipsecSaDisabled').lower() == 'on':
            continue
        out.append(VpnTunnel(
            name=_v(e, 'ipsecName'), ike_version=1 if _v(e, 'ipsecVersion') == '0' else None,
            aggressive=True if _v(e, 'ipsecP1Exch') == '2' else None, src=f'ipsecName_{n}'))
    return out


def _flag(kv: dict, key: str, on: str):
    return (kv[key].strip().lower() == on) if key in kv else None


_TLS_KEYS = (('enableTLS10', '1.0'), ('enableTLS11', '1.1'), ('enableTLS12', '1.2'),
             ('enableTLS13', '1.3'))
_DEFAULT_COMMUNITIES = ('public', 'private')


def _admin_hardening(kv: dict, cfg: NormalizedConfig) -> None:
    """Login lockout, password length, management TLS and SNMP, from keys seen in a real
    SonicOS 7 export. A setting is only recorded when its key is present with a recognised
    value; secrets (the SNMP community string) are compared and dropped, never stored."""
    lock = [_flag(kv, 'loginFailLockoutEnable', 'on'), _flag(kv, 'loginFailAcctLockoutEnable', 'on')]
    if any(v is not None for v in lock):
        cfg.set('admin.lockout', any(lock), 'loginFailLockoutEnable / loginFailAcctLockoutEnable')
    pw = kv.get('minPasswordLength', '').strip()
    if pw.isascii() and pw.isdecimal():
        cfg.set('admin.pw_min_len', int(pw), 'minPasswordLength')
    enabled = [ver for key, ver in _TLS_KEYS if _flag(kv, key, 'on')]
    if enabled and all(kv.get(k, '').strip().lower() in ('on', 'off') for k, _ in _TLS_KEYS if k in kv):
        cfg.set('admin.tls_min', enabled[0], 'enableTLS10..enableTLS13')   # lowest version allowed
    on, v3_only = _flag(kv, 'snmp_Enable', 'on'), _flag(kv, 'Snmp3_Mand_Required', 'on')
    if on is not None and 'snmp_GetCommunity' in kv:
        community = kv['snmp_GetCommunity'].strip()
        v1v2 = bool(on and not v3_only and community)
        cfg.set('admin.snmp_v1v2', v1v2, 'snmp_Enable / Snmp3_Mand_Required / snmp_GetCommunity')
        cfg.set('admin.snmp_default_community', bool(v1v2 and community.lower() in _DEFAULT_COMMUNITIES),
                'snmp_GetCommunity')


def normalize(text: str) -> NormalizedConfig:
    kv = decode(text)
    cfg = NormalizedConfig('sonicwall')
    cfg.device = {'model': kv.get('shortProdName', ''), 'firmware': kv.get('buildNum', ''),
                  'hostname': '', 'serial': ''}
    if 'shortProdName' in kv:
        cfg.set('system.model', kv['shortProdName'], 'shortProdName')
    if 'buildNum' in kv:
        cfg.set('system.firmware', kv['buildNum'], 'buildNum')
    timeout = kv.get('adminLoginTimeout', '').strip()
    if timeout.isascii() and timeout.isdecimal():         # isdigit() accepts e.g. superscripts
        cfg.set('admin.timeout_min', int(kv['adminLoginTimeout']), 'adminLoginTimeout')
    otp = [_flag(kv, 'adminOtpReq', '1'), _flag(kv, 'adminLoginOtpRequire', '1')]
    if any(v is not None for v in otp):
        cfg.set('admin.mfa', any(otp), 'adminOtpReq / adminLoginOtpRequire')
    if 'cli_loginBanner' in kv:
        cfg.set('admin.banner', bool(kv['cli_loginBanner'].strip()), 'cli_loginBanner')
    if (v := _flag(kv, 'sonicOsApi_enable', 'on')) is not None:
        cfg.set('admin.api', v, 'sonicOsApi_enable')
    _admin_hardening(kv, cfg)
    if (v := _flag(kv, 'ntp_useNtp', 'on')) is not None:
        cfg.set('ntp.enabled', v, 'ntp_useNtp')
    if 'syslogServerName' in kv:
        cfg.set('logging.remote', bool(kv['syslogServerName'].strip()), 'syslogServerName')
    if (v := _flag(kv, 'sslSpyEnabled', 'on')) is not None:
        cfg.set('services.dpi_ssl', v, 'sslSpyEnabled')
    if (v := _flag(kv, 'geoEnforcement', '1')) is not None:
        cfg.set('services.geoip', v, 'geoEnforcement')
    if (v := _flag(kv, 'botnetBlock', '1')) is not None:
        cfg.set('services.botnet', v, 'botnetBlock')
    _structure(kv, cfg)
    newest = max((r.last_hit for r in cfg.rules if r.last_hit), default=0)
    if newest >= 1_000_000_000:           # the export has no timestamp of its own: newest rule hit
        cfg.set('system.export_epoch', newest, 'newest policyTimeLastHit (lower bound)')
    return cfg


def _structure(kv: dict, cfg: NormalizedConfig) -> None:
    """Zones, interfaces, objects, rules, NAT and VPN; a section is marked read only when
    the export carries it."""
    cfg.rules_ordered = False
    cfg.addresses = _addresses(kv)
    cfg.services = _services(kv)
    cfg.interfaces = _interfaces(kv, _zones(kv))
    if cfg.interfaces:
        cfg.sections.add('interfaces')
    cfg.rules, unknown_action = _rules(kv)
    if unknown_action:
        cfg.notes.append(f'{unknown_action} access rule(s) have an action this audit does not '
                         'recognise: rule checks report "could not determine".')
    elif _overflow(kv, 'policyName'):
        cfg.notes.append('Too many access rules to read them all: rule checks report '
                         '"could not determine".')
    elif cfg.rules:
        cfg.sections.add('rules')
        cfg.notes.append('SonicOS evaluates rules by priority and specificity, not list order; '
                         'shadowed-rule checks are not run.')
    cfg.nat = _nat(kv, cfg.services)
    if indexed(kv, ('natPolicyName',)) and not _overflow(kv, 'natPolicyName'):
        cfg.sections.add('nat')
    cfg.vpn = _vpn(kv)
    if indexed(kv, ('ipsecName',)) and not _overflow(kv, 'ipsecName'):
        cfg.sections.add('vpn')
    missing = [label for sec, label in (('rules', 'access rules'), ('interfaces', 'interfaces'),
                                        ('nat', 'NAT policies'), ('vpn', 'IPsec policies'))
               if sec not in cfg.sections]
    if missing:
        cfg.notes.append(f'Not read from this export: {", ".join(missing)}. Those checks report '
                         '"could not determine".')
