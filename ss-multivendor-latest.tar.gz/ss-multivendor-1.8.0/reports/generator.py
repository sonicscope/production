"""
SonicScope Report Generator
===========================
Generates periodic and HR investigation PDF reports.
Uses Jinja2 for HTML templating and WeasyPrint for PDF output.
"""
from __future__ import annotations

import logging
import os
import re
from datetime import datetime, timezone

import jinja2
import markupsafe
import weasyprint

from .queries import (
    HR_TIMELINE_LIMIT,
    get_bandwidth_timeline,
    get_blocked_sites,
    get_blocked_users,
    get_department_breakdown,
    get_executive_summary,
    get_geo_stats,
    get_group_breakdown,
    get_hr_app_breakdown,
    get_hr_blocked,
    get_hr_categories,
    get_hr_timeline,
    get_hr_top_sites,
    get_hr_user_summary,
    get_productivity_breakdown,
    get_rule_activity,
    get_threat_breakdown,
    get_top_apps,
    get_top_domains,
    get_top_ports,
    get_top_users,
    get_vpn_activity,
    get_web_categories,
)
from .color_utils import _DEFAULT_ACCENT_COLOR, _readable_text_color, _valid_hex_color

log = logging.getLogger('ss.reports')

_TEMPLATES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
_LOGO_DIR = os.environ.get('REPORT_LOGO_DIR', '/var/lib/ss-multivendor/logos')


def _validated_logo_path(logo_path: str | None) -> str | None:
    """Return logo_path only if it resolves safely inside REPORT_LOGO_DIR; else None.

    Prevents WeasyPrint SSRF: a crafted logo_path in the DB could cause WeasyPrint
    to read arbitrary files (file://) or make HTTP requests (http://).
    """
    if not logo_path:
        return None
    try:
        real = os.path.realpath(logo_path)
        real_dir = os.path.realpath(
            os.environ.get('REPORT_LOGO_DIR', _LOGO_DIR)
        )
        if real.startswith(real_dir + os.sep) and os.path.isfile(real):
            return logo_path
    except (OSError, ValueError):
        pass
    log.warning('logo_path %r rejected — not inside REPORT_LOGO_DIR', logo_path)
    return None


def _brand(msp: dict) -> dict:
    """Return the sanitized brand accent + its contrast-safe text colour for
    the cover band. Pure — unit-testable without a DB or WeasyPrint.

    An MSP operator can store an arbitrary string in primary_color; sanitizing
    here means a malformed/hostile value can never break the report CSS."""
    accent = _valid_hex_color(msp.get('primary_color')) or _DEFAULT_ACCENT_COLOR
    return {'primary_color': accent, 'accent_text_color': _readable_text_color(accent)}


_JINJA_ENV: jinja2.Environment | None = None


CSS_STRING_MAX = 120


def _css_string(value) -> markupsafe.Markup:
    """Make a value safe INSIDE a double-quoted CSS string in a <style> block.

    <style> content is raw text: HTML entities are not decoded there, so autoescaping would
    print "&amp;" in running page footers. Instead escape what CSS needs (backslash, quote,
    control characters, and "</" so a name cannot close the style element) with hex escapes
    and return Markup so Jinja does not HTML-escape it again. Length is capped.
    """
    text = '' if value is None else str(value)
    text = text[:CSS_STRING_MAX]
    out: list[str] = []
    for i, ch in enumerate(text):
        if ch in '\\"' or ord(ch) < 0x20 or ord(ch) == 0x7f:
            out.append(f'\\{ord(ch):x} ')
        elif ch == '<' and text[i + 1:i + 2] == '/':
            out.append('\\3c ')
        else:
            out.append(ch)
    return markupsafe.Markup(''.join(out))


def _get_jinja_env() -> jinja2.Environment:
    """Return a cached Jinja2 Environment backed by the reports/templates/ directory."""
    global _JINJA_ENV
    if _JINJA_ENV is None:
        _JINJA_ENV = jinja2.Environment(
            loader=jinja2.FileSystemLoader(_TEMPLATES_DIR),
            autoescape=jinja2.select_autoescape(['html']),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        _JINJA_ENV.filters['css_string'] = _css_string
    return _JINJA_ENV


_ALLOWED_TABLES = frozenset({'msp_profiles', 'tenants'})

def _fetch_row(cur, table: str, id_col: str, id_val: int) -> dict:
    """Fetch one row from a table by primary key and return it as a dict."""
    if table not in _ALLOWED_TABLES or not id_col.isidentifier():
        raise ValueError(f"Disallowed table or column: {table!r}, {id_col!r}")
    cur.execute(f"SELECT * FROM {table} WHERE {id_col} = %s", (id_val,))  # noqa: S608
    row = cur.fetchone()
    if row is None:
        raise ValueError(f"{table}: no row with {id_col}={id_val}")
    return dict(zip([d[0] for d in cur.description], row))


def period_label(report_type: str, period_start: datetime, period_end: datetime) -> str:
    """Return a human-readable period label for the report cover page."""
    if report_type == 'daily':
        return period_start.strftime('%d %b %Y')
    if report_type == 'weekly':
        return f"Week of {period_start.strftime('%d %b %Y')}"
    if report_type == 'monthly':
        return period_start.strftime('%B %Y')
    return f"{period_start.strftime('%d %b %Y')} – {period_end.strftime('%d %b %Y')}"


def _safe_subject(s: str) -> str:
    """Convert a user name or IP string to a filesystem-safe slug."""
    s = s.replace(' ', '_').replace('.', '_')
    return re.sub(r'[^\w\-]', '', s)[:64]


_SENSITIVE_WEB_CATEGORIES: frozenset[str] = frozenset({
    'Adult/Mature Content', 'Pornography', 'Nudity', 'Sexual Expression',
    'Explicit Sexual Content', 'Dating/Personals', 'Gambling', 'Weapons',
    'Violence/Hate/Racism', 'Illegal Downloads', 'Illegal Drugs', 'Hacking',
    'Adult', 'Sex Education', 'Nudism',
})

def _make_clean_filter(clean_mode: bool):
    """Return a callable for templates to redact sensitive domain names."""
    def clean_domain(domain, web_category=None):
        if not clean_mode:
            return domain
        if web_category and web_category in _SENSITIVE_WEB_CATEGORIES:
            return '[Sensitive Content]'
        return domain
    return clean_domain


def _insert_generated_report(
    cur,
    tenant_id: int,
    schedule_id: int | None,
    report_type: str,
    period_start: datetime,
    period_end: datetime,
    subject_user: str | None,
    file_path: str,
) -> int:
    """Insert a generated_reports row and return its new id."""
    size = os.path.getsize(file_path) if os.path.isfile(file_path) else 0
    cur.execute(
        """
        INSERT INTO generated_reports
            (tenant_id, schedule_id, report_type, period_start, period_end,
             subject_user, file_path, file_size_bytes, delivery_status)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'pending')
        RETURNING id
        """,
        (tenant_id, schedule_id, report_type, period_start, period_end,
         subject_user, file_path, size),
    )
    return cur.fetchone()[0]


def generate_periodic_report(
    db_conn,
    tenant_id: int,
    msp_profile_id: int,
    report_type: str,
    period_start: datetime,
    period_end: datetime,
    output_dir: str,
    schedule_id: int | None = None,
) -> str:
    """Render a periodic PDF report and return the output file path."""
    os.makedirs(output_dir, exist_ok=True)

    try:
        with db_conn.cursor() as cur:
            # PostgreSQL 16 can raise InternalError "subplan was not initialized"
            # in a parallel worker on some of the report's analytics queries once
            # a tenant has enough data for the planner to go parallel (hit on
            # snwlrep2, 2026-07-15, ~10M rows). Disable parallel gather for THIS
            # report's transaction only (SET LOCAL) — reports aren't latency-
            # critical and results are identical; Grafana/collector keep their
            # own parallelism (different connections/roles).
            cur.execute('SET LOCAL max_parallel_workers_per_gather = 0')
            msp = _fetch_row(cur, 'msp_profiles', 'id', msp_profile_id)
            tenant = _fetch_row(cur, 'tenants', 'id', tenant_id)

            # Validate logo_path before it reaches WeasyPrint to prevent SSRF
            msp = dict(msp)
            msp['logo_path'] = _validated_logo_path(msp.get('logo_path'))
            msp.update(_brand(msp))

            id_enabled = bool(tenant.get('identity_enabled', True))

            exec_summary = get_executive_summary(cur, tenant_id, period_start, period_end)
            bandwidth_timeline = get_bandwidth_timeline(
                cur, tenant_id, period_start, period_end, 'daily'
            )
            top_users = get_top_users(cur, tenant_id, period_start, period_end,
                                      identity_enabled=id_enabled)
            top_apps = get_top_apps(cur, tenant_id, period_start, period_end)
            top_domains = get_top_domains(cur, tenant_id, period_start, period_end)
            web_categories = get_web_categories(cur, tenant_id, period_start, period_end)
            threats = get_threat_breakdown(cur, tenant_id, period_start, period_end)
            rules = get_rule_activity(cur, tenant_id, period_start, period_end)
            vpn = get_vpn_activity(cur, tenant_id, period_start, period_end,
                                   identity_enabled=id_enabled)
            geo_stats = get_geo_stats(cur, tenant_id, period_start, period_end)
            productivity = get_productivity_breakdown(cur, tenant_id, period_start, period_end)
            dept_breakdown  = get_department_breakdown(cur, tenant_id, period_start, period_end)
            group_breakdown = get_group_breakdown(cur, tenant_id, period_start, period_end)

        context = {
            'msp': msp,
            'tenant': tenant,
            'period_label': period_label(report_type, period_start, period_end),
            'period_start': period_start,
            'period_end': period_end,
            'generated_at': datetime.now(timezone.utc),
            'exec_summary': exec_summary,
            'bandwidth_timeline': bandwidth_timeline,
            'top_users': top_users,
            'top_apps': top_apps,
            'top_domains': top_domains,
            'web_categories': web_categories,
            'threats': threats,
            'rules': rules,
            'vpn': vpn,
            'show_vpn': bool(vpn),
            'geo_stats': geo_stats,
            'productivity': productivity,
            'dept_breakdown':  dept_breakdown,
            'group_breakdown': group_breakdown,
        }

        html = _get_jinja_env().get_template('periodic/report.html').render(**context)

        slug = tenant.get('slug') or f'tenant{tenant_id}'
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{slug}_{report_type}_{timestamp}.pdf"
        output_path = os.path.join(output_dir, filename)

        weasyprint.HTML(string=html, base_url='file:///').write_pdf(output_path)
        log.info('Generated periodic report: %s (%d bytes)', output_path, os.path.getsize(output_path))

        with db_conn.cursor() as cur:
            _insert_generated_report(
                cur, tenant_id, schedule_id, report_type,
                period_start, period_end, None, output_path,
            )
        db_conn.commit()
    except Exception:
        db_conn.rollback()
        raise

    return output_path


def generate_hr_report(
    db_conn,
    tenant_id: int,
    msp_profile_id: int,
    subject_user: str,
    period_start: datetime,
    period_end: datetime,
    generated_by: str,
    output_dir: str,
    clean_mode: bool = False,
) -> str:
    """Render an HR investigation PDF report and return the output file path."""
    os.makedirs(output_dir, exist_ok=True)

    try:
        with db_conn.cursor() as cur:
            # PostgreSQL 16 can raise InternalError "subplan was not initialized"
            # in a parallel worker on some of the report's analytics queries once
            # a tenant has enough data for the planner to go parallel (hit on
            # snwlrep2, 2026-07-15, ~10M rows). Disable parallel gather for THIS
            # report's transaction only (SET LOCAL) — reports aren't latency-
            # critical and results are identical; Grafana/collector keep their
            # own parallelism (different connections/roles).
            cur.execute('SET LOCAL max_parallel_workers_per_gather = 0')
            msp = _fetch_row(cur, 'msp_profiles', 'id', msp_profile_id)
            tenant = _fetch_row(cur, 'tenants', 'id', tenant_id)

            # Validate logo_path before it reaches WeasyPrint to prevent SSRF
            msp = dict(msp)
            msp['logo_path'] = _validated_logo_path(msp.get('logo_path'))
            msp.update(_brand(msp))

            id_enabled = bool(tenant.get('identity_enabled', True))

            user_summary = get_hr_user_summary(cur, tenant_id, period_start, period_end,
                                               subject_user, identity_enabled=id_enabled)
            timeline = get_hr_timeline(cur, tenant_id, period_start, period_end, subject_user)
            timeline_truncated = len(timeline) >= HR_TIMELINE_LIMIT
            top_sites = get_hr_top_sites(cur, tenant_id, period_start, period_end, subject_user)
            blocked = get_hr_blocked(cur, tenant_id, period_start, period_end, subject_user)
            categories = get_hr_categories(cur, tenant_id, period_start, period_end, subject_user)
            app_breakdown = get_hr_app_breakdown(cur, tenant_id, period_start, period_end, subject_user)

        pl = f"{period_start.strftime('%d %b %Y')} – {period_end.strftime('%d %b %Y')}"

        context = {
            'msp': msp,
            'tenant': tenant,
            'subject': subject_user,
            'period_label': pl,
            'period_start': period_start,
            'period_end': period_end,
            'generated_by': generated_by,
            'generated_at': datetime.now(timezone.utc),
            'user_summary': user_summary,
            'timeline': timeline,
            'timeline_truncated': timeline_truncated,
            'timeline_limit': HR_TIMELINE_LIMIT,
            'top_sites': top_sites,
            'blocked': blocked,
            'categories': categories,
            'app_breakdown': app_breakdown,
            'clean_mode': clean_mode,
            'clean_domain': _make_clean_filter(clean_mode),
        }

        html = _get_jinja_env().get_template('hr/report.html').render(**context)

        slug = tenant.get('slug') or f'tenant{tenant_id}'
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        safe = _safe_subject(subject_user)
        filename = f"{slug}_hr_{safe}_{timestamp}.pdf"
        output_path = os.path.join(output_dir, filename)

        weasyprint.HTML(string=html, base_url='file:///').write_pdf(output_path)
        log.info(
            'Generated HR report for %s: %s (%d bytes)',
            subject_user, output_path, os.path.getsize(output_path),
        )

        with db_conn.cursor() as cur:
            _insert_generated_report(
                cur, tenant_id, None, 'hr_investigation',
                period_start, period_end, subject_user, output_path,
            )
        db_conn.commit()
    except Exception:
        db_conn.rollback()
        raise

    return output_path


def generate_security_report(
    db_conn,
    tenant_id: int,
    msp_profile_id: int,
    period_start: datetime,
    period_end: datetime,
    output_dir: str,
    schedule_id: int | None = None,
) -> str:
    """Render an IT & Network Security PDF report and return the output file path."""
    os.makedirs(output_dir, exist_ok=True)

    try:
        with db_conn.cursor() as cur:
            # PostgreSQL 16 can raise InternalError "subplan was not initialized"
            # in a parallel worker on some of the report's analytics queries once
            # a tenant has enough data for the planner to go parallel (hit on
            # snwlrep2, 2026-07-15, ~10M rows). Disable parallel gather for THIS
            # report's transaction only (SET LOCAL) — reports aren't latency-
            # critical and results are identical; Grafana/collector keep their
            # own parallelism (different connections/roles).
            cur.execute('SET LOCAL max_parallel_workers_per_gather = 0')
            msp = _fetch_row(cur, 'msp_profiles', 'id', msp_profile_id)
            tenant = _fetch_row(cur, 'tenants', 'id', tenant_id)

            msp = dict(msp)
            msp['logo_path'] = _validated_logo_path(msp.get('logo_path'))
            msp.update(_brand(msp))

            id_enabled = bool(tenant.get('identity_enabled', True))

            exec_summary    = get_executive_summary(cur, tenant_id, period_start, period_end)
            bandwidth       = get_bandwidth_timeline(cur, tenant_id, period_start, period_end, 'daily')
            top_users       = get_top_users(cur, tenant_id, period_start, period_end,
                                            identity_enabled=id_enabled)
            threats         = get_threat_breakdown(cur, tenant_id, period_start, period_end)
            rules           = get_rule_activity(cur, tenant_id, period_start, period_end)
            geo_stats       = get_geo_stats(cur, tenant_id, period_start, period_end)
            blocked_sites   = get_blocked_sites(cur, tenant_id, period_start, period_end)
            blocked_users   = get_blocked_users(cur, tenant_id, period_start, period_end,
                                                identity_enabled=id_enabled)
            top_ports       = get_top_ports(cur, tenant_id, period_start, period_end)

        context = {
            'msp':            msp,
            'tenant':         tenant,
            'period_label':   period_label('security', period_start, period_end),
            'period_start':   period_start,
            'period_end':     period_end,
            'generated_at':   datetime.now(timezone.utc),
            'exec_summary':   exec_summary,
            'bandwidth':      bandwidth,
            'top_users':      top_users,
            'threats':        threats,
            'rules':          rules,
            'geo_stats':      geo_stats,
            'blocked_sites':  blocked_sites,
            'blocked_users':  blocked_users,
            'top_ports':      top_ports,
        }

        html = _get_jinja_env().get_template('security/report.html').render(**context)

        slug = tenant.get('slug') or f'tenant{tenant_id}'
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{slug}_security_{timestamp}.pdf"
        output_path = os.path.join(output_dir, filename)

        weasyprint.HTML(string=html, base_url='file:///').write_pdf(output_path)
        log.info('Generated security report: %s (%d bytes)', output_path, os.path.getsize(output_path))

        with db_conn.cursor() as cur:
            _insert_generated_report(
                cur, tenant_id, schedule_id, 'security',
                period_start, period_end, None, output_path,
            )
        db_conn.commit()
    except Exception:
        db_conn.rollback()
        raise

    return output_path


def generate_investigation_report(
    db_conn,
    tenant_id: int,
    msp_profile_id: int,
    title: str,
    summary: str,
    exhibits: list[dict],
    output_dir: str,
    commit: bool = True,
) -> tuple[str, int]:
    """Render an Investigation Report PDF from frozen finding evidence; no queries run.

    With commit=False the caller owns the transaction (it must commit, or roll back on
    failure); the generated_reports row is inserted but not committed.
    """
    os.makedirs(output_dir, exist_ok=True)
    try:
        with db_conn.cursor() as cur:
            msp = dict(_fetch_row(cur, 'msp_profiles', 'id', msp_profile_id))
            tenant = _fetch_row(cur, 'tenants', 'id', tenant_id)
        msp['logo_path'] = _validated_logo_path(msp.get('logo_path'))
        msp.update(_brand(msp))
        now = datetime.now(timezone.utc)
        html = _get_jinja_env().get_template('investigation/report.html').render(
            msp=msp, tenant=tenant, title=title, summary=summary or '',
            exhibits=exhibits, generated_at=now)
        slug = tenant.get('slug') or f'tenant{tenant_id}'
        filename = f"{slug}_investigation_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
        output_path = os.path.join(output_dir, filename)
        weasyprint.HTML(string=html, base_url='file:///').write_pdf(output_path)
        with db_conn.cursor() as cur:
            report_id = _insert_generated_report(
                cur, tenant_id, None, 'ai_investigation', now, now, None, output_path)
            cur.execute("UPDATE generated_reports SET delivery_status = 'ready' WHERE id = %s",
                        (report_id,))
        if commit:
            db_conn.commit()
    except Exception:
        if commit:
            db_conn.rollback()
        raise
    log.info('Generated investigation report: %s', output_path)
    return output_path, report_id


def generate_audit_report(
    db_conn,
    tenant_id: int,
    msp_profile_id: int,
    target_name: str,
    result: dict,
    output_dir: str,
    commit: bool = True,
) -> tuple[str, int]:
    """Render a Firewall Audit PDF from a stored audit result; nothing is queried or executed.

    With commit=False the caller owns the transaction (it must commit, or roll back on
    failure); the generated_reports row is inserted but not committed.
    """
    from reports.fwaudit import report_data

    os.makedirs(output_dir, exist_ok=True)
    output_path = None
    try:
        with db_conn.cursor() as cur:
            msp = dict(_fetch_row(cur, 'msp_profiles', 'id', msp_profile_id))
            tenant = _fetch_row(cur, 'tenants', 'id', tenant_id)
        msp['logo_path'] = _validated_logo_path(msp.get('logo_path'))
        msp.update(_brand(msp))
        now = datetime.now(timezone.utc)
        html = _get_jinja_env().get_template('fwaudit/report.html').render(
            msp=msp, tenant=tenant, target_name=target_name,
            d=report_data.prepare(result), generated_at=now)
        slug = tenant.get('slug') or f'tenant{tenant_id}'
        filename = f"{slug}_fwaudit_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
        output_path = os.path.join(output_dir, filename)
        weasyprint.HTML(string=html, base_url='file:///').write_pdf(output_path)
        with db_conn.cursor() as cur:
            report_id = _insert_generated_report(
                cur, tenant_id, None, 'fw_audit', now, now, None, output_path)
            cur.execute("UPDATE generated_reports SET delivery_status = 'ready' WHERE id = %s",
                        (report_id,))
        if commit:
            db_conn.commit()
    except Exception:
        if commit:
            db_conn.rollback()
        if output_path and os.path.exists(output_path):     # no orphan PDF without its row
            try:
                os.remove(output_path)
            except OSError:
                log.exception('could not remove orphan audit PDF %s', output_path)
        raise
    log.info('Generated firewall audit report: %s', output_path)
    return output_path, report_id
