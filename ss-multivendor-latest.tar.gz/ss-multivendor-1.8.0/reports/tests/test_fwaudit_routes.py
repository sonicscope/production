"""Firewall Audit routes: authorisation, validation, upload + run, limits, portal exclusion."""
import io
import os
from datetime import datetime, timedelta, timezone

import psycopg2
import pytest

from reports.fwaudit import routes as fwroutes
from reports.fwaudit import traffic as tr

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit', 'fortigate_hq.conf')


def sql(app_module, query, params=()):
    with psycopg2.connect(**app_module.DB_CONFIG) as conn, conn.cursor() as cur:
        cur.execute(query, params)
        return cur.fetchall() if cur.description else None


def fixture_bytes():
    with open(FIXTURE, 'rb') as fh:
        return fh.read()


@pytest.fixture
def env(app_module, seed_tenants, seed_msp_profile, tmp_path, monkeypatch):
    """Two customers; the first has an MSP profile; OUTPUT_DIR is a temp dir."""
    monkeypatch.setattr(app_module, 'OUTPUT_DIR', str(tmp_path))
    msp = seed_msp_profile('Audit MSP')
    a, b = seed_tenants('Acme', 'Globex')
    sql(app_module, 'UPDATE tenants SET msp_profile_id = %s WHERE id IN (%s, %s)', (msp, a, b))
    return {'a': a, 'b': b}


def add_target(app_module, tenant, name='HQ', vendor='fortigate', sensor=None):
    return sql(app_module, "INSERT INTO audit_targets (tenant_id, name, vendor, sensor_id) "
               "VALUES (%s, %s, %s, %s) RETURNING id", (tenant, name, vendor, sensor))[0][0]


def run(client, csrf_of, target, data=None, name='fw.conf', window=None):
    body = fixture_bytes() if data is None else data
    form = {'_csrf': csrf_of(client), 'config': (io.BytesIO(body), name)}
    if window:
        form['window_days'] = str(window)
    return client.post(f'/audit/targets/{target}/run', data=form,
                       content_type='multipart/form-data')


def count(app_module, table='audit_runs'):
    return sql(app_module, f'SELECT count(*) FROM {table}')[0][0]


# ── authorisation ────────────────────────────────────────────────────────────
@pytest.mark.parametrize('method,path', [
    ('get', '/audit'), ('get', '/audit/targets/1'), ('get', '/audit/runs/1'),
    ('get', '/audit/runs/1/pdf'), ('post', '/audit/targets'),
    ('post', '/audit/targets/1/run'), ('post', '/audit/targets/1/delete')])
def test_customers_and_anonymous_users_get_nothing(client, login_as, env, method, path):
    assert getattr(client, method)(path).status_code in (302, 401, 404)    # anonymous
    login_as('customer', tenant_ids=[env['a']])
    resp = getattr(client, method)(path)
    assert resp.status_code in (302, 404)       # customers are bounced to the portal or get a 404
    assert '/audit' not in resp.headers.get('Location', '')


def test_other_tenants_objects_are_invisible(client, app_module, login_as, csrf_of, env):
    other = add_target(app_module, env['b'])
    login_as('user', tenant_ids=[env['a']])
    assert client.get(f'/audit/targets/{other}').status_code == 404
    assert client.get(f'/audit/targets/{other + 99}').status_code == 404    # same answer: no oracle
    assert run(client, csrf_of, other).status_code == 404
    assert client.post(f'/audit/targets/{other}/delete',
                       data={'_csrf': csrf_of(client)}).status_code == 404
    assert count(app_module) == 0 and count(app_module, 'audit_targets') == 1
    body = client.get('/audit').get_data(as_text=True)
    assert 'Acme' in body and 'Globex' not in body


def add_run(app_module, target, report_id=None):
    return sql(app_module,
               "INSERT INTO audit_runs (target_id, score, band, severity_counts, domain_scores, "
               "coverage, findings, device, notes, traffic, snapshot, report_id) VALUES "
               "(%s, 50, 'Needs attention', '{}', '{}', "
               "'{\"counts\": {}, \"ledger\": [], \"frameworks\": []}', '[]', '{}', '[]', "
               "'{\"available\": false, \"window_days\": 90, \"events\": 0}', '{}', %s) "
               "RETURNING id", (target, report_id))[0][0]


def test_other_tenants_runs_pdfs_and_sensors_are_invisible(client, app_module, login_as,
                                                           seed_report, env):
    other_target = add_target(app_module, env['b'])
    other_run = add_run(app_module, other_target, seed_report(env['b'], 'fw_audit'))
    sql(app_module, "INSERT INTO sensors (tenant_id, name, vendor) VALUES "
        "(%s, 'globex-secret-sensor', 'fortinet')", (env['b'],))
    sql(app_module, "INSERT INTO sensors (tenant_id, name, vendor) VALUES "
        "(%s, 'acme-sensor', 'fortinet')", (env['a'],))
    login_as('user', tenant_ids=[env['a']])
    assert client.get(f'/audit/runs/{other_run}').status_code == 404
    assert client.get(f'/audit/runs/{other_run}/pdf').status_code == 404
    assert client.get(f'/audit/runs/{other_run + 99}').status_code == 404     # same answer
    body = client.get('/audit').get_data(as_text=True)
    assert 'acme-sensor' in body and 'globex-secret-sensor' not in body


def test_csrf_is_required(client, app_module, login_as, env):
    login_as('admin')
    t = add_target(app_module, env['a'])
    r = client.post(f'/audit/targets/{t}/run', data={'config': (io.BytesIO(b'x'), 'f')},
                    content_type='multipart/form-data')
    assert r.status_code == 400 and count(app_module) == 0
    assert client.post('/audit/targets', data={'name': 'x'}).status_code == 400


# ── targets ──────────────────────────────────────────────────────────────────
def test_create_and_validate_targets(client, app_module, login_as, csrf_of, env):
    login_as('user', tenant_ids=[env['a']])
    tok = csrf_of(client)
    ok = client.post('/audit/targets', data={'_csrf': tok, 'tenant_id': env['a'], 'name': 'HQ',
                                             'vendor': 'fortigate'})
    assert ok.status_code == 302 and '/audit/targets/' in ok.headers['Location']
    dup = client.post('/audit/targets', data={'_csrf': tok, 'tenant_id': env['a'], 'name': 'HQ',
                                              'vendor': 'fortigate'}, follow_redirects=True)
    assert 'already has a firewall' in dup.get_data(as_text=True)
    for form in ({'tenant_id': 'x'}, {'tenant_id': str(env['a']), 'sensor_id': 'x'}):
        assert client.post('/audit/targets', data={'_csrf': tok, 'name': 'n', 'vendor': 'fortigate',
                                                   **form}).status_code == 400
    assert client.post('/audit/targets', data={'_csrf': tok, 'tenant_id': env['b'], 'name': 'n',
                                               'vendor': 'fortigate'}).status_code == 404
    bad = client.post('/audit/targets', data={'_csrf': tok, 'tenant_id': env['a'], 'name': 'v',
                                              'vendor': 'checkpoint'}, follow_redirects=True)
    assert 'supported vendor' in bad.get_data(as_text=True)
    assert count(app_module, 'audit_targets') == 1


def test_delete_target(client, app_module, login_as, csrf_of, env):
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    r = client.post(f'/audit/targets/{t}/delete', data={'_csrf': csrf_of(client)})
    assert r.status_code == 302 and count(app_module, 'audit_targets') == 0


# ── running an audit ─────────────────────────────────────────────────────────
def test_run_happy_path_makes_a_run_and_a_pdf(client, app_module, login_as, csrf_of, env):
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    r = run(client, csrf_of, t)
    assert r.status_code == 302
    run_id = int(r.headers['Location'].rsplit('/', 1)[1])
    row = sql(app_module, 'SELECT score, report_id, created_by FROM audit_runs WHERE id = %s',
              (run_id,))[0]
    assert 0 < row[0] < 20 and row[1] and row[2]
    rep = sql(app_module, 'SELECT report_type, file_path, delivery_status FROM generated_reports '
              'WHERE id = %s', (row[1],))[0]
    assert rep[0] == 'fw_audit' and rep[2] == 'ready' and os.path.isfile(rep[1])
    page = client.get(f'/audit/runs/{run_id}').get_data(as_text=True)
    assert 'FWA-RUL-001' in page and 'Download PDF' in page
    pdf = client.get(f'/audit/runs/{run_id}/pdf', follow_redirects=True)
    assert pdf.status_code == 200 and pdf.data.startswith(b'%PDF-')
    assert 'Firewall audit' in client.get('/').get_data(as_text=True)         # labelled in MSP list
    kinds = [k for (k,) in sql(app_module, "SELECT kind FROM ai_audit WHERE kind IN "
                               "('fwaudit_start', 'fwaudit') ORDER BY id")]
    assert kinds == ['fwaudit_start', 'fwaudit']
    assert 'sk-' not in str(sql(app_module, 'SELECT * FROM ai_audit'))      # counts only, no content
    assert os.listdir(app_module.OUTPUT_DIR) == [os.path.basename(rep[1])]  # the upload is not kept


def test_run_input_errors_leave_nothing_behind(client, app_module, login_as, csrf_of, env):
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    r = client.post(f'/audit/targets/{t}/run', data={'_csrf': csrf_of(client)},
                    content_type='multipart/form-data', follow_redirects=True)
    assert 'Choose a configuration file' in r.get_data(as_text=True)
    sw = add_target(app_module, env['a'], 'SW', 'sonicwall')
    r = run(client, csrf_of, sw, data=b'not an export at all', name='x.exp')
    assert r.status_code == 302 and r.headers['Location'].endswith(f'/audit/targets/{sw}')
    assert 'does not look like a SonicWall' in client.get(r.headers['Location']).get_data(as_text=True)
    fg = run(client, csrf_of, t, data=b'hello world')
    assert 'does not look like a FortiGate' in client.get(fg.headers['Location']).get_data(as_text=True)
    assert count(app_module) == 0 and count(app_module, 'generated_reports') == 0
    big = run(client, csrf_of, t, data=b'#' * (fwroutes.MAX_UPLOAD + 10))
    assert big.status_code in (302, 413) and count(app_module) == 0


def test_a_failing_render_rolls_everything_back(client, app_module, login_as, csrf_of, env,
                                                monkeypatch):
    from reports import generator
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])

    def boom(*a, **k):
        raise RuntimeError('secret internal detail')
    monkeypatch.setattr(generator, 'generate_audit_report', boom)
    r = run(client, csrf_of, t)
    page = client.get(r.headers['Location']).get_data(as_text=True)
    assert 'Something went wrong' in page and 'secret internal detail' not in page
    assert count(app_module) == 0 and count(app_module, 'generated_reports') == 0
    assert app_module.app.extensions['fwaudit_inflight'] == {}                # slot released
    assert [k for (k,) in sql(app_module, "SELECT kind FROM ai_audit WHERE kind = 'fwaudit_start'")] \
        == ['fwaudit_start']                                                  # the attempt counted


def test_a_parser_error_is_logged_without_config_content(client, app_module, login_as, csrf_of,
                                                         env, monkeypatch, caplog):
    from reports.fwaudit import engine
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])

    def bad_parse(*a, **k):
        raise ValueError("invalid literal for int(): 'SECRET-CONFIG-TEXT'")
    monkeypatch.setattr(engine, 'run', bad_parse)
    with caplog.at_level('DEBUG'):
        r = run(client, csrf_of, t)
    assert 'Something went wrong' in client.get(r.headers['Location']).get_data(as_text=True)
    assert 'SECRET-CONFIG-TEXT' not in caplog.text
    assert 'ValueError' in caplog.text and count(app_module) == 0
    assert app_module.app.extensions['fwaudit_inflight'] == {}


def test_no_msp_profile_saves_the_run_without_a_pdf(client, app_module, login_as, csrf_of, env):
    sql(app_module, 'UPDATE tenants SET msp_profile_id = NULL')
    sql(app_module, 'INSERT INTO msp_profiles (name) VALUES (%s)', ('Second MSP',))   # now ambiguous
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    r = run(client, csrf_of, t)
    assert r.status_code == 302
    assert sql(app_module, 'SELECT report_id FROM audit_runs') == [(None,)]
    assert 'no PDF was made' in client.get(r.headers['Location']).get_data(as_text=True)


def test_rate_limit_counts_attempts_not_just_successes(client, app_module, login_as, csrf_of, env):
    uid = login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    for _ in range(fwroutes.RUN_PER_MIN - 1):
        sql(app_module, "INSERT INTO ai_audit (kind, user_id, tenant_id) VALUES "
            "('fwaudit_start', %s, %s)", (uid, env['a']))
    assert run(client, csrf_of, t, data=b'garbage').status_code == 302       # 5th attempt: allowed, fails
    assert run(client, csrf_of, t).status_code == 429                         # 6th is refused
    assert count(app_module) == 0


def test_in_flight_cap_is_per_user(client, app_module, login_as, csrf_of, env):
    uid = login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    app_module.app.extensions['fwaudit_inflight'][uid] = 1
    try:
        assert run(client, csrf_of, t).status_code == 429
    finally:
        app_module.app.extensions['fwaudit_inflight'].pop(uid, None)
    assert run(client, csrf_of, t).status_code == 302
    assert app_module.app.extensions['fwaudit_inflight'] == {}


def test_traffic_aware_checks_run_when_a_sensor_is_linked(client, app_module, login_as, csrf_of,
                                                          env):
    login_as('user', tenant_ids=[env['a']])
    sensor = sql(app_module, "INSERT INTO sensors (tenant_id, name, vendor) VALUES (%s, 's', "
                 "'fortinet') RETURNING id", (env['a'],))[0][0]
    t = add_target(app_module, env['a'], sensor=sensor)
    when = datetime.now(timezone.utc) - timedelta(days=2)
    for _ in range(3):
        sql(app_module, "INSERT INTO fw_events (time, tenant_id, sensor_id, vendor, data_source, "
            "event_type, action, src_ip, dst_ip, dst_port, bytes_sent, rule_name, rule_id) VALUES "
            "(%s, %s, %s, 'fortinet', 'syslog', 'traffic', 'allow', '203.0.113.7', '10.0.0.50', "
            "3389, 500, 'RDP-pub', 3)", (when, env['a'], sensor))
    r = run(client, csrf_of, t, window=30)
    run_id = int(r.headers['Location'].rsplit('/', 1)[1])
    page = client.get(f'/audit/runs/{run_id}').get_data(as_text=True)
    assert 'FWA-TRF-003' in page and 'Traffic compared: last 30 days' in page
    traffic = sql(app_module, 'SELECT traffic FROM audit_runs WHERE id = %s', (run_id,))[0][0]
    assert traffic == {'available': True, 'window_days': 30, 'events': 3}


def test_a_sensor_moved_to_another_customer_is_not_used(client, app_module, login_as, csrf_of,
                                                         env):
    login_as('user', tenant_ids=[env['a']])
    sensor = sql(app_module, "INSERT INTO sensors (tenant_id, name, vendor) VALUES (%s, 's', "
                 "'fortinet') RETURNING id", (env['a'],))[0][0]
    t = add_target(app_module, env['a'], sensor=sensor)
    when = datetime.now(timezone.utc) - timedelta(days=2)
    sql(app_module, "INSERT INTO fw_events (time, tenant_id, sensor_id, vendor, data_source, "
        "event_type, action, src_ip, dst_ip, dst_port, bytes_sent, rule_name, rule_id) VALUES "
        "(%s, %s, %s, 'fortinet', 'syslog', 'traffic', 'allow', '203.0.113.7', '10.0.0.50', "
        "3389, 500, 'RDP-pub', 3)", (when, env['b'], sensor))
    sql(app_module, 'UPDATE sensors SET tenant_id = %s WHERE id = %s', (env['b'], sensor))
    r = run(client, csrf_of, t)
    run_id = int(r.headers['Location'].rsplit('/', 1)[1])
    traffic, notes = sql(app_module, 'SELECT traffic, notes FROM audit_runs WHERE id = %s',
                         (run_id,))[0]
    assert traffic['available'] is False
    assert any('no longer matches' in n for n in notes)


def test_results_filters_ignore_junk(client, app_module, login_as, csrf_of, env):
    login_as('user', tenant_ids=[env['a']])
    t = add_target(app_module, env['a'])
    run_id = int(run(client, csrf_of, t).headers['Location'].rsplit('/', 1)[1])
    base = client.get(f'/audit/runs/{run_id}').get_data(as_text=True)
    junk = client.get(f'/audit/runs/{run_id}?sev=%3Cscript%3E&domain=%27%3B')
    assert junk.status_code == 200 and '<script>' not in junk.get_data(as_text=True)
    assert junk.get_data(as_text=True).count('class="finding"') == base.count('class="finding"')
    only = client.get(f'/audit/runs/{run_id}?sev=1').get_data(as_text=True)
    assert 0 < only.count('class="finding"') < base.count('class="finding"')


# ── portal exclusion ─────────────────────────────────────────────────────────
@pytest.mark.parametrize('path', ['/portal', '/portal/reports'])
def test_customers_never_see_audit_pdfs(client, app_module, login_as, seed_report, env, path):
    audit_pdf = seed_report(env['a'], 'fw_audit')
    periodic = seed_report(env['a'], 'periodic')
    login_as('customer', tenant_ids=[env['a']])
    body = client.get(path).get_data(as_text=True)
    assert f'/reports/{periodic}/download' in body
    assert f'/reports/{audit_pdf}/download' not in body
    assert client.get(f'/reports/{audit_pdf}/download').status_code == 404
    assert client.get(f'/reports/{periodic}/download').status_code == 200
