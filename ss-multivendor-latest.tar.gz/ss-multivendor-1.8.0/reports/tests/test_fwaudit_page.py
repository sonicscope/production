import datetime
import os

from reports.fwaudit import engine, page

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit', 'fortigate_hq.conf')
NOW = datetime.datetime(2026, 11, 21, 9, 30)
XSS = '<script>alert(1)</script>'


def _run(**kw):
    res = engine.run('fortigate', open(FIXTURE).read())
    run = {'id': 7, 'target_id': 3, 'started_at': NOW, 'report_id': 9, 'target_name': 'HQ',
           'tenant_name': 'Acme', 'vendor': 'fortigate', 'tenant_id': 1,
           'score': res['score'], 'band': res['band'], 'severity_counts': res['severity_counts'],
           'domain_scores': res['domain_scores'], 'counts': res['counts'],
           'ledger': res['ledger'], 'frameworks': res['frameworks'], 'findings': res['findings'],
           'device': res['device'], 'notes': res['notes'], 'traffic': res['traffic']}
    run.update(kw)
    return run


def test_index_lists_targets_and_escapes():
    targets = [{'id': 1, 'tenant_id': 1, 'tenant_name': XSS, 'name': XSS, 'vendor': 'fortigate',
                'sensor_id': None, 'run_id': 5, 'started_at': NOW, 'score': 62, 'band': 'Needs attention',
                'report_id': None},
               {'id': 2, 'tenant_id': 1, 'tenant_name': 'Acme', 'name': 'New', 'vendor': 'sonicwall',
                'sensor_id': None, 'run_id': None, 'started_at': None, 'score': None, 'band': None,
                'report_id': None}]
    html = page.index_html(targets, [(1, XSS)], [(4, 1, 'sensor<b>', 'fortigate')])
    assert XSS not in html and '&lt;script&gt;' in html and 'sensor&lt;b&gt;' in html
    assert '62' in html and 'Not audited yet' in html and 'action="/audit/targets"' in html
    assert 'Add a firewall' in html
    assert 'No firewalls yet' in page.index_html([], [], [])


def test_target_page_shows_hints_and_window_only_with_sensor():
    t = {'id': 3, 'tenant_name': 'Acme', 'name': 'HQ', 'vendor': 'fortigate', 'sensor_id': None}
    html = page.target_html(t, [])
    assert 'show full-configuration' in html and 'traffic-aware checks' in html
    assert 'name="window_days"' not in html and 'enctype="multipart/form-data"' in html
    assert 'name="window_days"' in page.target_html(dict(t, sensor_id=4), [])
    runs = [{'id': 7, 'started_at': NOW, 'score': 40, 'band': 'At risk',
             'severity_counts': {'critical': 2, 'high': 3}, 'report_id': 9}]
    html = page.target_html(t, runs)
    assert '/audit/runs/7/pdf' in html and '2 critical, 3 high' in html


def test_run_page_filters_and_escapes():
    run = _run()
    run['findings'][0]['title'] = XSS
    run['findings'][0]['evidence'] = [XSS]
    html = page.run_html(run)
    assert XSS not in html and '&lt;script&gt;' in html
    assert 'What was checked' in html and 'Download PDF' in html
    crit = page.run_html(run, sev='1')
    assert crit.count('class="finding"') == sum(1 for f in run['findings'] if f['severity'] == 1)
    only_rul = page.run_html(run, domain='RUL')
    assert only_rul.count('class="finding"') == sum(1 for f in run['findings'] if f['domain'] == 'RUL')
    assert 'class="fid">FWA-RUL-001 ' in only_rul and 'class="fid">FWA-MGT-004 ' not in only_rul
    assert page.run_html(run, sev='9', domain='nope').count('class="finding"') == len(run['findings'])
    assert 'Clear filters' in page.run_html(run, sev='2')
    assert 'Download PDF' not in page.run_html(_run(report_id=None))


def test_run_page_shows_coverage_and_unassessed_domains():
    run = _run(score=90, band='Limited coverage',
               domain_scores={'MGT': 80, 'RUL': None},
               counts={'passed': 2, 'finding': 1, 'not_applicable': 0,
                       'could_not_determine': 43, 'skipped': 5})
    html = page.run_html(run)
    assert '3 of 51 checks assessed' in html and 'Limited coverage' in html
    assert html.count('Not assessed') >= 7                   # every domain except MGT
    assert 'width:80%' in html
