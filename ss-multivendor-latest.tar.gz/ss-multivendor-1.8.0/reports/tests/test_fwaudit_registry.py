import pytest  # noqa: F401

from reports.fwaudit import checks as _checks  # noqa: F401  (registers every check)
from reports.fwaudit import framework as fw
from reports.fwaudit.model import NormalizedConfig


def _cfg(vendor='fortigate'):
    return NormalizedConfig(vendor=vendor)


def test_registry_ids_are_unique_and_well_formed():
    assert len(fw.REGISTRY) >= 45
    for cid, (meta, _fn) in fw.REGISTRY.items():
        assert cid == meta.id
        assert meta.domain in fw.DOMAINS


def test_every_check_ends_in_exactly_one_ledger_state():
    res = fw.run_checks(_cfg())
    assert len(res['ledger']) == len(fw.REGISTRY)
    assert {e['check_id'] for e in res['ledger']} == set(fw.REGISTRY)
    assert all(e['state'] in fw.STATES for e in res['ledger'])
    assert sum(res['counts'].values()) == len(fw.REGISTRY)


def test_empty_config_is_undetermined_never_a_false_pass_or_finding():
    res = fw.run_checks(_cfg())
    assert res['findings'] == [] and res['counts']['passed'] == 0
    assert res['counts']['could_not_determine'] > 0


def test_empty_config_reports_limited_coverage_not_a_clean_score():
    res = fw.run_checks(_cfg())
    assert res['band'] == 'Limited coverage'
    assert res['coverage']['assessed'] == 0 and res['coverage']['pct'] == 0
    assert res['coverage']['total'] == len(fw.REGISTRY) - res['counts']['not_applicable']
    assert all(v is None for v in res['domain_scores'].values())   # nothing assessed anywhere


def test_logs_required_checks_are_skipped_without_logs():
    res = fw.run_checks(_cfg())
    trf = [e for e in res['ledger'] if e['domain'] == 'TRF']
    assert trf and all(e['state'] == fw.SKIPPED for e in trf)
