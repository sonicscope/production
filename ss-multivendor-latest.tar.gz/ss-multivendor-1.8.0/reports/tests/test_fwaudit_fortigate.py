import os

import pytest

from reports.fwaudit import engine
from reports.fwaudit import framework as fw
from reports.fwaudit.model import ANY
from reports.fwaudit.errors import ConfigError
from reports.fwaudit.parsers import fortigate

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit', 'fortigate_hq.conf')


def _cfg():
    with open(FIXTURE) as fh:
        return fortigate.normalize(fh.read())


def test_device_and_facts_with_provenance():
    c = _cfg()
    assert c.device['model'] == 'FGVM64' and c.device['firmware'] == '7.4.3'
    f = c.fact('admin.timeout_min')
    assert f.known and f.value == 30 and f.src == 'system global/admintimeout'
    assert c.fact('admin.telnet').value is True
    assert c.fact('admin.tls_min').value == '1.1'
    assert c.fact('admin.mfa').value is False and c.fact('admin.default_account').value is True
    assert c.fact('admin.pw_min_len').value is None             # known: no password policy
    assert c.fact('logging.remote').value is False
    assert c.fact('services.ips').value is False


def test_values_not_in_the_export_stay_unknown():
    c = _cfg()
    assert not c.fact('vpn.ssl_mfa').known and not c.fact('ntp.enabled').known


def test_rules_keep_order_and_normalise_any():
    c = _cfg()
    assert [r.name for r in c.rules] == ['LAN-out', 'any-any', 'RDP-pub']
    r0, r1, r2 = c.rules
    assert r0.action == 'allow' and r0.dst_addr == (ANY,) and r0.service == (ANY,)
    assert r0.src_addr == ('LAN-net',) and r0.log == 'all'
    assert r1.log == 'utm' and r1.src_addr == (ANY,)        # FortiOS default is utm-only logging
    assert r2.log == 'none' and r2.service == ('RDP',)
    assert c.has('rules') and c.has('nat') and c.has('vpn') and c.has('interfaces')


def test_interfaces_nat_vpn():
    c = _cfg()
    wan = [i for i in c.interfaces if i.role == 'wan'][0]
    assert wan.mgmt == ('ping', 'https', 'ssh') and wan.trusted_hosts is False
    nat = c.nat[0]
    assert nat.ports == ((3389, 3389),) and nat.internal == '10.0.0.50'
    assert nat.source_restricted is False and nat.ips is False
    v = c.vpn[0]
    assert v.aggressive and v.ike_version == 1 and 'aes256' in v.enc and '3des' in v.enc
    assert v.dh == (2, 14) and v.psk_weak is None


def test_address_objects_expand():
    c = _cfg()
    assert c.addresses['LAN-net'] == ['10.0.0.0/24']
    assert [str(n) for n in c.nets(('LAN-net',))] == ['10.0.0.0/24']
    assert c.nets(('all',)) is None and c.nets(('unknown-object',)) is None


def test_partial_export_marks_only_what_it_read():
    c = fortigate.normalize('config firewall policy\n  edit 1\n  set action accept\n next\nend\n')
    assert c.has('rules') and not c.has('vpn') and not c.has('nat')
    assert not c.fact('admin.timeout_min').known


def test_multi_vdom_audits_root_and_says_so():
    txt = ('config global\n config system global\n  set admintimeout 5\n end\nend\n'
           'config vdom\n edit root\n config firewall policy\n  edit 1\n   set action accept\n  next\n end\n next\n'
           ' edit other\n config firewall policy\n  edit 9\n   set action deny\n  next\n end\n next\nend\n')
    c = fortigate.normalize(txt)
    assert [r.rid for r in c.rules] == ['1']
    assert any('Multi-VDOM' in n for n in c.notes)


def test_restricted_rules_are_flagged():
    txt = ('config system global\nend\nconfig firewall policy\n edit 1\n  set users "bob"\n next\n'
           ' edit 2\n  set srcaddr-negate enable\n next\n edit 3\n  set srcaddr "all"\n next\nend\n')
    c = fortigate.normalize(txt)
    assert [r.restricted for r in c.rules] == [True, True, False]


def test_hostile_values_do_not_crash():
    txt = ('config system global\nend\nconfig firewall address\n edit "x"\n set subnet notanip\n next\n'
           ' edit "y"\n set type iprange\n set start-ip 1.1.1.1\n set end-ip bad\n next\nend\n'
           'config firewall vip\n edit "v"\n set portforward enable\n set extport 1-99999999\n next\nend\n'
           'config system global\n set admintimeout abc\nend\n'
           'config vpn ipsec phase1-interface\n edit "t"\n set ike-version two\n next\nend\n')
    c = fortigate.normalize(txt)
    assert c.addresses == {} and c.nat[0].ports is None and c.vpn[0].ike_version == 1


def test_files_without_fortigate_content_are_rejected():
    for junk in ('', 'hello world', 'config foo bar\n set a 1\nend\n'):
        with pytest.raises(ConfigError, match='FortiGate'):
            fortigate.normalize(junk)


# ── absent fields, internet-service, IPv6, static NAT (review I3/I4) ─────────
HEADER = '#config-version=FGT60F-7.2.8-FW-build1639-240313:opmode=0:vdom=0:user=admin\n'
BASE = HEADER + """config system global
    set hostname "fw"
end
config system interface
    edit "wan1"
        set role wan
    next
    edit "internal"
        set role lan
    next
end
config firewall address
    edit "srv"
        set subnet 10.0.0.5 255.255.255.255
    next
end
config firewall address6
    edit "h6"
        set ip6 2001:db8::5/128
    next
end
"""


def _policy(pid: int, **sets) -> str:
    lines = [f'    edit {pid}']
    for k, v in sets.items():
        lines.append(f'        set {k.replace("_", "-")} {v}')
    return '\n'.join(lines + ['    next'])


def _conf(*policies, extra: str = '') -> str:
    return BASE + extra + 'config firewall policy\n' + '\n'.join(policies) + '\nend\n'


def _states(text):
    res = engine.run('fortigate', text)
    return ({e['check_id']: e['state'] for e in res['ledger']},
            {f['check_id']: f for f in res['findings']})


def test_absent_address_and_service_are_unknown_not_any():
    c = fortigate.normalize(_conf(_policy(1, srcintf='"internal"', dstintf='"wan1"',
                                          action='accept')))
    r = c.rules[0]
    assert r.src_addr == () and r.dst_addr == () and r.service == ()
    assert c.nets(r.src_addr) is None
    states, _ = _states(_conf(_policy(1, srcintf='"internal"', dstintf='"wan1"',
                                      action='accept')))
    assert states['FWA-RUL-001'] == fw.PASSED and states['FWA-RUL-009'] == fw.PASSED


def test_internet_service_policy_is_not_any_any():
    text = _conf(_policy(1, name='"o365"', srcintf='"internal"', dstintf='"wan1"',
                         srcaddr='"all"', internet_service='enable',
                         internet_service_name='"Microsoft-Office365"', action='accept'))
    r = fortigate.normalize(text).rules[0]
    assert r.dst_addr == ('internet-service',) and r.service == ('internet-service',)
    assert r.src_addr == (ANY,)
    states, _ = _states(text)
    assert states['FWA-RUL-001'] == fw.PASSED and states['FWA-RUL-002'] == fw.PASSED


def test_ipv6_only_policy_reads_srcaddr6_and_dstaddr6():
    text = _conf(_policy(1, srcintf='"internal"', dstintf='"wan1"', srcaddr6='"h6"',
                         dstaddr6='"all"', service='"ALL"', action='accept'))
    r = fortigate.normalize(text).rules[0]
    assert r.src_addr == ('h6',) and r.dst_addr == (ANY,) and r.families == ('6',)
    states, _ = _states(text)
    assert states['FWA-RUL-001'] == fw.PASSED
    dual = fortigate.normalize(_conf(_policy(
        1, srcaddr='"srv"', srcaddr6='"all"', dstaddr='"all"', dstaddr6='"all"',
        service='"ALL"', action='accept'))).rules[0]
    assert dual.src_addr == ('srv', '::/0') and dual.dst_addr == (ANY,)
    assert dual.families == ('4', '6')


def test_v4_any_rule_does_not_shadow_a_v6_only_rule():
    text = _conf(_policy(1, srcintf='"internal"', dstintf='"wan1"', srcaddr='"all"',
                         dstaddr='"all"', service='"ALL"', action='accept'),
                 _policy(2, srcintf='"internal"', dstintf='"wan1"', srcaddr6='"h6"',
                         dstaddr6='"all"', service='"ALL"', action='deny'))
    states, _ = _states(text)
    assert states['FWA-RUL-003'] == fw.PASSED


def test_user_restricted_any_any_is_not_reported_as_any_any():
    text = _conf(_policy(1, srcintf='"internal"', dstintf='"wan1"', srcaddr='"all"',
                         dstaddr='"all"', service='"ALL"', groups='"staff"', action='accept'))
    states, _ = _states(text)
    assert states['FWA-RUL-001'] == fw.PASSED
    assert states['FWA-RUL-002'] == fw.PASSED and states['FWA-RUL-009'] == fw.PASSED


def test_genuine_any_any_is_still_critical():
    text = _conf(_policy(1, srcintf='"internal"', dstintf='"wan1"', srcaddr='"all"',
                         dstaddr='"all"', service='"ALL"', action='accept'))
    states, found = _states(text)
    assert states['FWA-RUL-001'] == fw.FINDING and found['FWA-RUL-001']['severity'] == 1


def test_restricted_inbound_rule_needs_validation():
    text = _conf(_policy(1, srcintf='"wan1"', dstintf='"internal"', srcaddr='"all"',
                         dstaddr='"srv"', service='"RDP"', users='"bob"', action='accept'))
    states, found = _states(text)
    assert states['FWA-EXP-004'] == fw.FINDING and found['FWA-EXP-004']['needs_validation']


STATIC_VIP = """config firewall service custom
    edit "ALLTCP"
        set tcp-portrange 1-65535
    next
    edit "BROKEN"
        set tcp-portrange abc-def
    next
end
config firewall vip
    edit "static-srv"
        set extip 203.0.113.5
        set mappedip "10.0.0.5"
        set extintf "wan1"
    next
end
"""


def test_static_vip_with_wide_custom_service_fails_exposure_checks():
    text = _conf(_policy(1, name='"pub"', srcintf='"wan1"', dstintf='"internal"',
                         srcaddr='"all"', dstaddr='"static-srv"', service='"ALLTCP"',
                         action='accept', schedule='"always"'), extra=STATIC_VIP)
    c = fortigate.normalize(text)
    assert c.services['ALLTCP'] == ((1, 65535),) and c.services['BROKEN'] is None
    assert c.nat[0].ports == ((1, 65535),) and c.nat[0].source_restricted is False
    states, found = _states(text)
    assert states['FWA-EXP-001'] == fw.FINDING and found['FWA-EXP-001']['severity'] == 1
    assert states['FWA-EXP-004'] == fw.FINDING and 'RDP (3389)' in found['FWA-EXP-004']['evidence'][0]
    assert states['FWA-SEG-001'] == fw.FINDING


def test_unused_static_vip_is_reported_with_needs_validation():
    states, found = _states(_conf(extra=STATIC_VIP))
    assert states['FWA-EXP-001'] == fw.FINDING and found['FWA-EXP-001']['needs_validation']


def test_unparseable_custom_service_is_undetermined_not_no_ports():
    text = _conf(_policy(1, srcintf='"wan1"', dstintf='"internal"', srcaddr='"all"',
                         dstaddr='"srv"', service='"BROKEN"', action='accept'), extra=STATIC_VIP)
    states, _ = _states(text)
    assert states['FWA-EXP-004'] == fw.UNDETERMINED


def test_wide_port_forward_range_hits_risky_ports():
    vip = ('config firewall vip\n    edit "rng"\n        set extip 203.0.113.6\n'
           '        set mappedip "10.0.0.6"\n        set portforward enable\n'
           '        set extport 1000-2000\n    next\nend\n')
    c = fortigate.normalize(_conf(extra=vip))
    assert c.nat[0].ports == ((1000, 2000),)
    states, found = _states(_conf(extra=vip))
    assert states['FWA-EXP-001'] == fw.FINDING and 'MS-SQL (1433)' in found['FWA-EXP-001']['evidence'][0]


def test_service_groups_expand_and_unknown_members_stay_unknown():
    grp = ('config firewall service custom\n    edit "c1"\n        set tcp-portrange 3389\n'
           '    next\nend\nconfig firewall service group\n    edit "remote"\n'
           '        set member "c1" "SSH"\n    next\n    edit "odd"\n'
           '        set member "c1" "nosuch"\n    next\nend\n')
    c = fortigate.normalize(_conf(extra=grp))
    assert c.services['remote'] == ((22, 22), (3389, 3389)) and c.services['odd'] is None


# ── partial exports, role inference, normaliser assumptions (review M3-M5) ───
def test_global_without_backup_header_is_not_a_full_export():
    text = 'config system global\n    set admintimeout 10\nend\n'
    c = fortigate.normalize(text)
    assert not c.has('nat') and not c.has('vpn') and not c.has('rules')
    assert c.fact('admin.timeout_min').value == 10            # what is there is still read
    assert not c.fact('admin.snmp_v1v2').known and not c.fact('services.ips').known
    full = fortigate.normalize(HEADER + text)
    assert full.has('nat') and full.has('vpn') and full.has('rules')
    assert full.fact('admin.snmp_v1v2').value is False


@pytest.mark.parametrize('name,role', [
    ('vlan10', None), ('patriot', None), ('wan1', 'wan'), ('WAN', 'wan'), ('internal1', 'lan'),
    ('lan', 'lan'), ('guest-wifi', 'guest'), ('iot_cams', 'iot'), ('dmz', 'dmz'),
    ('port1', None), ('mgmt', 'mgmt'), ('swan', None), ('planet', None)])
def test_role_inference_uses_name_tokens(name, role):
    assert fortigate._role(name, None) == role


def test_mixed_role_zone_gets_no_role():
    from reports.fwaudit.checks.common import role_map
    from reports.fwaudit.model import Interface
    from reports.tests.fwaudit_helpers import cfg
    c = cfg()
    c.interfaces = [Interface('a', zone='Z', role='lan'), Interface('b', zone='Z', role='dmz'),
                    Interface('c', zone='Y', role='lan'), Interface('d', zone='Y', role='lan')]
    rm = role_map(c)
    assert 'z' not in rm and rm['y'] == 'lan' and rm['a'] == 'lan' and rm['b'] == 'dmz'


@pytest.mark.parametrize('section', ['log syslogd2 setting', 'log syslogd4 setting',
                                     'log fortianalyzer3 setting',
                                     'log fortianalyzer-cloud setting'])
def test_additional_log_destinations_count_as_remote_logging(section):
    c = fortigate.normalize(HEADER + f'config {section}\n    set status enable\nend\n'
                            'config system global\n    set hostname "fw"\nend\n')
    assert c.fact('logging.remote').value is True


def test_profile_groups_make_profiles_unknown():
    text = _conf(_policy(1, srcintf='"internal"', dstintf='"wan1"', srcaddr='"all"',
                         dstaddr='"all"', service='"HTTPS"', action='accept',
                         utm_status='enable', profile_type='group', profile_group='"pg"'))
    c = fortigate.normalize(text)
    assert c.rules[0].profiles == {}
    assert not c.fact('services.ips').known and not c.fact('services.av').known
    states, _ = _states(text)
    assert states['FWA-RUL-008'] == fw.UNDETERMINED and states['FWA-THR-001'] == fw.UNDETERMINED


def test_remote_auth_admins_make_mfa_unknown():
    admins = ('config system admin\n    edit "admin"\n        set accprofile "super_admin"\n'
              '    next\n    edit "radius-ops"\n        set remote-auth enable\n'
              '        set remote-group "ops"\n    next\nend\n')
    c = fortigate.normalize(HEADER + 'config system global\nend\n' + admins)
    assert not c.fact('admin.mfa').known
    assert c.fact('admin.default_account').value is True
