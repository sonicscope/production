import base64
import os
import urllib.parse

import pytest

from reports.fwaudit.errors import ConfigError

from reports.fwaudit import compliance, engine
from reports.fwaudit import framework as fw
from reports.fwaudit.parsers import fortitree, sonicwall

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit', 'fortigate_hq.conf')


def exp(**kv):
    raw = '&'.join(f'{k}={urllib.parse.quote(v)}' for k, v in kv.items())
    return base64.b64encode(raw.encode()).decode()


def test_fortigate_fixture_end_to_end():
    res = engine.run('fortigate', open(FIXTURE).read())
    ids = {f['check_id'] for f in res['findings']}
    assert {'FWA-RUL-001', 'FWA-EXP-001', 'FWA-EXP-004', 'FWA-MGT-004', 'FWA-VPN-001',
            'FWA-VPN-002', 'FWA-MGT-010', 'FWA-RUL-004'} <= ids
    assert 0 < res['score'] < 20 and res['band'] == 'At risk'      # many findings: low, but not a flat 0
    assert sum(res['counts'].values()) == len(fw.REGISTRY) == len(res['ledger'])
    assert res['traffic'] == {'available': False, 'window_days': 90, 'events': 0}
    assert res['device']['model'] == 'FGVM64' and res['snapshot']['vendor'] == 'fortigate'
    assert res['frameworks'] and all(f['controls'] for f in res['frameworks'])
    sev = [f['severity'] for f in res['findings']]
    assert sev == sorted(sev)                                   # most severe first
    assert all(f['evidence'] for f in res['findings'])          # every finding carries evidence


def test_result_is_json_serialisable_and_has_no_secrets():
    import json
    res = engine.run('fortigate', open(FIXTURE).read())
    blob = json.dumps(res)
    assert 'ENC abc' not in blob
    assert 'abc' not in json.dumps(res['snapshot'])            # the PSK value never persists
    assert 'psksecret' not in blob.lower()                     # nor the raw key
    assert 'xyz' not in blob                                   # the admin password hash


def test_sonicwall_facts_only_reports_the_rest_as_undetermined():
    res = engine.run('sonicwall', exp(shortProdName='NSa 2800', buildNum='8.1.0',
                                      adminLoginTimeout='30', adminOtpReq='0',
                                      adminLoginOtpRequire='0', cli_loginBanner='',
                                      syslogServerName='', botnetBlock='0'))
    ids = {f['check_id'] for f in res['findings']}
    assert ids == {'FWA-MGT-001', 'FWA-MGT-002', 'FWA-MGT-008', 'FWA-RES-004', 'FWA-THR-005'}
    assert res['counts']['could_not_determine'] > 30
    assert any('Not read from this export: access rules, interfaces, NAT policies, IPsec '
               'policies' in n for n in res['notes'])


def test_sonicwall_settings_only_is_limited_coverage_with_unassessed_domains():
    res = engine.run('sonicwall', exp(shortProdName='NSa 2800', buildNum='8.1.0',
                                      adminLoginTimeout='10', adminOtpReq='1',
                                      cli_loginBanner='Authorised use only'))
    assert res['band'] == 'Limited coverage' and res['coverage']['pct'] < 50
    assert res['coverage']['assessed'] == res['counts']['passed'] + res['counts']['finding']
    for dom in ('RUL', 'EXP', 'VPN', 'SEG', 'TRF'):
        assert res['domain_scores'][dom] is None, dom
    assert res['domain_scores']['MGT'] is not None


def test_sonicwall_decode_variants():
    plain = 'adminLoginTimeout=5&shortProdName=TZ+370'
    assert sonicwall.decode(plain)['adminLoginTimeout'] == '5'
    wrapped = base64.encodebytes(plain.encode()).decode()          # base64 with line breaks
    assert sonicwall.decode(wrapped)['adminLoginTimeout'] == '5'
    with pytest.raises(ConfigError):
        sonicwall.decode('this is not an export')
    with pytest.raises(ConfigError):
        sonicwall.decode('a=b&' * (sonicwall.MAX_PAIRS + 1))


def test_sonicwall_values_cannot_inject_settings():
    kv = sonicwall.decode(exp(adminOtpReq='0', cli_loginBanner='Welcome&adminOtpReq=1&x=%3D'))
    assert kv['adminOtpReq'] == '0'
    assert kv['cli_loginBanner'] == 'Welcome&adminOtpReq=1&x=%3D'
    assert sonicwall.decode('shortProdName=TZ+370&a=b')['shortProdName'] == 'TZ 370'


def test_non_ascii_digits_are_unknown_not_a_crash():
    res = engine.run('sonicwall', exp(adminLoginTimeout='\u00b2', shortProdName='TZ'))
    assert {e['check_id']: e['state'] for e in res['ledger']}['FWA-MGT-001'] == fw.UNDETERMINED
    hdr = '#config-version=FGT60F-7.2.8-FW-build1639-240313:opmode=0:vdom=0:user=admin\n'
    for text in (hdr + 'config system global\n set admintimeout \u00b2\nend\n',
                 hdr + 'config system global\n set hostname x\nend\n'
                       'config vpn ipsec phase1-interface\n edit "t"\n set dhgrp \u00b2 14\n'
                       ' set ike-version \u00b2\n next\nend\n'
                       'config firewall vip\n edit "v"\n set portforward enable\n'
                       ' set extport \u00b2\n next\nend\n'):
        engine.run('fortigate', text)                         # no exception
    c = fortitree_cfg(hdr + 'config system global\n set admintimeout \u00b2\nend\n')
    assert not c.fact('admin.timeout_min').known


def fortitree_cfg(text):
    from reports.fwaudit.parsers import fortigate
    return fortigate.normalize(text)


def test_unsupported_vendor_and_hostile_files():
    with pytest.raises(ValueError):
        engine.run('checkpoint', 'x')
    for junk in ('', '\x00' * 1000, 'config\n' * 3, 'set a b\n',
                 '<?xml version="1.0"?><!DOCTYPE x [<!ENTITY a "' + 'a' * 100 + '">]><x>&a;</x>'):
        with pytest.raises(ConfigError, match='FortiGate'):         # never a fake "score 100" run
            engine.run('fortigate', junk)
    with pytest.raises(ConfigError):
        engine.run('fortigate', 'x' * (fortitree.MAX_BYTES + 1))
    with pytest.raises(ConfigError):
        engine.run('sonicwall', '')


def test_compliance_tags_and_matrix():
    assert compliance.tags_for('FWA-MGT-002')['pci'] == ['8.4.2']
    assert compliance.tags_for('FWA-RUL-001')['iso'] == ['A.8.20', 'A.8.22']
    assert compliance.tags_for('FWA-ZZZ-001') == {}
    t = compliance.tags_for('FWA-RUL-001')
    t['iso'].append('x')
    assert 'x' not in compliance.tags_for('FWA-RUL-001')['iso']        # callers get copies
    ledger = [{'check_id': 'FWA-MGT-001', 'state': 'finding'},
              {'check_id': 'FWA-MGT-002', 'state': 'passed'},
              {'check_id': 'FWA-MGT-003', 'state': 'could_not_determine'},
              {'check_id': 'FWA-RUL-001', 'state': 'passed'},
              {'check_id': 'FWA-TRF-001', 'state': 'skipped'}]
    m = {r['key']: r for r in compliance.matrix(ledger)}
    ctl = {c['control']: c for c in m['pci']['controls']}
    assert ctl['8.4.2']['status'] == 'finding' and ctl['8.4.2']['findings'] == 1   # MGT-001 + MGT-002
    assert ctl['1.3.1']['status'] == 'passed'                                         # only RUL-001
    assert ctl['10.4.1']['status'] == 'not_assessed'                                  # only TRF-001, skipped
    assert m['pci']['controls'][0]['status'] == 'finding'                             # worst first
    assert m['pci']['summary']['finding'] >= 1
    assert {'nist', 'sp80053', 'iso', 'pci', 'cis', 'popia'} <= set(m)               # all six frameworks
    mixed = compliance.matrix([{'check_id': 'FWA-TRF-001', 'state': 'skipped'},
                               {'check_id': 'FWA-RUL-001', 'state': 'passed'}])
    pci = {c['control']: c['status'] for c in {r['key']: r for r in mixed}['pci']['controls']}
    assert pci['1.2.7'] == 'undetermined'                 # passed + skipped is not a pass
    only_undetermined = compliance.matrix([{'check_id': 'FWA-MGT-003', 'state': 'could_not_determine'}])
    assert {c['status'] for c in only_undetermined[0]['controls']} == {'undetermined'}


def test_indexed_groups_numbered_settings():
    kv = {'objName_1': 'b', 'objAction_1': 'allow', 'objName_0': 'a', 'objAction_0': 'deny',
          'other_0': 'x', 'objName_99999': 'skipped', 'objName': 'no-suffix', 'obj_Name_2': 'y',
          'objName_2x': 'z'}
    got = sonicwall.indexed(kv, ['objName', 'objAction'])
    assert list(got) == [0, 1]                                    # numeric order, bounded
    assert got[0] == {'objName': 'a', 'objAction': 'deny'}
    assert got[1] == {'objName': 'b', 'objAction': 'allow'}
    assert sonicwall.indexed({}, ['objName']) == {} and sonicwall.indexed(kv, []) == {}


def test_800_53_and_cis_controls_are_tagged_and_overrides_merge():
    t = compliance.tags_for('FWA-MGT-001')
    assert t['sp80053'] == ['AC-11', 'AC-12'] and t['cis'] == ['4.3']       # override replaces
    assert t['nist'] == compliance.DOMAIN_TAGS['MGT']['nist']                # other frameworks keep defaults
    assert compliance.tags_for('FWA-MGT-008')['cis'] == []                   # an explicit "no CIS control"
    assert compliance.tags_for('FWA-RUL-001')['sp80053'] == ['AC-4', 'CM-6', 'SC-7']
    for cid in fw.REGISTRY:                                                  # every check maps to 800-53
        assert compliance.tags_for(cid)['sp80053'], cid
    assert set(compliance.CHECK_TAGS) <= set(fw.REGISTRY)                    # no override for a missing check
    assert set(compliance.SHORT) == set(compliance.FRAMEWORKS)
    res = engine.run('fortigate', open(FIXTURE).read())
    f = res['findings'][0]
    assert 'sp80053' in f['frameworks'] and 'cis' in f['frameworks']
