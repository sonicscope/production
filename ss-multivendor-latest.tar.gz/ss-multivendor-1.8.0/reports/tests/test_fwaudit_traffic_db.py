"""traffic.load against real fw_events rows."""
from datetime import datetime, timedelta, timezone

import psycopg2
import pytest

from reports.fwaudit import framework as fw
from reports.fwaudit import traffic as tr
from reports.tests.fwaudit_helpers import cfg, run1

NOW = datetime.now(timezone.utc)


@pytest.fixture
def cur(app_module):
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    yield conn.cursor()
    conn.rollback()
    conn.close()


@pytest.fixture
def sensors(cur, seed_tenants):
    t, = seed_tenants('Acme')
    ids = []
    for n in ('s1', 's2'):
        cur.execute("INSERT INTO sensors (tenant_id, name, vendor) VALUES (%s, %s, 'fortinet') "
                    "RETURNING id", (t, n))
        ids.append(cur.fetchone()[0])
    return t, ids


def ev(cur, tenant, sensor, *, action='allow', src='203.0.113.9', dport=443, rule_name=None,
       rule_id=None, sent=100, rcvd=0, age_days=1, n=1):
    for _ in range(n):
        cur.execute(
            "INSERT INTO fw_events (time, tenant_id, sensor_id, vendor, data_source, event_type, "
            "action, src_ip, dst_ip, dst_port, bytes_sent, bytes_received, rule_name, rule_id) "
            "VALUES (%s, %s, %s, 'fortinet', 'syslog', 'traffic', %s, %s, '10.0.0.5', %s, %s, %s, %s, %s)",
            (NOW - timedelta(days=age_days), tenant, sensor, action, src, dport, sent, rcvd,
             rule_name, rule_id))


def test_no_events_means_no_log_data(cur, sensors):
    _t, (s1, _s2) = sensors
    assert tr.load(cur, tenant_id=_t, sensor_id=s1, window_days=90) is None


def test_rows_ports_and_window(cur, sensors):
    t, (s1, s2) = sensors
    ev(cur, t, s1, rule_name='web', rule_id=7, dport=443, n=3, sent=1000, rcvd=500)
    ev(cur, t, s1, rule_name='web', rule_id=7, dport=80, n=1)
    ev(cur, t, s1, rule_name='web', rule_id=7, action='deny', n=2)
    ev(cur, t, s1, rule_name='old', rule_id=8, age_days=200)                 # outside the window
    ev(cur, t, s2, rule_name='other-sensor', rule_id=9)                      # another sensor
    h = tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90)
    assert h.total_events == 6 and h.window_days == 90
    assert [r['name'] for r in h.rows] == ['web']
    web = h.rows[0]
    assert (web['id'], web['allow'], web['deny'], web['bytes']) == (7, 4, 2, 3 * 1500 + 100 + 2 * 100)
    assert dict(web['ports']) == {443: 3, 80: 1}
    assert len(tr.load(cur, tenant_id=t, sensor_id=s1, window_days=365).rows) == 2


def test_probes_and_risky_allowed(cur, sensors):
    t, (s1, _s2) = sensors
    for i in range(6):                                                       # 6 sources, 120 events
        ev(cur, t, s1, action='deny', dport=3389, src=f'198.51.100.{i + 1}', n=20)
    ev(cur, t, s1, action='allow', dport=3389, src='203.0.113.50', n=4)      # public source: counted
    ev(cur, t, s1, action='allow', dport=3389, src='10.1.2.3', n=9)          # private: ignored
    ev(cur, t, s1, action='allow', dport=443, src='203.0.113.51', n=9)       # not a risky port
    h = tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90)
    assert {p['port']: (p['events'], p['sources']) for p in h.probes} == {3389: (120, 6)}
    assert h.risky_allowed == [{'port': 3389, 'events': 4, 'sources': 1}]


def test_tenant_filter_reset_events_and_internal_sources(cur, sensors, seed_tenants):
    t, (s1, _s2) = sensors
    other, = seed_tenants('Other')
    ev(cur, t, s1, action='reset', dport=3389, n=5)                         # an allowed session
    ev(cur, t, s1, action='deny', dport=3389, src='198.51.100.1', n=3)
    for src in ('100.64.1.1', 'fe80::1', '::1', '203.0.113.60'):
        ev(cur, t, s1, action='allow', dport=3389, src=src)
    h = tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90)
    assert h.total_events == 12 and h.allow_events == 4 and h.deny_events == 3
    assert {p['port']: p['events'] for p in h.probes} == {3389: 3}           # resets are not probes
    assert h.risky_allowed == [{'port': 3389, 'events': 1, 'sources': 1}]   # only the public source
    assert tr.load(cur, tenant_id=other, sensor_id=s1, window_days=90) is None
    cur.execute('SHOW statement_timeout')
    assert cur.fetchone()[0] == '20s'


def test_only_deny_rows_make_allow_checks_undetermined(cur, sensors):
    t, (s1, _s2) = sensors
    ev(cur, t, s1, action='deny', dport=22, n=4)
    h = tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90)
    assert h.allow_events == 0 and h.deny_events == 4
    assert run1('FWA-TRF-003', cfg(sections=('rules',)), h)[0] == fw.UNDETERMINED


def test_only_allow_rows_make_probe_check_undetermined(cur, sensors):
    t, (s1, _s2) = sensors
    ev(cur, t, s1, action='allow', dport=443, n=4)
    h = tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90)
    assert h.allow_events == 4 and h.deny_events == 0
    assert run1('FWA-TRF-004', cfg(sections=('rules',)), h)[0] == fw.UNDETERMINED


def test_row_limit_sets_the_truncation_flag(cur, sensors, monkeypatch):
    t, (s1, _s2) = sensors
    ev(cur, t, s1, rule_name='a', rule_id=1)
    ev(cur, t, s1, rule_name='b', rule_id=2)
    assert not tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90).truncated
    monkeypatch.setattr(tr, 'MAX_ROWS', 1)
    h = tr.load(cur, tenant_id=t, sensor_id=s1, window_days=90)
    assert h.truncated and len(h.rows) == 1
