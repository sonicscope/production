"""Shared helpers for the Firewall Audit check tests."""
from reports.fwaudit import checks as _checks  # noqa: F401  (registers every check)
from reports.fwaudit import framework as fw
from reports.fwaudit import traffic as tr
from reports.fwaudit.model import NormalizedConfig, Rule


def run1(cid, cfg, hits=None):
    """Run a single check; returns (state, findings)."""
    res = fw.run_checks(cfg, hits, registry={cid: fw.REGISTRY[cid]})
    return res['ledger'][0]['state'], res['findings']


def cfg(vendor='fortigate', **sections):
    c = NormalizedConfig(vendor=vendor)
    c.sections.update(sections.get('sections', ()))
    return c


def rule(i, **kw):
    kw.setdefault('name', f'r{i}')
    kw.setdefault('rid', str(i + 1))
    kw.setdefault('action', 'allow')
    kw.setdefault('src', f'firewall policy/{i + 1}')
    return Rule(idx=i, **kw)


def hits(rows, **kw):
    kw.setdefault('allow_events', 600)
    kw.setdefault('deny_events', 400)
    return tr.RuleHits(window_days=90, total_events=1000, rows=rows, **kw)


def row(name=None, id_=None, allow=10, deny=0, nbytes=0, ports=()):
    return {'name': name, 'id': id_, 'allow': allow, 'deny': deny, 'bytes': nbytes,
            'last_seen': '2026-11-01T00:00:00', 'ports': list(ports)}
