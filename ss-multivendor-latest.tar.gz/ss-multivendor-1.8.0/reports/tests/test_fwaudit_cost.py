"""Algorithmic cost bounds for the rule-base comparisons (hostile or very large exports)."""
import time

from reports.fwaudit import engine
from reports.fwaudit import framework as fw
from reports.fwaudit.checks import rulebase
from reports.fwaudit.model import ANY
from reports.fwaudit.parsers import fortigate
from reports.tests.fwaudit_helpers import cfg, rule, run1

HEADER = '#config-version=FGT60F-7.2.8-FW-build1639-240313:opmode=0:vdom=0:user=admin\n'


def _conf(n_policies: int, group_size: int, disjoint_dst: bool) -> str:
    out = [HEADER, 'config system global', '    set hostname "fw"', 'end',
           'config system interface',
           '    edit "wan1"', '        set role wan', '    next',
           '    edit "internal"', '        set role lan', '    next', 'end',
           'config firewall address']
    for i in range(group_size):
        out += [f'    edit "h{i}"', f'        set subnet 10.{i // 250}.{i % 250}.1 255.255.255.255',
                '    next']
    for i in range(n_policies):
        out += [f'    edit "d{i}"', f'        set subnet 198.18.{i}.0 255.255.255.0', '    next']
    out += ['end', 'config firewall addrgrp', '    edit "big"',
            '        set member ' + ' '.join(f'"h{i}"' for i in range(group_size)),
            '    next', 'end', 'config firewall policy']
    for i in range(n_policies):
        out += [f'    edit {i + 1}', f'        set name "p{i}"',
                '        set srcintf "internal"', '        set dstintf "wan1"',
                '        set srcaddr "big"',
                f'        set dstaddr "{f"d{i}" if disjoint_dst else "all"}"',
                '        set action accept', '        set schedule "always"',
                '        set service "HTTPS"', '        set logtraffic all', '    next']
    out.append('end')
    return '\n'.join(out) + '\n'


def test_shared_200_member_group_over_60_policies_is_fast():
    for disjoint in (True, False):
        text = _conf(60, 200, disjoint)
        t0 = time.monotonic()
        res = engine.run('fortigate', text)
        took = time.monotonic() - t0
        assert took < 5.0, f'engine.run took {took:.1f}s (disjoint={disjoint})'
        states = {e['check_id']: e['state'] for e in res['ledger']}
        if disjoint:
            assert states['FWA-RUL-004'] == fw.PASSED          # nothing covers a disjoint rule
        else:
            assert states['FWA-RUL-004'] == fw.FINDING         # rule 1 covers rules 2..60


def test_small_known_shadow_case_still_found():
    c = cfg(sections=('rules',))
    c.addresses = {'net24': ['10.0.0.0/24'], 'host': ['10.0.0.5/32'],
                   'pair': ['10.0.0.0/25', '10.0.0.128/25']}
    c.rules = [rule(0, src_addr=('pair',), dst_addr=(ANY,), service=(ANY,)),
               rule(1, src_addr=('net24',), dst_addr=(ANY,), service=('HTTP',))]
    assert run1('FWA-RUL-004', c)[0] == fw.FINDING            # two halves cover the /24
    c.rules = [rule(0, src_addr=('host',), dst_addr=(ANY,), service=(ANY,)),
               rule(1, src_addr=('net24',), dst_addr=(ANY,), service=('HTTP',))]
    assert run1('FWA-RUL-004', c)[0] == fw.PASSED


def test_shadow_budget_exhausted_is_undetermined(monkeypatch):
    monkeypatch.setattr(rulebase, 'SHADOW_BUDGET_S', 0.0)
    c = cfg(sections=('rules',))
    c.rules = [rule(i, src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,)) for i in range(5)]
    for cid in ('FWA-RUL-003', 'FWA-RUL-004'):
        res = fw.run_checks(c, registry={cid: fw.REGISTRY[cid]})
        assert res['ledger'][0]['state'] == fw.UNDETERMINED
        assert 'too large to compare in time' in res['ledger'][0]['reason']


def test_address_and_rule_expansion_is_capped():
    c = cfg(sections=('rules',))
    c.addresses = {f'h{i}': [f'10.0.{i // 200}.{(i % 200) + 1}/32'] for i in range(300)}
    many = tuple(f'h{i}' for i in range(0, 300, 1))
    assert c.nets(many) is None                               # above the per-rule cap
    assert c.nets(('h1', 'h2')) is not None
    assert c.nets(()) is None                                 # unknown, never "nothing"


def _group_conf(members: list, extra: str = '') -> str:
    lines = [HEADER, 'config firewall address']
    for i in range(400):
        lines += [f'    edit "h{i}"', f'        set subnet 10.{i // 200}.{(i % 200) * 1}.1 '
                  '255.255.255.255', '    next']
    lines += ['    edit "rng"', '        set type iprange', '        set start-ip 10.9.0.1',
              '        set end-ip 10.9.255.254', '    next', 'end',
              'config firewall addrgrp',
              '    edit "g"', '        set member ' + ' '.join(f'"{m}"' for m in members),
              '    next', '    edit "outer"', '        set member "g" "g" "h0"', '    next',
              extra, 'end']
    return '\n'.join(lines) + '\n'


def test_group_expansion_dedupes_and_caps():
    c = fortigate.normalize(_group_conf(['h1', 'h1', 'h2']))
    assert c.addresses['g'] == ['10.0.1.1/32', '10.0.2.1/32']          # duplicate member dropped
    assert c.addresses['outer'] == ['10.0.1.1/32', '10.0.2.1/32', '10.0.0.1/32']
    big = fortigate.normalize(_group_conf([f'h{i}' for i in range(400)]))
    assert 'g' not in big.addresses and 'outer' not in big.addresses   # too large: unknown
    assert big.addresses['rng'] and len(big.addresses['rng']) <= 256
