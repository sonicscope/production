from reports.fwaudit import framework as fw
from reports.fwaudit import traffic as tr
from reports.fwaudit.model import ANY
from reports.tests.fwaudit_helpers import cfg, hits, row, rule, run1


# ── traffic-aware ───────────────────────────────────────────────────────────
def test_zero_hit_rules():
    c = cfg(sections=('rules',))
    c.rules = [rule(0, name='used', log='all'), rule(1, name='dead', log='all'),
               rule(2, name='utm-only', log='utm')]
    state, fs = run1('FWA-TRF-001', c, hits([row('used')]))
    assert state == fw.FINDING and len(fs[0].evidence) == 1 and 'dead' in fs[0].evidence[0]
    assert '1 other rule(s) could not be assessed' in fs[0].description
    assert run1('FWA-TRF-001', c, None)[0] == fw.SKIPPED
    c.rules = [rule(0, name='used', log='all')]
    assert run1('FWA-TRF-001', c, hits([row('USED ')]))[0] == fw.PASSED      # case/space tolerant
    c.rules = [rule(0, name='x', log='utm')]
    assert run1('FWA-TRF-001', c, hits([]))[0] == fw.UNDETERMINED
    o = cfg('opnsense', sections=('rules',))
    o.rules = [rule(0, name='x', log='all')]
    assert run1('FWA-TRF-001', o, hits([]))[0] == fw.UNDETERMINED            # unreliable identity


def test_fortigate_matches_by_id_before_name():
    c = cfg(sections=('rules',))
    c.rules = [rule(0, rid='7', name='renamed', log='all')]
    assert run1('FWA-TRF-001', c, hits([row('old-name', 7)]))[0] == fw.PASSED
    assert run1('FWA-TRF-001', c, hits([row('other', 8)]))[0] == fw.FINDING


def test_sonicwall_never_matches_on_ambiguous_ids():
    c = cfg('sonicwall', sections=('rules',))
    c.rules = [rule(0, rid='5', name='', log='all')]
    assert tr.eligible_for_zero_hit('sonicwall', c.rules[0]) is False
    c.rules = [rule(0, rid='5', name='lan-out', log='all')]
    assert run1('FWA-TRF-001', c, hits([row(None, 5)]))[0] == fw.FINDING     # id ignored
    assert run1('FWA-TRF-001', c, hits([row('lan-out', None)]))[0] == fw.PASSED


def test_broad_rule_in_use_shows_what_it_carries():
    c = cfg(sections=('rules',))
    c.rules = [rule(0, name='open', src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,))]
    h = hits([row('open', nbytes=40_000_000_000, allow=12345, ports=[(3389, 900), (443, 500)])])
    state, fs = run1('FWA-TRF-002', c, h)
    assert state == fw.FINDING and fs[0].severity == 1
    assert '40.0 GB' in fs[0].evidence[0] and 'RDP' in fs[0].evidence[0]
    h = hits([row('open', nbytes=5_000_000, ports=[(443, 5)])])
    assert run1('FWA-TRF-002', c, h)[1][0].severity == 2
    assert run1('FWA-TRF-002', c, hits([row('other')]))[0] == fw.UNDETERMINED
    c.rules = [rule(0, src_addr=('a',), dst_addr=('b',), service=('HTTP',))]
    assert run1('FWA-TRF-002', c, hits([]))[0] == fw.PASSED


def test_risky_allowed_and_probes():
    c = cfg()
    h = hits([], risky_allowed=[{'port': 3389, 'events': 50, 'sources': 3}])
    state, fs = run1('FWA-TRF-003', c, h)
    assert state == fw.FINDING and fs[0].severity == 1 and 'RDP (3389)' in fs[0].evidence[0]
    assert run1('FWA-TRF-003', c, hits([]))[0] == fw.PASSED
    probes = [{'port': 22, 'events': 500, 'sources': 40}, {'port': 3389, 'events': 50, 'sources': 2}]
    state, fs = run1('FWA-TRF-004', c, hits([], probes=probes))
    assert state == fw.FINDING and len(fs[0].evidence) == 1 and 'port 22' in fs[0].evidence[0]


def test_stale_rule_names_in_logs():
    c = cfg(sections=('rules',))
    c.rules = [rule(0, name='a', log='all')]
    state, fs = run1('FWA-TRF-005', c, hits([row('a'), row('gone')]))
    assert state == fw.FINDING and 'gone' in fs[0].evidence[0] and fs[0].needs_validation
    assert run1('FWA-TRF-005', c, hits([row('a')]))[0] == fw.PASSED
    o = cfg('opnsense', sections=('rules',))
    o.rules = [rule(0)]
    assert run1('FWA-TRF-005', o, hits([row('a')]))[0] == fw.UNDETERMINED


def test_missing_log_classes_are_undetermined_not_passed():
    c = cfg(sections=('rules',))
    state, _ = run1('FWA-TRF-003', c, hits([], allow_events=0))
    assert state == fw.UNDETERMINED
    res = fw.run_checks(c, hits([], allow_events=0),
                        registry={'FWA-TRF-003': fw.REGISTRY['FWA-TRF-003']})
    assert 'no allowed sessions are logged' in res['ledger'][0]['reason']
    res = fw.run_checks(c, hits([], deny_events=0),
                        registry={'FWA-TRF-004': fw.REGISTRY['FWA-TRF-004']})
    assert res['ledger'][0]['state'] == fw.UNDETERMINED
    assert 'no blocked connections are logged' in res['ledger'][0]['reason']


def test_truncated_rule_rows_make_zero_hit_undetermined():
    c = cfg(sections=('rules',))
    c.rules = [rule(0, log='all'), rule(1, name='unused', log='all')]
    assert run1('FWA-TRF-001', c, hits([row('r0')]))[0] == fw.FINDING
    res = fw.run_checks(c, hits([row('r0')], truncated=True),
                        registry={'FWA-TRF-001': fw.REGISTRY['FWA-TRF-001']})
    assert res['ledger'][0]['state'] == fw.UNDETERMINED
    assert 'busiest' in res['ledger'][0]['reason']
