import pytest

from reports.fwaudit import framework as fw
from reports.fwaudit.model import ANY, Interface, NatRule, VpnTunnel
from reports.tests.fwaudit_helpers import cfg, rule, run1


@pytest.mark.parametrize('cid,key,bad,good', [
    ('FWA-THR-001', 'services.ips', False, True),
    ('FWA-THR-002', 'services.av', False, True),
    ('FWA-THR-003', 'services.url', False, True),
    ('FWA-THR-004', 'services.dpi_ssl', False, True),
    ('FWA-THR-005', 'services.botnet', False, True),
    ('FWA-VPN-007', 'vpn.ssl_mfa', False, True),
    ('FWA-VPN-008', 'vpn.ssl_tls_min', '1.1', '1.2'),
    ('FWA-RES-001', 'dos.enabled', False, True),
    ('FWA-RES-002', 'ha.enabled', False, True),
    ('FWA-RES-003', 'ntp.enabled', False, True),
    ('FWA-RES-004', 'logging.remote', False, True),
])
def test_fact_checks_threat_vpn_resilience(cid, key, bad, good):
    c = cfg()
    assert run1(cid, c)[0] == fw.UNDETERMINED               # not in the export: never a verdict
    c.set(key, bad, 'src/path')
    state, fs = run1(cid, c)
    assert state == fw.FINDING and fs[0].check_id == cid
    assert 'src/path' in fs[0].evidence[0] and fs[0].frameworks and fs[0].remediation
    c.set(key, good, 'src/path')
    assert run1(cid, c)[0] == fw.PASSED


# ── exposure ────────────────────────────────────────────────────────────────
def test_exposure_checks():
    assert run1('FWA-EXP-001', cfg())[0] == fw.UNDETERMINED
    c = cfg(sections=('nat', 'rules', 'interfaces'))
    assert run1('FWA-EXP-001', c)[0] == fw.PASSED
    c.nat = [NatRule('rdp', ports=((3389, 3389),), internal='10.0.0.5', source_restricted=False, ips=False,
                     src='firewall vip/rdp'),
             NatRule('web', ports=((443, 443),), internal='10.0.0.6', source_restricted=True, ips=True)]
    state, fs = run1('FWA-EXP-001', c)
    assert state == fw.FINDING and fs[0].severity == 1 and 'RDP (3389)' in fs[0].evidence[0]
    assert run1('FWA-EXP-002', c)[0] == fw.FINDING and run1('FWA-EXP-003', c)[0] == fw.FINDING
    c.nat = [NatRule('x', ports=((8443, 8443),), source_restricted=None, ips=None)]
    assert run1('FWA-EXP-002', c)[0] == fw.UNDETERMINED
    c.nat = [NatRule('db', ports=((5432, 5432),), source_restricted=False)]
    assert run1('FWA-EXP-001', c)[1][0].severity == 2          # risky but not in the critical set
    c.nat = [NatRule('odd', ports=None)]
    assert run1('FWA-EXP-001', c)[0] == fw.UNDETERMINED         # unreadable ports: no verdict
    c.nat = [NatRule('static', ports=((1, 65535),), source_restricted=None)]
    state, fs = run1('FWA-EXP-001', c)
    assert state == fw.FINDING and fs[0].needs_validation and 'all ports' in fs[0].evidence[0]


def test_inbound_risky_rule_needs_wan_and_open_source():
    c = cfg(sections=('rules', 'interfaces'))
    c.interfaces = [Interface('port1', role='wan'), Interface('port2', role='lan')]
    c.rules = [rule(0, src_zone=('port1',), src_addr=(ANY,), service=('RDP',)),
               rule(1, src_zone=('port2',), src_addr=(ANY,), service=('RDP',)),
               rule(2, src_zone=('port1',), src_addr=('a',), service=('RDP',)),
               rule(3, src_zone=('port1',), src_addr=(ANY,), service=('HTTPS',))]
    state, fs = run1('FWA-EXP-004', c)
    assert state == fw.FINDING and len(fs[0].evidence) == 1 and 'r0' in fs[0].evidence[0]
    c.services = {'custom-rdp': ((3389, 3389),)}
    c.rules = [rule(0, src_zone=('port1',), src_addr=(ANY,), service=('custom-rdp',))]
    assert run1('FWA-EXP-004', c)[0] == fw.FINDING
    c.interfaces = [Interface('port2', role='lan')]
    assert run1('FWA-EXP-004', c)[0] == fw.UNDETERMINED


# ── vpn ─────────────────────────────────────────────────────────────────────
def test_vpn_checks():
    assert run1('FWA-VPN-001', cfg())[0] == fw.UNDETERMINED
    c = cfg(sections=('vpn',))
    assert run1('FWA-VPN-001', c)[0] == fw.NA                  # no tunnels configured
    c.vpn = [VpnTunnel('t', ike_version=1, aggressive=True, enc=('3des',), hashes=('md5',),
                       dh=(2,), src='vpn/t')]
    for cid in ('FWA-VPN-001', 'FWA-VPN-002', 'FWA-VPN-003', 'FWA-VPN-004', 'FWA-VPN-005'):
        assert run1(cid, c)[0] == fw.FINDING, cid
    assert run1('FWA-VPN-006', c)[0] == fw.UNDETERMINED        # PSK not assessable
    c.vpn = [VpnTunnel('t', ike_version=2, aggressive=False, enc=('aes256',), hashes=('sha256',),
                       dh=(14, 19), psk_weak=False)]
    for cid in ('FWA-VPN-001', 'FWA-VPN-002', 'FWA-VPN-003', 'FWA-VPN-004', 'FWA-VPN-005',
                'FWA-VPN-006'):
        assert run1(cid, c)[0] == fw.PASSED, cid
    c.vpn[0].psk_weak = True
    assert run1('FWA-VPN-006', c)[0] == fw.FINDING


# ── segmentation ────────────────────────────────────────────────────────────
def test_segmentation_checks():
    c = cfg(sections=('rules', 'interfaces'))
    assert run1('FWA-SEG-001', c)[0] == fw.UNDETERMINED
    c.interfaces = [Interface('port1', role='wan'), Interface('port2', role='lan'),
                    Interface('port3', role='guest', zone='GuestZ')]
    c.rules = [rule(0, src_zone=('port1',), dst_zone=('port2',), service=(ANY,)),
               rule(1, src_zone=('GuestZ',), dst_zone=('port2',), service=(ANY,)),
               rule(2, src_zone=('port2',), dst_zone=('port1',), service=(ANY,))]
    assert run1('FWA-SEG-001', c)[0] == fw.FINDING and run1('FWA-SEG-002', c)[0] == fw.FINDING
    assert run1('FWA-SEG-003', c)[0] == fw.PASSED              # a guest zone exists
    c.rules = [rule(0, src_zone=('port1',), dst_zone=('port2',), service=('HTTPS',))]
    assert run1('FWA-SEG-001', c)[0] == fw.PASSED
    c.rules = [rule(0, src_zone=('port1',), dst_zone=('port2',), service=(ANY,), restricted=True)]
    state, fs = run1('FWA-SEG-001', c)
    assert state == fw.FINDING and fs[0].needs_validation
    c.interfaces = [Interface('port1', role='wan'), Interface('port2', role='lan')]
    assert run1('FWA-SEG-003', c)[0] == fw.FINDING
