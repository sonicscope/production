import pytest

from reports.fwaudit import framework as fw
from reports.fwaudit.model import ANY, Interface
from reports.tests.fwaudit_helpers import cfg, rule, run1


# ── management (fact checks) ─────────────────────────────────────────────────
@pytest.mark.parametrize('cid,key,bad,good', [
    ('FWA-MGT-001', 'admin.timeout_min', 30, 10),
    ('FWA-MGT-002', 'admin.mfa', False, True),
    ('FWA-MGT-003', 'admin.lockout', False, True),
    ('FWA-MGT-004', 'admin.telnet', True, False),
    ('FWA-MGT-005', 'admin.snmp_v1v2', True, False),
    ('FWA-MGT-006', 'admin.snmp_default_community', True, False),
    ('FWA-MGT-007', 'admin.default_account', True, False),
    ('FWA-MGT-008', 'admin.banner', False, True),
    ('FWA-MGT-009', 'admin.pw_min_len', None, 14),
    ('FWA-MGT-011', 'admin.tls_min', '1.1', '1.2'),
    ('FWA-MGT-012', 'admin.api', True, False),
])
def test_fact_checks_fail_pass_and_unknown(cid, key, bad, good):
    c = cfg()
    assert run1(cid, c)[0] == fw.UNDETERMINED               # not in the export: never a verdict
    c.set(key, bad, 'src/path')
    state, fs = run1(cid, c)
    assert state == fw.FINDING and fs[0].check_id == cid
    assert 'src/path' in fs[0].evidence[0] and fs[0].frameworks and fs[0].remediation
    c.set(key, good, 'src/path')
    assert run1(cid, c)[0] == fw.PASSED


def test_remediation_is_vendor_specific():
    c = cfg('fortigate')
    c.set('admin.timeout_min', 30)
    assert 'admintimeout' in run1('FWA-MGT-001', c)[1][0].remediation
    s = cfg('sonicwall')
    s.set('admin.timeout_min', 30)
    assert 'Device > Settings' in run1('FWA-MGT-001', s)[1][0].remediation
    o = cfg('opnsense')
    o.set('admin.timeout_min', 30)
    assert run1('FWA-MGT-001', o)[1][0].remediation.startswith('Lower')


def test_mgmt_on_wan():
    c = cfg(sections=('interfaces',))
    assert run1('FWA-MGT-010', c)[0] == fw.UNDETERMINED          # no interfaces / no WAN role
    c.interfaces = [Interface('port1', role='wan', mgmt=('ping', 'https'), trusted_hosts=False,
                              src='system interface/port1')]
    state, fs = run1('FWA-MGT-010', c)
    assert state == fw.FINDING and fs[0].severity == 2 and fs[0].needs_validation
    c.interfaces[0].mgmt = ('ping', 'telnet')
    assert run1('FWA-MGT-010', c)[1][0].severity == 1
    c.interfaces[0].trusted_hosts = True
    assert run1('FWA-MGT-010', c)[0] == fw.PASSED
    c.interfaces[0].mgmt = ('ping',)
    c.interfaces[0].trusted_hosts = False
    assert run1('FWA-MGT-010', c)[0] == fw.PASSED
    assert run1('FWA-MGT-010', cfg('sonicwall'))[0] == fw.UNDETERMINED


# ── rule base ───────────────────────────────────────────────────────────────
def test_rules_not_read_is_undetermined():
    for cid in ('FWA-RUL-001', 'FWA-RUL-003', 'FWA-RUL-005', 'FWA-RUL-008'):
        assert run1(cid, cfg())[0] == fw.UNDETERMINED


def test_any_any_and_any_service():
    c = cfg(sections=('rules',))
    c.rules = [rule(0, src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,)),
               rule(1, src_addr=('a',), dst_addr=(ANY,), service=(ANY,)),
               rule(2, src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,), enabled=False),
               rule(3, src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,), action='deny')]
    s1, f1 = run1('FWA-RUL-001', c)
    assert s1 == fw.FINDING and len(f1[0].evidence) == 1 and 'r0' in f1[0].evidence[0]
    assert run1('FWA-RUL-002', c)[0] == fw.PASSED             # r1 is open egress only (RUL-009)
    s9, f9 = run1('FWA-RUL-009', c)
    assert s9 == fw.FINDING and len(f9[0].evidence) == 1 and 'r1' in f9[0].evidence[0]
    c.rules = [rule(0, src_addr=(ANY,), dst_addr=('srv',), service=(ANY,))]
    s2, f2 = run1('FWA-RUL-002', c)
    assert s2 == fw.FINDING and 'r0' in f2[0].evidence[0]
    assert run1('FWA-RUL-009', c)[0] == fw.PASSED             # disjoint: one rule, one penalty
    c.rules = [rule(0, src_addr=('a',), dst_addr=('b',), service=('HTTP',))]
    assert run1('FWA-RUL-001', c)[0] == fw.PASSED


def shadow_cfg():
    c = cfg(sections=('rules',))
    c.addresses = {'net24': ['10.0.0.0/24'], 'host': ['10.0.0.5/32'], 'other': ['192.168.1.0/24']}
    return c


def test_shadowed_same_action_is_redundant():
    c = shadow_cfg()
    c.rules = [rule(0, src_addr=('net24',), dst_addr=(ANY,), service=(ANY,)),
               rule(1, src_addr=('host',), dst_addr=(ANY,), service=('HTTP',))]
    assert run1('FWA-RUL-004', c)[0] == fw.FINDING
    assert run1('FWA-RUL-003', c)[0] == fw.PASSED


def test_shadowed_opposite_action_is_unreachable():
    c = shadow_cfg()
    c.rules = [rule(0, src_addr=('net24',), dst_addr=(ANY,), service=(ANY,)),
               rule(1, src_addr=('host',), dst_addr=(ANY,), service=(ANY,), action='deny')]
    state, fs = run1('FWA-RUL-003', c)
    assert state == fw.FINDING and fs[0].needs_validation and 'covered by earlier' in fs[0].evidence[0]
    assert run1('FWA-RUL-004', c)[0] == fw.PASSED


@pytest.mark.parametrize('a_kw,b_kw', [
    (dict(src_addr=('host',)), dict(src_addr=('net24',))),                  # narrower earlier rule
    (dict(src_addr=('other',)), dict(src_addr=('net24',))),                 # disjoint
    (dict(service=('HTTP',)), dict(service=(ANY,))),
    (dict(src_zone=('lan',)), dict(src_zone=(ANY,))),
    (dict(restricted=True), dict()),                                        # user/app conditions
    (dict(schedule='worktime'), dict()),
])
def test_not_shadowed_cases(a_kw, b_kw):
    c = shadow_cfg()
    base = dict(src_addr=('net24',), dst_addr=(ANY,), service=(ANY,))
    c.rules = [rule(0, **{**base, **a_kw}), rule(1, **{**base, **b_kw, 'src_addr': b_kw.get('src_addr', ('host',))})]
    assert run1('FWA-RUL-004', c)[0] == fw.PASSED


def test_unresolvable_address_is_not_assumed_covered():
    c = shadow_cfg()
    c.rules = [rule(0, src_addr=('fqdn-obj',), dst_addr=(ANY,), service=(ANY,)),
               rule(1, src_addr=('host',), dst_addr=(ANY,), service=(ANY,))]
    assert run1('FWA-RUL-004', c)[0] == fw.PASSED


def test_shadow_scan_limit():
    c = shadow_cfg()
    c.rules = [rule(i) for i in range(1501)]
    assert run1('FWA-RUL-003', c)[0] == fw.UNDETERMINED


def test_logging_comments_disabled_profiles():
    c = cfg(sections=('rules',))
    c.rules = [rule(i, log='none' if i < 2 else 'all', comment='' if i < 4 else 'ok',
                    profiles={'ips': False}) for i in range(6)]
    assert run1('FWA-RUL-005', c)[0] == fw.FINDING
    assert run1('FWA-RUL-006', c)[0] == fw.FINDING
    assert run1('FWA-RUL-008', c)[0] == fw.FINDING
    assert run1('FWA-RUL-007', c)[0] == fw.PASSED
    c.rules = [rule(i, enabled=False) for i in range(6)]
    assert run1('FWA-RUL-007', c)[0] == fw.FINDING
    assert run1('FWA-RUL-006', c)[0] == fw.NA                 # disabled rules are not counted
    c.rules = ([rule(i, comment='ok') for i in range(5)]
               + [rule(5 + i, enabled=False) for i in range(6)])
    assert run1('FWA-RUL-006', c)[0] == fw.PASSED
    c.rules = [rule(0, log='')]
    assert run1('FWA-RUL-005', c)[0] == fw.UNDETERMINED
    assert run1('FWA-RUL-006', c)[0] == fw.NA                 # fewer than 5 rules
    assert run1('FWA-RUL-008', c)[0] == fw.UNDETERMINED       # no profile data


def test_factory_default_rules_are_a_separate_lower_severity_finding():
    c = cfg('sonicwall', sections=('rules',))
    c.rules = [rule(0, name='Default Access Rule', src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,),
                    builtin=True)]
    assert run1('FWA-RUL-001', c)[0] == fw.PASSED             # not an administrator-written any/any
    s, f = run1('FWA-RUL-010', c)
    assert s == fw.FINDING and f[0].severity == fw.Severity.LOW and 'Default Access Rule' in f[0].evidence[0]
    c.rules.append(rule(1, name='Mine', src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,)))
    s1, f1 = run1('FWA-RUL-001', c)
    assert s1 == fw.FINDING and len(f1[0].evidence) == 1 and 'Mine' in f1[0].evidence[0]
    s10, f10 = run1('FWA-RUL-010', c)
    assert len(f10[0].evidence) == 1 and 'Mine' not in f10[0].evidence[0]
    c.rules = [rule(0, src_addr=('a',), dst_addr=('b',), service=('HTTP',), builtin=True)]
    assert run1('FWA-RUL-010', c)[0] == fw.PASSED
    assert run1('FWA-RUL-010', cfg('fortigate', sections=('rules',)))[0] == fw.NA   # a SonicOS concept


# ── unused rules from the export's own hit counters (FWA-RUL-011) ────────────
DAY = 86400
NOW = 1_795_000_000


def _unused_cfg(*rules, now=NOW):
    c = cfg('sonicwall', sections=('rules',))
    c.rules = list(rules)
    if now is not None:
        c.set('system.export_epoch', now, 'test')
    return c


def _r(i, **kw):
    kw.setdefault('src_addr', ('a',))
    return rule(i, **kw)


def test_unused_rules_never_hit_and_idle():
    c = _unused_cfg(
        _r(0, name='never-old', hits=0, last_hit=0, created=NOW - 200 * DAY),
        _r(1, name='never-new', hits=0, last_hit=0, created=NOW - 3 * DAY),         # too young
        _r(2, name='idle', hits=500, last_hit=NOW - 120 * DAY, created=NOW - 400 * DAY),
        _r(3, name='busy', hits=900, last_hit=NOW - 2 * DAY, created=NOW - 400 * DAY),
        _r(4, name='factory', hits=0, last_hit=0, builtin=True),
        _r(5, name='auto', hits=0, last_hit=0, generated=True, created=NOW - 300 * DAY),
        _r(6, name='off', hits=0, last_hit=0, enabled=False, created=NOW - 300 * DAY),
        _r(7, name='deny', hits=0, last_hit=0, action='deny', created=NOW - 300 * DAY))
    s, f = run1('FWA-RUL-011', c)
    assert s == fw.FINDING and f[0].severity == fw.Severity.LOW and f[0].needs_validation
    ev = ' | '.join(f[0].evidence)
    assert 'never-old' in ev and 'idle' in ev and '500 hits' in ev
    assert 'never-new' not in ev and 'busy' not in ev and 'factory' not in ev
    names = {line.split(' (')[0] for line in f[0].evidence}
    assert names == {'never-old', 'idle'}                      # factory, auto-generated, disabled and deny rules are left out
    assert f[0].current == '1 never hit, 1 idle over 90 days'
    assert f[0].evidence[0].startswith('never-old')               # never-hit first, oldest first


def test_unused_rules_pass_and_cannot_determine():
    ok = _unused_cfg(_r(0, hits=10, last_hit=NOW - DAY, created=NOW - 300 * DAY),
                     _r(1, hits=0, last_hit=0, created=NOW - 5 * DAY))
    assert run1('FWA-RUL-011', ok)[0] == fw.PASSED
    edge = _unused_cfg(_r(0, hits=3, last_hit=NOW - 90 * DAY, created=NOW - 300 * DAY))   # exactly 90 days: not idle
    assert run1('FWA-RUL-011', edge)[0] == fw.PASSED
    no_counters = _unused_cfg(_r(0), _r(1))                    # the export carried no counters
    s, _ = run1('FWA-RUL-011', no_counters)
    assert s == fw.UNDETERMINED
    assert run1('FWA-RUL-011', _unused_cfg(_r(0, hits=0, last_hit=0), now=None))[0] == fw.UNDETERMINED
    fgt = cfg('fortigate', sections=('rules',))
    assert run1('FWA-RUL-011', fgt)[0] == fw.NA                # FortiGate exports carry no hit counters
