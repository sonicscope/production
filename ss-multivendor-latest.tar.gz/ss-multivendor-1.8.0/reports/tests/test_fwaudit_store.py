"""Firewall Audit persistence (real test DB)."""
import os

import psycopg2
import pytest

from reports.fwaudit import engine, store

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit', 'fortigate_hq.conf')


@pytest.fixture
def cur(app_module):
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    yield conn.cursor()
    conn.rollback()
    conn.close()


@pytest.fixture
def result():
    with open(FIXTURE) as fh:
        return engine.run('fortigate', fh.read())


def mk(cur, tenant, name='HQ', vendor='fortigate', sensor=None):
    return store.create_target(cur, tenant_id=tenant, name=name, vendor=vendor,
                               sensor_id=sensor, created_by=None)


def sensor(cur, tenant, name='s1'):
    cur.execute("INSERT INTO sensors (tenant_id, name, vendor) VALUES (%s, %s, 'fortinet') "
                "RETURNING id", (tenant, name))
    return cur.fetchone()[0]


def test_create_target_validates(cur, seed_tenants):
    a, b = seed_tenants('Acme', 'Globex')
    tid = mk(cur, a, name='  HQ   Firewall ')
    assert store.get_target(cur, tid)['name'] == 'HQ Firewall'
    assert store.get_target(cur, tid)['tenant_name'] == 'Acme'
    with pytest.raises(ValueError, match='already has'):
        mk(cur, a, name='HQ Firewall')
    mk(cur, b, name='HQ Firewall')                     # same name for another customer is fine
    for bad in ('', '   ', 'x' * 121):
        with pytest.raises(ValueError, match='Enter a name'):
            mk(cur, a, name=bad)
    with pytest.raises(ValueError, match='supported vendor'):
        mk(cur, a, name='x', vendor='checkpoint')
    with pytest.raises(ValueError, match='supported vendor'):
        mk(cur, a, name='y', vendor="x'); DROP TABLE audit_targets;--")


def test_sensor_must_belong_to_the_customer(cur, seed_tenants):
    a, b = seed_tenants('Acme', 'Globex')
    other = sensor(cur, b)
    with pytest.raises(ValueError, match='sensor'):
        mk(cur, a, sensor=other)
    own = sensor(cur, a, 's2')
    assert store.get_target(cur, mk(cur, a, sensor=own))['sensor_id'] == own


def test_run_roundtrip(cur, seed_tenants, result):
    a, = seed_tenants('Acme')
    t = mk(cur, a)
    rid = store.insert_run(cur, t, None, result)
    run = store.get_run(cur, rid)
    assert run['score'] == result['score'] and 0 < run['score'] < 20 and run['band'] == 'At risk'
    assert run['target_name'] == 'HQ' and run['tenant_id'] == a and run['vendor'] == 'fortigate'
    assert run['counts'] == result['counts'] and run['ledger'] == result['ledger']
    assert run['frameworks'] == result['frameworks'] and run['findings'] == result['findings']
    assert run['report_id'] is None and run['device']['model'] == 'FGVM64'
    assert store.get_run(cur, rid + 999) is None
    cur.execute("INSERT INTO generated_reports (tenant_id, report_type, period_start, period_end, "
                "file_path) VALUES (%s, 'fw_audit', now(), now(), '/x.pdf') RETURNING id", (a,))
    report = cur.fetchone()[0]
    store.set_run_report(cur, rid, report)
    assert store.get_run(cur, rid)['report_id'] == report
    cur.execute('DELETE FROM generated_reports WHERE id = %s', (report,))
    assert store.get_run(cur, rid)['report_id'] is None          # deleting the PDF keeps the run


def test_list_targets_shows_latest_run_and_scopes_by_tenant(cur, seed_tenants, result):
    a, b = seed_tenants('Acme', 'Globex')
    t1, t2 = mk(cur, a, 'One'), mk(cur, a, 'Two')
    mk(cur, b, 'Other')
    store.insert_run(cur, t1, None, dict(result, score=40, band='At risk'))
    store.insert_run(cur, t1, None, dict(result, score=70, band='Good'))
    rows = {r['name']: r for r in store.list_targets(cur, [a])}
    assert set(rows) == {'One', 'Two'}
    assert rows['One']['score'] == 70 and rows['Two']['run_id'] is None
    assert [r['score'] for r in store.list_runs(cur, t1)] == [70, 40]
    assert store.list_targets(cur, []) == []


def test_runs_are_pruned_to_the_keep_limit(cur, seed_tenants, result):
    a, = seed_tenants('Acme')
    t, other = mk(cur, a), mk(cur, a, 'Other')
    keep_other = store.insert_run(cur, other, None, result)
    for i in range(store.KEEP_RUNS + 3):
        store.insert_run(cur, t, None, dict(result, score=i % 100))
    assert len(store.list_runs(cur, t)) == store.KEEP_RUNS
    cur.execute('SELECT count(*) FROM audit_runs WHERE target_id = %s', (t,))
    assert cur.fetchone()[0] == store.KEEP_RUNS
    assert store.get_run(cur, keep_other) is not None             # other targets untouched


def test_delete_target_cascades_runs(cur, seed_tenants, result):
    a, = seed_tenants('Acme')
    t = mk(cur, a)
    rid = store.insert_run(cur, t, None, result)
    store.delete_target(cur, t)
    assert store.get_target(cur, t) is None and store.get_run(cur, rid) is None


def test_role_ss_ai_ro_has_no_access(cur):
    cur.execute("SELECT rolname FROM pg_roles WHERE rolname = 'ss_ai_ro'")
    if cur.fetchone() is None:
        pytest.skip('ss_ai_ro not present in this test database')
    for table in ('audit_targets', 'audit_runs'):
        cur.execute("SELECT has_table_privilege('ss_ai_ro', %s, 'SELECT')", (table,))
        assert cur.fetchone()[0] is False, table


def test_sensor_vendor_must_match_the_target_vendor(cur, seed_tenants):
    a, = seed_tenants('Acme')
    forti = sensor(cur, a, 'forti')                                  # a 'fortinet' sensor
    with pytest.raises(ValueError, match='sensor'):
        mk(cur, a, name='SW', vendor='sonicwall', sensor=forti)
    assert store.get_target(cur, mk(cur, a, name='FG', sensor=forti))['sensor_id'] == forti
    assert store.sensor_ok(cur, forti, a, 'fortigate')
    assert not store.sensor_ok(cur, forti, a, 'sonicwall')
    b, = seed_tenants('Beta')
    assert not store.sensor_ok(cur, forti, b, 'fortigate')
