"""Firewall Audit PDF: real WeasyPrint + real test DB."""
import copy
import datetime
import os
import shutil
import subprocess

import psycopg2
import pytest

from reports.fwaudit import engine, report_data
from reports.generator import _get_jinja_env, generate_audit_report

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit', 'fortigate_hq.conf')
XSS = '<script>alert(1)</script>'


@pytest.fixture(scope='module')
def result():
    with open(FIXTURE) as fh:
        return engine.run('fortigate', fh.read())


@pytest.fixture
def ctx(app_module, seed_tenants, seed_msp_profile, tmp_path):
    (tid,) = seed_tenants('Smith & Sons "Ltd"')
    msp = seed_msp_profile('Test MSP & Co', primary_color='#2255aa', footer_text='Test MSP & Co')
    conn = psycopg2.connect(**app_module.DB_CONFIG)
    yield conn, tid, msp, str(tmp_path)
    conn.close()


def pdf_text(path):
    if not shutil.which('pdftotext'):
        pytest.skip('pdftotext not available')
    return subprocess.run(['pdftotext', '-layout', path, '-'], capture_output=True, text=True,
                          check=True).stdout


def render_html(result, **names):
    msp = {'name': 'MSP', 'primary_color': '#2255aa', 'accent_text_color': '#fff',
           'logo_path': None, 'footer_text': 'MSP'}
    return _get_jinja_env().get_template('fwaudit/report.html').render(
        msp=msp, tenant={'name': names.get('tenant', 'Acme')},
        target_name=names.get('target', 'HQ'), d=report_data.prepare(result),
        generated_at=datetime.datetime(2026, 11, 21))


def test_pdf_is_generated_and_recorded(ctx, result):
    conn, tid, msp, out = ctx
    path, rid = generate_audit_report(conn, tid, msp, 'HQ firewall', result, out)
    with open(path, 'rb') as fh:
        assert fh.read(5) == b'%PDF-'
    with conn.cursor() as cur:
        cur.execute('SELECT report_type, delivery_status, file_path, tenant_id FROM '
                    'generated_reports WHERE id = %s', (rid,))
        assert cur.fetchone() == ('fw_audit', 'ready', path, tid)
    assert os.path.basename(path).endswith('.pdf') and '_fwaudit_' in path


def test_names_with_ampersands_print_correctly(ctx, result):
    conn, tid, msp, out = ctx
    path, _ = generate_audit_report(conn, tid, msp, 'HQ <FortiGate> & co', result, out)
    text = pdf_text(path)
    assert '&amp;' not in text
    assert 'Smith & Sons "Ltd"' in text and 'Test MSP & Co' in text
    assert 'HQ <FortiGate> & co' in text
    assert 'CONFIDENTIAL' in text and 'What was checked' in text and 'Remediation checklist' in text


def test_hostile_finding_text_is_escaped(result):
    evil = copy.deepcopy(result)
    evil['findings'][0]['title'] = XSS
    evil['findings'][0]['evidence'] = [XSS, '</style><b>x']
    evil['notes'] = [XSS]
    html = render_html(evil, tenant=XSS, target=XSS)
    assert XSS not in html and '&lt;script&gt;alert(1)&lt;/script&gt;' in html
    assert '</style><b>x' not in html


def test_report_is_bounded(result):
    big = copy.deepcopy(result)
    big['findings'] = big['findings'] * 10                      # 300 findings
    big['findings'][0]['evidence'] = [f'line {i}' for i in range(100)]
    big['findings'][1]['description'] = 'd' * 5000
    html = render_html(big)
    assert f"{len(big['findings']) - 200} further finding(s) were omitted" in html
    assert 'line 24' in html and 'line 25' not in html and '… and 75 more' in html
    assert 'd' * 701 not in html


def test_unassessed_domains_and_coverage_in_pdf_html(result):
    limited = dict(copy.deepcopy(result), score=90, band='Limited coverage',
                   domain_scores={'MGT': 80, 'RUL': None},
                   counts={'passed': 2, 'finding': 1, 'not_applicable': 0,
                           'could_not_determine': 43, 'skipped': 5})
    d = report_data.prepare(limited)
    assert d['coverage'] == {'assessed': 3, 'total': 51, 'pct': 6}
    rul = [x for x in d['domains'] if x['code'] == 'RUL'][0]
    assert rul['score'] is None and rul['band'] is None
    html = render_html(limited)
    assert '3 of 51 checks assessed' in html and 'Limited coverage' in html
    assert 'Not assessed' in html


def test_no_traffic_and_with_traffic_wording(result):
    assert 'No traffic logs were available' in render_html(result)
    with_logs = dict(copy.deepcopy(result), traffic={'available': True, 'window_days': 90,
                                                     'events': 12345})
    assert '12,345 events' in render_html(with_logs)


def test_commit_false_leaves_the_transaction_to_the_caller(ctx, result):
    conn, tid, msp, out = ctx
    _path, rid = generate_audit_report(conn, tid, msp, 'HQ', result, out, commit=False)
    conn.rollback()
    with conn.cursor() as cur:
        cur.execute('SELECT count(*) FROM generated_reports WHERE id = %s', (rid,))
        assert cur.fetchone()[0] == 0


def test_a_missing_msp_profile_fails_cleanly(ctx, result):
    conn, tid, _msp, out = ctx
    with pytest.raises(Exception):
        generate_audit_report(conn, tid, 999999, 'HQ', result, out)
    with conn.cursor() as cur:
        cur.execute("SELECT count(*) FROM generated_reports WHERE report_type = 'fw_audit'")
        assert cur.fetchone()[0] == 0


def test_a_late_db_failure_removes_the_written_pdf(ctx, result, monkeypatch):
    from reports import generator
    conn, tid, msp, out = ctx

    def boom(*a, **k):
        raise RuntimeError('insert failed')
    monkeypatch.setattr(generator, '_insert_generated_report', boom)
    with pytest.raises(RuntimeError):
        generate_audit_report(conn, tid, msp, 'HQ', result, out)
    assert os.listdir(out) == []
