import pytest

from reports.fwaudit.errors import ConfigError

from reports.fwaudit.parsers import fortitree as ft

TXT = '''#config-version=FGVM64-7.4.3-FW-build2573-240131:opmode=0:vdom=0:user=admin
config system global
    set admintimeout 30
    set hostname "FGT HQ"
end
config firewall policy
    edit 1
        set name "a b"
        set service "HTTP" "HTTPS"
        set comments "say \\"hi\\""
        set psksecret ENC abc
        set password ENC def
    next
    edit 2
        config sub
            set x 1
        end
        set y 2
    next
end
'''


def test_parses_settings_entries_and_quotes():
    r = ft.parse(TXT)
    t = r['tree']
    assert r['header'].startswith('config-version=FGVM64-7.4.3')
    assert t['system global']['admintimeout'] == ['30']
    assert t['system global']['hostname'] == ['FGT HQ']
    e1 = t['firewall policy']['1']
    assert e1['service'] == ['HTTP', 'HTTPS'] and e1['comments'] == ['say "hi"']
    assert list(t['firewall policy']) == ['1', '2']            # file order is rule order
    assert t['firewall policy']['2']['@sub'] == {'x': ['1']} and t['firewall policy']['2']['y'] == ['2']


def test_secrets_are_redacted_at_parse_time():
    e1 = ft.parse(TXT)['tree']['firewall policy']['1']
    assert e1['psksecret'] == ['<redacted>'] and e1['password'] == ['<redacted>']
    assert 'abc' not in repr(ft.parse(TXT)) and 'def' not in repr(ft.parse(TXT))


def test_unset_and_unbalanced_input_do_not_crash():
    r = ft.parse('config a\nset x 1\nunset x\nend\nend\nend\nnext\n')
    assert r['tree']['a'] == {}


def test_limits():
    with pytest.raises(ConfigError):
        ft.parse('x' * (ft.MAX_BYTES + 1))
    with pytest.raises(ConfigError):
        ft.parse('config a\n' * (ft.MAX_DEPTH + 1))
    with pytest.raises(ConfigError):
        ft.parse('\n' * (ft.MAX_LINES + 1))


def test_garbage_and_binary_input():
    assert ft.parse('\x00\x01 binary \xff garbage') == {'header': '', 'tree': {}}
    assert ft.parse('') == {'header': '', 'tree': {}}
    assert isinstance(ft.parse("set a 'unterminated")['tree'], dict)   # no crash on bad quoting


SECRET_NAMES = ('psksecret-remote', 'ppk-secret', 'passphrase', 'sae-password', 'key-string',
                'api-key', 'secondary-secret', 'tertiary-secret', 'secondary-key', 'authkey',
                'enckey', 'proxy-password', 'ddns-password', 'logon-password', 'sso-password',
                'client-secret', 'secret-key', 'private-key', 'privatekey', 'community',
                'auth-pwd', 'md5-key')


def test_secret_keys_are_redacted_by_pattern():
    body = ''.join(f' set {k} "s3cr3t-{i}"\n' for i, k in enumerate(SECRET_NAMES))
    text = 'config system x\n edit 1\n' + body + '  set keepalive 10\n  set name "n"\n next\nend\n'
    entry = ft.parse(text)['tree']['system x']['1']
    for k in SECRET_NAMES:
        assert entry[k] == ['<redacted>'], k
    assert 's3cr3t' not in repr(ft.parse(text))
    assert entry['keepalive'] == ['10'] and entry['name'] == ['n']        # harmless keys kept
