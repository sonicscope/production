import json
import re
from datetime import date

from reports.fwaudit import framework as fw
from reports.fwaudit.checks import lifecycle
from reports.tests.fwaudit_helpers import cfg

TODAY = date(2026, 11, 21)
TABLE = [
    {'vendor': 'fortigate', 're': re.compile(r'^7\.0\.'), 'label': 'FortiOS 7.0',
     'eos': date(2025, 9, 30), 'source': 'https://example.test/lifecycle', 'checked': '2026-11-01'},
    {'vendor': 'fortigate', 're': re.compile(r'^7\.4\.'), 'label': 'FortiOS 7.4',
     'eos': date(2028, 5, 1), 'source': 'https://example.test/lifecycle', 'checked': '2026-11-01'},
    {'vendor': 'fortigate', 're': re.compile(r'^7\.2\.'), 'label': 'FortiOS 7.2',
     'eos': date(2027, 3, 1), 'source': 'https://example.test/lifecycle', 'checked': '2026-11-01'},
]


def run(vendor, firmware, table=TABLE):
    c = cfg(vendor)
    if firmware is not None:
        c.set('system.firmware', firmware, 'header')
    meta, fn = fw.REGISTRY['FWA-RES-005']
    return fn(fw.Ctx(c, None, meta), table=table, today=TODAY)


def test_states():
    out = run('fortigate', '7.0.14')
    assert out.state == fw.FINDING and out.findings[0].severity == 2
    assert 'ended support' in out.findings[0].current and 'example.test' in out.findings[0].evidence[0]
    soon = run('fortigate', '7.2.8')       # ends 2027-03-01: 100 days away
    assert soon.state == fw.FINDING and soon.findings[0].severity == 4        # inside 180 days
    assert run('fortigate', '7.4.3').state == fw.PASSED


def test_unknown_firmware_or_table_is_never_a_verdict():
    assert run('fortigate', None).state == fw.UNDETERMINED
    assert run('fortigate', '9.9.9').state == fw.UNDETERMINED
    assert run('sonicwall', '7.0.1').state == fw.UNDETERMINED                 # other vendor's entry
    assert run('fortigate', '7.0.14', table=[]).state == fw.UNDETERMINED


def test_table_loading_skips_bad_entries(tmp_path):
    p = tmp_path / 't.json'
    p.write_text(json.dumps([
        {'vendor': 'fortigate', 'pattern': r'^7\.4\.', 'label': 'ok', 'end_of_support': '2027-05-01',
         'source': 'https://example.test', 'checked': '2026-11-01'},
        {'vendor': 'fortigate', 'pattern': '(', 'label': 'bad regex', 'end_of_support': '2027-05-01',
         'source': 's', 'checked': 'c'},
        {'vendor': 'x', 'pattern': 'a', 'label': 'bad date', 'end_of_support': 'soon',
         'source': 's', 'checked': 'c'}, {'vendor': 'missing fields'}, 'junk']))
    assert [e['label'] for e in lifecycle.load_table(str(p))] == ['ok']
    assert lifecycle.load_table(str(tmp_path / 'nope.json')) == []
    p.write_text('not json')
    assert lifecycle.load_table(str(p)) == []
    assert lifecycle.load_table() == lifecycle.load_table(lifecycle.TABLE_PATH)   # shipped file loads


def test_shipped_table_is_valid_and_sourced():
    """Every entry in the shipped lifecycle table must be sourced and dated (never guessed)."""
    with open(lifecycle.TABLE_PATH, encoding='utf-8') as fh:
        raw = json.load(fh)
    assert isinstance(raw, list)
    assert len(lifecycle.load_table()) == len(raw)                # no entry is silently skipped
    for e in raw:
        assert e['source'].startswith('https://'), e
        assert (date.today() - date.fromisoformat(e['checked'])).days < 400, f'stale entry: {e}'
        assert e['vendor'] in ('fortigate', 'sonicwall'), e


def test_sonicwall_6x_entry_matches_its_label():
    entry = [e for e in lifecycle.load_table() if e['vendor'] == 'sonicwall'
             and e['label'].startswith('SonicOS 6')][0]
    assert '6.5.4.15 and older' in entry['label']
    for fwv in ('6.5.4.15-116n', '6.5.4.4', '6.5.3.1', '6.2.9.1', '6.5.4.15'):
        assert entry['re'].search(fwv), fwv
    for fwv in ('6.5.4.16-1n', '6.5.4.150', '6.5.5.1', '7.0.1'):
        assert not entry['re'].search(fwv), fwv
