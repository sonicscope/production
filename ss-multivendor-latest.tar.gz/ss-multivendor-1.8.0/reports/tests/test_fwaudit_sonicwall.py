"""SonicWall (.exp) rules, zones, NAT and VPN, from a sanitised SonicOS 7 export."""
import base64
import os
import urllib.parse

import pytest

from reports.fwaudit import engine
from reports.fwaudit import framework as fw
from reports.fwaudit import traffic as tr
from reports.fwaudit.errors import ConfigError
from reports.fwaudit.model import ANY, Rule
from reports.fwaudit.parsers import sonicwall
from reports.tests.fwaudit_helpers import cfg, hits, row, rule, run1

FIXTURE = os.path.join(os.path.dirname(__file__), 'fixtures', 'fwaudit',
                       'sonicwall_gen7_sample.exp')


def _text():
    with open(FIXTURE) as fh:
        return fh.read()


@pytest.fixture(scope='module')
def sw():
    return sonicwall.normalize(_text())


def exp(**kv):
    raw = '&'.join(f'{k}={urllib.parse.quote(v)}' for k, v in kv.items())
    return base64.b64encode(raw.encode()).decode()


# ── decode ───────────────────────────────────────────────────────────────────
def test_decode_real_export_with_trailing_ampersands():
    text = _text()
    assert text.rstrip().endswith('&&')
    kv = sonicwall.decode(text)
    assert len(kv) == 854
    assert kv['shortProdName'] and kv['adminLoginTimeout'] == '999'


def test_decode_padding_written_as_ampersands():
    raw = 'adminLoginTimeout=5&shortProdName=TZ+370x'          # needs base64 padding
    enc = base64.b64encode(raw.encode()).decode()
    assert enc.endswith('=')
    for variant in (enc, enc.rstrip('=') + '&' * enc.count('='), enc + '&&',
                    enc.rstrip('='), enc[:20] + '\n' + enc[20:] + '&&\n'):
        assert sonicwall.decode(variant)['adminLoginTimeout'] == '5', variant
    assert sonicwall.decode('adminLoginTimeout=5')['adminLoginTimeout'] == '5'   # plain text
    with pytest.raises(ConfigError):
        sonicwall.decode('abcd&&')                          # decodes, but is not key=value


def _rule_cfg(**f):
    base = dict(policyName_1='r', policyAction_1='2', policyEnabled_1='1', policySrcZone_1='WAN',
                policyDstZone_1='LAN', policySrcNet_1='', policyDstNet_1='', policySrcSvc_1='',
                policyDstSvc_1='')
    base.update(f)
    return sonicwall.normalize(exp(shortProdName='NSA 2700', **base)).rules[0]


def test_service_in_the_source_service_field_is_unknown_not_any():
    """A real export stores 'ICMP' (and a Teams group) in policySrcSvc with policyDstSvc empty;
    that rule must not be read as 'any service' (it produced false critical findings)."""
    assert _rule_cfg(policySrcSvc_1='ICMP').service == ()
    assert _rule_cfg(policySrcSvc_1='teams_grp', policyDstSvc_1='').service == ()


def test_empty_service_is_any_and_destination_service_wins():
    assert _rule_cfg().service == (ANY,)                              # both empty: any
    assert _rule_cfg(policyDstSvc_1='HTTPS Management').service == ('HTTPS Management',)
    assert _rule_cfg(policySrcSvc_1='ICMP', policyDstSvc_1='Ping').service == ('Ping',)


def _admin_cfg(**kv):
    return sonicwall.normalize(exp(shortProdName='NSA 2700', **kv))


def test_login_lockout_password_length_and_management_tls():
    c = _admin_cfg(loginFailLockoutEnable='off', loginFailAcctLockoutEnable='off',
                   minPasswordLength='8', enableTLS10='off', enableTLS11='off', enableTLS12='on',
                   enableTLS13='on')
    assert c.fact('admin.lockout').value is False and c.fact('admin.lockout').known
    assert c.fact('admin.pw_min_len').value == 8
    assert c.fact('admin.tls_min').value == '1.2'
    assert _admin_cfg(loginFailLockoutEnable='on').fact('admin.lockout').value is True
    assert _admin_cfg(loginFailAcctLockoutEnable='on', loginFailLockoutEnable='off').fact('admin.lockout').value is True
    assert _admin_cfg(enableTLS10='on', enableTLS11='off', enableTLS12='on').fact('admin.tls_min').value == '1.0'
    # nothing recorded when the keys are missing or carry an unrecognised value
    c0 = _admin_cfg()
    assert not any(c0.fact(k).known for k in ('admin.lockout', 'admin.pw_min_len', 'admin.tls_min'))
    assert not _admin_cfg(minPasswordLength='eight').fact('admin.pw_min_len').known
    assert not _admin_cfg(enableTLS12='maybe', enableTLS10='on').fact('admin.tls_min').known


def test_snmp_v1v2_and_default_community_without_storing_the_secret():
    c = _admin_cfg(snmp_Enable='on', Snmp3_Mand_Required='off', snmp_GetCommunity='s3cr3t-community')
    assert c.fact('admin.snmp_v1v2').value is True and c.fact('admin.snmp_default_community').value is False
    assert 's3cr3t' not in repr(c.facts) and 's3cr3t' not in repr(c.notes)
    d = _admin_cfg(snmp_Enable='on', Snmp3_Mand_Required='off', snmp_GetCommunity='Public')
    assert d.fact('admin.snmp_default_community').value is True
    assert 'public' not in repr(d.facts).lower().replace('snmp_getcommunity', '')
    assert _admin_cfg(snmp_Enable='off', snmp_GetCommunity='public').fact('admin.snmp_v1v2').value is False
    assert _admin_cfg(snmp_Enable='on', Snmp3_Mand_Required='on', snmp_GetCommunity='public').fact('admin.snmp_v1v2').value is False
    assert _admin_cfg(snmp_Enable='on', Snmp3_Mand_Required='off', snmp_GetCommunity='').fact('admin.snmp_v1v2').value is False
    assert not _admin_cfg(snmp_Enable='on').fact('admin.snmp_v1v2').known       # no community key: not read


def test_factory_zone_rules_are_flagged_builtin():
    base = dict(policyAction_1='2', policyEnabled_1='1', policySrcZone_1='LAN', policyDstZone_1='WAN')
    assert _admin_cfg(policyName_1='Default Access Rule', policyDefaultRule_1='2', **base).rules[0].builtin
    assert not _admin_cfg(policyName_1='Mine', policyDefaultRule_1='1', **base).rules[0].builtin
    assert not _admin_cfg(policyName_1='Default Access Rule', **base).rules[0].builtin   # key absent


def test_rule_hit_counters_creation_time_and_generated_rules():
    base = dict(policyAction_1='2', policyEnabled_1='1', policySrcZone_1='LAN', policyDstZone_1='WAN')
    c = _admin_cfg(policyName_1='Mine', policyHitCount_1='167887', policyTimeLastHit_1='1795000000',
                   policyTimeCreated_1='1700000000', policyComment_1='', **base)
    r = c.rules[0]
    assert (r.hits, r.last_hit, r.created, r.generated) == (167887, 1795000000, 1700000000, False)
    assert c.fact('system.export_epoch').value == 1795000000          # newest hit = export time (lower bound)
    never = _admin_cfg(policyName_1='Mine', policyHitCount_1='0', policyTimeLastHit_1='0', **base).rules[0]
    assert (never.hits, never.last_hit) == (0, 0) and never.created is None
    assert not _admin_cfg(policyName_1='Mine', policyHitCount_1='0', policyTimeLastHit_1='0', **base).fact('system.export_epoch').known
    absent = _admin_cfg(policyName_1='Mine', **base).rules[0]
    assert (absent.hits, absent.last_hit) == (None, None)             # no counters in the export
    bad = _admin_cfg(policyName_1='Mine', policyHitCount_1='lots', policyTimeLastHit_1='-5', **base).rules[0]
    assert (bad.hits, bad.last_hit) == (None, None)
    assert _admin_cfg(policyName_1='VPN', policyComment_1='Auto added for inbound VPN - WAN Group', **base).rules[0].generated


# ── zones and interfaces ─────────────────────────────────────────────────────
def test_interfaces_take_their_zone_role_and_management(sw):
    by = {i.name: i for i in sw.interfaces}
    assert len(sw.interfaces) == 10
    assert (by['X0'].zone, by['X0'].role) == ('LAN', 'lan')
    assert (by['X1'].zone, by['X1'].role, by['X1'].mgmt) == ('WAN', 'wan', ('ping',))
    assert (by['X6'].zone, by['X6'].role) == ('WLAN', 'guest')
    assert (by['X0:V99'].zone, by['X0:V99'].role) == ('WifiDemo', 'guest')    # custom WLAN-type zone
    assert by['X0'].mgmt == ('https', 'ssh', 'snmp', 'ping')
    assert by['X0:V101'].mgmt == ()
    assert all(i.trusted_hosts is None for i in sw.interfaces)
    assert sw.has('interfaces')


def test_zone_roles():
    assert sonicwall.ZONE_ROLES == {'0': 'wan', '1': 'lan', '2': 'dmz', '4': 'guest', '9': 'mgmt'}


# ── rules ────────────────────────────────────────────────────────────────────
def test_rules_in_export_order(sw):
    assert sw.has('rules') and len(sw.rules) == 15
    assert [r.idx for r in sw.rules] == list(range(15))
    assert sw.rules_ordered is False                     # priority + specificity, not list order
    names = [r.name for r in sw.rules]
    assert names.count('Default Access Rule') == 8
    assert names[3:5] == ['Teams', 'Block Test Hosts']
    assert names[11] == 'Custom Access Rule'             # trailing newline in the export stripped
    assert all(r.rid == '' for r in sw.rules)            # no stable id is used


def test_lan_to_wan_default_rule_is_any_any_allow(sw):
    r = sw.rules[10]
    assert (r.action, r.enabled, r.log) == ('allow', True, 'all')
    assert (r.src_zone, r.dst_zone) == (('LAN',), ('WAN',))
    assert r.src_addr == r.dst_addr == r.service == (ANY,)
    assert not r.restricted
    assert r.label == 'Default Access Rule (LAN -> WAN)'


def test_disabled_deny_and_restricted_rules(sw):
    assert sw.rules[2].enabled is False and sw.rules[11].enabled is False
    deny = sw.rules[4]
    assert deny.action == 'deny' and deny.name == 'Block Test Hosts'
    assert deny.src_addr == ('TestHosts',) and deny.dst_addr == ('TestHosts_Block_grp',)
    assert sw.rules[12].action == 'deny'                 # WAN -> LAN default deny
    teams = sw.rules[3]
    assert teams.action == 'allow' and teams.service == ()   # service named only in the source field: unknown, not any
    assert teams.restricted is True                      # a source-port service condition
    custom = sw.rules[6]
    assert custom.label == 'Custom Access Rule (WAN -> LAN)'
    assert custom.dst_addr == ('WAN Primary IP',) and custom.service == ('AppServer2 Services',)
    assert custom.comment == 'Internal app A'
    assert sw.rules[9].label == 'Block Sites'            # unique name: no zone suffix


def test_addresses_resolve_only_what_the_export_states(sw):
    assert sw.addresses['WAN Primary IP'] == ['198.51.100.2/32']
    assert sw.addresses['TestHosts'] == ['198.51.100.5/32']
    assert sw.addresses['All LAN Management IP'] == ['198.51.100.1/32']     # group of one host
    assert 'X2 IP' not in sw.addresses                   # host 0.0.0.0: interface has no address
    assert 'All X2 Management IP' not in sw.addresses    # its only member is unresolvable
    assert 'LAN Interface IP' not in sw.addresses        # one member unresolvable
    assert 'TestHosts_Block_grp' not in sw.addresses     # members not in the export
    assert sw.nets(('LAN Interface IP',)) is None


def test_address_types_host_range_network_group_fqdn():
    c = sonicwall.normalize(exp(
        addrObjId_0='h', addrObjType_0='1', addrObjIp1_0='192.0.2.10', addrObjIp2_0='0.0.0.0',
        addrObjId_1='r', addrObjType_1='2', addrObjIp1_1='192.0.2.0', addrObjIp2_1='192.0.2.3',
        addrObjId_2='n', addrObjType_2='4', addrObjIp1_2='10.1.0.0', addrObjIp2_2='255.255.0.0',
        addrObjId_3='g', addrObjType_3='8', addrObjIp1_3='0.0.0.0', addrObjIp2_3='0.0.0.0',
        addrObjId_4='f', addrObjType_4='8192', addrObjIp1_4='0.0.0.0', addrObjIp2_4='0.0.0.0',
        addrObjId_5='bad', addrObjType_5='4', addrObjIp1_5='nonsense', addrObjIp2_5='x',
        addrObjId_6='odd', addrObjType_6='77', addrObjIp1_6='192.0.2.1', addrObjIp2_6='0.0.0.0',
        addro_atomToGrp_0='h', addro_grpToGrp_0='g', addro_atomToGrp_1='n', addro_grpToGrp_1='g'))
    assert c.addresses['h'] == ['192.0.2.10/32']
    assert c.addresses['r'] == ['192.0.2.0/30']
    assert c.addresses['n'] == ['10.1.0.0/16']
    assert sorted(c.addresses['g']) == ['10.1.0.0/16', '192.0.2.10/32']
    for unknown in ('f', 'bad', 'odd'):
        assert unknown not in c.addresses


def test_services_from_atoms_and_groups(sw):
    assert sw.services['HTTPS Management'] == ((4433, 4433),)
    assert sw.services['teams_svc1'] == ((50000, 50019),)
    assert sw.services['webcert Services'] == ((80, 80), (443, 443))       # group: ports of members
    assert sw.services['teams_grp'] == ((50000, 50019), (50020, 50039), (50040, 50059),
                                        (50070, 50089))
    assert sw.services['AppServer1 Services'] is None    # group without members in the export


def test_service_protocols():
    c = sonicwall.normalize(exp(
        svcObjId_0='icmp', svcObjType_0='1', svcObjIpType_0='1', svcObjPort1_0='8', svcObjPort2_0='0',
        svcObjId_1='weird', svcObjType_1='1', svcObjIpType_1='6', svcObjPort1_1='x', svcObjPort2_1='1',
        svcObjId_2='gre', svcObjType_2='1', svcObjIpType_2='47', svcObjPort1_2='0', svcObjPort2_2='0',
        svcObjId_3='back', svcObjType_3='1', svcObjIpType_3='17', svcObjPort1_3='90', svcObjPort2_3='80'))
    assert c.services['icmp'] == ()
    assert c.services['weird'] is None and c.services['gre'] is None and c.services['back'] is None


# ── NAT and VPN ──────────────────────────────────────────────────────────────
def test_nat_inbound_forwards(sw):
    assert sw.has('nat')
    assert [(n.name, n.internal) for n in sw.nat] == [('Custom NAT Policy', 'Proxy Private'),
                                                        ('Custom NAT Policy', 'Lab Private')]
    assert all(n.ports is None for n in sw.nat)          # 'Proxy Services' is not in the export
    assert all(n.source_restricted is None and n.ips is None for n in sw.nat)


def test_nat_ports():
    c = sonicwall.normalize(exp(
        natPolicyName_0='any', natPolicyEnabled_0='1', natPolicyOrigDst_0='pub', natPolicyTransDst_0='srv',
        natPolicyOrigSvc_0='',
        natPolicyName_1='rdp', natPolicyEnabled_1='1', natPolicyOrigDst_1='pub', natPolicyTransDst_1='srv',
        natPolicyOrigSvc_1='rdp-svc',
        natPolicyName_2='off', natPolicyEnabled_2='0', natPolicyOrigDst_2='pub', natPolicyTransDst_2='srv',
        svcObjId_0='rdp-svc', svcObjType_0='1', svcObjIpType_0='6', svcObjPort1_0='3389',
        svcObjPort2_0='3389'))
    assert [(n.name, n.ports) for n in c.nat] == [('any', ((1, 65535),)), ('rdp', ((3389, 3389),))]


def test_vpn_only_enabled_policies_and_no_crypto_guessing(sw):
    assert sw.has('vpn') and sw.vpn == []                # both GroupVPN policies are disabled
    c = sonicwall.normalize(exp(ipsecName_0='site', ipsecP1Exch_0='2', ipsecVersion_0='0',
                                ipsecSaDisabled_0='off', ipsecAlgo_0='9', ipsecP1DHGrp_0='1',
                                ipsecName_1='other', ipsecP1Exch_1='7', ipsecVersion_1='5'))
    t, u = c.vpn
    assert (t.name, t.aggressive, t.ike_version) == ('site', True, 1)
    assert t.enc == () and t.hashes == () and t.dh == () and t.psk_weak is None
    assert (u.aggressive, u.ike_version) == (None, None)         # unconfirmed codes stay unknown


def test_sections_and_notes(sw):
    assert sw.sections == {'rules', 'interfaces', 'nat', 'vpn'}
    assert not any('not read yet' in n for n in sw.notes)
    assert any('priority and specificity' in n for n in sw.notes)


def test_no_rules_section_means_rule_checks_undetermined():
    c = sonicwall.normalize(exp(shortProdName='TZ', adminLoginTimeout='5'))
    assert not c.has('rules') and not c.has('nat') and not c.has('vpn')
    assert run1('FWA-RUL-001', c)[0] == fw.UNDETERMINED


def test_hostile_values_do_not_crash_or_pass():
    c = sonicwall.normalize(exp(
        policyName_x='bad-id', policyName_0='', policyAction_0='2', policyEnabled_0='1',
        policySrcZone_0='', policyDstZone_0='WAN', policyDstNet_0='missing-object',
        policyName_1='odd', policyAction_1='9', policyEnabled_1='1'))
    assert [r.name for r in c.rules] == ['', 'odd']
    assert c.rules[0].src_zone == () and c.rules[0].label == 'rule 1'
    assert c.nets(c.rules[0].dst_addr) is None
    assert not c.has('rules')                            # an unknown action: never a false pass
    assert any('action' in n for n in c.notes)
    res = engine.run('sonicwall', exp(policyName_0='a', policyAction_0='2',
                                      policyDstNet_0='missing', zoneObjId_0='',
                                      zoneObjZoneType_0='x', iface_name_0='',
                                      interface_Zone_0='nowhere'))
    assert not any('internal error' in (e.get('reason') or '') for e in res['ledger'])

def test_no_secret_is_read():
    res = engine.run('sonicwall', _text())
    import json
    blob = json.dumps(res['snapshot']).lower()
    for word in ('psk', 'secret', 'password', 'sharedkey'):
        assert word not in blob


# ── check behaviour this vendor needs ────────────────────────────────────────
def test_shadow_checks_do_not_run_without_list_order():
    c = cfg('sonicwall', sections=('rules',))
    c.rules = [rule(0, src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,), src_zone=(ANY,),
                    dst_zone=(ANY,)),
               rule(1, src_addr=(ANY,), dst_addr=(ANY,), service=(ANY,), src_zone=(ANY,),
                    dst_zone=(ANY,))]
    assert run1('FWA-RUL-004', c)[0] == fw.FINDING
    c.rules_ordered = False
    for cid in ('FWA-RUL-003', 'FWA-RUL-004'):
        state = fw.run_checks(c, None, registry={cid: fw.REGISTRY[cid]})['ledger'][0]
        assert state['state'] == fw.UNDETERMINED and 'list order' in state['reason']


def test_duplicate_rule_names_are_never_judged_unused():
    c = cfg('sonicwall', sections=('rules',))
    c.rules = [rule(0, rid='', name='Default Access Rule', log='all'),
               rule(1, rid='', name='default access rule ', log='all'),
               rule(2, rid='', name='dead', log='all')]
    state, fs = run1('FWA-TRF-001', c, hits([row('used-elsewhere')]))
    assert state == fw.FINDING and len(fs[0].evidence) == 1 and 'dead' in fs[0].evidence[0]
    assert '2 other rule(s) could not be assessed' in fs[0].description
    counts = tr.name_counts(c.rules)
    assert tr.eligible_for_zero_hit('sonicwall', c.rules[0], counts) is False
    assert tr.eligible_for_zero_hit('sonicwall', c.rules[2], counts) is True
    f = cfg('fortigate', sections=('rules',))
    f.rules = [rule(0, name='same', log='all'), rule(1, name='same', log='all')]
    assert tr.eligible_for_zero_hit('fortigate', f.rules[0], tr.name_counts(f.rules)) is True


def test_rule_display_label():
    assert Rule(idx=0, name='x', display='x (LAN -> WAN)').label == 'x (LAN -> WAN)'
    assert Rule(idx=0, name='x').label == 'x'
    assert Rule(idx=4).label == 'rule 5'


# ── end to end ───────────────────────────────────────────────────────────────
def test_engine_run_on_the_real_export():
    res = engine.run('sonicwall', _text())
    state = {e['check_id']: e for e in res['ledger']}
    by_id = {f['check_id']: f for f in res['findings']}
    assert state['FWA-MGT-001']['state'] == fw.FINDING                  # 999 minute timeout
    # the only any/any allow rules here are SonicOS factory zone rules: reported separately, lower
    assert state['FWA-RUL-001']['state'] == fw.PASSED
    assert state['FWA-RUL-010']['state'] == fw.FINDING
    ev = ' | '.join(by_id['FWA-RUL-010']['evidence'])
    assert 'Default Access Rule (LAN -> WAN)' in ev and 'Default Access Rule (WLAN -> LAN)' in ev
    assert 'Teams' not in ev                              # source-port restricted
    seg = ' | '.join(by_id['FWA-SEG-002']['evidence'])
    assert 'Default Access Rule (WLAN -> LAN)' in seg
    for cid in ('FWA-RUL-003', 'FWA-RUL-004'):
        assert state[cid]['state'] == fw.UNDETERMINED
    assert state['FWA-RUL-005']['state'] == fw.PASSED     # every allow rule logs
    assert state['FWA-VPN-001']['state'] == fw.NA
    assert state['FWA-EXP-001']['state'] == fw.UNDETERMINED          # forward ports unreadable
    assert res['domain_scores']['RUL'] is not None
    assert not any('not read yet' in n for n in res['notes'])


def test_more_objects_than_can_be_read_is_not_a_partial_pass():
    big = sonicwall.MAX_INDEXED
    c = sonicwall.normalize(exp(**{'policyName_0': 'a', 'policyAction_0': '2',
                                   f'policyName_{big}': 'late',
                                   'natPolicyName_0': 'n', f'natPolicyName_{big}': 'm',
                                   'addrObjId_0': 'h', 'addrObjType_0': '1',
                                   'addrObjIp1_0': '192.0.2.1',
                                   'addro_atomToGrp_0': 'h', 'addro_grpToGrp_0': 'g',
                                   f'addro_atomToGrp_{big}': 'x', f'addro_grpToGrp_{big}': 'g'}))
    assert not c.has('rules') and not c.has('nat')
    assert 'g' not in c.addresses and c.addresses['h'] == ['192.0.2.1/32']
