import pytest

from reports.fwaudit import framework as fw
from reports.fwaudit.framework import Severity
from reports.fwaudit.model import FACT_KEYS, NormalizedConfig


def _cfg(vendor='fortigate'):
    return NormalizedConfig(vendor=vendor)



def test_bad_or_duplicate_ids_rejected():
    fw.check('FWA-RES-950', 't', Severity.LOW)(lambda c: fw.passed())      # a throw-away check
    reg_before = dict(fw.REGISTRY)
    with pytest.raises(ValueError):
        fw.check('FWA-RES-950', 't', Severity.LOW)(lambda c: fw.passed())
    with pytest.raises(ValueError):
        fw.check('XXX-MGT-999', 't', Severity.LOW)(lambda c: fw.passed())
    with pytest.raises(ValueError):
        fw.check('FWA-ZZZ-001', 't', Severity.LOW)(lambda c: fw.passed())
    assert fw.REGISTRY == reg_before
    del fw.REGISTRY['FWA-RES-950']





def test_vendor_scoping_marks_not_applicable():
    reg = {}
    meta = fw.CheckMeta('FWA-VPN-900', 'x', Severity.LOW, vendors=frozenset({'sonicwall'}))
    reg['FWA-VPN-900'] = (meta, lambda c: fw.passed())
    res = fw.run_checks(_cfg('fortigate'), registry=reg)
    assert res['ledger'][0]['state'] == fw.NA


def test_a_crashing_check_cannot_sink_the_audit():
    meta = fw.CheckMeta('FWA-RUL-900', 'x', Severity.HIGH)

    def boom(_ctx):
        raise RuntimeError('secret internal detail')
    res = fw.run_checks(_cfg(), registry={'FWA-RUL-900': (meta, boom)})
    entry = res['ledger'][0]
    assert entry['state'] == fw.UNDETERMINED and 'secret' not in entry['reason']


def test_finding_outcome_without_findings_is_rejected():
    meta = fw.CheckMeta('FWA-RUL-901', 'x', Severity.HIGH)
    res = fw.run_checks(_cfg(), registry={'FWA-RUL-901': (meta, lambda c: fw.Outcome(fw.FINDING))})
    assert res['ledger'][0]['state'] == fw.UNDETERMINED


def test_score_and_bands():
    f = lambda sev, dom='MGT': fw.Finding('FWA-MGT-1', dom, 't', int(sev), '', [], '', '', '', {})
    assert fw.score([]) == 100
    assert fw.score([f(Severity.CRITICAL)]) == 80
    assert fw.score([f(Severity.HIGH), f(Severity.MEDIUM), f(Severity.LOW), f(Severity.INFO)]) == 84
    assert fw.score([f(Severity.CRITICAL)] * 6) == 26             # diminishing returns, never a flat 0
    # the real NSa2700 mix (3 critical, 4 high, 2 medium, 3 low) used to floor at 0
    mix = ([f(Severity.CRITICAL)] * 3 + [f(Severity.HIGH)] * 4 + [f(Severity.MEDIUM)] * 2
           + [f(Severity.LOW)] * 3)
    assert fw.score(mix) == 29 and fw.band(fw.score(mix)) == 'At risk'
    scores = [fw.score([f(Severity.CRITICAL)] * n) for n in range(0, 12)]
    assert scores == sorted(scores, reverse=True) and len(set(scores)) == len(scores)   # strictly worse with each one
    assert all(s > 0 for s in scores)
    assert fw.score([f(Severity.CRITICAL, 'RUL')], domain='MGT') == 100
    assert [fw.band(v) for v in (95, 80, 60, 10)] == [
        'Excellent', 'Good', 'Needs attention', 'At risk']


def test_unknown_fact_keys_are_rejected():
    cfg = _cfg()
    with pytest.raises(KeyError):
        cfg.set('admin.nope', 1)
    with pytest.raises(KeyError):
        cfg.fact('admin.nope')
    assert 'admin.mfa' in FACT_KEYS and not cfg.fact('admin.mfa').known


def _meta(cid):
    return fw.CheckMeta(cid, 'x', Severity.HIGH)


def test_domain_scores_and_band_follow_coverage():
    reg = {'FWA-MGT-901': (_meta('FWA-MGT-901'), lambda c: fw.passed()),
           'FWA-MGT-902': (_meta('FWA-MGT-902'), lambda c: fw.passed()),
           'FWA-RUL-902': (_meta('FWA-RUL-902'), lambda c: fw.undetermined('n/a')),
           'FWA-VPN-902': (_meta('FWA-VPN-902'), lambda c: fw.not_applicable('none'))}
    res = fw.run_checks(_cfg(), registry=reg)
    assert res['domain_scores']['MGT'] == 100
    assert res['domain_scores']['RUL'] is None and res['domain_scores']['VPN'] is None
    assert res['coverage'] == {'assessed': 2, 'total': 3, 'pct': 67}
    assert res['band'] == 'Excellent'                     # 2 of 3 applicable checks assessed
    reg['FWA-RUL-903'] = (_meta('FWA-RUL-903'), lambda c: fw.undetermined('n/a'))
    res = fw.run_checks(_cfg(), registry=reg)
    assert res['coverage']['pct'] == 50 and res['band'] == 'Excellent'
    reg['FWA-RUL-904'] = (_meta('FWA-RUL-904'), lambda c: fw.undetermined('n/a'))
    res = fw.run_checks(_cfg(), registry=reg)
    assert res['coverage']['pct'] == 40 and res['band'] == 'Limited coverage'
    assert res['score'] == 100                            # the number stays; the band is withheld
    assert fw.coverage(res['counts']) == res['coverage']
